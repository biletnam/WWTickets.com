<? $root = $_SERVER['DOCUMENT_ROOT'];
$private = str_replace('public','private',$root);
include_once("$private/config.php");

$permissions = 4;

// error_reporting(E_ALL);
// ini_set('display_errors', 1);

// Verify login
include_once("$root/lc.php");
	
// update database with new info
	$date_mod = date("Y-m-d H:i:s",strtotime("-1 hour"));


// $city_request = ("select city_name,city_zip FROM cities WHERE city_name = '$custCity'");
// $city_result = mysql_query ($city_request,$db) or die ("Query failed: $city_request");

// while ($city_row = mysql_fetch_array($city_result)) { 
	
// 	$firstcustZip = $city_row['city_zip'];	
// }


// $zip_request = ("select city_name,city_zip FROM cities WHERE city_zip = '$custZip'");
// $zip_result = mysql_query ($zip_request,$db) or die ("Query failed: $zip_request");

// while ($zip_row = mysql_fetch_array($zip_result)) { 
	
// 	$custCity = $zip_row['city_name'];
// }

// if ($custZip != $firstcustZip) {$firstcustZip = $custZip; }


	if ($type == 'new') {

		$sql_query = "INSERT INTO customerInfo (custFName, custLName, custComp, custBillAdd, custSecAdd, custCity, custState, custZip, custPhone, custFax, custMobile, custWork, custEmail, custEmail2, custPrimaryF, custPrimPhone, custRank, custNotes,storeID,referralType,dateCreated) ";
		$sql_query .= "VALUES ('$custFName', '$custLName', '$custComp', '$custBillAdd', '$custSecAdd', '$custCity', '$custState', '$custZip', '$custPhone', '$custFax', '$custMobile', '$custWork', '$custEmail', '$custEmail2', '$custPrimaryF', '$custPrimPhone', '$custRank', '$custNotes','$storeID','$referralType','$date_mod');";

	}

	elseif ($type == 'edit'){

	$sql_query = "UPDATE customerInfo SET custFName = '$custFName', custLName = '$custLName', custComp = '$custComp', custBillAdd = '$custBillAdd', custSecAdd = '$custSecAdd', custCity = '$custCity', custState = '$custState', custZip = '$custZip', custPhone = '$custPhone', custFax = '$custFax', custMobile = '$custMobile', custWork = '$custWork', custEmail = '$custEmail', custEmail2 = '$custEmail2', custPrimaryF = '$custPrimaryF', custPrimPhone = '$custPrimPhone', custRank = '$custRank', custNotes = '$custNotes',storeID = '$storeID',referralType = '$referralType' WHERE custID = '$custID'";

	}

	$result = mysql_query($sql_query,$db);
	if ($type == 'new') {$custID = mysql_insert_id(); }
	$result = mysql_query($sql_query,$secdb);


header("Location: /customers/cust_view.php?ID=$custID"); 


?>
