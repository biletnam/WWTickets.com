                                                        <tr>
                                                            <th>&nbsp;</th>
                                                            <th>Assigned</th>
                                                            <th>Created By</th>
                                                            <th>Date</th>
                                                            <th>Note</th>
                                                            <th>Status</th>
                                                            <th>&nbsp;</th>
                                                        </tr>