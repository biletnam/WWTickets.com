<?php
	
	// DB Connection Configuration
	// define('DB_HOST', 'localhost'); 
	// define('DB_USERNAME', 'root'); 
	// define('DB_PASSWORD', ''); 
	// define('DATABASE', 'calendar'); 

	define('DB_HOST', 'sql5c0c.megasqlservers.com'); 
 	define('DB_USERNAME', 'windowworl806950'); 
 	define('DB_PASSWORD', 'W1n0rd3rs*'); 
 	define('DATABASE', 'server_windowworldtickets_com'); 

 		
	define('TABLE', 'calendar');
	define('USERS_TABLE', 'users');
	
	// Default Categories
	$categories = array("General","Party","Work", "Letters & Arts");
	$jobProducts = array("Scheduled to Install","Scheduled for Estimate");
	
?>