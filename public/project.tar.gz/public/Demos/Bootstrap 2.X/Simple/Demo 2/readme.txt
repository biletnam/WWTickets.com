This demo uses all the files from the Demo 1 except: 

index.php - just added the form for filter the respective jquery option and the loader
add_event.php - just added the category field to the form and the loader
connection.php - added categories to it
loader.php - added necessary logic

Use the 'connection.php' found at 'includes' to configure your database and categories