This is the original work created based on bootstrap 2.x Version.

The Admin Panel Folder you will find demos that have a protected area.

Demo 1 -> All the calendar is protected with a username (testuser / demouser) and password (12345), the                  created events are acessible to every all users but in protected mode.
Demo 2 -> The initial area is a calendar that only can be viewed its events, all edit modes are only available           to those that have an username and password. 
Demo 3 -> The calendar is protected and each user have access to the created event. Each event is private to             its creator and only him can manage his events.

On Simple Folder you will find demos that shows the features of the calendar. There are alot of combinations and you can try yourself.

Demo 1 -> Simple and basic calendar.
Demo 2 -> Users can filter the events.
Demo 3 -> Users can filter the events and search events.