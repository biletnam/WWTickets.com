<?php
	
	// DB Connection Configuration
	define('DB_HOST', 'sql5c0c.megasqlservers.com'); 
 	define('DB_USERNAME', 'windowworl806950'); 
 	define('DB_PASSWORD', 'W1n0rd3rs*'); 
 	define('DATABASE', 'server_windowworldtickets_com'); 
	define('TABLE', 'calendar');

?>