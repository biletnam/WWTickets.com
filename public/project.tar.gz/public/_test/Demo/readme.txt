Admin Panel
-----------
Contains demos in protected mode, this was made if you want to use the calendar as it is for your own purposes.

Demo 1 -> Use as you wish. Use this for personal calendar events.
          If you want to add more users all of them will be administrators (1,2,3+) and the events will be
          acessible to all of them, and all of them will manage the events.

Demo 2 -> Use as you wish. Do not use it for personal calendar events.
          This demo provides the events to the public, all events created are public for everyone to see, the added users
          will manage those public events. 

Demo 3 -> Use as you wish. Use this for personal calendar events.
          This demo is ideal for creating communities, each user has its own calendar, each event created are particular           to that created user and only he have the rights to manage their own event.

This demo if you have manually installed comes with two demo users, that is advised to remove. If you use the one click
installer you will be able to create a user.


Simple
------
Contains demo in its pure mode, its ideal for integrating in other applications, testing, and for educational purposes.

I don't advise you to use this for your own personal calendar system because everyone have access to it, if google
crawles this demo it will be on google.