                                        <tr>
                                            <th>Name</th>
                                            <th>Street</th>
                                            <th>City</th>
                                            <th>Telephone</th>
                                            <th>Email Address</th>
                                            <th>Store</th>
                                        </tr>