<?php
	
	// DB Connection Configuration
	define('DB_HOST', 'localhost'); 
 	define('DB_USERNAME', 'root'); 
 	define('DB_PASSWORD', ''); 
 	define('DATABASE', 'calendar'); 
	define('TABLE', 'calendar');
	
	// Default Calendar Categories
	$categories = array('Work', 'General', 'Parties');
	
?>