<?php
	
	// Loader - class and connection
	include('loader.php');
	
	echo $calendar->json_transform();
		
?>