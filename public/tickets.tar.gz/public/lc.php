<?  
//include_once($_SERVER['DOCUMENT_ROOT']."/_shared/lc.php"); 

	#######################################################
	## Redirect to WWW
	#######################################################
	$request = $_SERVER['REQUEST_URI'];
	$server = $_SERVER['HTTP_HOST'];
	
	
	#######################################################
	## Site Variables
	#######################################################
	$tz_diff					= '-1 hour'; // difference between local TZ and host TZ
	$datetime					= date("Y-m-d H:i:s",strtotime($tz_diff));
	$ip_whitelist				= array('98.179.23.180','69.92.89.30','65.116.108.88','67.135.145.252');
	
	function is_admin() {
		global $ip_whitelist;
		if(in_array($_SERVER['REMOTE_ADDR'],$ip_whitelist)) return true;
		else return false;
	}


	#######################################################
	## MySQL Functions
	#######################################################
	// Connect to the databasie
$db = mysql_connect("$dbserver","$dbuser","$dbpass");
	mysql_select_db("$dbname",$db);


	// Query function
	function pwr_query($query,$database=false,$error_reporting=true) {
		global $db;
		if($database === false) $database = $db;
		
		if($error_reporting) $result = mysql_query ($query,$database) or die (query_failed($query,mysql_error()));
		else $result = mysql_query ($query,$database);
		
		$total = mysql_num_rows($result);
		$last_id = mysql_insert_id();
		$error_no = mysql_errno();
		## MySQL ERRORS
		## 1062 - duplicate entry
		
		return array($result,$total,$last_id,$error_no);
	}
	// MySQL query failed function. Prints query and error
	function query_failed($query,$error) {
		if($_SERVER['REMOTE_ADDR'] == '98.168.224.123') {
			echo "<p><b>Error:</b> $error<br /><b>Query:</b> $query</p>";
		}
		else echo "There was a problem connecting to the database. Please <a href=\"mailto:".$contact['email']."\">let us know</a> if you continue to experience problems.";
	}
	

	
	## Website Error List
	############################################
	$errors = array(
		'04' => '<strong>Cookies required</strong> &ndash; It appears that cookies are not enabled on your browser. <br />Please adjust this in your security preferences before continuing.',
		'10' => "You didn't complete the entire form. Please fill in all of the required fields below.",
		'11' => "The date or time you entered appears to be invalid. Please try again.",
		'20' => "A user has already been setup with that e-mail address. Please login using the box to the right or use a different e-mail address.",
		'21' => "A user has already been setup with that e-mail address. Please choose a different e-mail address. <br />If you've forgotten your password, please use our <a href=\"/forgot/\">Forgotten Password Tool</a>.",
		'22' => "That username does not exist. Please feel free to <a href=\"/signup/\">create an account</a>.",
		'23' => "Incorrect login information.",
		'24' => "A business listing with that name already exists. If you've forgotten your password, please use our <a href=\"/forgot/\">Forgotten Password Tool</a>.<br />If you need further assistance in taking ownership of this listing, please e-mail us at <span class=\"cloak\">".$contact['email']."</span>.",
		'25' => "That listing does not exist.",
		'30' => "The password you entered was incorrect. Please try again.",
		'31' => "You must enter the same password twice. Your passwords did not match.",
		'32' => "You must choose a new password in order to change your password.",
		'90' => "The form you submitted has been detected as spam. <br /> You wrote in the box labeled \"DO NOT WRITE IN THIS BOX!\"."
	);


session_start();  // Start Session
header("Cache-control: private"); //IE 6 Fix 

// Get the user's input from the form 
   if ($_POST['username']) $username = $_POST['username']; 
   if ($_POST['password']) $password = $_POST['password'];

// Register session key with the value 
   if ($_POST['username']) $_SESSION['username'] = $username;
   if ($_POST['password']) $_SESSION['password'] = $password; 
 
// Use session variables
	$cms_user = $_SESSION['username'];
	$cms_pass = $_SESSION['password'];

// Connect to the database
$db = mysql_connect("$dbserver","$dbuser","$dbpass");
mysql_select_db("$dbname",$db);

// update last login time
   if ($_POST['username']) {
   	 $datetime = date("Y-m-d H:i:s");
	 mysql_query("UPDATE cmsUsers SET dateLogin= '$datetime' WHERE username='$username'");
   }


// If not logged in, redirect to login page
if(!$_SESSION['username']){ 
    header("Location: /login.php");
} 

// if username exists, check to see if they are a real user
if ($_SESSION['username']) {
	$user_request = ("SELECT * FROM cmsUsers WHERE username='$cms_user' and password='$cms_pass';");
	$user_result = mysql_query ($user_request,$db) or die ("Query failed: $user_request.<br />".mysql_error());
	$verify = mysql_num_rows($user_result);
	while($user_row = mysql_fetch_array($user_result)) {
		$user_type = $user_row["usertype"];
		$cms_user_id = $user_row["ID"];
		$username = $user_row['username'];
		$firstName = $user_row['firstName'];
		$lastName = $user_row['lastName'];
		$initials = $user_row['initials'];
	
	}
}
if ($verify == "0") {
	echo "<p>&nbsp;</p>\n<p style=\"text-align: center\">Invalid login. <a href=\"/login.php\">Try Again</a></p>";
	exit();
}

// Page Permissions (0=Everyone,1=Admin)
	if(!$permissions) $permissions = '0';
	$user_level = Array(
		'Author' => '0', // write only
		'Designer' => '1', // write and upload
		'Coder' => '2', // create modules
		'Owner' => '3', // modify users
		'Administrator' => '4' // everything
	);
	if($permissions > $user_level[$user_type]) {
		echo "<p>&nbsp;</p>\n<p style=\"text-align: center\">Access Denied.</p>";
		exit();
	}


	
?>
