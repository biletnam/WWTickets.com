            	<!-- Windows -->
                <div class="col-lg-2 col-md-6 ">
                    <a href="/tickets/windows.php">
                    <div class="panel panel-primary">
                        <div class="panel-heading" style="padding-top:10px;">
                            <div class="row center-text">
                                <div class="col-s-12 text-center"><i class="fa fa-tasks fa-5x"></i><br/>
                                    <span class="center-text">Windows<br/>&nbsp;</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    </a>
                </div>
               
            	<!-- Siding -->
                <div class="col-lg-2 col-md-6 ">
                    <a href="/tickets/siding.php">
                    <div class="panel panel-primary">
                        <div class="panel-heading" style="padding-top:10px;">
                            <div class="row center-text">
                                <div class="col-s-12 text-center"><i class="fa fa-tasks fa-5x"></i><br/>
                                    <span class="center-text">Siding<br/>&nbsp;</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    </a>
                </div>


            	<!-- Window & Door Repair -->
                <div class="col-lg-2 col-md-6 ">
                    <a href="/tickets/window-door-repair.php">
                    <div class="panel panel-primary">
                        <div class="panel-heading" style="padding-top:10px;">
                            <div class="row center-text">
                                <div class="col-s-12 text-center"><i class="fa fa-tasks fa-5x"></i><br/>
                                    <span class="center-text">Window &amp;<br/>Door Repair</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    </a>
                </div>

            	<!-- Siding Repair -->
                <div class="col-lg-2 col-md-6 ">
                    <a href="/tickets/siding-repair.php">
                    <div class="panel panel-primary">
                        <div class="panel-heading" style="padding-top:10px;">
                            <div class="row center-text">
                                <div class="col-s-12 text-center"><i class="fa fa-tasks fa-5x"></i><br/>
                                    <span class="center-text">Siding Repair<br/>&nbsp;</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    </a>
                </div>

            	<!-- Incomplete -->
<!--                 <div class="col-lg-2 col-md-6 ">
                    <a href="/tickets/">
                    <div class="panel panel-primary">
                        <div class="panel-heading" style="padding-top:10px;">
                            <div class="row center-text">
                                <div class="col-s-12 text-center"><i class="fa fa-tasks fa-5x"></i><br/>
                                    <span class="center-text">Incomplete</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    </a>
                </div> -->

            	<!-- Vendors -->
                <div class="col-lg-2 col-md-6 ">
                    <a href="/tickets/solar-zone-attics.php">
                    <div class="panel panel-primary">
                        <div class="panel-heading" style="padding-top:10px;">
                            <div class="row center-text">
                                <div class="col-s-12 text-center"><i class="fa fa-tasks fa-5x"></i><br/>
                                    <span class="center-text">Solar Zone &amp; Attics<br/>&nbsp;</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    </a>
                </div>