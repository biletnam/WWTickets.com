#
# MySQL database dump
# Created by MySQL_Backup class, ver. 1.0.0
#
# Host: sql5c0c.megasqlservers.com
# Generated: Feb 7, 2016 at 11:09
# MySQL version: 5.5.32-log
# PHP version: 5.3.28
#
# Database: `server_windowworldtickets_com`
#


#
# Table structure for table `VendorAds`
#

DROP TABLE IF EXISTS `VendorAds`;
CREATE TABLE `VendorAds` (
  `adID` int(11) NOT NULL AUTO_INCREMENT,
  `adVendorID` varchar(100) DEFAULT NULL,
  `adName` varchar(250) DEFAULT NULL,
  `adLocation` varchar(250) DEFAULT NULL,
  `adPrice` varchar(15) DEFAULT NULL,
  `adstartContract` date NOT NULL,
  `adendContract` date NOT NULL,
  `adRenewal` date NOT NULL,
  `adPayment` varchar(250) DEFAULT NULL,
  `adNotes` text,
  PRIMARY KEY (`adID`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

#
# Dumping data for table `VendorAds`
#

INSERT INTO VendorAds VALUES ('1', '1', 'Ad Square', 'Newspaper', '500.57', '2015-07-24', '2015-07-24', '2015-07-24', 'Visa/Mastercard', 'Notes goes here about ad.');
INSERT INTO VendorAds VALUES ('5', '4', '2016 farm show ', 'Norfolk', '$420', '2016-01-13', '2016-01-14', '1969-12-31', 'Check', '');
INSERT INTO VendorAds VALUES ('6', '5', '2016  59th Annual Siouxland Home Show ', 'Sioux City', '1425.00  (balan', '2016-02-25', '2016-02-28', '1969-12-31', 'Check', 'made down payment of 635.00 need to make final payment by Jan 10th of 790.');
INSERT INTO VendorAds VALUES ('7', '6', 'Weather sponsorship ', 'Norfolk', '$350 per month', '2015-10-01', '1969-12-31', '1969-12-31', 'Check', 'Live :15 commerials, minimum of 15 per week 7 days a week ');
INSERT INTO VendorAds VALUES ('8', '7', '2016 Columbus Home and Builders Show ', 'Columbus', '$1,400 ', '2016-02-26', '2016-02-28', '1969-12-31', 'Check', '');
INSERT INTO VendorAds VALUES ('9', '9', 'digital portion ', 'Columbus', '68.50 a month', '2016-06-27', '2017-06-26', '1969-12-31', 'Check', 'This is for the digital portion of the contract! confirmation# 522324848  ');
INSERT INTO VendorAds VALUES ('10', '9', 'print portion', 'Columbus', '87.15 a month ', '2016-06-27', '2017-06-26', '1969-12-31', 'Check', 'print portion of contract
confirmation# 522324848  ');


#
# Table structure for table `Vendors`
#

DROP TABLE IF EXISTS `Vendors`;
CREATE TABLE `Vendors` (
  `vendorID` int(11) NOT NULL AUTO_INCREMENT,
  `vendorName` varchar(250) DEFAULT NULL,
  `vendorContact` varchar(250) DEFAULT NULL,
  `vendorPhone` varchar(100) DEFAULT NULL,
  `vendorType` varchar(150) DEFAULT NULL,
  `vendorFax` varchar(250) DEFAULT NULL,
  `vendorEmail` varchar(250) DEFAULT NULL,
  `vendorNotes` text,
  `vendorSlug` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`vendorID`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

#
# Dumping data for table `Vendors`
#

INSERT INTO Vendors VALUES ('1', 'Norfolk Daily News', 'Scott DeBoer', '(402) 851-2428', 'Newspaper', '(402) 851-2428', 'Info@Example.com', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptatibus voluptas incidunt hic natus consequuntur nostrum vel, recusandae consequatur sequi, maiores fugit eum, vero voluptate odit deleniti commodi veniam ab possimus.', 'norfolk-daily-news');
INSERT INTO Vendors VALUES ('4', '106 Kix', '', '', 'Newspaper', '', '', '', '');
INSERT INTO Vendors VALUES ('3', 'Power Pages', 'Scott DeBoer', '(402) 851-2428', 'Online', '(402) 379-2428', 'Web-Design@PowerPGS.com', 'Vendor Notes', '');
INSERT INTO Vendors VALUES ('5', 'Home Builders Assoc of Greater Siouxland  (Siouxland Home Show)', 'Nancy Moos', '712-255-3852', 'Outdoor and Transit', '', '', '
', '');
INSERT INTO Vendors VALUES ('6', '94.7 ', 'Gary Farnik', '402-379-0100 / 841-4212', 'Radio', '402-', 'gary@newschannelnebraska.com', '', '');
INSERT INTO Vendors VALUES ('7', 'Columbus Homebuilders Assoc', 'Steve ', '402-562-7068 (steve) / 402-276-0028 (Kelly)', 'Social Media', '', '', '', '');
INSERT INTO Vendors VALUES ('8', 'Norfolk Area Home Builders Assoc. ', 'Jane ', 'mechele 402-992-5946 / jane ', 'Social Media', '', 'nahb@telebeep.com', 'PO Box 558
Norfolk, NE 68702-0558
', '');
INSERT INTO Vendors VALUES ('9', 'berry Company/ frontier Columbus Norfolk region', 'Jordan Stokes', '336-821-4208', 'Directories', '866-492-4803', 'jordan.stokes@theberrycompany.com', '', '');
INSERT INTO Vendors VALUES ('10', 'Stacy @ Yellowbook/HIBU 605-381-3199', 'Stacy ', '605-381-3199', 'Directories', '', '', '', '');


#
# Table structure for table `calendar`
#

DROP TABLE IF EXISTS `calendar`;
CREATE TABLE `calendar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(160) NOT NULL,
  `description` text NOT NULL,
  `start` datetime NOT NULL,
  `end` datetime NOT NULL,
  `allDay` varchar(5) NOT NULL,
  `color` varchar(7) NOT NULL,
  `url` varchar(255) NOT NULL,
  `category` varchar(200) NOT NULL,
  `repeat_type` varchar(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `repeat_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

#
# Dumping data for table `calendar`
#

INSERT INTO calendar VALUES ('1', 'Test Event', '', '2015-09-17 00:00:00', '0000-00-00 00:00:00', 'false', '', '?page=', '', 'every_day', '0', '1');
INSERT INTO calendar VALUES ('2', 'Test Event', '', '2015-09-18 00:00:00', '1970-01-01 00:00:00', 'false', '', '?page=', '', 'every_day', '0', '1');
INSERT INTO calendar VALUES ('3', 'Test Event', '', '2015-09-19 00:00:00', '1970-01-02 00:00:00', 'false', '', '?page=', '', 'every_day', '0', '1');
INSERT INTO calendar VALUES ('4', 'Test Event', '', '2015-09-20 00:00:00', '1970-01-03 00:00:00', 'false', '', '?page=', '', 'every_day', '0', '1');
INSERT INTO calendar VALUES ('5', 'Event Two', '', '2015-09-18 00:00:00', '0000-00-00 00:00:00', 'false', '#680000', '?page=', '', 'no', '0', '5');


#
# Table structure for table `cities`
#

DROP TABLE IF EXISTS `cities`;
CREATE TABLE `cities` (
  `city_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `city_name` varchar(100) DEFAULT NULL,
  `city_slug` varchar(100) DEFAULT NULL,
  `city_state` varchar(2) DEFAULT NULL,
  `city_zip` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`city_id`),
  UNIQUE KEY `city_slug` (`city_slug`)
) ENGINE=MyISAM AUTO_INCREMENT=548 DEFAULT CHARSET=latin1;

#
# Dumping data for table `cities`
#

INSERT INTO cities VALUES ('1', 'Norfolk', 'norfolk', 'NE', '68701');
INSERT INTO cities VALUES ('2', 'Pierce', 'pierce', 'NE', '68767');
INSERT INTO cities VALUES ('3', 'Stanton', 'stanton', 'NE', '68779');
INSERT INTO cities VALUES ('4', 'Hadar', 'hadar', 'NE', '68738');
INSERT INTO cities VALUES ('5', 'Battle Creek', 'battle-creek', 'NE', '68715');
INSERT INTO cities VALUES ('6', 'Madison', 'madison', 'NE', '68748');
INSERT INTO cities VALUES ('7', 'Coleridge', 'coleridge', 'NE', '68727');
INSERT INTO cities VALUES ('8', 'Oakdale', 'oakdale', 'NE', '68761');
INSERT INTO cities VALUES ('9', 'Neligh', 'neligh', 'NE', '68756');
INSERT INTO cities VALUES ('10', 'O\'Neill', 'oneill', 'NE', '68763');
INSERT INTO cities VALUES ('11', 'Newman Grove', 'newman-grove', 'NE', '68758');
INSERT INTO cities VALUES ('12', 'Plainview', 'plainview', 'NE', '68769');
INSERT INTO cities VALUES ('13', 'Clearwater', 'clearwater', 'NE', '68726');
INSERT INTO cities VALUES ('14', 'Hartington', 'hartington', 'NE', '68739');
INSERT INTO cities VALUES ('15', 'Creighton', 'creighton', 'NE', '68729');
INSERT INTO cities VALUES ('16', 'Bloomfield', 'bloomfield', 'NE', '68718');
INSERT INTO cities VALUES ('17', 'Wausa', 'wausa', 'NE', '68786');
INSERT INTO cities VALUES ('18', 'Wayne', 'wayne', 'NE', '68787');
INSERT INTO cities VALUES ('19', 'Elgin', 'elgin', 'NE', '68636');
INSERT INTO cities VALUES ('20', 'West Point', 'west-point', 'NE', '68788');
INSERT INTO cities VALUES ('21', 'Royal', 'royal', 'NE', '68773');
INSERT INTO cities VALUES ('22', 'Wisner', 'wisner', 'NE', '68791');
INSERT INTO cities VALUES ('23', 'Beemer', 'beemer', 'NE', '68716');
INSERT INTO cities VALUES ('24', 'Tilden', 'tilden', 'NE', '68781');
INSERT INTO cities VALUES ('25', 'Humphrey', 'humphrey', 'NE', '68642');
INSERT INTO cities VALUES ('26', 'Clarkson', 'clarkson', 'NE', '68629');
INSERT INTO cities VALUES ('27', 'Dodge', 'dodge', 'NE', '68633');
INSERT INTO cities VALUES ('28', 'Meadow Grove', 'meadow-grove', 'NE', '68752');
INSERT INTO cities VALUES ('29', 'Pilger', 'pilger', 'NE', '68768');
INSERT INTO cities VALUES ('30', 'Laurel', 'laurel', 'NE', '68745');
INSERT INTO cities VALUES ('31', 'Albion', 'albion', 'NE', '68620');
INSERT INTO cities VALUES ('32', 'Orchard', 'orchard', 'NE', '68764');
INSERT INTO cities VALUES ('33', 'Winside', 'winside', 'NE', '68790');
INSERT INTO cities VALUES ('34', 'Hoskins', 'hoskins', 'NE', '68740');
INSERT INTO cities VALUES ('35', 'Lindsay', 'lindsay', 'NE', '68644');
INSERT INTO cities VALUES ('36', 'Ewing', 'ewing', 'NE', '68735');
INSERT INTO cities VALUES ('37', 'Carroll', 'carroll', 'NE', '68723');
INSERT INTO cities VALUES ('38', 'Leigh', 'leigh', 'NE', '68643');
INSERT INTO cities VALUES ('39', 'Howells', 'howells', 'NE', '68641');
INSERT INTO cities VALUES ('40', 'Osmond', 'osmond', 'NE', '68765');
INSERT INTO cities VALUES ('41', 'Crofton', 'crofton', 'NE', '68730');
INSERT INTO cities VALUES ('42', 'Columbus', 'columbus', 'NE', '68601');
INSERT INTO cities VALUES ('43', 'Verdigre', 'verdigre', 'NE', '68783');
INSERT INTO cities VALUES ('44', 'Randolph', 'randolph', 'NE', '68771');
INSERT INTO cities VALUES ('45', 'Niobrara', 'niobrara', 'NE', '68760');
INSERT INTO cities VALUES ('46', 'Newcastle', 'newcastle', 'NE', '68757');
INSERT INTO cities VALUES ('47', 'Ponca', 'ponca', 'NE', '68770');
INSERT INTO cities VALUES ('48', 'Wakefield', 'wakefield', 'NE', '68784');
INSERT INTO cities VALUES ('49', 'Winnetoon', 'winnetoon', 'NE', '68789');
INSERT INTO cities VALUES ('50', 'Pender', 'pender', 'NE', '68047');
INSERT INTO cities VALUES ('51', 'Scribner', 'scribner', 'NE', '68057');
INSERT INTO cities VALUES ('52', 'Schuyler', 'schuyler', 'NE', '68661');
INSERT INTO cities VALUES ('53', 'North Bend', 'north-bend', 'NE', '68649');
INSERT INTO cities VALUES ('54', 'Wynot', 'wynot', 'NE', '68792');
INSERT INTO cities VALUES ('55', 'Petersburg', 'petersburg', 'NE', '68652');
INSERT INTO cities VALUES ('56', 'Foster', 'foster', 'NE', '68737');
INSERT INTO cities VALUES ('57', 'Wahoo', 'wahoo', 'NE', '68066');
INSERT INTO cities VALUES ('58', 'Kearney', 'kearney', 'NE', '68845');
INSERT INTO cities VALUES ('59', 'Lincoln', 'lincoln', 'NE', '68501');
INSERT INTO cities VALUES ('60', 'Omaha', 'omaha', 'NE', '68114');
INSERT INTO cities VALUES ('61', 'Dixon', 'dixon', 'NE', '68732');
INSERT INTO cities VALUES ('62', 'Brunswick', 'brunswick', 'NE', '68720');
INSERT INTO cities VALUES ('63', 'Creston', 'creston', 'NE', '68631');
INSERT INTO cities VALUES ('64', 'Grand Island', 'grand-island', 'NE', '68801');
INSERT INTO cities VALUES ('65', 'Duncan', 'duncan', 'NE', '68634');
INSERT INTO cities VALUES ('66', 'Santee', 'santee', 'NE', '68760');
INSERT INTO cities VALUES ('67', 'Center', 'center', 'NE', '68724');
INSERT INTO cities VALUES ('68', 'Sioux City', 'sioux-city', 'IA', '51101');
INSERT INTO cities VALUES ('69', 'Yankton', 'yankton', 'SD', '57078');
INSERT INTO cities VALUES ('70', 'Abie', 'abie', 'NE', '68001');
INSERT INTO cities VALUES ('71', 'Adams', 'adams', 'NE', '68301');
INSERT INTO cities VALUES ('72', 'Ainsworth', 'ainsworth', 'NE', '69210');
INSERT INTO cities VALUES ('73', 'Alda', 'alda', 'NE', '68810');
INSERT INTO cities VALUES ('74', 'Alexandria', 'alexandria', 'NE', '68303');
INSERT INTO cities VALUES ('75', 'Allen', 'allen', 'NE', '68710');
INSERT INTO cities VALUES ('76', 'Alliance', 'alliance', 'NE', '69301');
INSERT INTO cities VALUES ('77', 'Alma', 'alma', 'NE', '68920');
INSERT INTO cities VALUES ('78', 'Alvo', 'alvo', 'NE', '68304');
INSERT INTO cities VALUES ('79', 'Amelia', 'amelia', 'NE', '68711');
INSERT INTO cities VALUES ('80', 'Ames', 'ames', 'NE', '68621');
INSERT INTO cities VALUES ('81', 'Amherst', 'amherst', 'NE', '68812');
INSERT INTO cities VALUES ('82', 'Angora', 'angora', 'NE', '69331');
INSERT INTO cities VALUES ('83', 'Anselmo', 'anselmo', 'NE', '68813');
INSERT INTO cities VALUES ('84', 'Ansley', 'ansley', 'NE', '68814');
INSERT INTO cities VALUES ('85', 'Arapahoe', 'arapahoe', 'NE', '68922');
INSERT INTO cities VALUES ('86', 'Arcadia', 'arcadia', 'NE', '68815');
INSERT INTO cities VALUES ('87', 'Archer', 'archer', 'NE', '68816');
INSERT INTO cities VALUES ('88', 'Arlington', 'arlington', 'NE', '68002');
INSERT INTO cities VALUES ('89', 'Arnold', 'arnold', 'NE', '69120');
INSERT INTO cities VALUES ('90', 'Arthur', 'arthur', 'NE', '69121');
INSERT INTO cities VALUES ('91', 'Ashby', 'ashby', 'NE', '69333');
INSERT INTO cities VALUES ('92', 'Ashland', 'ashland', 'NE', '68003');
INSERT INTO cities VALUES ('93', 'Ashton', 'ashton', 'NE', '68817');
INSERT INTO cities VALUES ('94', 'Atkinson', 'atkinson', 'NE', '68713');
INSERT INTO cities VALUES ('95', 'Atlanta', 'atlanta', 'NE', '68923');
INSERT INTO cities VALUES ('96', 'Auburn', 'auburn', 'NE', '68305');
INSERT INTO cities VALUES ('97', 'Aurora', 'aurora', 'NE', '68818');
INSERT INTO cities VALUES ('98', 'Avoca', 'avoca', 'NE', '68307');
INSERT INTO cities VALUES ('99', 'Axtell', 'axtell', 'NE', '68924');
INSERT INTO cities VALUES ('100', 'Ayr', 'ayr', 'NE', '68925');
INSERT INTO cities VALUES ('101', 'Bancroft', 'bancroft', 'NE', '68004');
INSERT INTO cities VALUES ('102', 'Barneston', 'barneston', 'NE', '68309');
INSERT INTO cities VALUES ('103', 'Bartlett', 'bartlett', 'NE', '68622');
INSERT INTO cities VALUES ('104', 'Bartley', 'bartley', 'NE', '69020');
INSERT INTO cities VALUES ('105', 'Bassett', 'bassett', 'NE', '68714');
INSERT INTO cities VALUES ('106', 'Bayard', 'bayard', 'NE', '69334');
INSERT INTO cities VALUES ('107', 'Beatrice', 'beatrice', 'NE', '68310');
INSERT INTO cities VALUES ('108', 'Beaver City', 'beaver-city', 'NE', '68926');
INSERT INTO cities VALUES ('109', 'Beaver Crossing', 'beaver-crossing', 'NE', '68313');
INSERT INTO cities VALUES ('110', 'Bee', 'bee', 'NE', '68314');
INSERT INTO cities VALUES ('111', 'Belden', 'belden', 'NE', '68717');
INSERT INTO cities VALUES ('112', 'Belgrade', 'belgrade', 'NE', '68623');
INSERT INTO cities VALUES ('113', 'Bellevue', 'bellevue', 'NE', '68005');
INSERT INTO cities VALUES ('114', 'Bellwood', 'bellwood', 'NE', '68624');
INSERT INTO cities VALUES ('115', 'Belvidere', 'belvidere', 'NE', '68315');
INSERT INTO cities VALUES ('116', 'Benedict', 'benedict', 'NE', '68316');
INSERT INTO cities VALUES ('117', 'Benkelman', 'benkelman', 'NE', '69021');
INSERT INTO cities VALUES ('118', 'Bennet', 'bennet', 'NE', '68317');
INSERT INTO cities VALUES ('119', 'Bennington', 'bennington', 'NE', '68007');
INSERT INTO cities VALUES ('120', 'Bertrand', 'bertrand', 'NE', '68927');
INSERT INTO cities VALUES ('121', 'Berwyn', 'berwyn', 'NE', '68819');
INSERT INTO cities VALUES ('122', 'Big Springs', 'big-springs', 'NE', '69122');
INSERT INTO cities VALUES ('123', 'Bingham', 'bingham', 'NE', '69335');
INSERT INTO cities VALUES ('124', 'Bladen', 'bladen', 'NE', '68928');
INSERT INTO cities VALUES ('125', 'Blair', 'blair', 'NE', '68008');
INSERT INTO cities VALUES ('128', 'Blue Hill', 'blue-hill', 'NE', '68930');
INSERT INTO cities VALUES ('129', 'Blue Springs', 'blue-springs', 'NE', '68318');
INSERT INTO cities VALUES ('130', 'Boelus', 'boelus', 'NE', '68820');
INSERT INTO cities VALUES ('131', 'Boys Town', 'boys-town', 'NE', '68010');
INSERT INTO cities VALUES ('132', 'Bradshaw', 'bradshaw', 'NE', '68319');
INSERT INTO cities VALUES ('133', 'Brady', 'brady', 'NE', '69123');
INSERT INTO cities VALUES ('134', 'Brainard', 'brainard', 'NE', '68626');
INSERT INTO cities VALUES ('135', 'Brewster', 'brewster', 'NE', '68821');
INSERT INTO cities VALUES ('136', 'Bridgeport', 'bridgeport', 'NE', '69336');
INSERT INTO cities VALUES ('137', 'Bristow', 'bristow', 'NE', '68719');
INSERT INTO cities VALUES ('138', 'Broadwater', 'broadwater', 'NE', '69125');
INSERT INTO cities VALUES ('139', 'Brock', 'brock', 'NE', '68320');
INSERT INTO cities VALUES ('140', 'Broken Bow', 'broken-bow', 'NE', '68822');
INSERT INTO cities VALUES ('141', 'Brownville', 'brownville', 'NE', '68321');
INSERT INTO cities VALUES ('142', 'Brule', 'brule', 'NE', '69127');
INSERT INTO cities VALUES ('143', 'Bruning', 'bruning', 'NE', '68322');
INSERT INTO cities VALUES ('144', 'Bruno', 'bruno', 'NE', '68014');
INSERT INTO cities VALUES ('145', 'Burchard', 'burchard', 'NE', '68323');
INSERT INTO cities VALUES ('146', 'Burr', 'burr', 'NE', '68324');
INSERT INTO cities VALUES ('147', 'Burwell', 'burwell', 'NE', '68823');
INSERT INTO cities VALUES ('148', 'Bushnell', 'bushnell', 'NE', '69128');
INSERT INTO cities VALUES ('149', 'Butte', 'butte', 'NE', '68722');
INSERT INTO cities VALUES ('150', 'Byron', 'byron', 'NE', '68325');
INSERT INTO cities VALUES ('151', 'Cairo', 'cairo', 'NE', '68824');
INSERT INTO cities VALUES ('152', 'Callaway', 'callaway', 'NE', '68825');
INSERT INTO cities VALUES ('153', 'Cambridge', 'cambridge', 'NE', '69022');
INSERT INTO cities VALUES ('154', 'Campbell', 'campbell', 'NE', '68932');
INSERT INTO cities VALUES ('155', 'Carleton', 'carleton', 'NE', '68326');
INSERT INTO cities VALUES ('156', 'Cedar Bluffs', 'cedar-bluffs', 'NE', '68015');
INSERT INTO cities VALUES ('157', 'Cedar Creek', 'cedar-creek', 'NE', '68016');
INSERT INTO cities VALUES ('158', 'Cedar Rapids', 'cedar-rapids', 'NE', '68627');
INSERT INTO cities VALUES ('159', 'Central City', 'central-city', 'NE', '68826');
INSERT INTO cities VALUES ('160', 'Ceresco', 'ceresco', 'NE', '68017');
INSERT INTO cities VALUES ('161', 'Chadron', 'chadron', 'NE', '69337');
INSERT INTO cities VALUES ('162', 'Chambers', 'chambers', 'NE', '68725');
INSERT INTO cities VALUES ('163', 'Champion', 'champion', 'NE', '69023');
INSERT INTO cities VALUES ('164', 'Chapman', 'chapman', 'NE', '68827');
INSERT INTO cities VALUES ('165', 'Chappell', 'chappell', 'NE', '69129');
INSERT INTO cities VALUES ('166', 'Chester', 'chester', 'NE', '68327');
INSERT INTO cities VALUES ('167', 'Clarks', 'clarks', 'NE', '68628');
INSERT INTO cities VALUES ('168', 'Clatonia', 'clatonia', 'NE', '68328');
INSERT INTO cities VALUES ('169', 'Clay Center', 'clay-center', 'NE', '68933');
INSERT INTO cities VALUES ('170', 'Cody', 'cody', 'NE', '69211');
INSERT INTO cities VALUES ('171', 'Colon', 'colon', 'NE', '68018');
INSERT INTO cities VALUES ('172', 'Comstock', 'comstock', 'NE', '68828');
INSERT INTO cities VALUES ('173', 'Concord', 'concord', 'NE', '68728');
INSERT INTO cities VALUES ('174', 'Cook', 'cook', 'NE', '68329');
INSERT INTO cities VALUES ('175', 'Cordova', 'cordova', 'NE', '68330');
INSERT INTO cities VALUES ('176', 'Cortland', 'cortland', 'NE', '68331');
INSERT INTO cities VALUES ('177', 'Cozad', 'cozad', 'NE', '69130');
INSERT INTO cities VALUES ('178', 'Crab Orchard', 'crab-orchard', 'NE', '68332');
INSERT INTO cities VALUES ('179', 'Craig', 'craig', 'NE', '68019');
INSERT INTO cities VALUES ('180', 'Crawford', 'crawford', 'NE', '69339');
INSERT INTO cities VALUES ('181', 'Crete', 'crete', 'NE', '68333');
INSERT INTO cities VALUES ('182', 'Crookston', 'crookston', 'NE', '69212');
INSERT INTO cities VALUES ('183', 'Culbertson', 'culbertson', 'NE', '69024');
INSERT INTO cities VALUES ('184', 'Curtis', 'curtis', 'NE', '69025');
INSERT INTO cities VALUES ('185', 'Dakota City', 'dakota-city', 'NE', '68731');
INSERT INTO cities VALUES ('186', 'Dalton', 'dalton', 'NE', '69131');
INSERT INTO cities VALUES ('187', 'Danbury', 'danbury', 'NE', '69026');
INSERT INTO cities VALUES ('188', 'Dannebrog', 'dannebrog', 'NE', '68831');
INSERT INTO cities VALUES ('189', 'Davenport', 'davenport', 'NE', '68335');
INSERT INTO cities VALUES ('190', 'Davey', 'davey', 'NE', '68336');
INSERT INTO cities VALUES ('191', 'David City', 'david-city', 'NE', '68632');
INSERT INTO cities VALUES ('192', 'Dawson', 'dawson', 'NE', '68337');
INSERT INTO cities VALUES ('193', 'Daykin', 'daykin', 'NE', '68338');
INSERT INTO cities VALUES ('194', 'De Witt', 'de-witt', 'NE', '68341');
INSERT INTO cities VALUES ('195', 'Decatur', 'decatur', 'NE', '68020');
INSERT INTO cities VALUES ('196', 'Denton', 'denton', 'NE', '68339');
INSERT INTO cities VALUES ('197', 'Deshler', 'deshler', 'NE', '68340');
INSERT INTO cities VALUES ('198', 'Deweese', 'deweese', 'NE', '68934');
INSERT INTO cities VALUES ('199', 'Dickens', 'dickens', 'NE', '69132');
INSERT INTO cities VALUES ('200', 'Diller', 'diller', 'NE', '68342');
INSERT INTO cities VALUES ('201', 'Dix', 'dix', 'NE', '69133');
INSERT INTO cities VALUES ('202', 'Doniphan', 'doniphan', 'NE', '68832');
INSERT INTO cities VALUES ('203', 'Dorchester', 'dorchester', 'NE', '68343');
INSERT INTO cities VALUES ('204', 'Douglas', 'douglas', 'NE', '68344');
INSERT INTO cities VALUES ('205', 'Du Bois', 'du-bois', 'NE', '68345');
INSERT INTO cities VALUES ('206', 'Dunbar', 'dunbar', 'NE', '68346');
INSERT INTO cities VALUES ('207', 'Dunning', 'dunning', 'NE', '68833');
INSERT INTO cities VALUES ('208', 'Dwight', 'dwight', 'NE', '68635');
INSERT INTO cities VALUES ('209', 'Eagle', 'eagle', 'NE', '68347');
INSERT INTO cities VALUES ('210', 'Eddyville', 'eddyville', 'NE', '68834');
INSERT INTO cities VALUES ('211', 'Edgar', 'edgar', 'NE', '68935');
INSERT INTO cities VALUES ('212', 'Edison', 'edison', 'NE', '68936');
INSERT INTO cities VALUES ('213', 'Elba', 'elba', 'NE', '68835');
INSERT INTO cities VALUES ('214', 'Elk Creek', 'elk-creek', 'NE', '68348');
INSERT INTO cities VALUES ('215', 'Elkhorn', 'elkhorn', 'NE', '68022');
INSERT INTO cities VALUES ('216', 'Ellsworth', 'ellsworth', 'NE', '69340');
INSERT INTO cities VALUES ('217', 'Elm Creek', 'elm-creek', 'NE', '68836');
INSERT INTO cities VALUES ('218', 'Elmwood', 'elmwood', 'NE', '68349');
INSERT INTO cities VALUES ('219', 'Elsie', 'elsie', 'NE', '69134');
INSERT INTO cities VALUES ('220', 'Elsmere', 'elsmere', 'NE', '69135');
INSERT INTO cities VALUES ('221', 'Elwood', 'elwood', 'NE', '68937');
INSERT INTO cities VALUES ('222', 'Elyria', 'elyria', 'NE', '68837');
INSERT INTO cities VALUES ('223', 'Emerson', 'emerson', 'NE', '68733');
INSERT INTO cities VALUES ('224', 'Emmet', 'emmet', 'NE', '68734');
INSERT INTO cities VALUES ('225', 'Enders', 'enders', 'NE', '69027');
INSERT INTO cities VALUES ('226', 'Endicott', 'endicott', 'NE', '68350');
INSERT INTO cities VALUES ('227', 'Ericson', 'ericson', 'NE', '68637');
INSERT INTO cities VALUES ('228', 'Eustis', 'eustis', 'NE', '69028');
INSERT INTO cities VALUES ('229', 'Exeter', 'exeter', 'NE', '68351');
INSERT INTO cities VALUES ('230', 'Fairbury', 'fairbury', 'NE', '68352');
INSERT INTO cities VALUES ('231', 'Fairfield', 'fairfield', 'NE', '68938');
INSERT INTO cities VALUES ('232', 'Fairmont', 'fairmont', 'NE', '68354');
INSERT INTO cities VALUES ('233', 'Falls City', 'falls-city', 'NE', '68355');
INSERT INTO cities VALUES ('234', 'Farnam', 'farnam', 'NE', '69029');
INSERT INTO cities VALUES ('235', 'Farwell', 'farwell', 'NE', '68838');
INSERT INTO cities VALUES ('236', 'Filley', 'filley', 'NE', '68357');
INSERT INTO cities VALUES ('237', 'Firth', 'firth', 'NE', '68358');
INSERT INTO cities VALUES ('238', 'Fordyce', 'fordyce', 'NE', '68736');
INSERT INTO cities VALUES ('239', 'Fort Calhoun', 'fort-calhoun', 'NE', '68023');
INSERT INTO cities VALUES ('240', 'Franklin', 'franklin', 'NE', '68939');
INSERT INTO cities VALUES ('241', 'Fremont', 'fremont', 'NE', '68025');
INSERT INTO cities VALUES ('243', 'Friend', 'friend', 'NE', '68359');
INSERT INTO cities VALUES ('244', 'Fullerton', 'fullerton', 'NE', '68638');
INSERT INTO cities VALUES ('245', 'Funk', 'funk', 'NE', '68940');
INSERT INTO cities VALUES ('246', 'Garland', 'garland', 'NE', '68360');
INSERT INTO cities VALUES ('247', 'Geneva', 'geneva', 'NE', '68361');
INSERT INTO cities VALUES ('248', 'Genoa', 'genoa', 'NE', '68640');
INSERT INTO cities VALUES ('249', 'Gering', 'gering', 'NE', '69341');
INSERT INTO cities VALUES ('250', 'Gibbon', 'gibbon', 'NE', '68840');
INSERT INTO cities VALUES ('251', 'Gilead', 'gilead', 'NE', '68362');
INSERT INTO cities VALUES ('252', 'Giltner', 'giltner', 'NE', '68841');
INSERT INTO cities VALUES ('253', 'Glenvil', 'glenvil', 'NE', '68941');
INSERT INTO cities VALUES ('254', 'Goehner', 'goehner', 'NE', '68364');
INSERT INTO cities VALUES ('255', 'Gordon', 'gordon', 'NE', '69343');
INSERT INTO cities VALUES ('256', 'Gothenburg', 'gothenburg', 'NE', '69138');
INSERT INTO cities VALUES ('257', 'Grafton', 'grafton', 'NE', '68365');
INSERT INTO cities VALUES ('258', 'Grant', 'grant', 'NE', '69140');
INSERT INTO cities VALUES ('259', 'Greeley', 'greeley', 'NE', '68842');
INSERT INTO cities VALUES ('260', 'Greenwood', 'greenwood', 'NE', '68366');
INSERT INTO cities VALUES ('261', 'Gresham', 'gresham', 'NE', '68367');
INSERT INTO cities VALUES ('262', 'Gretna', 'gretna', 'NE', '68028');
INSERT INTO cities VALUES ('263', 'Guide Rock', 'guide-rock', 'NE', '68942');
INSERT INTO cities VALUES ('264', 'Gurley', 'gurley', 'NE', '69141');
INSERT INTO cities VALUES ('265', 'Haigler', 'haigler', 'NE', '69030');
INSERT INTO cities VALUES ('266', 'Hallam', 'hallam', 'NE', '68368');
INSERT INTO cities VALUES ('267', 'Halsey', 'halsey', 'NE', '69142');
INSERT INTO cities VALUES ('268', 'Hamlet', 'hamlet', 'NE', '69031');
INSERT INTO cities VALUES ('269', 'Hampton', 'hampton', 'NE', '68843');
INSERT INTO cities VALUES ('270', 'Hardy', 'hardy', 'NE', '68943');
INSERT INTO cities VALUES ('271', 'Harrisburg', 'harrisburg', 'NE', '69345');
INSERT INTO cities VALUES ('272', 'Harrison', 'harrison', 'NE', '69346');
INSERT INTO cities VALUES ('273', 'Harvard', 'harvard', 'NE', '68944');
INSERT INTO cities VALUES ('274', 'Hastings', 'hastings', 'NE', '68901');
INSERT INTO cities VALUES ('276', 'Hay Springs', 'hay-springs', 'NE', '69347');
INSERT INTO cities VALUES ('277', 'Hayes Center', 'hayes-center', 'NE', '69032');
INSERT INTO cities VALUES ('278', 'Hazard', 'hazard', 'NE', '68844');
INSERT INTO cities VALUES ('279', 'Heartwell', 'heartwell', 'NE', '68945');
INSERT INTO cities VALUES ('280', 'Hebron', 'hebron', 'NE', '68370');
INSERT INTO cities VALUES ('281', 'Hemingford', 'hemingford', 'NE', '69348');
INSERT INTO cities VALUES ('282', 'Henderson', 'henderson', 'NE', '68371');
INSERT INTO cities VALUES ('283', 'Hendley', 'hendley', 'NE', '68946');
INSERT INTO cities VALUES ('284', 'Henry', 'henry', 'NE', '69349');
INSERT INTO cities VALUES ('285', 'Herman', 'herman', 'NE', '68029');
INSERT INTO cities VALUES ('286', 'Hershey', 'hershey', 'NE', '69143');
INSERT INTO cities VALUES ('287', 'Hickman', 'hickman', 'NE', '68372');
INSERT INTO cities VALUES ('288', 'Hildreth', 'hildreth', 'NE', '68947');
INSERT INTO cities VALUES ('289', 'Holbrook', 'holbrook', 'NE', '68948');
INSERT INTO cities VALUES ('290', 'Holdrege', 'holdrege', 'NE', '68949');
INSERT INTO cities VALUES ('291', 'Holmesville', 'holmesville', 'NE', '68374');
INSERT INTO cities VALUES ('292', 'Holstein', 'holstein', 'NE', '68950');
INSERT INTO cities VALUES ('293', 'Homer', 'homer', 'NE', '68030');
INSERT INTO cities VALUES ('294', 'Hooper', 'hooper', 'NE', '68031');
INSERT INTO cities VALUES ('295', 'Hordville', 'hordville', 'NE', '68846');
INSERT INTO cities VALUES ('296', 'Hubbard', 'hubbard', 'NE', '68741');
INSERT INTO cities VALUES ('297', 'Hubbell', 'hubbell', 'NE', '68375');
INSERT INTO cities VALUES ('298', 'Humboldt', 'humboldt', 'NE', '68376');
INSERT INTO cities VALUES ('299', 'Hyannis', 'hyannis', 'NE', '69350');
INSERT INTO cities VALUES ('300', 'Imperial', 'imperial', 'NE', '69033');
INSERT INTO cities VALUES ('301', 'Inavale', 'inavale', 'NE', '68952');
INSERT INTO cities VALUES ('302', 'Indianola', 'indianola', 'NE', '69034');
INSERT INTO cities VALUES ('303', 'Inland', 'inland', 'NE', '68954');
INSERT INTO cities VALUES ('304', 'Inman', 'inman', 'NE', '68742');
INSERT INTO cities VALUES ('305', 'Ithaca', 'ithaca', 'NE', '68033');
INSERT INTO cities VALUES ('306', 'Jackson', 'jackson', 'NE', '68743');
INSERT INTO cities VALUES ('307', 'Jansen', 'jansen', 'NE', '68377');
INSERT INTO cities VALUES ('308', 'Ohnson', 'ohnson', 'NE', '68378');
INSERT INTO cities VALUES ('309', 'Johnstown', 'johnstown', 'NE', '69214');
INSERT INTO cities VALUES ('310', 'Juniata', 'juniata', 'NE', '68955');
INSERT INTO cities VALUES ('311', 'Kenesaw', 'kenesaw', 'NE', '68956');
INSERT INTO cities VALUES ('312', 'Kennard', 'kennard', 'NE', '68034');
INSERT INTO cities VALUES ('313', 'Keystone', 'keystone', 'NE', '69144');
INSERT INTO cities VALUES ('314', 'Kilgore', 'kilgore', 'NE', '69216');
INSERT INTO cities VALUES ('315', 'Kimball', 'kimball', 'NE', '69145');
INSERT INTO cities VALUES ('316', 'La Vista', 'la-vista', 'NE', '68128');
INSERT INTO cities VALUES ('317', 'Lakeside', 'lakeside', 'NE', '69351');
INSERT INTO cities VALUES ('318', 'Lawrence', 'lawrence', 'NE', '68957');
INSERT INTO cities VALUES ('319', 'Lebanon', 'lebanon', 'NE', '69036');
INSERT INTO cities VALUES ('320', 'Lemoyne', 'lemoyne', 'NE', '69146');
INSERT INTO cities VALUES ('321', 'Leshara', 'leshara', 'NE', '68035');
INSERT INTO cities VALUES ('322', 'Lewellen', 'lewellen', 'NE', '69147');
INSERT INTO cities VALUES ('323', 'Lewiston', 'lewiston', 'NE', '68380');
INSERT INTO cities VALUES ('324', 'Lexington', 'lexington', 'NE', '68850');
INSERT INTO cities VALUES ('325', 'Liberty', 'liberty', 'NE', '68381');
INSERT INTO cities VALUES ('326', 'Linwood', 'linwood', 'NE', '68036');
INSERT INTO cities VALUES ('327', 'Lisco', 'lisco', 'NE', '69148');
INSERT INTO cities VALUES ('328', 'Litchfield', 'litchfield', 'NE', '68852');
INSERT INTO cities VALUES ('329', 'Lodgepole', 'lodgepole', 'NE', '69149');
INSERT INTO cities VALUES ('330', 'Long Pine', 'long-pine', 'NE', '69217');
INSERT INTO cities VALUES ('331', 'Loomis', 'loomis', 'NE', '68958');
INSERT INTO cities VALUES ('332', 'Lorton', 'lorton', 'NE', '68382');
INSERT INTO cities VALUES ('333', 'Louisville', 'louisville', 'NE', '68037');
INSERT INTO cities VALUES ('334', 'Loup City', 'loup-city', 'NE', '68853');
INSERT INTO cities VALUES ('335', 'Lyman', 'lyman', 'NE', '69352');
INSERT INTO cities VALUES ('336', 'Lynch', 'lynch', 'NE', '68746');
INSERT INTO cities VALUES ('337', 'Lyons', 'lyons', 'NE', '68038');
INSERT INTO cities VALUES ('338', 'Macy', 'macy', 'NE', '68039');
INSERT INTO cities VALUES ('339', 'Madrid', 'madrid', 'NE', '69150');
INSERT INTO cities VALUES ('340', 'Magnet', 'magnet', 'NE', '68749');
INSERT INTO cities VALUES ('341', 'Malcolm', 'malcolm', 'NE', '68402');
INSERT INTO cities VALUES ('342', 'Malmo', 'malmo', 'NE', '68040');
INSERT INTO cities VALUES ('343', 'Manley', 'manley', 'NE', '68403');
INSERT INTO cities VALUES ('344', 'Marquette', 'marquette', 'NE', '68854');
INSERT INTO cities VALUES ('345', 'Marsland', 'marsland', 'NE', '69354');
INSERT INTO cities VALUES ('346', 'Martell', 'martell', 'NE', '68404');
INSERT INTO cities VALUES ('347', 'Maskell', 'maskell', 'NE', '68751');
INSERT INTO cities VALUES ('348', 'Mason City', 'mason-city', 'NE', '68855');
INSERT INTO cities VALUES ('349', 'Max', 'max', 'NE', '69037');
INSERT INTO cities VALUES ('350', 'Maxwell', 'maxwell', 'NE', '69151');
INSERT INTO cities VALUES ('351', 'Maywood', 'maywood', 'NE', '69038');
INSERT INTO cities VALUES ('352', 'Mccook', 'mccook', 'NE', '69001');
INSERT INTO cities VALUES ('353', 'Mccool Junction', 'mccool-junction', 'NE', '68401');
INSERT INTO cities VALUES ('354', 'Mcgrew', 'mcgrew', 'NE', '69353');
INSERT INTO cities VALUES ('355', 'Mclean', 'mclean', 'NE', '68747');
INSERT INTO cities VALUES ('356', 'Mead', 'mead', 'NE', '68041');
INSERT INTO cities VALUES ('357', 'Melbeta', 'melbeta', 'NE', '69355');
INSERT INTO cities VALUES ('358', 'Memphis', 'memphis', 'NE', '68042');
INSERT INTO cities VALUES ('359', 'Merna', 'merna', 'NE', '68856');
INSERT INTO cities VALUES ('360', 'Merriman', 'merriman', 'NE', '69218');
INSERT INTO cities VALUES ('361', 'Milford', 'milford', 'NE', '68405');
INSERT INTO cities VALUES ('362', 'Miller', 'miller', 'NE', '68858');
INSERT INTO cities VALUES ('363', 'Milligan', 'milligan', 'NE', '68406');
INSERT INTO cities VALUES ('364', 'Mills', 'mills', 'NE', '68753');
INSERT INTO cities VALUES ('365', 'Minatare', 'minatare', 'NE', '69356');
INSERT INTO cities VALUES ('366', 'Minden', 'minden', 'NE', '68959');
INSERT INTO cities VALUES ('367', 'Mitchell', 'mitchell', 'NE', '69357');
INSERT INTO cities VALUES ('368', 'Monroe', 'monroe', 'NE', '68647');
INSERT INTO cities VALUES ('369', 'Moorefield', 'moorefield', 'NE', '69039');
INSERT INTO cities VALUES ('370', 'Morrill', 'morrill', 'NE', '69358');
INSERT INTO cities VALUES ('371', 'Morse Bluff', 'morse-bluff', 'NE', '68648');
INSERT INTO cities VALUES ('372', 'Mullen', 'mullen', 'NE', '69152');
INSERT INTO cities VALUES ('373', 'Murdock', 'murdock', 'NE', '68407');
INSERT INTO cities VALUES ('374', 'Murray', 'murray', 'NE', '68409');
INSERT INTO cities VALUES ('375', 'Naper', 'naper', 'NE', '68755');
INSERT INTO cities VALUES ('376', 'Naponee', 'naponee', 'NE', '68960');
INSERT INTO cities VALUES ('377', 'Nebraska City', 'nebraska-city', 'NE', '68410');
INSERT INTO cities VALUES ('378', 'Nehawka', 'nehawka', 'NE', '68413');
INSERT INTO cities VALUES ('379', 'Nelson', 'nelson', 'NE', '68961');
INSERT INTO cities VALUES ('380', 'Nemaha', 'nemaha', 'NE', '68414');
INSERT INTO cities VALUES ('381', 'Nenzel', 'nenzel', 'NE', '69219');
INSERT INTO cities VALUES ('382', 'Newport', 'newport', 'NE', '68759');
INSERT INTO cities VALUES ('383', 'Nickerson', 'nickerson', 'NE', '68044');
INSERT INTO cities VALUES ('384', 'Norman', 'norman', 'NE', '68963');
INSERT INTO cities VALUES ('385', 'North Loup', 'north-loup', 'NE', '68859');
INSERT INTO cities VALUES ('386', 'North Platte', 'north-platte', 'NE', '69101');
INSERT INTO cities VALUES ('387', 'Oak', 'oak', 'NE', '68964');
INSERT INTO cities VALUES ('388', 'Oakland', 'oakland', 'NE', '68045');
INSERT INTO cities VALUES ('389', 'Oconto', 'oconto', 'NE', '68860');
INSERT INTO cities VALUES ('390', 'Odell', 'odell', 'NE', '68415');
INSERT INTO cities VALUES ('391', 'Odessa', 'odessa', 'NE', '68861');
INSERT INTO cities VALUES ('392', 'Offutt AFB', 'offutt-afb', 'NE', '68113');
INSERT INTO cities VALUES ('393', 'Ogallala', 'ogallala', 'NE', '69153');
INSERT INTO cities VALUES ('394', 'Ohiowa', 'ohiowa', 'NE', '68416');
INSERT INTO cities VALUES ('395', 'Ong', 'ong', 'NE', '68452');
INSERT INTO cities VALUES ('396', 'Ord', 'ord', 'NE', '68862');
INSERT INTO cities VALUES ('397', 'Orleans', 'orleans', 'NE', '68966');
INSERT INTO cities VALUES ('398', 'Osceola', 'osceola', 'NE', '68651');
INSERT INTO cities VALUES ('399', 'Oshkosh', 'oshkosh', 'NE', '69154');
INSERT INTO cities VALUES ('401', 'Otoe', 'otoe', 'NE', '68417');
INSERT INTO cities VALUES ('402', 'Overton', 'overton', 'NE', '68863');
INSERT INTO cities VALUES ('403', 'Oxford', 'oxford', 'NE', '68967');
INSERT INTO cities VALUES ('404', 'Page', 'page', 'NE', '68766');
INSERT INTO cities VALUES ('405', 'Palisade', 'palisade', 'NE', '69040');
INSERT INTO cities VALUES ('406', 'Palmer', 'palmer', 'NE', '68864');
INSERT INTO cities VALUES ('407', 'Palmyra', 'palmyra', 'NE', '68418');
INSERT INTO cities VALUES ('408', 'Panama', 'panama', 'NE', '68419');
INSERT INTO cities VALUES ('409', 'Papillion', 'papillion', 'NE', '68046');
INSERT INTO cities VALUES ('410', 'Parks', 'parks', 'NE', '69041');
INSERT INTO cities VALUES ('411', 'Pawnee City', 'pawnee-city', 'NE', '68420');
INSERT INTO cities VALUES ('412', 'Paxton', 'paxton', 'NE', '69155');
INSERT INTO cities VALUES ('413', 'Peru', 'peru', 'NE', '68421');
INSERT INTO cities VALUES ('414', 'Phillips', 'phillips', 'NE', '68865');
INSERT INTO cities VALUES ('415', 'Pickrell', 'pickrell', 'NE', '68422');
INSERT INTO cities VALUES ('416', 'Platte Center', 'platte-center', 'NE', '68653');
INSERT INTO cities VALUES ('417', 'Plattsmouth', 'plattsmouth', 'NE', '68048');
INSERT INTO cities VALUES ('418', 'Pleasant Dale', 'pleasant-dale', 'NE', '68423');
INSERT INTO cities VALUES ('419', 'Pleasanton', 'pleasanton', 'NE', '68866');
INSERT INTO cities VALUES ('420', 'Plymouth', 'plymouth', 'NE', '68424');
INSERT INTO cities VALUES ('421', 'Polk', 'polk', 'NE', '68654');
INSERT INTO cities VALUES ('422', 'Potter', 'potter', 'NE', '69156');
INSERT INTO cities VALUES ('423', 'Prague', 'prague', 'NE', '68050');
INSERT INTO cities VALUES ('424', 'Primrose', 'primrose', 'NE', '68655');
INSERT INTO cities VALUES ('425', 'Purdum', 'purdum', 'NE', '69157');
INSERT INTO cities VALUES ('426', 'Ragan', 'ragan', 'NE', '68969');
INSERT INTO cities VALUES ('427', 'Ravenna', 'ravenna', 'NE', '68869');
INSERT INTO cities VALUES ('428', 'Raymond', 'raymond', 'NE', '68428');
INSERT INTO cities VALUES ('429', 'Red Cloud', 'red-cloud', 'NE', '68970');
INSERT INTO cities VALUES ('430', 'Republican City', 'republican-city', 'NE', '68971');
INSERT INTO cities VALUES ('431', 'Reynolds', 'reynolds', 'NE', '68429');
INSERT INTO cities VALUES ('432', 'Richfield', 'richfield', 'NE', '68054');
INSERT INTO cities VALUES ('433', 'Rising City', 'rising-city', 'NE', '68658');
INSERT INTO cities VALUES ('434', 'Riverdale', 'riverdale', 'NE', '68870');
INSERT INTO cities VALUES ('435', 'Riverton', 'riverton', 'NE', '68972');
INSERT INTO cities VALUES ('436', 'Roca', 'roca', 'NE', '68430');
INSERT INTO cities VALUES ('437', 'Rockville', 'rockville', 'NE', '68871');
INSERT INTO cities VALUES ('438', 'Rogers', 'rogers', 'NE', '68659');
INSERT INTO cities VALUES ('439', 'Rosalie', 'rosalie', 'NE', '68055');
INSERT INTO cities VALUES ('440', 'Rose', 'rose', 'NE', '68772');
INSERT INTO cities VALUES ('441', 'Roseland', 'roseland', 'NE', '68973');
INSERT INTO cities VALUES ('442', 'Rulo', 'rulo', 'NE', '68431');
INSERT INTO cities VALUES ('443', 'Rushville', 'rushville', 'NE', '69360');
INSERT INTO cities VALUES ('444', 'Ruskin', 'ruskin', 'NE', '68974');
INSERT INTO cities VALUES ('445', 'Saint Edward', 'saint-edward', 'NE', '68660');
INSERT INTO cities VALUES ('446', 'Saint Helena', 'saint-helena', 'NE', '68774');
INSERT INTO cities VALUES ('447', 'Saint Libory', 'saint-libory', 'NE', '68872');
INSERT INTO cities VALUES ('448', 'Saint Paul', 'saint-paul', 'NE', '68873');
INSERT INTO cities VALUES ('449', 'Salem', 'salem', 'NE', '68433');
INSERT INTO cities VALUES ('450', 'Sargent', 'sargent', 'NE', '68874');
INSERT INTO cities VALUES ('451', 'Saronville', 'saronville', 'NE', '68975');
INSERT INTO cities VALUES ('452', 'Scotia', 'scotia', 'NE', '68875');
INSERT INTO cities VALUES ('453', 'Scottsbluff', 'scottsbluff', 'NE', '69361');
INSERT INTO cities VALUES ('454', 'Seneca', 'seneca', 'NE', '69161');
INSERT INTO cities VALUES ('455', 'Seward', 'seward', 'NE', '68434');
INSERT INTO cities VALUES ('456', 'Shelby', 'shelby', 'NE', '68662');
INSERT INTO cities VALUES ('457', 'Shelton', 'shelton', 'NE', '68876');
INSERT INTO cities VALUES ('458', 'Shickley', 'shickley', 'NE', '68436');
INSERT INTO cities VALUES ('459', 'Shubert', 'shubert', 'NE', '68437');
INSERT INTO cities VALUES ('460', 'Sidney', 'sidney', 'NE', '69160');
INSERT INTO cities VALUES ('462', 'Silver Creek', 'silver-creek', 'NE', '68663');
INSERT INTO cities VALUES ('463', 'Smithfield', 'smithfield', 'NE', '68976');
INSERT INTO cities VALUES ('464', 'Snyder', 'snyder', 'NE', '68664');
INSERT INTO cities VALUES ('465', 'South Bend', 'south-bend', 'NE', '68058');
INSERT INTO cities VALUES ('466', 'South Sioux City', 'south-sioux-city', 'NE', '68776');
INSERT INTO cities VALUES ('467', 'Spalding', 'spalding', 'NE', '68665');
INSERT INTO cities VALUES ('468', 'Sparks', 'sparks', 'NE', '69220');
INSERT INTO cities VALUES ('469', 'Spencer', 'spencer', 'NE', '68777');
INSERT INTO cities VALUES ('470', 'Sprague', 'sprague', 'NE', '68438');
INSERT INTO cities VALUES ('471', 'Springfield', 'springfield', 'NE', '68059');
INSERT INTO cities VALUES ('472', 'Springview', 'springview', 'NE', '68778');
INSERT INTO cities VALUES ('473', 'St Columbans', 'st-columbans', 'NE', '68056');
INSERT INTO cities VALUES ('474', 'Stamford', 'stamford', 'NE', '68977');
INSERT INTO cities VALUES ('475', 'Staplehurst', 'staplehurst', 'NE', '68439');
INSERT INTO cities VALUES ('476', 'Stapleton', 'stapleton', 'NE', '69163');
INSERT INTO cities VALUES ('477', 'Steele City', 'steele-city', 'NE', '68440');
INSERT INTO cities VALUES ('478', 'Steinauer', 'steinauer', 'NE', '68441');
INSERT INTO cities VALUES ('479', 'Stella', 'stella', 'NE', '68442');
INSERT INTO cities VALUES ('480', 'Sterling', 'sterling', 'NE', '68443');
INSERT INTO cities VALUES ('481', 'Stockville', 'stockville', 'NE', '69042');
INSERT INTO cities VALUES ('482', 'Strang', 'strang', 'NE', '68444');
INSERT INTO cities VALUES ('483', 'Stratton', 'stratton', 'NE', '69043');
INSERT INTO cities VALUES ('484', 'Stromsburg', 'stromsburg', 'NE', '68666');
INSERT INTO cities VALUES ('485', 'Stuart', 'stuart', 'NE', '68780');
INSERT INTO cities VALUES ('486', 'Sumner', 'sumner', 'NE', '68878');
INSERT INTO cities VALUES ('487', 'Superior', 'superior', 'NE', '68978');
INSERT INTO cities VALUES ('488', 'Surprise', 'surprise', 'NE', '68667');
INSERT INTO cities VALUES ('489', 'Sutherland', 'sutherland', 'NE', '69165');
INSERT INTO cities VALUES ('490', 'Sutton', 'sutton', 'NE', '68979');
INSERT INTO cities VALUES ('491', 'Swanton', 'swanton', 'NE', '68445');
INSERT INTO cities VALUES ('492', 'Syracuse', 'syracuse', 'NE', '68446');
INSERT INTO cities VALUES ('493', 'Table Rock', 'table-rock', 'NE', '68447');
INSERT INTO cities VALUES ('494', 'Talmage', 'talmage', 'NE', '68448');
INSERT INTO cities VALUES ('495', 'Taylor', 'taylor', 'NE', '68879');
INSERT INTO cities VALUES ('496', 'Tecumseh', 'tecumseh', 'NE', '68450');
INSERT INTO cities VALUES ('497', 'Tekamah', 'tekamah', 'NE', '68061');
INSERT INTO cities VALUES ('498', 'Thedford', 'thedford', 'NE', '69166');
INSERT INTO cities VALUES ('499', 'Thurston', 'thurston', 'NE', '68062');
INSERT INTO cities VALUES ('500', 'Tobias', 'tobias', 'NE', '68453');
INSERT INTO cities VALUES ('501', 'Trenton', 'trenton', 'NE', '69044');
INSERT INTO cities VALUES ('502', 'Trumbull', 'trumbull', 'NE', '68980');
INSERT INTO cities VALUES ('503', 'Tryon', 'tryon', 'NE', '69167');
INSERT INTO cities VALUES ('504', 'Uehling', 'uehling', 'NE', '68063');
INSERT INTO cities VALUES ('505', 'Ulysses', 'ulysses', 'NE', '68669');
INSERT INTO cities VALUES ('506', 'Unadilla', 'unadilla', 'NE', '68454');
INSERT INTO cities VALUES ('507', 'Union', 'union', 'NE', '68455');
INSERT INTO cities VALUES ('508', 'Upland', 'upland', 'NE', '68981');
INSERT INTO cities VALUES ('509', 'Utica', 'utica', 'NE', '68456');
INSERT INTO cities VALUES ('510', 'Valentine', 'valentine', 'NE', '69201');
INSERT INTO cities VALUES ('511', 'Valley', 'valley', 'NE', '68064');
INSERT INTO cities VALUES ('512', 'Valparaiso', 'valparaiso', 'NE', '68065');
INSERT INTO cities VALUES ('513', 'Venango', 'venango', 'NE', '69168');
INSERT INTO cities VALUES ('514', 'Verdon', 'verdon', 'NE', '68457');
INSERT INTO cities VALUES ('515', 'Virginia', 'virginia', 'NE', '68458');
INSERT INTO cities VALUES ('516', 'Waco', 'waco', 'NE', '68460');
INSERT INTO cities VALUES ('517', 'Wallace', 'wallace', 'NE', '69169');
INSERT INTO cities VALUES ('518', 'Walthill', 'walthill', 'NE', '68067');
INSERT INTO cities VALUES ('519', 'Walton', 'walton', 'NE', '68461');
INSERT INTO cities VALUES ('520', 'Washington', 'washington', 'NE', '68068');
INSERT INTO cities VALUES ('521', 'Waterbury', 'waterbury', 'NE', '68785');
INSERT INTO cities VALUES ('522', 'Waterloo', 'waterloo', 'NE', '68069');
INSERT INTO cities VALUES ('523', 'Wauneta', 'wauneta', 'NE', '69045');
INSERT INTO cities VALUES ('524', 'Waverly', 'waverly', 'NE', '68462');
INSERT INTO cities VALUES ('525', 'Weeping Water', 'weeping-water', 'NE', '68463');
INSERT INTO cities VALUES ('526', 'Weissert', 'weissert', 'NE', '68880');
INSERT INTO cities VALUES ('527', 'Wellfleet', 'wellfleet', 'NE', '69170');
INSERT INTO cities VALUES ('528', 'Western', 'western', 'NE', '68464');
INSERT INTO cities VALUES ('529', 'Westerville', 'westerville', 'NE', '68881');
INSERT INTO cities VALUES ('530', 'Weston', 'weston', 'NE', '68070');
INSERT INTO cities VALUES ('531', 'Whiteclay', 'whiteclay', 'NE', '69365');
INSERT INTO cities VALUES ('532', 'Whitman', 'whitman', 'NE', '69366');
INSERT INTO cities VALUES ('533', 'Whitney', 'whitney', 'NE', '69367');
INSERT INTO cities VALUES ('534', 'Wilber', 'wilber', 'NE', '68465');
INSERT INTO cities VALUES ('535', 'Wilcox', 'wilcox', 'NE', '68982');
INSERT INTO cities VALUES ('536', 'Willow Island', 'willow-island', 'NE', '69171');
INSERT INTO cities VALUES ('537', 'Wilsonville', 'wilsonville', 'NE', '69046');
INSERT INTO cities VALUES ('538', 'Winnebago', 'winnebago', 'NE', '68071');
INSERT INTO cities VALUES ('539', 'Winslow', 'winslow', 'NE', '68072');
INSERT INTO cities VALUES ('540', 'Wolbach', 'wolbach', 'NE', '68882');
INSERT INTO cities VALUES ('541', 'Wood Lake', 'wood-lake', 'NE', '69221');
INSERT INTO cities VALUES ('542', 'Wood River', 'wood-river', 'NE', '68883');
INSERT INTO cities VALUES ('543', 'Wymore', 'wymore', 'NE', '68466');
INSERT INTO cities VALUES ('544', 'York', 'york', 'NE', '68467');
INSERT INTO cities VALUES ('545', 'Yutan', 'yutan', 'NE', '68073');


#
# Table structure for table `cmsUsers`
#

DROP TABLE IF EXISTS `cmsUsers`;
CREATE TABLE `cmsUsers` (
  `ID` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `firstName` varchar(100) DEFAULT NULL,
  `lastName` varchar(100) DEFAULT NULL,
  `initials` varchar(3) DEFAULT NULL,
  `usertype` enum('Author','Designer','Coder','Owner','Administrator') DEFAULT NULL,
  `dateLogin` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=39 DEFAULT CHARSET=latin1;

#
# Dumping data for table `cmsUsers`
#

INSERT INTO cmsUsers VALUES ('1', 'admin', 'pci2428', 'Power', 'Pages', 'SDD', 'Administrator', '2016-02-01 12:27:59');
INSERT INTO cmsUsers VALUES ('17', 'angi', 'kruse', 'Angi', 'Kruse', 'ak', 'Administrator', '2016-02-05 16:27:59');
INSERT INTO cmsUsers VALUES ('27', 'karla', 'frey', 'Karla ', 'Frey ', 'kf', 'Administrator', '2016-02-05 15:19:13');
INSERT INTO cmsUsers VALUES ('26', 'brent', 'frey', 'Brent ', 'Frey', 'bf', 'Administrator', '2016-02-06 11:49:53');
INSERT INTO cmsUsers VALUES ('28', 'hailey', 'christiansen', 'Hailey', 'Christiansen', 'HBC', 'Administrator', '2016-02-05 15:29:05');
INSERT INTO cmsUsers VALUES ('29', 'mark', 'peterson ', 'Mark ', 'Peterson', 'mp', 'Administrator', '2016-02-05 10:49:58');
INSERT INTO cmsUsers VALUES ('30', 'tyler', 'leinbaugh', 'Tyler ', 'Leinbaugh', 'tl', 'Administrator', '2015-09-15 14:31:41');
INSERT INTO cmsUsers VALUES ('31', 'sue', 'roach', 'Sue ', 'Roach', 'sr', 'Administrator', '2016-01-22 15:31:41');
INSERT INTO cmsUsers VALUES ('32', 'dwayne ', 'cornett', 'Dwayne', 'Cornett', 'dc ', 'Administrator', '2015-12-23 15:52:09');
INSERT INTO cmsUsers VALUES ('33', 'matthew', 'bilek', 'Matthew ', 'Bilek', 'mb', 'Administrator', '2015-09-15 14:35:30');
INSERT INTO cmsUsers VALUES ('34', 'jons', 'arens ', 'Jons', 'Arens ', 'ja', 'Administrator', '2015-09-15 14:41:06');
INSERT INTO cmsUsers VALUES ('35', 'stephen ', 'halovec', 'Stephen ', 'Havolec ', 'sh', 'Administrator', '2015-09-15 14:44:26');
INSERT INTO cmsUsers VALUES ('36', 'jeff', 'white', 'Jeff ', 'White ', 'jw', 'Administrator', '2016-02-05 15:38:30');
INSERT INTO cmsUsers VALUES ('37', 'mike', 'funkhouser', 'Mike ', 'Funkhouser', 'mf', 'Administrator', '2015-09-15 14:48:39');
INSERT INTO cmsUsers VALUES ('38', 'jerry', 'Pospisil', 'Jerry ', 'Pospisil', 'jp', 'Administrator', '2015-09-23 09:56:53');


#
# Table structure for table `customerInfo`
#

DROP TABLE IF EXISTS `customerInfo`;
CREATE TABLE `customerInfo` (
  `custID` int(11) NOT NULL AUTO_INCREMENT,
  `storeID` varchar(10) DEFAULT NULL,
  `custFName` varchar(40) DEFAULT NULL,
  `custLName` varchar(40) DEFAULT NULL,
  `custBillAdd` varchar(50) DEFAULT NULL,
  `custSecAdd` varchar(100) DEFAULT NULL,
  `custCity` varchar(80) DEFAULT NULL,
  `custState` varchar(40) DEFAULT NULL,
  `custZip` varchar(40) DEFAULT NULL,
  `custPhone` varchar(40) DEFAULT NULL,
  `custFax` varchar(40) NOT NULL,
  `custMobile` varchar(40) DEFAULT NULL,
  `custWork` varchar(40) DEFAULT NULL,
  `custEmail` varchar(40) DEFAULT NULL,
  `custEmail2` varchar(40) DEFAULT NULL,
  `custNotes` text,
  `custRank` varchar(10) DEFAULT NULL,
  `custPrimaryF` varchar(100) DEFAULT NULL,
  `custPrimPhone` varchar(100) DEFAULT NULL,
  `custComp` varchar(150) DEFAULT NULL,
  `referralType` varchar(250) DEFAULT NULL,
  `dateCreated` date NOT NULL,
  PRIMARY KEY (`custID`)
) ENGINE=MyISAM AUTO_INCREMENT=411 DEFAULT CHARSET=latin1;

#
# Dumping data for table `customerInfo`
#

INSERT INTO customerInfo VALUES ('3', '72', 'John', 'Avidano', '3006 N. Highway 35', '', 'Norfolk', 'Nebraska', '68701', '(402) 882-0025', '', '(402) 882-0025', '(402) 851-2428', 'JohnAvidano@Gmail.com', 'Info@Powerpgs.com', 'Large front windows, Brent indicated there was stucco would be a very difficult job.', '1', 'Amanda Avidano', '(402) 750-7142', 'Amanda Inc.', '106 Kix - Radio Ad', '2015-08-19');
INSERT INTO customerInfo VALUES ('4', '72', 'Angi', 'Kruse', '1302 Hillview Dr', '', 'Norfolk', 'Nebraska', '68701', '402-379-2238', '', '402-992-1947', '', 'akruse@q.com', '', '', '5', 'Angi ', '', '', '', '0000-00-00');
INSERT INTO customerInfo VALUES ('6', '72', 'Tim', 'Davy', '1217 Koenigstein ', '', 'Norfolk', 'Nebraska', '68701', '402-316-8282', '', '841-7632', '', '', '', '', '4', '', '', '', 'Norfolk Daily News - Ad Square', '0000-00-00');
INSERT INTO customerInfo VALUES ('31', '72', 'Don', 'Wacker', '305 W. Herman', '305 W. Herman', 'Battle Creek', 'Nebraska', '68715', '402-675-3595', '', '', '', '', '', '', '1', '', '', '', '', '2015-09-23');
INSERT INTO customerInfo VALUES ('7', '112', 'Tyler and Emily ', 'Leinbaugh', '4501 Cherrywood Lane', '', 'Sioux City', 'Iowa', '51106', '712-223-4198', '', '712-223-4198', '', 'tyler@windowworldnen.com', '', '', '1', 'Tyler ', '712-223-4198', '', '106 Kix - Radio Ad', '2015-09-03');
INSERT INTO customerInfo VALUES ('9', '72', 'Jon', 'Arens', '302 S. Madison ', '', 'Hartington', 'Nebraska', '68739', '605-661-5704', '', '', '', 'jarens@hartel.net', '', '', '5', 'Jon Arens ', '605-661-5704', '', 'Power Pages - ', '2015-09-15');
INSERT INTO customerInfo VALUES ('10', '72', 'James', 'Bahm', '303 Aspen Dr.', '', 'Norfolk', 'Nebraska', '68701', '371-8775', '', '', '', '', '', '', '3', 'James Bahm', '371-8775', '', 'Power Pages - ', '2015-09-15');
INSERT INTO customerInfo VALUES ('11', '72', 'Scott', 'DeBoer', '207 W. Norfolk Ave', '', 'Norfolk', 'Nebraska', '68701', '(402) 851-2428', '', '', '', 'Info@PowerPgs.com', '', '', '5', 'Scott DeBoer', '', 'Power Pages', '', '2015-09-15');
INSERT INTO customerInfo VALUES ('12', '72', 'Jon', 'Kleinschmidt', '2401 Valli Hi Road', '', 'Norfolk', 'Nebraska', '68701', '402 640-7262', '', '', '', '', '', 'DIY', '3', 'Jon ', '402-640-7262', '', 'Power Pages - ', '2015-09-16');
INSERT INTO customerInfo VALUES ('13', '72', 'Molly', 'Navritil', '100 W 4th St.', '', 'Tilden', 'Nebraska', '68758', '402-651-3370', '', '', '', '', '', 'estimate', '1', '', '', '', '', '2015-09-16');
INSERT INTO customerInfo VALUES ('14', '72', 'Battle Creek Coop', '', '86411 Hwy 121', 'PO Box 10     Battle Creek, NE', 'Osmond', 'Nebraska', '', '748-3371', '', '', '', '', '', '', '1', '', '', 'Battle Creek Coop', '', '2015-09-17');
INSERT INTO customerInfo VALUES ('16', '72', 'Patty', 'Score', '', 'PO Box 268    ', 'Saint Edward', 'Nebraska', '68661', '913-645-7070', '', '', '', '', '', '', '3', '', '', '', '', '2015-09-21');
INSERT INTO customerInfo VALUES ('17', '72', 'Maxine', 'Birkel', '1456 N. 3rd St.', '', 'David City', 'Nebraska', '68632', '402-367-3459', '', '', '', '', '', '', '3', '', '', '', '', '2015-09-21');
INSERT INTO customerInfo VALUES ('18', '72', 'Greg & Ellen ', 'Thiele', '2614 Westside Dr.', '', 'Norfolk', 'Nebraska', '68701', '402-649-1210', '', '', '', '', '', '', '1', '', '', '', '', '2015-09-21');
INSERT INTO customerInfo VALUES ('19', '72', 'Theresa & Steve', 'Perry', '83658 556th Ave', '83658 556th Ave', 'Norfolk', 'Nebraska', '68701', '402-841-3996', '', '', '', '', '', '', '3', '', '', '', '', '2015-09-21');
INSERT INTO customerInfo VALUES ('20', '72', 'Doris', 'Kocina', '353 Platte St.', '', 'Platte Center', 'Nebraska', '68653', '402-276-3945', '', '', '', '', '', '', '3', '', '', '', '', '2015-09-21');
INSERT INTO customerInfo VALUES ('21', '72', 'Josie', 'Renze', '3960 Lost Creek Dr. ', '', 'Columbus', 'Nebraska', '68601', '402-606-9516', '', '', '', '', '', '', '3', '', '', '', '', '2015-09-22');
INSERT INTO customerInfo VALUES ('22', '72', 'Kevin', 'Gray', '314 Forest Dr', '', 'Norfolk', 'Nebraska', '68701', '402-992-8634', '', '', '', '', '', '', '3', '', '', '', '', '2015-09-22');
INSERT INTO customerInfo VALUES ('23', '72', 'Josh', 'Kruger', '111 Park St', '111 Park St.', 'Madison', 'Nebraska', '68748', '402-841-4392', '', '', '', '', '', '', '1', '', '', '', '', '2015-09-22');
INSERT INTO customerInfo VALUES ('24', '72', 'Kevin', 'Ingemansen', '2918 14th St', '', 'Columbus', 'Nebraska', '68601', '402-564-5568', '', '', '', '', '', '', '1', '', '', '', '', '2015-09-22');
INSERT INTO customerInfo VALUES ('25', '72', 'Karol', 'Michael', '601 Neuer St', '601 Neuer St', 'Clearwater', 'Nebraska', '68726', '402-485-2813', '', '402-750-0064', '', '', '', '', '3', '', '', '', '', '2015-09-22');
INSERT INTO customerInfo VALUES ('30', '72', 'Leland', 'Wilson', '831 S. 8th St.', '', 'Norfolk', 'Nebraska', '68701', '402-379-3865', '', '', '', '', '', '', '1', '', '', '', '', '2015-09-23');
INSERT INTO customerInfo VALUES ('26', '72', 'Kirk & Carol ', 'Griffith', '607 S.Boxelder', '607 S. Boxelder', 'Norfolk', 'Nebraska', '68701', '402-640-7770', '', '', '', '', '', '', '5', '', '', '', '', '2015-09-22');
INSERT INTO customerInfo VALUES ('27', '72', 'JEREMY', 'SANNE', '505 DIBBLE ST', '', 'Clearwater', 'Nebraska', '68726', '4028877286', '', '', '4024854646', 'SANNE_SERVICE@YAHOO.COM', '', '', '1', '', '', '', '', '2015-09-22');
INSERT INTO customerInfo VALUES ('28', '72', 'John & Peg', 'Beemer', '84826 561st Ave', '', 'Hoskins', 'Nebraska', '68740', '402-640-1618', '', '', '', '', '', '', '3', '', '', '', '', '2015-09-22');
INSERT INTO customerInfo VALUES ('29', '72', 'Bruce', 'Brester', '1440 Eagle Ridge Circle', '', 'Pierce', 'Nebraska', '68767', '402-649-5430', '', '', '', 'bresterb@midwestbank.com', '', '', '3', '', '', '', '', '2015-09-22');
INSERT INTO customerInfo VALUES ('32', '72', 'Jack', 'Sauser', '511 W. Wayne St.', '', 'Randolph', 'Nebraska', '68771', '402-485-2813', '', '', '', '', '', '', '1', '', '', '', '', '2015-09-23');
INSERT INTO customerInfo VALUES ('33', '72', 'Carol', 'Schlisman', '1105 Charolais', '', 'Norfolk', 'Nebraska', '68701', '402-440-2822', '', '', '', '', '', '', '3', '', '', '', '', '2015-09-23');
INSERT INTO customerInfo VALUES ('34', '72', 'Justin & Carla', 'Wilkinson', '306 Oak St.', '', 'Tilden', 'Nebraska', '68781', 'Justin: 841-9204', '', 'Carla: 841-9267', '', '', '', '', '1', '', '', '', '', '2015-09-23');
INSERT INTO customerInfo VALUES ('35', '72', 'Geraldine', 'Timperley', '708 S. 8th St.', '', 'Norfolk', 'Nebraska', '68701', '371-3144', '', '', '', '', '', '', '1', '', '', '', '', '2015-09-23');
INSERT INTO customerInfo VALUES ('36', '72', 'Mark', 'Ramaeker', '34211 430th St. ', '34211 430th St.', 'Humphrey', 'Nebraska', '68642', '402-920-0099', '', '', '', '', '', '', '3', '', '', '', '', '2015-09-24');
INSERT INTO customerInfo VALUES ('37', '72', 'Richard', 'Stelling', '51303 861st Rd', '51303 861st Rd', 'Orchard', 'Nebraska', '68764', '', '', '402-929-0335', '', '', '', '', '1', '', '', '', '', '2015-09-24');
INSERT INTO customerInfo VALUES ('38', '72', 'Michael', 'Dusek', '84459  Hwy 35', '', 'Norfolk', 'Nebraska', '68701', '402-841-0625', '', '', '', '', '', '', '1', '', '', '', '', '2015-09-24');
INSERT INTO customerInfo VALUES ('39', '72', 'Patty', 'Thiele', '85043 513th Avenue', '', 'Clearwater', 'Nebraska', '68726', '(402) 640-3335', '', '', '', '', '', '', '3', '', '', '', '', '2015-09-24');
INSERT INTO customerInfo VALUES ('40', '72', 'Francisco', 'Medina', '509 E. 22nd St.', '', 'Schuyler', 'Nebraska', '68661', '615-4089', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-01');
INSERT INTO customerInfo VALUES ('41', '72', 'Jessica', 'Froehner', '2675 E. 14th Ave', '', 'Columbus', 'Nebraska', '68601', '562-8735', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-01');
INSERT INTO customerInfo VALUES ('42', '72', 'Doug', 'Storm', '3008 295th Ave', '', 'Albion', 'Nebraska', '68620', '678-3444', '', '', '', '', '', '', '1', '', '', '', '', '2015-10-01');
INSERT INTO customerInfo VALUES ('43', '72', 'Jordan ', 'Turpen', '669 11th Ave', '', 'Columbus', 'Nebraska', '68601', '599-0703', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-01');
INSERT INTO customerInfo VALUES ('44', '72', 'Laura', 'McGuinnis', '56 Lakewood Dr.', '', 'Columbus', 'Nebraska', '68601', '699-2519', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-01');
INSERT INTO customerInfo VALUES ('45', '72', 'Jim & Joyce', 'Kuchar', '3405  Rolling Hills Drive', '', 'Norfolk', 'Nebraska', '68701', '371-0355', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-01');
INSERT INTO customerInfo VALUES ('46', '72', 'Jayson', 'Vice', '1216 N. Lincoln Ave', '', 'York', 'Nebraska', '68467', '363-8308', '', '710-1635', '', '', '', '', '3', '', '', '', '', '2015-10-01');
INSERT INTO customerInfo VALUES ('47', '72', 'Ruby', 'Jurgensen', '2161 412th Rd', '', 'Wisner', 'Nebraska', '68791', '529-6576', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-02');
INSERT INTO customerInfo VALUES ('48', '72', 'Kathy', 'Love', '', '', 'Norfolk', 'Nebraska', '68701', '', '', '', '', '', '', '', '5', '', '', 'Custom Heating', '', '2015-10-02');
INSERT INTO customerInfo VALUES ('49', '72', 'Kevin ', 'Jarecki', '166 D St', '', 'Platte Center', 'Nebraska', '68653', '4022705935', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-02');
INSERT INTO customerInfo VALUES ('50', '72', 'Brad', 'Reisdorf', '', '14022 X Rd', 'Shelby', 'Nebraska', '68662', '910-2064', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-02');
INSERT INTO customerInfo VALUES ('51', '72', 'Keith', 'Dostal', '57479 823 Rd', '', 'Howells', 'Nebraska', '68641', '750-8219', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-02');
INSERT INTO customerInfo VALUES ('52', '72', 'John ', 'Gorrell', '407 N. 28th St.', '', 'Norfolk', 'Nebraska', '68701', '402-750-1347', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-02');
INSERT INTO customerInfo VALUES ('53', '72', 'Richard', 'Stelling', '', '', 'Abie', 'Nebraska', '', '4029920335', '', '', '', '', '', '', '1', '', '', '', '', '2015-10-05');
INSERT INTO customerInfo VALUES ('54', '72', 'Dave & Jennifer', 'Timmerman', '904 Lovely Lane', '', 'Norfolk', 'Nebraska', '68701', '402-750-6962', '', '', '', '', '', '', '4', '', '', '', '', '2015-10-05');
INSERT INTO customerInfo VALUES ('55', '72', 'Jose', 'Parra', '405 N St.      Apt: 15', '', 'Neligh', 'Nebraska', '68756', '640-0429', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-05');
INSERT INTO customerInfo VALUES ('56', '72', 'Trudy', 'Mosel ', '207 North Elm', '', 'Plainview', 'Nebraska', '68769', '402-841-1041', '', '', '', '', '', 'Sun Porch ', '1', '', '', '', '', '2015-10-05');
INSERT INTO customerInfo VALUES ('57', '72', 'Steve', 'McClure', '', '105 Morton Rd. Columbus, NE ', 'Columbus', 'Nebraska', '68601', '402-563-1803', '', '', '', '', '', 'Rental: 2315 22nd St.', '1', '', '', '', '', '2015-10-05');
INSERT INTO customerInfo VALUES ('58', '72', 'Rugosa LLC', '', 'P.O. BOX 1833', '', 'Norfolk', 'Nebraska', '68701', '', '', '', '', '', '', '', '5', 'SHELLEE  HONICEK', '', 'RUGOSA LLC', '', '2015-10-05');
INSERT INTO customerInfo VALUES ('59', '72', 'Andy', 'Starman', '848th Rd', '', 'Elgin', 'Nebraska', '68636', '402-843-6521', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-05');
INSERT INTO customerInfo VALUES ('60', '72', 'Crystal', 'Foltz', '40963 280th ', '', 'Humphrey', 'Nebraska', '68642', '402-920-2339', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-05');
INSERT INTO customerInfo VALUES ('61', '72', 'Shelly', 'Schnelle', '1713 RD 9', '', 'Clarkson', 'Nebraska', '68629', '402-942-2252', '', '', '', '', '', '', '4', '', '', '', '', '2015-10-05');
INSERT INTO customerInfo VALUES ('62', '72', 'Richard', 'Grenz', '705 Linden Lane', '', 'Norfolk', 'Nebraska', '68701', '402-371-8284', '', '', '', '', '', 'WANTS TO INSTALL (1 window) IN APRIL.', '3', '', '', '', '', '2015-10-05');
INSERT INTO customerInfo VALUES ('63', '72', 'Richard ', 'Buckendahl', '55477 834th Rd', '', 'Norfolk', 'Nebraska', '68701', '371-6640', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-05');
INSERT INTO customerInfo VALUES ('64', '72', 'Angela', 'Petersen', '552755 Hwy 20', '', 'Brunswick', 'Nebraska', '68720', '402-649-0929', '', '', '', 'angiepetersen73@plvwtelco.net', '', '1/4 mile east of brunswick turn  north side', '3', '', '', '', '', '2015-10-06');
INSERT INTO customerInfo VALUES ('65', '72', 'Scott', 'Rutten', '1205 8th St.', '', 'Stanton', 'Nebraska', '68779', '402-649-4436', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-06');
INSERT INTO customerInfo VALUES ('195', '72', 'Audrey', 'Forney', '8 Clear Lake Acres', '', 'Columbus', 'Nebraska', '68601', '402-270-7720', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-03');
INSERT INTO customerInfo VALUES ('66', '72', 'MANETTE', 'RICHARDSON', '83949 531ST AVE', '', 'Tilden', 'Nebraska', '68781', '402-368-2928', '', '', '', '', '', 'FROM PDQ- 3 MILES SOUTH ON HWY 45 TO 840TH ROAD - 3 WEST ON 840TH ROAD TO 531ST AVE - 1/2 SOUTH', '1', '', '', '', '', '2015-10-07');
INSERT INTO customerInfo VALUES ('67', '72', 'Paul & Deb', 'Allpress', '3404 Prospect', '', 'Norfolk', 'Nebraska', '68701', '402-371-9192', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-08');
INSERT INTO customerInfo VALUES ('68', '72', 'kevin', 'ingemansen', '2918 14th st', '', 'Columbus', 'Nebraska', '68601', '402-564-5568', '', '', '', '', '', '', '1', '', '', '', '', '2015-10-08');
INSERT INTO customerInfo VALUES ('69', '72', 'Barb ', 'Douglas', '216 N. 5th St.', '', 'Pierce', 'Nebraska', '68767', '', '', '', '', '', '', '', '1', '', '', '', '', '2015-10-08');
INSERT INTO customerInfo VALUES ('70', '72', 'Heather & Hans', 'Goeschel', '955 N. 9th St', '', 'David City', 'Nebraska', '68632', '367-3024', '', '', '', '', '', '', '1', '', '', '', '', '2015-10-08');
INSERT INTO customerInfo VALUES ('71', '72', 'Janelle ', 'Fischer', '312 N. Main St.', 'PO Box 216', 'Leigh', 'Nebraska', '68643', '487-2737', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-08');
INSERT INTO customerInfo VALUES ('72', '72', 'Golden Living Center', '', '2855 40th Ave', '', 'Columbus', 'Nebraska', '68601', '', '', '', '', '', '', '', '3', 'Terry', '402-750-8799', 'Golden Living Center', '', '2015-10-08');
INSERT INTO customerInfo VALUES ('73', '72', 'Bob ', 'Taylor', '3903 14th St.', '', 'Columbus', 'Nebraska', '68601', '276-3030', '', '', '', '', '', '', '1', '', '', '', '', '2015-10-08');
INSERT INTO customerInfo VALUES ('74', '72', 'Everlasting Love Church', '', '4714 27th St.', '', 'Columbus', 'Nebraska', '68601', '', '', '', '', '', '', '', '1', 'Pat Cool', '402-270-1744', 'Everlasting Love Church', '', '2015-10-08');
INSERT INTO customerInfo VALUES ('75', '72', 'Santiago', 'Vasquez', '3520 27th St', '', 'Columbus', 'Nebraska', '68601', '276-6049', '', '', '', '', '', '', '1', '', '', '', '', '2015-10-08');
INSERT INTO customerInfo VALUES ('76', '72', 'Patty', 'Sliva', '701 Main St-Humphrey', '', 'Humphrey', 'Nebraska', '68642', '923-1723', '', '', '', '', '', '', '1', '', '', '', '', '2015-10-09');
INSERT INTO customerInfo VALUES ('77', '72', 'Lanny & Jeannie', 'Young', '1055 S. 4th St.-Albion', '', 'Albion', 'Nebraska', '', '395-6329', '', '', '', '', '', '', '1', '', '', '', '', '2015-10-09');
INSERT INTO customerInfo VALUES ('78', '72', 'Tim &  Michelle', 'Brabec', '56826 825 Rd-Clarkson', '', 'Clarkson', 'Nebraska', '68629', '402-892-3461', '', '', '', '', '', '', '1', '', '', '', '', '2015-10-09');
INSERT INTO customerInfo VALUES ('79', '72', 'Larry', 'Krohn', '86602 545 RD', '', 'Osmond', 'Nebraska', '68765', '402-748-3676', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-09');
INSERT INTO customerInfo VALUES ('80', '72', 'Gena', 'Luhr-Puls', '1009 1st Ave', '', 'Wayne', 'Nebraska', '68787', '375-4936', '', '', '', '', '', '', '1', '', '', '', '', '2015-10-09');
INSERT INTO customerInfo VALUES ('81', '72', 'mary', 'erb', '531 Colfax', '', 'West Point', 'Nebraska', '68788', '4023804204', '', '', '', '', '', 'referred by son DAVE ERB
466 SOUTH COLFAX
WEST POINT, NE 68788', '1', '', '', '', '', '2015-10-09');
INSERT INTO customerInfo VALUES ('82', '72', 'Larry ', 'Petz', '618 S Oak ', '', 'West Point', 'Nebraska', '68788', '402-372-3915', '', '', '', '', '', '', '1', '', '', '', '', '2015-10-09');
INSERT INTO customerInfo VALUES ('83', '72', 'Al', 'Jenkins', '406 7th St. ', '', 'Stanton', 'Nebraska', '68779', '439-2555', '', '841-7453', '', '', '', '', '3', '', '', '', '', '2015-10-12');
INSERT INTO customerInfo VALUES ('84', '72', 'Michael', 'Kuester', '2607 W. Prospect', '', 'Norfolk', 'Nebraska', '68701', '402-640-3597', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-12');
INSERT INTO customerInfo VALUES ('85', '72', 'Rich & Theresa', 'Anderson', '3058 Maple St.', '', 'Emerson', 'Nebraska', '68733', '402-695-2471', '', 'Theresa Cell: 402-369-0119', '', '', '', '', '5', '', '', '', '', '2015-10-12');
INSERT INTO customerInfo VALUES ('86', '72', 'Dave', 'Carter', '701 Northdale Dr.', '', 'Norfolk', 'Nebraska', '68701', '314-3526', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-12');
INSERT INTO customerInfo VALUES ('87', '72', 'Cory', 'Schmidt', '1108 Rose Ln', '', 'Norfolk', 'Nebraska', '68701', '402-649-8350', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-12');
INSERT INTO customerInfo VALUES ('88', '72', 'DERRICK', 'NELSON', '201 SHETLAND PATH', '', 'Norfolk', 'Nebraska', '68701', '402-851-0349', '', '750-5933', '', '', '', '', '1', '', '', '', '', '2015-10-12');
INSERT INTO customerInfo VALUES ('89', '72', 'Donna ', 'Ingoglia ', '1501 Syracuse', '', 'Norfolk', 'Nebraska', '68701', '402-360-3208', '', '', '', '', '', '', '5', '', '', '', '', '2015-10-12');
INSERT INTO customerInfo VALUES ('90', '72', 'Chad', 'Jochum', '1703 Sheridan Dr.', '', 'Norfolk', 'Nebraska', '68701', '640-6933', '', '402-637-3010', '', '', '', '', '3', '', '', '', '', '2015-10-12');
INSERT INTO customerInfo VALUES ('91', '72', 'Ken  & Eileen', 'Petit', '610 W. 6th St.', '', 'Wakefield', 'Nebraska', '68784', '287-2362', '', '369-3513', '', '', '', 'Wife Usually Home during the day.
Referred by Son: Bill Miller(Newman Grove) 
', '5', '', '', '', '', '2015-10-13');
INSERT INTO customerInfo VALUES ('92', '72', 'Merry', 'Braun', '300 Aspen Dr.', '', 'Norfolk', 'Nebraska', '68701', '649-7326', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-13');
INSERT INTO customerInfo VALUES ('93', '72', 'Dennis & Mary', 'Mrsny', '833735 556th Ave', '', 'Norfolk', 'Nebraska', '68701', '371-7914', '', '640-4922', '', '', '', '', '3', '', '', '', '', '2015-10-13');
INSERT INTO customerInfo VALUES ('94', '72', 'Dennis & Mary', 'Mrsny', '833735 556th Ave', '', 'Norfolk', 'Nebraska', '68701', '371-7914', '', '640-4922', '', '', '', '', '3', '', '', '', '', '2015-10-13');
INSERT INTO customerInfo VALUES ('95', '72', 'Paul & Shannon', 'Filsinger', '310 Brentwood Dr.', '', 'Norfolk', 'Nebraska', '68701', '379-3911', '', '', '', '', '', '', '1', '', '', '', '', '2015-10-14');
INSERT INTO customerInfo VALUES ('96', '72', 'Brian', 'Anderson', '305 N. Main St.', '', 'Pilger', 'Nebraska', '68768', '369-0033', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-14');
INSERT INTO customerInfo VALUES ('98', '72', 'Danielle ', 'Kubes', '306 W Norfolk Ave', '', 'Norfolk', 'Nebraska', '68701', '402649-3075', '', '', '', 'djkubes@gmail.com', '', '', '5', '', '', '', '', '2015-10-15');
INSERT INTO customerInfo VALUES ('99', '72', 'Tony ', 'Hoffman', '1300 Galeta Unit C', '', 'Norfolk', 'Nebraska', '68701', '649-1956', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-16');
INSERT INTO customerInfo VALUES ('100', '72', 'Bob', 'Hering', '303 S. Boyer', '', 'Battle Creek', 'Nebraska', '68715', '706-564-6936', '', '', '', '', '', '', '5', '', '', '', '', '2015-10-16');
INSERT INTO customerInfo VALUES ('101', '72', 'Looking Glass Methodist Church', '', '430 St               47893 400th St-Lindsay', '', 'Newman Grove', 'Nebraska', '68758', '', '', '', '', '', '', '', '3', 'Charles Borg', '428-4975        920-1783', 'Looking Glass Methodist Church', '', '2015-10-16');
INSERT INTO customerInfo VALUES ('102', '72', 'Rita & John', 'Hoebbing', '1869 W. Calle Columbo', '', 'Columbus', 'Nebraska', '68601', '563-2238', '', '270-3146', '', '', '', '', '3', '', '', '', '', '2015-10-16');
INSERT INTO customerInfo VALUES ('103', '72', 'Dean ', 'Korus', '203 S. 4th St.', '', 'Humphrey', 'Nebraska', '68642', '910-8842', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-16');
INSERT INTO customerInfo VALUES ('371', '72', 'Jeanie', 'Booth', '84707 Airport Rd', '', 'Neligh', 'Nebraska', '', '402-841-2326', '', '', '', 'jdbooth@frontiernet.net', '', '', '3', '', '', '', '', '2016-01-22');
INSERT INTO customerInfo VALUES ('105', '72', 'Tracy ', 'Cook', '3302 Mach 1 ', '', 'Norfolk', 'Nebraska', '68701', '402-316-7710', '', '402-860-5780', '', '', '', 'broken patio door estimate for new scheduled for Jerry on Oct 19th at 930am ', '3', '', '', '', '', '2015-10-16');
INSERT INTO customerInfo VALUES ('106', '72', 'Mary', 'Rocheford', '119 North 5th st', '', 'Howells', 'Nebraska', '68641', '', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-19');
INSERT INTO customerInfo VALUES ('107', '72', 'Mick & Kim', 'Vogt', '505 Kent St.', '', 'Madison', 'Nebraska', '68748', '454-2930', '', '', '', '', '', '', '1', '', '', '', '', '2015-10-19');
INSERT INTO customerInfo VALUES ('108', '72', 'Chris & Jenn', 'Geidner', '808 Nebraska Ave', '', 'Wayne', 'Nebraska', '68787', '402-375-8487', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-19');
INSERT INTO customerInfo VALUES ('109', '72', 'Gary', 'Boehle', '', '1120 Douglas St-Wayne NE 68787', 'Abie', 'Nebraska', '', '402-375-2511', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-19');
INSERT INTO customerInfo VALUES ('110', '72', 'Travis ', 'Wemhoff', '405 Ash St', '', 'Creston', 'Nebraska', '', '920-0870', '', '', '', '', '', '', '1', '', '', '', '', '2015-10-19');
INSERT INTO customerInfo VALUES ('111', '72', 'Andrea', 'Rodriguez', '413 E. Nebraska Ave', '', 'Norfolk', 'Nebraska', '68701', '750-9676', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-19');
INSERT INTO customerInfo VALUES ('112', '72', 'Lance', 'Novacek', '1903 Carmel Dr.', '', 'Norfolk', 'Nebraska', '68701', '308-750-4245', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-20');
INSERT INTO customerInfo VALUES ('113', '72', 'KARLA', 'FREY', '85824 519TH AVE.', '', 'Clearwater', 'Nebraska', '68726', '', '', '', '', '', '', '', '1', '', '', '', '', '2015-10-20');
INSERT INTO customerInfo VALUES ('114', '72', 'Frank', 'Morrison', '85824 519th Ave.', '', 'Clearwater', 'Nebraska', '68726', '402-929-0387', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-20');
INSERT INTO customerInfo VALUES ('115', '72', 'Katrina', 'Lange', '300 N. 3rd St.', '', 'Ulysses', 'Nebraska', '68669', '310-2131', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-20');
INSERT INTO customerInfo VALUES ('116', '72', 'Karin', 'Phillips', '4019 13th St.', '', 'Columbus', 'Nebraska', '68601', '402-276-1154', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-20');
INSERT INTO customerInfo VALUES ('117', '72', 'Curt', 'Nielsen', '1811 Imperial Rd', '', 'Norfolk', 'Nebraska', '68701', '', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-20');
INSERT INTO customerInfo VALUES ('118', '72', 'DJ', 'Denn', '3406 Foxridge', '', 'Norfolk', 'Nebraska', '68701', '402-371-2127', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-20');
INSERT INTO customerInfo VALUES ('119', '73', 'TERRY', '', '2855 40TH AVE.', '', 'Columbus', 'Nebraska', '68601', '402-750-8799', '', '', '', '', '', '', '1', '', '', 'GOLDEN LIVING CENTER', '', '2015-10-20');
INSERT INTO customerInfo VALUES ('120', '72', 'Susan', 'Askew', '700 Linden Lane', '', 'Norfolk', 'Nebraska', '68701', '992-8109', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-20');
INSERT INTO customerInfo VALUES ('121', '72', 'Sandra Bruns', 'Joel Kratke', '57985 858 Rd', '', 'Wakefield', 'Nebraska', '68784', '402-369-1041', '', '402-369-2290', '', '', '', '', '3', '', '', '', '', '2015-10-20');
INSERT INTO customerInfo VALUES ('122', '72', 'Willard', 'Hart', '504 E. Maple', '', 'Norfolk', 'Nebraska', '68701', '402-371-5599', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-20');
INSERT INTO customerInfo VALUES ('123', '72', 'Sara ', 'McClary', '205 S. Birch', '', 'Norfolk', 'Nebraska', '68701', '841-3233', '', '', '371-5300', '', '', '', '3', '', '', '', '', '2015-10-20');
INSERT INTO customerInfo VALUES ('124', '72', 'Larry ', 'Sohler', '320 Sherwood Lane', '', 'Norfolk', 'Nebraska', '68701', '4029927998', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-20');
INSERT INTO customerInfo VALUES ('344', '72', 'Joe & Jenna', 'Rehak', '391 Rd X', '', 'Clarkson', 'Nebraska', '', '402-276-0511', '', '', '', '', '', '', '3', '', '', '', '', '2016-01-13');
INSERT INTO customerInfo VALUES ('126', '72', 'Kelly', 'Muchmore', '1531 7th St', '', 'Duncan', 'Nebraska', '68634', '402-270-9951', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-20');
INSERT INTO customerInfo VALUES ('127', '72', 'Gilbert', 'Grimm', '1201 N 25th', '', 'Norfolk', 'Nebraska', '68701', '4023710749', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-20');
INSERT INTO customerInfo VALUES ('128', '72', 'Robert and Lori', 'Uecker', '84378 541st Ave', '', 'Meadow Grove', 'Nebraska', '68752', '4026342365', '', '4027509485', '', '', '', '', '5', '', '', '', '', '2015-10-20');
INSERT INTO customerInfo VALUES ('355', '72', 'Chris', 'Albrecht', '314 Park', '', 'Magnet', 'Nebraska', '', '712-251-1450', '', '', '', '', '', '', '3', '', '', '', '', '2016-01-14');
INSERT INTO customerInfo VALUES ('130', '72', 'Nancy', 'Karmann', '2607 E. 38th St. ', '', 'Columbus', 'Nebraska', '68601', '276-5885 Melody Hataway', '', '276-5799 Dave Hataway', '', '', '', '', '1', '', '', '', '', '2015-10-21');
INSERT INTO customerInfo VALUES ('132', '72', 'Neil', 'McClary', '54049 841st Rd', '', 'Meadow Grove', 'Nebraska', '68752', '4026342969', '', '', '', '', '', 'curve before meadow grove by bridge south to 841st rd west 1st place 1/2 mile northside ', '3', '', '', '', '', '2015-10-21');
INSERT INTO customerInfo VALUES ('133', '72', 'dean', 'brewer', '109 ash st', '', 'Lindsay', 'Nebraska', '68644', '402-920-1967', '', '402-920-1186', '', '', '', '', '1', '', '', '', '', '2015-10-22');
INSERT INTO customerInfo VALUES ('134', '72', 'Ryan', 'Baumgard', '3304 Mach 1 Dr.', '', 'Norfolk', 'Nebraska', '68701', '605-595-3293', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-22');
INSERT INTO customerInfo VALUES ('135', '72', 'Al', 'Collison', '426 S. 5th St. ', '', 'Pierce', 'Nebraska', '68767', '402-379-9695', '', '', '', '', '', '', '5', '', '', '', '', '2015-10-22');
INSERT INTO customerInfo VALUES ('136', '72', 'Mary ', 'Loseke', '18428 280th St.', '', 'Columbus', 'Nebraska', '68601', '563-2985', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-22');
INSERT INTO customerInfo VALUES ('137', '72', 'Pete & Kathy', 'Hastreiter', '83441 557th Ave', '', 'Norfolk', 'Nebraska', '68701', '920-0684', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-23');
INSERT INTO customerInfo VALUES ('138', '72', 'Deb', 'Kallenbach', '271 3rd Ave', '', 'Columbus', 'Nebraska', '68601', '563-0362', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-23');
INSERT INTO customerInfo VALUES ('139', '72', 'Corey', 'Pilakowski', '', 'PO Box 245', 'Genoa', 'Nebraska', '68640', '948-0206', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-23');
INSERT INTO customerInfo VALUES ('140', '72', 'Tiffani & Lee', 'Stegeman', '1010 Grainland', '', 'Wayne', 'Nebraska', '68787', '605-759-0915', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-23');
INSERT INTO customerInfo VALUES ('141', '72', 'Kristie ', 'Kolb', '522Rd H', '', 'Schuyler', 'Nebraska', '68661', '402-942-2604', '', '', '', '', '', 'north of hwy 30 to rd h the only house between rd 5 and rd 6', '3', '', '', '', '', '2015-10-23');
INSERT INTO customerInfo VALUES ('142', '72', 'Jeff', 'Russo', '604 E Klug', '', 'Norfolk', 'Nebraska', '68701', '992-8728', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-26');
INSERT INTO customerInfo VALUES ('143', '72', 'Roger', 'Borgman', '1205 Eldorado Rd', '', 'Norfolk', 'Nebraska', '68701', '402-379-0677', '', '402-379-9695', '', '', '', '', '3', '', '', '', '', '2015-10-26');
INSERT INTO customerInfo VALUES ('144', '72', 'Jon', 'Zavadil', '', '315 Pershing Rd', 'Columbus', 'Nebraska', '68601', '402-270-3091', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-26');
INSERT INTO customerInfo VALUES ('145', '72', 'Duane', 'Bright', '13898 T Rd', '', 'Shelby', 'Nebraska', '68662', '402-527-5622', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-26');
INSERT INTO customerInfo VALUES ('146', '72', 'Lanny', 'Fisher', '2960 18th Ave.', '', 'Columbus', 'Nebraska', '68601', '402-920-0321', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-26');
INSERT INTO customerInfo VALUES ('147', '72', 'lanny', 'fischer', '2960 18th ave.', '', 'Columbus', 'Nebraska', '68601', '402-920-0321', '', '', '', '', '', '', '1', '', '', '', '', '2015-10-26');
INSERT INTO customerInfo VALUES ('148', '72', 'Bob ', 'Pollock', '54345 550th Ave', '', 'Norfolk', 'Nebraska', '68701', '640-5058', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-26');
INSERT INTO customerInfo VALUES ('149', '72', 'Tony', 'Squire', '500 W. 6th', '', 'Lindsay', 'Nebraska', '68644', '402-608-0337', '', '402-276-4690', '', '', '', '', '3', '', '', '', '', '2015-10-26');
INSERT INTO customerInfo VALUES ('150', '72', 'Roy', 'Walter', '370 10th Ave', '', 'Columbus', 'Nebraska', '68601', '402-270-1019', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-26');
INSERT INTO customerInfo VALUES ('151', '72', 'Brendan', 'Janssen', '729 S. 11th St.', '', 'Norfolk', 'Nebraska', '68701', '402-649-7086', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-26');
INSERT INTO customerInfo VALUES ('152', '72', 'Ponca Housing', '', '', '1501 Michigan Ave', 'Norfolk', 'Nebraska', '68701', 'Office: 379-8224', '', '', '', '', '', '', '5', 'Alex', '402-649-0978', 'Ponca Housing', '', '2015-10-26');
INSERT INTO customerInfo VALUES ('153', '72', 'Brian', 'Lind', '2009 N Eastwood', '', 'Norfolk', 'Nebraska', '68701', '302-4509', '', '379-2590-Deb', '', '', '', '', '3', '', '', '', '', '2015-10-26');
INSERT INTO customerInfo VALUES ('154', '72', 'Steve & Linda', 'Eggers', 'PO Box 516', '84254 535th Ave', 'Tilden', 'Nebraska', '68781', 'Holly: 841-0766', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-27');
INSERT INTO customerInfo VALUES ('155', '72', 'Kelli', 'Berryman', '802 N. Birch', '', 'Norfolk', 'Nebraska', '68701', '402-750-3629', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-27');
INSERT INTO customerInfo VALUES ('156', '72', 'John & Ashley', 'Lammli', '2303 Prospect Ave', '', 'Norfolk', 'Nebraska', '68701', '913-302-7706', '', '', '', '', '', '', '5', '', '', '', '', '2015-10-27');
INSERT INTO customerInfo VALUES ('157', '72', 'Jeff', 'Jensen', '2616 W. Madison Ave', '', 'Norfolk', 'Nebraska', '68701', '750-9009', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-28');
INSERT INTO customerInfo VALUES ('158', '72', 'James', 'Lentz', '211 E. Canfield', '', 'Coleridge', 'Nebraska', '68727', '402-283-4024', '', '308-258-0013', '', '', '', '', '3', '', '', '', '', '2015-10-28');
INSERT INTO customerInfo VALUES ('159', '72', 'Jared', 'Michaels', '503 N. Boxelder', '', 'Norfolk', 'Nebraska', '68701', '750-8997', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-28');
INSERT INTO customerInfo VALUES ('160', '72', 'Paula ', 'Hoeft', '2104 skyline ', '', 'Norfolk', 'Nebraska', '68701', '3032040250', '', '', '', 'paula.hoeft@icloud.com', '', '', '3', 'Paula', '', '', '', '2015-10-28');
INSERT INTO customerInfo VALUES ('161', '72', 'Muffin ', 'Morris', '508 logan', '', 'Wayne', 'Nebraska', '68787', '605-202-0577', '', '', '', 'mumorris1@wsc.edu', '', '', '3', '', '', '', '', '2015-10-28');
INSERT INTO customerInfo VALUES ('162', '72', 'Terri', 'Davis', '2959 18th Ave', '', 'Columbus', 'Nebraska', '68601', '402-910-3246', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-29');
INSERT INTO customerInfo VALUES ('163', '72', 'Wanda', 'Wondercheck', '2083 300th Ave', '', 'Albion', 'Nebraska', '68620', '402-395-2287', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-29');
INSERT INTO customerInfo VALUES ('164', '72', 'Doug', 'Demuth', '1922 Keene Dr', '', 'Columbus', 'Nebraska', '68601', '402-910-2264', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-29');
INSERT INTO customerInfo VALUES ('165', '72', 'Justin ', 'Wetjen', '', 'PO Box 417       ', 'Humphrey', 'Nebraska', '68642', '923-0606', '', '920-0422', '', '', '', '', '3', '', '', '', '', '2015-10-29');
INSERT INTO customerInfo VALUES ('166', '72', 'Robert ', 'Oswald', '411 Market Place', '', 'Norfolk', 'Nebraska', '68701', '430-9725', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-29');
INSERT INTO customerInfo VALUES ('167', '72', 'Ron', 'Tuma', '2916 33rd St', '', 'Columbus', 'Nebraska', '68601', '564-7634', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-29');
INSERT INTO customerInfo VALUES ('168', '72', 'Charles & Deb ', 'Misfeldt', '2803 Ruthann Circle', '', 'Norfolk', 'Nebraska', '68701', '371-4984', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-29');
INSERT INTO customerInfo VALUES ('321', '72', 'Ernest ', 'Brabec', '121 Spruce St', '', 'Clarkson', 'Nebraska', '', '4028923580', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-24');
INSERT INTO customerInfo VALUES ('322', '72', 'Mona ', 'Michaels', '402 N 7TH BOX 188', '', 'Plainview', 'Nebraska', '', '', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-24');
INSERT INTO customerInfo VALUES ('170', '72', 'Shauna', 'Seebohm', '1020 5th St.', '', 'Columbus', 'Nebraska', '68601', '276-2780', '', '', '', '', '', '', '4', '', '', '', '', '2015-10-30');
INSERT INTO customerInfo VALUES ('171', '72', 'Kathy', 'Fadschild', '29493 205th Ave', '', 'Columbus', 'Nebraska', '68601', '402-910-3479', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-30');
INSERT INTO customerInfo VALUES ('172', '72', 'Bryan ', 'Bahns', '411 E. Park', '', 'Norfolk', 'Nebraska', '68701', '860-0264', '', '', '', '', '', '(Matt Claussen original owner)-No warranty was transferred', '3', '', '', '', '', '2015-10-30');
INSERT INTO customerInfo VALUES ('173', '72', 'Deloris', 'Kneifel', '764 27th Ave', '', 'Columbus', 'Nebraska', '68601', '564-3067', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-30');
INSERT INTO customerInfo VALUES ('174', '72', 'Tim', 'Parker', '137 E. Parkway', '', 'Columbus', 'Nebraska', '68601', '562-6450', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-30');
INSERT INTO customerInfo VALUES ('175', '72', 'Doris (Dorri)', 'Chrisp', '3172 Fairlane Ave', '', 'Columbus', 'Nebraska', '68601', '402-563-1928', '', '', '', '', '', 'built in 1981 will pay cash;-)', '1', '', '', '', '', '2015-10-30');
INSERT INTO customerInfo VALUES ('176', '72', 'Jim ', 'Luedtke', '56721 822nd Rd', '', 'Clarkson', 'Nebraska', '68629', '402-920-0204', '', '', '', '', '', '1970-72 house  from 91/57 intersection - 2 miles north and 1 1/4 East  ', '3', '', '402-920-0204', '', '', '2015-10-30');
INSERT INTO customerInfo VALUES ('177', '72', 'Rick ', 'Wilmes', '1004 Redick Ave', '', 'Creighton', 'Nebraska', '', '402-929-3955', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-30');
INSERT INTO customerInfo VALUES ('178', '72', 'Bob and Karla', 'Linsteadt', '1501 W. Norfolk Ave', '', 'Norfolk', 'Nebraska', '68701', '402-371-9158', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-30');
INSERT INTO customerInfo VALUES ('179', '72', 'Peg', 'Webster', '2214 Highview Dr.', '', 'Wayne', 'Nebraska', '68787', '402-369-1118', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-02');
INSERT INTO customerInfo VALUES ('180', '72', 'Delores', 'Jaeke', '307 Willow', '', 'Norfolk', 'Nebraska', '68701', '402-371-0069', '', '', '', '', '', '', '3', '', '371-0069', '', '', '2015-11-02');
INSERT INTO customerInfo VALUES ('181', '72', 'Dillon & Whitney', 'Busch', '805 Irving St.', '', 'Fullerton', 'Nebraska', '68638', '308-550-0777', '', '741-2828', '', '', '', '', '3', '', '', '', '', '2015-11-02');
INSERT INTO customerInfo VALUES ('182', '72', 'Glenda', 'Liebig', '2921 8th St.', '', 'Columbus', 'Nebraska', '68601', '402-270-4195', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-02');
INSERT INTO customerInfo VALUES ('183', '72', 'Carrie', 'Brandt', '1204 Meadow Dr', '', 'Norfolk', 'Nebraska', '68701', '402-750-9112', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-02');
INSERT INTO customerInfo VALUES ('184', '72', 'Melissa ', 'Hyde', '', '4530 31st St.', 'Columbus', 'Nebraska', '68601', '276-8761', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-02');
INSERT INTO customerInfo VALUES ('185', '72', 'JoAnn', 'Meyer', '1308  Madison Ave', '', 'Norfolk', 'Nebraska', '68701', '371-7573', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-02');
INSERT INTO customerInfo VALUES ('186', '72', 'Jackie ', 'Samway', '902 Quincy St', '', 'Madison', 'Nebraska', '68748', '4027505526', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-02');
INSERT INTO customerInfo VALUES ('303', '72', 'Todd & Lynette', 'Kasik', '110 Taylor Creek', '', 'Madison', 'Nebraska', '', '402-454-2351', '', 'Lynette: 402-992-1850', '', '', '', '', '3', '', '', '', '', '2015-12-22');
INSERT INTO customerInfo VALUES ('188', '72', 'Dennis', 'Beltz', '406 E. Park', '', 'Norfolk', 'Nebraska', '68701', '402-640-5555', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-02');
INSERT INTO customerInfo VALUES ('189', '72', 'Tara', 'Ward', '213 S. Maple', '', 'Plainview', 'Nebraska', '', '402-929-3858', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-02');
INSERT INTO customerInfo VALUES ('190', '72', 'Randall and Connie', 'Bargstadt', '84981 569th Ave', '', 'Winside', 'Nebraska', '68790', '4022864951', '', '4026402747', '', '', '', '', '3', '', '', '', '', '2015-11-02');
INSERT INTO customerInfo VALUES ('191', '73', 'Columbus Aquatic Center', '', '1783 10th Ave', '', 'Columbus', 'Nebraska', '68601', '563-3222', '', '', '', '', '', '', '3', '', '', 'Columbus Aquatic Center       ', '', '2015-11-02');
INSERT INTO customerInfo VALUES ('192', '72', 'Jeanette ', 'Helmer', '23122 430th st', '', 'Humphrey', 'Nebraska', '68642', '4029200078', '', '', '', 'jeanette@bellerandbackes.com', '', '', '3', '', '', '', '', '2015-11-02');
INSERT INTO customerInfo VALUES ('193', '72', 'Wanda', 'Borowiak', '2836 E. 38th St.', '', 'Columbus', 'Nebraska', '68601', '402-276-5546', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-03');
INSERT INTO customerInfo VALUES ('194', '72', 'John', 'Badje', '3218 17th St.', '', 'Columbus', 'Nebraska', '68601', '402-942-9501', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-03');
INSERT INTO customerInfo VALUES ('196', '72', 'Kathy ', 'Patras', '609 Iowa', '', 'Clearwater', 'Nebraska', '68726', '4024852552', '', '4028416544', '', 'kspatras@nntc.net', '', '', '3', '', '', '', '', '2015-11-03');
INSERT INTO customerInfo VALUES ('197', '72', 'Marg', 'Houston', '', '', 'Emmet', 'Nebraska', '68743', '4023401903', '', '', '', '', '', '2 1/2 miles west of Emmet hog barns south side turn south west right away that is the driveway  white house', '3', '', '', '', '', '2015-11-03');
INSERT INTO customerInfo VALUES ('198', '72', 'David ', 'Nesladek', '450 15th Rd Lot #1', '', 'West Point', 'Nebraska', '68788', 'Dan: 380-2133', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-03');
INSERT INTO customerInfo VALUES ('199', '72', 'Ken', 'Gall', '57047 825TH ROAD', '', 'Clarkson', 'Nebraska', '68629', '402-750-7486', '', '', '', '', '', '', '1', '', '', '', '', '2015-11-04');
INSERT INTO customerInfo VALUES ('200', '72', 'Richard', 'Smith', '760 Centennial Pl.', '', 'Columbus', 'Nebraska', '68601', '402-606-8486', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-04');
INSERT INTO customerInfo VALUES ('201', '72', 'Greg & Carla ', 'Pippitt', '86920 574th Ave ', '', 'Laurel', 'Nebraska', '68745', '402-256-3635', '', '402-375-0622 (Greg)', '', '', '', 'He\'s a farmer, Carla called in but Greg will be the one to set up with ', '3', '', '', '', '', '2015-11-05');
INSERT INTO customerInfo VALUES ('202', '72', 'Karen ', 'Fundus', '308 South 12th St ', '', 'Norfolk', 'Nebraska', '67801', '402-750-77207', '', '', '', '', '', 'rental house repeat customer', '3', '', '', '', '', '2015-11-05');
INSERT INTO customerInfo VALUES ('203', '72', 'Wes & Kelly ', 'Van Ert', '201 Main St', '', 'Battle Creek', 'Nebraska', '68715', '739-1952', '', '', '', '', '', '', '4', '', '', '', '', '2015-11-06');
INSERT INTO customerInfo VALUES ('204', '72', 'Steve & Sue ', 'Falk', '55937 847th Rd', '', 'Hoskins', 'Nebraska', '68740', '402-841-7920', '', '', '', '', '', '', '5', '', '', '', '', '2015-11-06');
INSERT INTO customerInfo VALUES ('205', '72', 'Leon and Pamela ', 'Handke', '83937 Eagle Ridge rd', '', 'Norfolk', 'Nebraska', '68701', '', '', '', '', '', '', '', '1', '', '402-649-2350', '', '', '2015-11-06');
INSERT INTO customerInfo VALUES ('206', '72', 'Mike', 'Wiedeman', '304 E. Herman', '', 'Battle Creek', 'Nebraska', '', '', '', '', '', '', '', '', '1', '', '', '', '', '2015-11-06');
INSERT INTO customerInfo VALUES ('207', '72', 'M&J Roofing', '', '', '', 'Norfolk', 'Nebraska', '', '649-6422', '', '', '', '', '', '', '3', '', '', 'M&J Roofing', '', '2015-11-06');
INSERT INTO customerInfo VALUES ('208', '72', 'Angie', 'Beiermann', '621 W 1st St', '', 'Wayne', 'Nebraska', '68787', '518-8184', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-09');
INSERT INTO customerInfo VALUES ('209', '72', 'Sergio', 'Deanda', '2580 3rd Ave.', '', 'Columbus', 'Nebraska', '68601', '402-270-2238', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-09');
INSERT INTO customerInfo VALUES ('210', '72', 'Deb', 'Arter', '1106 E Sycamore', '', 'Norfolk', 'Nebraska', '68701', '303-517-9921', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-10');
INSERT INTO customerInfo VALUES ('211', '72', 'dean and pat', 'chapman', '1501 south chestnut', '', 'Norfolk', 'Nebraska', '68701', '402-379-2046', '', '', '', '', '', '', '1', '', '', '', '', '2015-11-10');
INSERT INTO customerInfo VALUES ('212', '72', 'Jason', 'Doele', '2300 Random Rd', '', 'Norfolk', 'Nebraska', '68701', '371-3100', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-11');
INSERT INTO customerInfo VALUES ('213', '72', 'Zack', 'Lindsley', '310 Oak St.', '', 'Creston', 'Nebraska', '68631', '910-0959', '', '', '', 'zack.linsdley@doane.edu', '', '', '3', '', '', '', '', '2015-11-11');
INSERT INTO customerInfo VALUES ('214', '72', 'Rob & Corrie ', 'Starkey', '801 W. 10th St.', '', 'Neligh', 'Nebraska', '68756', '402-929-3907', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-11');
INSERT INTO customerInfo VALUES ('215', '72', 'Judy ', 'Merten', '2693 NE39', '', 'Albion', 'Nebraska', '68620', '4027411720', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-11');
INSERT INTO customerInfo VALUES ('216', '72', 'Laura ', 'Nelson', '107 N 5th', '', 'Newman Grove', 'Nebraska', '68758', '4029201181', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-11');
INSERT INTO customerInfo VALUES ('217', '72', 'Mikal', 'Shalikow', '115 S. 9th St. ', '', 'Newman Grove', 'Nebraska', '68758', '402-750-5697', '', '', '402-447-6294', '', '', '', '3', '', '', '', '', '2015-11-12');
INSERT INTO customerInfo VALUES ('218', '72', 'Steve ', 'Anderson', '4 Driftwood Dr.', '', 'Columbus', 'Nebraska', '68601', '402-910-1858', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-12');
INSERT INTO customerInfo VALUES ('219', '72', 'Eldon', 'Christensen', '14232 280th St', '', 'Columbus', 'Nebraska', '68601', '402-910-1761', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-12');
INSERT INTO customerInfo VALUES ('220', '72', 'Keith', 'Shonka', '4251 D Rd', '', 'Bellwood', 'Nebraska', '68624', '402-910-8909', '', '', '', '', '', 'Call when comes to Norfolk-He may pick up from Norfolk. Needs them ASAP', '3', '', '', '', '', '2015-11-12');
INSERT INTO customerInfo VALUES ('221', '72', 'Walter & Dorothy', 'Johnson', '820 E. Hynes', '', 'O\'Neill', 'Nebraska', '68763', '340-6224', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-12');
INSERT INTO customerInfo VALUES ('222', '72', 'Bill ', 'Lamm', '511 N. Pine St', '', 'Norfolk', 'Nebraska', '68701', '640-8112', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-12');
INSERT INTO customerInfo VALUES ('223', '72', 'Jim ', 'Wichman', '1616 W. Berry Hill Dr', '', 'Norfolk', 'Nebraska', '68701', '640-7146', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-12');
INSERT INTO customerInfo VALUES ('224', '72', 'Joel', 'Putters', '84030 562nd Ave', '', 'Stanton', 'Nebraska', '68779', '402-750-0735', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-12');
INSERT INTO customerInfo VALUES ('225', '72', 'Tilden Housing Authority', '', '', '600 Gile Creek', 'Tilden', 'Nebraska', '68781', '649-2960', '', '', '', '', '', '', '4', '', '', 'Tilden Housing Authority', '', '2015-11-12');
INSERT INTO customerInfo VALUES ('226', '72', 'Arvyn & Reta ', 'Neuhaus', '84953 562nd Ave', '', 'Hoskins', 'Nebraska', '68730', '750-6656', '', '565-4864', '', '', '', '', '3', '', '', '', '', '2015-11-12');
INSERT INTO customerInfo VALUES ('227', '72', 'Steve', 'Jorgensen', '312 Vroman St', '', 'Winside', 'Nebraska', '68790', '286-4328', '', '402-480-5513', '', '', '', 'Customer would like to wait until After January 1, 2016 to install her windows. Doesnt want to have to move around her Christmas tree....she will have it down by the 1st.', '3', '', '', '', '', '2015-11-13');
INSERT INTO customerInfo VALUES ('228', '72', 'Jason ', 'Feddern', '806 S. 5th St.', '', 'Norfolk', 'Nebraska', '68701', '640-7845', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-16');
INSERT INTO customerInfo VALUES ('229', '72', 'Charlotte', 'Reifert', '55956 845 Rd', '', 'Norfolk', 'Nebraska', '68701', '402-860-0891', '', '', '', '', '', '', '4', '', '', '', '', '2015-11-16');
INSERT INTO customerInfo VALUES ('230', '72', 'Jose & Odilia', 'Leon', '116 Norfolk Ave', '', 'Norfolk', 'Nebraska', '68701', '371-4778', '', '402-992-2612', '', '', '', '', '4', '', '', '', '', '2015-11-16');
INSERT INTO customerInfo VALUES ('231', '72', 'Gary', 'Kopietz', '83910 563rd Ave.', '', 'Stanton', 'Nebraska', '68779', '402-640-4885', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-16');
INSERT INTO customerInfo VALUES ('232', '72', 'Don', 'Maguire', '607 Cedar', '', 'Norfolk', 'Nebraska', '68701', '402-649-4533', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-16');
INSERT INTO customerInfo VALUES ('233', '72', 'Kylee & Tyler', 'Carey', '2309 18th St.', '', 'Columbus', 'Nebraska', '68601', '308-390-4642', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-16');
INSERT INTO customerInfo VALUES ('234', '72', 'Randy & Jody', 'Peters', '2907 Dover Dr.', '', 'Norfolk', 'Nebraska', '68701', '402-760-4765', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-17');
INSERT INTO customerInfo VALUES ('235', '72', 'Becky', 'Wulf', '902 S. Pine St', '', 'Norfolk', 'Nebraska', '68701', '640-4573', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-17');
INSERT INTO customerInfo VALUES ('236', '72', 'Matt', 'Kampschneider', '1305 Sunrise Dr.', '', 'Norfolk', 'Nebraska', '68701', '402-992-4610', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-17');
INSERT INTO customerInfo VALUES ('237', '72', 'Dale', 'Pelster', '', '', 'Elgin', 'Nebraska', '68636', '402-929-0597', '', '', '', '', '', 'NORTH OF ELGIN HOUSE RIGHT BY THE POPULATION SIGN WHITE WEST SIDE OF HWY', '3', '', '', '', '', '2015-11-20');
INSERT INTO customerInfo VALUES ('275', '72', 'Joan ', 'Melcher', '106 N. Maple St.', '', 'Lindsay', 'Nebraska', '', '4026495738', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-18');
INSERT INTO customerInfo VALUES ('276', '72', 'Pam', 'Schlote', '55491 839 Rd', '', 'Battle Creek', 'Nebraska', '', '402-675-6002', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-18');
INSERT INTO customerInfo VALUES ('239', '72', 'rick ', 'schack ', '1330 w church st ', '', 'Albion', 'Nebraska', '', '4023952115', '', '4023952205', '', '', '', '', '3', '', '', '', '', '2015-11-23');
INSERT INTO customerInfo VALUES ('240', '72', 'Maria', 'Babel', '113 N 5th St.', 'P.O. Box 216', 'Newman Grove', 'Nebraska', '68758', '402-447-6144', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-23');
INSERT INTO customerInfo VALUES ('241', '72', 'Dave', 'Braun', '510 Hillcrest', '', 'Wayne', 'Nebraska', '68787', '402-369-1472', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-23');
INSERT INTO customerInfo VALUES ('242', '72', 'Tyler ', 'Schmidt', '500 South 6th St', '', 'Norfolk', 'Nebraska', '68701', '402-992-2128', '', '', '', '', '', 'Estimate Big Window, Big Front Window ', '1', '', '', '', '', '2015-11-25');
INSERT INTO customerInfo VALUES ('243', '72', 'Trisha ', 'Peters', '913 9th st ', '', 'Wisner', 'Nebraska', '68791', '4025180675', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-25');
INSERT INTO customerInfo VALUES ('244', '72', 'Laine', 'Wiegard', '86530 Old Hwy 81', '', 'Norfolk', 'Nebraska', '68701', '379-3027', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-25');
INSERT INTO customerInfo VALUES ('245', '72', 'Dave', 'Freudenburg', '1610 W. Benjamin Ave.', '', 'Norfolk', 'Nebraska', '68701', '402-640-6112', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-30');
INSERT INTO customerInfo VALUES ('246', '72', 'Steve ', 'Shoemaker', '207 N 18th ', '', 'Norfolk', 'Nebraska', '68701', '402-379-1277', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-01');
INSERT INTO customerInfo VALUES ('323', '72', 'Tom', 'Schmitz', '414 Walnut - rental', '412 Walnut - Home address', 'Wayne', 'Nebraska', '', 'cell - 402-375-0412', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-28');
INSERT INTO customerInfo VALUES ('248', '72', 'Jerry & Kathy', 'Pfeifer', '3658 50th Ave.', '', 'Columbus', 'Nebraska', '68601', '402-910-2421', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-07');
INSERT INTO customerInfo VALUES ('249', '72', 'Tami', 'Kruse', '2160 24th Ave.', '', 'Columbus', 'Nebraska', '68601', '402-942-2876', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-07');
INSERT INTO customerInfo VALUES ('250', '72', 'Chris', 'Scholl', '2469 53rd Ave', '', 'Columbus', 'Nebraska', '68601', '402-910-4875', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-07');
INSERT INTO customerInfo VALUES ('251', '72', 'Joslen', 'Anson', '307 N. 2nd', '', 'Plainview', 'Nebraska', '68769', '', '', '', '', '', '', 'Call Jill @ 402-842-2968. She will be the one to let us in. Joslen is a nurse so hard to get in touch with.', '3', '', '', '', '', '2015-12-07');
INSERT INTO customerInfo VALUES ('252', '72', 'Jim', 'Gaylen', '305 N. 37th St.', '', 'Norfolk', 'Nebraska', '68701', '520-909-3922-ed mack', '', '', '', '', '', '', '4', '', '', 'Sunny Meadow Clinic', '', '2015-12-07');
INSERT INTO customerInfo VALUES ('253', '72', 'John & Nancy', 'Blezek', '754 7th Ave.', '', 'Columbus', 'Nebraska', '68601', '402-564-8109', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-08');
INSERT INTO customerInfo VALUES ('254', '72', 'Jamie', 'Winter ', '2204 Vernon Ave', '', 'Norfolk', 'Nebraska', '68701', '402-649-8651', '', '', '', 'jrkawinter@hotmail.com', '', '', '3', '', '', '', '', '2015-12-08');
INSERT INTO customerInfo VALUES ('255', '72', 'Gerald', 'Carstens', '55034 856 Rd', '', 'Pierce', 'Nebraska', '68767', '329-4461', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-08');
INSERT INTO customerInfo VALUES ('257', '72', 'Brent', 'Vandiest', '2263 Circle Dr', '', 'Columbus', 'Nebraska', '68601', '', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-08');
INSERT INTO customerInfo VALUES ('258', '72', 'Linda', 'Delk', '420 Exchange St', '', 'Stromsburg', 'Nebraska', '68666', '745-0188', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-08');
INSERT INTO customerInfo VALUES ('259', '72', 'Matt', 'Gonka', '1972 25th Ave', '', 'Columbus', 'Nebraska', '68601', '606-9058', '', '', '', '', '', 'moved to a new house address 
4526 28th St. 
Columbus, NE 68601', '3', '', '', '', '', '2015-12-08');
INSERT INTO customerInfo VALUES ('260', '73', 'Olivia (Dorothy)', 'Finecy', '', '30627 122nd Ave columbus', 'Columbus', 'Nebraska', '68601', '276-1086', '', '564-0178', '', '', '', '', '3', '', '', '', '', '2015-12-09');
INSERT INTO customerInfo VALUES ('261', '72', 'RICHARD AND RONALD ', 'BRAND', '1400 NORFOLK AVE', '', 'Norfolk', 'Nebraska', '68701', '4023713706', '', '', '', '', '', '', '3', '', '', 'VON ALAN INVESTMENT', '', '2015-12-09');
INSERT INTO customerInfo VALUES ('262', '72', 'Galen & Diane', 'Anderson', '728 E Main', '', 'Pierce', 'Nebraska', '68767', '402-329-4778', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-10');
INSERT INTO customerInfo VALUES ('264', '72', 'Colleen', 'Wolverton', '978 4th Rd', '', 'Wisner', 'Nebraska', '68790', '402-640-3052', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-14');
INSERT INTO customerInfo VALUES ('302', '72', 'Battle Creek Farmer\'s Pride', '', '700 W. 3rd St.', '', 'Madison', 'Nebraska', '', '', '', '', '', '', '', '', '3', 'Julie Freudenberg', '402-454-2999', 'Battle Creek Farmer\'s Pride', '', '2015-12-22');
INSERT INTO customerInfo VALUES ('266', '72', 'Nevada ', 'Claussen', '505 N 1ST ', '', 'Pierce', 'Nebraska', '68767', '', '', '4027508247', '', '', '', '', '3', '', '', '', '', '2015-12-14');
INSERT INTO customerInfo VALUES ('267', '72', 'Tammy', 'Korth', '311 Brentwood Dr.', '', 'Norfolk', 'Nebraska', '68701', '860-3532', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-14');
INSERT INTO customerInfo VALUES ('268', '72', 'Kayla ', 'Humlicek', '904 5th St.', '', 'Duncan', 'Nebraska', '', '276-3192', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-15');
INSERT INTO customerInfo VALUES ('269', '72', 'Jason ', 'Brandt', '203 S Brown', '', 'Pierce', 'Nebraska', '68767', '4023604297', '', '', '', 'bjasonbrandt@gmail.com', '', '', '3', '', '', '', '', '2015-12-15');
INSERT INTO customerInfo VALUES ('270', '72', 'Gary and Liz ', 'Doerr', '87067 537th Ave', '', 'Creighton', 'Nebraska', '68729', '402-582-3582', '', '', '', '', '', 'Directions:   6 1/2  miles north of Plainview on 9th st/ 537th Ave, west side, grey with white trim ', '3', '', '', '', '', '2015-12-15');
INSERT INTO customerInfo VALUES ('271', '73', 'Joe', 'Yindrick', '3451 S Rd', '', 'David City', 'Nebraska', '68632', '', '', '', '', '', '', '', '3', 'Jim Sylvester', '367-3391', '', '', '2015-12-15');
INSERT INTO customerInfo VALUES ('272', '72', 'Fred', 'Neemeyer', '2908 25th St', '3377 Fairlane Ave', 'Columbus', 'Nebraska', '68601', '564-7452', '', '', '', '', '', '', '3', '', '', 'F&D Rentals', '', '2015-12-17');
INSERT INTO customerInfo VALUES ('277', '72', 'John ', 'Becker', '508 Oak St.', '1920 320th Street - Albion, NE  68620', 'Stanton', 'Nebraska', '', '402-741-1477', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-18');
INSERT INTO customerInfo VALUES ('278', '72', 'Adam ', 'Hinton ', '86641 533rd Ave', '', 'Plainview', 'Nebraska', '68769', '402-992-3457', '', '', '', '', '', 'Granda Apts - Prior $375 a window wh/whi 6000(ami) with quarter round ', '5', '', '', 'HT Investment ', '', '2015-12-18');
INSERT INTO customerInfo VALUES ('279', '72', 'Jim', 'Krienert', '54482 Hwy 20', '', 'Osmond', 'Nebraska', '', '', '', '402-992-1003', '', '', '', '', '3', '', '', '', '', '2015-12-21');
INSERT INTO customerInfo VALUES ('280', '72', 'Steve ', 'Banks ', '55067 878rd', '', 'Wausa', 'Nebraska', '68786', '402-360-1706', '', '402-360-1653', '', '', '', '', '3', '', '', '', '', '2015-12-21');
INSERT INTO customerInfo VALUES ('281', '73', 'Dwayne ', 'Lindhorst', '44991 460th Ave', '', 'Lindsay', 'Nebraska', '68644', '402-428-5605', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-21');
INSERT INTO customerInfo VALUES ('282', '72', 'Tracy', 'Gradert', '55984 845th Rd', '', 'Norfolk', 'Nebraska', '68701', '', '', '402-841-8947', '', '', '', '', '3', '', '', '', '', '2015-12-21');
INSERT INTO customerInfo VALUES ('283', '72', 'Emily', 'Miller', '84459 N. Hwy 35', '', 'Norfolk', 'Nebraska', '', '', '', '', '402-841-0625', '', '', '', '3', 'Emily Miller', '402-841-0625', 'Michael Dusek', '', '2015-12-21');
INSERT INTO customerInfo VALUES ('284', '72', 'Seth & Brittney', 'Fevold', '1916 W. Prospect Ave', '', 'Norfolk', 'Nebraska', '', 'Seth: 515-570-9901', '', 'Brittney: 515-351-9703', '', '', '', '', '3', '', '', '', '', '2015-12-21');
INSERT INTO customerInfo VALUES ('285', '72', 'Dennis & Barb', 'Brandt', '1004 S 3rd St.', '', 'Norfolk', 'Nebraska', '', '402-844-5926', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-21');
INSERT INTO customerInfo VALUES ('286', '72', 'John', 'Kruid', '1400 Pierce St.', '', 'Norfolk', 'Nebraska', '', '419-305-2292', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-21');
INSERT INTO customerInfo VALUES ('287', '72', 'Cindy', 'Voichoskie', '2061 Brentwood Dr.', '', 'Norfolk', 'Nebraska', '', '379-2577', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-21');
INSERT INTO customerInfo VALUES ('288', '72', 'Bill & Jeanne', 'Tichota', '210 N. Boxelder', '', 'Norfolk', 'Nebraska', '', '402-750-6739', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-21');
INSERT INTO customerInfo VALUES ('289', '72', 'Dwayne', 'Thies', '56027 Hwy 98', '', 'Hoskins', 'Nebraska', '', '750-9522', '', '', '', '', '', '', '3', 'Amanda Menke(Dwaynes Daughter)', '402-661-9972', '', '', '2015-12-21');
INSERT INTO customerInfo VALUES ('290', '72', 'Dan & Karen', 'Jackson', '2203 Koenigstein Ave', '', 'Norfolk', 'Nebraska', '', '402-640-6121', '', 'Karen: 841-7457', '', '', '', '', '3', '', '', '', '', '2015-12-21');
INSERT INTO customerInfo VALUES ('291', '72', 'Steve & Cindy', 'Ganskow', '305 W. Sherwood Rd.', '', 'Norfolk', 'Nebraska', '', '402-371-2044', '', '402-640-6649', '', '', '', '', '3', '', '', '', '', '2015-12-21');
INSERT INTO customerInfo VALUES ('292', '72', 'Mike', 'Hines', '303 Trailridge Rd', '', 'Norfolk', 'Nebraska', '', '402-992-3370', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-21');
INSERT INTO customerInfo VALUES ('293', '72', 'Jason & Kristina', 'King', '111 Morningside Dr.', '', 'Norfolk', 'Nebraska', '', '402-644-8329', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-21');
INSERT INTO customerInfo VALUES ('294', '72', 'Amy', 'Nielsen', '201 Shetland Path', '', 'Norfolk', 'Nebraska', '', '402-750-5933', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-22');
INSERT INTO customerInfo VALUES ('295', '72', 'Greg & LeAnn ', 'Rathke', '1620 Hackberry', '', 'Norfolk', 'Nebraska', '', 'LeAnn: 316-0123', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-22');
INSERT INTO customerInfo VALUES ('296', '72', 'Andrew', 'Linnaus', '1004 Nord St.', '', 'Norfolk', 'Nebraska', '', '402-843-0134', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-22');
INSERT INTO customerInfo VALUES ('297', '72', 'Matt', 'Hampschneider', '1305 Sunrise Dr', '', 'Norfolk', 'Nebraska', '68701', '402-992-4610', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-22');
INSERT INTO customerInfo VALUES ('298', '72', 'Richard', 'Kuchar', '117 N. Crown Point', '', 'Bloomfield', 'Nebraska', '', '402-640-5828', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-22');
INSERT INTO customerInfo VALUES ('299', '72', 'Reid', 'Rosendahl', '1100 S. 2nd St.', '', 'Norfolk', 'Nebraska', '68701', '402-920-3786', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-22');
INSERT INTO customerInfo VALUES ('300', '72', 'Tim', 'Koepke', '56075 854 Rd', 'PO Box 6449', 'Hoskins', 'Nebraska', '', '402-750-6026', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-22');
INSERT INTO customerInfo VALUES ('301', '72', 'Kylie', 'Eckert', '601 S. Center St.', '', 'Tilden', 'Nebraska', '', '402-851-1136', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-22');
INSERT INTO customerInfo VALUES ('305', '72', ' Connie', 'Beckman', '51652 Hwy 70', '', 'Elgin', 'Nebraska', '', '402-843-5463', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-22');
INSERT INTO customerInfo VALUES ('306', '72', 'Levi', 'Trautman', '85277 581st Ave', '', 'Wakefield', 'Nebraska', '', '402-841-1119', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-22');
INSERT INTO customerInfo VALUES ('307', '72', 'Jeff', 'Windeshausen', '1405 Bel Air Rd.', '', 'Norfolk', 'Nebraska', '402-992-0320', '', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-22');
INSERT INTO customerInfo VALUES ('308', '72', 'Chad & Amanda', 'Huigens', '309 N 2nd St.', '', 'Plainview', 'Nebraska', '', '', '', 'Chad Cell: 402-843-8409', 'Chad Work: 402-843-2146', '', '', '', '3', '', '', '', '', '2015-12-22');
INSERT INTO customerInfo VALUES ('309', '72', 'Chad and Gwen', 'Friders', '408 Lincoln st ', '', 'Wayne', 'Nebraska', '', '4023692768', '', '4023692762', '', '', '', '', '3', '', '', '', '', '2015-12-22');
INSERT INTO customerInfo VALUES ('310', '72', 'Brian', 'Lampert', '1709 Bel Air', '', 'Norfolk', 'Nebraska', '', '402-860-4055', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-22');
INSERT INTO customerInfo VALUES ('311', '72', 'Jim', 'Hastreiter', '82424 558th Ave.', '', 'Madison', 'Nebraska', '', '402-285-0275', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-22');
INSERT INTO customerInfo VALUES ('312', '72', 'Pam', 'Scholte', '55491 839 road', '', 'Battle Creek', 'Nebraska', '', '402-675-6002', '', '', '', '', '', '', '1', '', '', '', '', '2015-12-22');
INSERT INTO customerInfo VALUES ('314', '72', 'John', 'Stappert', '207 West Norfolk Avenue', '', 'Norfolk', 'Nebraska', '68701', '(402) 851-2428', '', '', '', 'webdesign@powerpgs.com', '', 'Test Profile for Power Pages', '3', '', '', 'Power Computing Inc', '', '2015-12-23');
INSERT INTO customerInfo VALUES ('316', '72', 'Brook', 'Bugenhagen', '2007 Koenigstein Ave', '', 'Norfolk', 'Nebraska', '', ' 402-649-0796', '', '', '', 'bbugenhagen@outlook.com', '', '', '3', '', '', '', '', '2015-12-23');
INSERT INTO customerInfo VALUES ('324', '72', 'Ronald', 'MacDonald', '', '', 'Norfolk', 'Nebraska', '', '', '', '', '', '', '', '', '3', '', '', '', '', '2016-01-04');
INSERT INTO customerInfo VALUES ('325', '73', 'Bud & Glee', 'Kracl', '320 A St.', '', 'Schuyler', 'Nebraska', '', '402-352-5828', '', '', '', '', '', '', '3', '', '', '', '', '2016-01-04');
INSERT INTO customerInfo VALUES ('326', '72', 'Jeff ', 'Korus ', '', '', 'West Point', 'Nebraska', '68788', '402-270-2040', '', '', '', 'jkorus@ehpirates.org', '', '1/4/16 refered by a friend, came by email, emailed him looking for date  ', '3', '', '', '', '', '2016-01-04');
INSERT INTO customerInfo VALUES ('327', '72', 'Julie', 'Lingenfelter', '53144 865th Rd', '', 'Plainview', 'Nebraska', '68769', '402-640-4503', '', '', '', '', '', '', '3', '', '', '', '', '2016-01-05');
INSERT INTO customerInfo VALUES ('328', '72', 'Mike', 'Noelle', '', '', 'Norfolk', 'Nebraska', '', '402-640-8924', '', '', '', '', '', '', '3', 'Mike Noelle', '402-640-8924', 'Habitat for Humanity', '', '2016-01-05');
INSERT INTO customerInfo VALUES ('329', '72', 'Dale ', 'Hansen', '190 Y Rd', '', 'Wisner', 'Nebraska', '', '402-518-0206', '', '', '', '', '', '', '3', '', '', '', '', '2016-01-05');
INSERT INTO customerInfo VALUES ('330', '72', 'Nick', 'Humphrey', 'Downtown: 426 W. Norfolk Ave-Norfolk', '602 E. Pasewalk Ave.', 'Norfolk', 'Nebraska', '68701', '402-644-4785', '', '', '', '', '', '', '3', '', '', '', '', '2016-01-06');
INSERT INTO customerInfo VALUES ('331', '73', 'Shannon', 'Dorcey', '', '58595 858th Rd', 'Wakefield', 'Nebraska', '68784', '402-369-1582', '', 'Renter: Melissa 712-635-3446', '', '', '', '', '3', '', '', '', '', '2016-01-06');
INSERT INTO customerInfo VALUES ('332', '72', 'Terry', 'Lehman', '601 14th', '', 'Stanton', 'Nebraska', '', '402-439-2549', '', '', '', '', '', '', '3', '', '', '', '', '2016-01-06');
INSERT INTO customerInfo VALUES ('333', '72', 'Sue', 'Montgomery', '706 n boxelder', '', 'Norfolk', 'Nebraska', '', '4027501476', '', '', '', '', '', '', '3', '', '', '', '', '2016-01-06');
INSERT INTO customerInfo VALUES ('334', '72', 'Angela', 'Gray', '54572 839th Rd', '', 'Battle Creek', 'Nebraska', '', '640-4105', '', '', '', '', '', 'Just south of Battle Creek high school on blacktop
121 South to 839th West 1/4 mile-1st place on south side-brick house.', '3', '', '', '', '', '2016-01-07');
INSERT INTO customerInfo VALUES ('335', '72', 'STEVE', 'PELLATZ', '85879 528TH', '', 'Brunswick', 'Nebraska', '', '4028424655', '', '', '', '', '', '', '3', '', '', '', '', '2016-01-07');
INSERT INTO customerInfo VALUES ('336', '72', 'mke', 'nolle', '1503 4th st', '', 'Norfolk', 'Nebraska', '', '4026408924', '', '', '', '', '', '', '3', '', '', 'habitat for humaity', '', '2016-01-08');
INSERT INTO customerInfo VALUES ('337', '72', 'nate', 'schwager', '', '', 'Orchard', 'Nebraska', '', '', '', '', '', '', '', '', '3', '', '', '', '', '2016-01-08');
INSERT INTO customerInfo VALUES ('338', '72', 'Chris', 'Sukup', '131 Hillside Drive', '', 'Hadar', 'Nebraska', '', '', '', '402-360-3555', '', 'crsukup@cableone.net', '', '', '3', '', '', '', '', '2016-01-11');
INSERT INTO customerInfo VALUES ('339', '73', 'Ben', 'Wilshusen', '3322 Brunken', '', 'Columbus', 'Nebraska', '', '402-615-1979', '', '', '', '', '', '', '3', '', '', '', '', '2016-01-11');
INSERT INTO customerInfo VALUES ('340', '72', 'Steve ', 'Smith ', '101 Calcavechia ', '', 'Laurel', 'Nebraska', '', '4025180068', '', '', '', '', '', '', '3', '', '', 'Cedarview Country Club', '', '2016-01-12');
INSERT INTO customerInfo VALUES ('341', '72', 'Eugene', 'Zuhlke', '85919 526th Ave.', '', 'Brunswick', 'Nebraska', '', 'Home: 402-842-2535', '', '402-640-4646', '', '', '', '', '3', '', '', '', '', '2016-01-12');
INSERT INTO customerInfo VALUES ('342', '72', 'Bob', 'Morgan', '2700 32nd St.', '', 'Columbus', 'Nebraska', '68601', '402-606-6414', '', '', '', '', '', '', '3', '', '', '', '', '2016-01-13');
INSERT INTO customerInfo VALUES ('343', '72', 'Chet', 'Bohac', '56418 hwy 32', '', 'Leigh', 'Nebraska', '', '310-990-3281', '', '402-640-5590', '', '', '', '', '3', '', '', '', '', '2016-01-13');
INSERT INTO customerInfo VALUES ('345', '72', 'Bob & Tammi', 'Barry', '305 S. 5th St.', '', 'Battle Creek', 'Nebraska', '', '402-841-5508', '', '', '', '', '', 'Lunch hour works best. Off @ 5.', '3', '', '', '', '', '2016-01-13');
INSERT INTO customerInfo VALUES ('346', '73', 'Paul', 'Berans', '754 19th Ave', '', 'Columbus', 'Nebraska', '', '402-910-4596', '', '', '', '', '', '', '3', '', '', '', '', '2016-01-13');
INSERT INTO customerInfo VALUES ('347', '73', 'Denise ', 'Becker ', '2877 38th Ave', '', 'Columbus', 'Nebraska', '68601', '402-606-4311', '', '', '', '', '', '', '3', '', '', '', '', '2016-01-14');
INSERT INTO customerInfo VALUES ('348', '73', 'Alan', 'Vynhalek', '3272 33rd Ave', '', 'Columbus', 'Nebraska', '', '402-563-0260', '', '402-910-5573', '', '', '', '', '3', '', '', '', '', '2016-01-14');
INSERT INTO customerInfo VALUES ('351', '73', 'Rose Mary ', 'Seier ', '927 South 7th', '', 'Albion', 'Nebraska', '68620', '402-395-5167', '', '', '', '', '', '', '3', '', '', '', '', '2016-01-14');
INSERT INTO customerInfo VALUES ('350', '73', 'Norman', 'Dubsky', '315 W. 9th St.', '', 'Schuyler', 'Nebraska', '', '352-2211', '', '', '', '', '', '', '3', '', '', '', '', '2016-01-14');
INSERT INTO customerInfo VALUES ('352', '72', 'Stan ', 'Brichacek', '1556 Rd 11', '', 'Clarkson', 'Nebraska', '', '402-352-2948', '', '', '', '', '', '', '3', '', '', '', '106 Kix - 2016 farm show ', '2016-01-14');
INSERT INTO customerInfo VALUES ('353', '72', 'Mike ', 'Ruppert', '53567 Hwy 57', '', 'Stanton', 'Nebraska', '68779', '402-649-2826', '', '402-439-5164', '', '', '', 'north of stanton on Hwy 57 1/4 mile, brown house north side of road', '3', '', '', '', '', '2016-01-14');
INSERT INTO customerInfo VALUES ('354', '72', 'Brian', 'Becker', '324 W. 4th St.', '', 'Clarkson', 'Nebraska', '', '308-830-0026', '', '', '', '', '', '', '3', '', '', '', '', '2016-01-14');
INSERT INTO customerInfo VALUES ('356', '72', 'Steve', 'Brockhaus', '', '410 Walnut St.: Humphrey', 'Norfolk', 'Nebraska', '', '402-920-3383', '', '', '', '', '', '', '3', '', '', '', '', '2016-01-18');
INSERT INTO customerInfo VALUES ('357', '72', 'Kevin ', 'Kallweit', '41960 220th Ave ', '', 'Humphrey', 'Nebraska', '68642', '402-563-4815', '', '', '', '', '', '', '3', '', '', '', '', '2016-01-18');
INSERT INTO customerInfo VALUES ('358', '73', 'Bill', 'Meysenberg', '2846 Old Mill Rd', '', 'Albion', 'Nebraska', '68620', '402-910-3700', '', '', '', '', '', '', '3', '', '', '', '', '2016-01-18');
INSERT INTO customerInfo VALUES ('359', '72', 'Shirley', 'Staver', '205 S 3rd', 'PO Box 506', 'Battle Creek', 'Nebraska', '', '402-675-1495', '', '', '', '', '', 'Afternoons.', '3', '', '', '', '', '2016-01-18');
INSERT INTO customerInfo VALUES ('360', '72', 'Tom', 'McDonald', '85430 521s Ave', '', 'Neligh', 'Nebraska', '', 'Lynn:402-841-6337', '', '', '', '', '', '', '3', '', '', '', '', '2016-01-18');
INSERT INTO customerInfo VALUES ('361', '72', 'Larry', 'Wiegert', '54827 Hwy 20', '', 'Osmond', 'Nebraska', '', '402-841-5142', '', '', '', '', '', '', '3', '', '', '', '', '2016-01-18');
INSERT INTO customerInfo VALUES ('362', '72', 'Dale', 'Haack', '82637 547th Ave', '', 'Madison', 'Nebraska', '', '402-454-3902', '', '', '', '', '', '', '3', '', '', '', '', '2016-01-18');
INSERT INTO customerInfo VALUES ('363', '73', 'Jim', 'Pfeifer', '3168 Kummer Dr', '', 'Columbus', 'Nebraska', '', '402-564-3973', '', '402-270-2070', '', '', '', '', '3', '', '', '', '', '2016-01-18');
INSERT INTO customerInfo VALUES ('364', '72', 'Cori & Michael ', 'Kruid', '', '1104 W. 5th St. ', 'Madison', 'Nebraska', '', '402-454-2819', '', '', '', '', '', '', '3', '', '', '', '', '2016-01-19');
INSERT INTO customerInfo VALUES ('365', '72', 'Larry', 'Herberer', '55850 846th Road', '', 'Hoskins', 'Nebraska', '', '402-640-0449', '', '', '', '', '', '', '3', '', '', '', '', '2016-01-19');
INSERT INTO customerInfo VALUES ('366', '72', 'Gina', 'Reinke', '1003 Poplar', '', 'Wayne', 'Nebraska', '', '402-833-5451', '', '402-826-9688', '', '', '', '', '3', '', '', '', '', '2016-01-19');
INSERT INTO customerInfo VALUES ('367', '72', 'Vince', 'Maly', '911 E. Walnut', '', 'West Point', 'Nebraska', '', '402-380-1891', '', '', '', '', '', '', '3', '', '', '', '', '2016-01-20');
INSERT INTO customerInfo VALUES ('368', '72', 'Bill & Kandi', 'Kralik', '800 N. Hwy 35', '', 'Norfolk', 'Nebraska', '', '402-841-0902', '', '', '', '', '', '', '3', '', '', '', '', '2016-01-20');
INSERT INTO customerInfo VALUES ('369', '72', 'John & Selma ', 'Addison', '415 W. 11th St.', '', 'Wayne', 'Nebraska', '', '402-375-1953', '', '', '', '', '', '', '3', '', '', '', '', '2016-01-21');
INSERT INTO customerInfo VALUES ('370', '73', 'Gil', 'Wigington', '210 E. 17th Ave', '', 'Schuyler', 'Nebraska', '', '402-615-1004', '', '', '', '', '', '', '3', '', '', '', '', '2016-01-21');
INSERT INTO customerInfo VALUES ('372', '112', 'JULIUS', 'STRAND', '909 1 ST SE', '', 'Lyons', 'Iowa', '51031', '712-546-1788', '', '', '', '', '', '', '3', '', '', '', '', '2016-01-22');
INSERT INTO customerInfo VALUES ('373', '112', 'JEFF & CANDY', 'KLINGSMITH', '704 CONISTON CR', '', 'Table Rock', 'Iowa', '51054', '712-301-5914 JEFF', '', '712-253-9911 CANDY', '', '', '', '', '3', '', '', '', '', '2016-01-22');
INSERT INTO customerInfo VALUES ('374', '112', 'JIM', 'O\'KANE', '2505 W 15 TH', '', 'Sioux City', 'Iowa', '51103', '712-490-2410', '', '', '', '', '', '', '3', '', '', '', '', '2016-01-22');
INSERT INTO customerInfo VALUES ('375', '73', 'Mark', 'Kunhart', '2671 Pershing', '', 'Columbus', 'Nebraska', '', '', '', '402-276-6325', '', 'kmkunha@frontiernet.net', '', '', '3', '', '', '', '', '2016-01-22');
INSERT INTO customerInfo VALUES ('376', '112', 'TOM & SAMATHA', 'MACKEY', '1833 S CYPRESS ST', '', 'Sioux City', 'Iowa', '51106', '712-251-2016', '', '', '', '', '', '', '1', '', '', '', '', '2016-01-22');
INSERT INTO customerInfo VALUES ('378', '72', 'Jay', 'Fisher', '2201 Bel Air Road', '', 'Norfolk', 'Nebraska', '', '402-649-6289', '', '', '', '', '', '', '3', '', '', '', '', '2016-01-25');
INSERT INTO customerInfo VALUES ('379', '72', 'Kellin', 'Bretschneider', '705 W. Pierce St.', '', 'Pierce', 'Nebraska', '', '402-641-7411', '', '', '', '', '', '', '3', '', '', '', '', '2016-01-25');
INSERT INTO customerInfo VALUES ('380', '72', 'Roger ', 'Loseke', '5152 83rd St. ', '', 'Columbus', 'Nebraska', '68601', '402-750-8014 Roger ', '', '402-920-3166 Michelle ', '', '', '', '', '3', '', '', '', '', '2016-01-25');
INSERT INTO customerInfo VALUES ('381', '72', 'Sue', 'Loseke', '4923 35th st', '', 'Columbus', 'Nebraska', '68601', '', '', '', '', '', '', '', '3', '', '', '', '', '2016-01-26');
INSERT INTO customerInfo VALUES ('382', '73', 'Clay', 'Brandl', '3171 30th Ave', '', 'Columbus', 'Nebraska', '', '402-615-1942', '', '', '', '', '', '', '3', '', '', '', '', '2016-01-26');
INSERT INTO customerInfo VALUES ('383', '73', 'Jerry & Stacy', 'Hollendieck', '1720 1st St.', '', 'Columbus', 'Nebraska', '', 'Jerry; 402-942-2562', '', 'Stacys Business: 402-564-0879', '', '', '', '', '3', '', '', '', '', '2016-01-26');
INSERT INTO customerInfo VALUES ('384', '73', 'Holly', 'Champlin', '2207 16th St.', '', 'Columbus', 'Nebraska', '', '402-276-4856', '', '', '', '', '', '', '3', '', '', '', '', '2016-01-26');
INSERT INTO customerInfo VALUES ('385', '73', 'David', 'Roberg', '928 S. 9th St.', '', 'Albion', 'Nebraska', '', '402-741-1211', '', '', '', '', '', '', '3', '', '', '', '', '2016-01-26');
INSERT INTO customerInfo VALUES ('386', '72', 'Paul & Brenda ', 'Otto', '812 8th St.', '', 'Wisner', 'Nebraska', '', 'Brenda: 402-640-8584', '', 'Paul: 402-640-2145', '', '', '', '', '3', 'Brenda: 402-640-8584', '', '', '', '2016-01-26');
INSERT INTO customerInfo VALUES ('387', '72', 'Kelly ', 'Knudson', '', '1903 Tomlo St', 'Norfolk', 'Nebraska', '68701', '402-750-1234', '', '402-379-2065', '', '', '', '', '3', '', '', '', '', '2016-01-26');
INSERT INTO customerInfo VALUES ('388', '73', 'James', 'Delp', '2220 28th St', '', 'Columbus', 'Nebraska', '', '402-276-6362', '', '', '', '', '', '', '3', '', '', '', '', '2016-01-27');
INSERT INTO customerInfo VALUES ('389', '72', 'Nebraska Department of Roads', '', '', '', 'Wayne', 'Nebraska', '', 'office: 402-375-7070', '', '', '', '', '', '', '3', 'Dick Soden', 'Cell: 402-369-2656', 'NE Dept of Roads', '', '2016-01-27');
INSERT INTO customerInfo VALUES ('390', '72', 'Al & Marg', 'Reynoldson', '708 E. Donegal', '', 'O\'Neill', 'Nebraska', '', '402-340-9191', '', '', '', '', '', '1/26/2016: Stopped in to showroom. Showed them the patio door. Karla gave them a price of $1250.00 installed. Extra $200 for triple.', '3', '', '', '', '', '2016-01-27');
INSERT INTO customerInfo VALUES ('391', '72', 'Josh', 'Gustafson', '170 North Walnut st', '', 'Polk', 'Nebraska', '68654', '308-940-0812', '', '', '', '', '', '', '3', '', '', '', '', '2016-01-27');
INSERT INTO customerInfo VALUES ('392', '72', 'Patrick', 'Tate', '3612 13th st', '', 'Columbus', 'Nebraska', '68601', '1-402-910-9135', '', '1-402-9104581-angie', '', '', '', '', '3', '', '', '', '', '2016-01-27');
INSERT INTO customerInfo VALUES ('393', '72', 'Todd', 'Quigley', '', '', 'Bassett', 'Nebraska', '68714', '402-382-5300', '', '', '', 'todd@toddquigley.com', '', '', '3', '', '', '', '', '2016-01-28');
INSERT INTO customerInfo VALUES ('394', '72', 'Selma ', 'addison', '415 W 11TH', '', 'Wayne', 'Nebraska', '', '375-1953', '', '', '', '', '', '', '3', '', '', '', '', '2016-01-28');
INSERT INTO customerInfo VALUES ('395', '73', 'Jim', 'Korth', '201 Pine St', '', 'Lindsay', 'Nebraska', '68644', '402-920-2002', '', '', '', '', '', '', '3', '', '', '', '', '2016-01-29');
INSERT INTO customerInfo VALUES ('396', '73', 'Dan', 'Cole', '3761 S Rd', '', 'David City', 'Nebraska', '', '402-367-0141', '', '402-954-0284', '', '', '', '', '3', '', '', '', '', '2016-01-29');
INSERT INTO customerInfo VALUES ('397', '73', 'Jim & Karen', 'Bulkley', '81 Cottonwood Dr.', '', 'Columbus', 'Nebraska', '', '40-564-7423', '', '402-910-5385', '', '', '', '', '3', '', '', '', '', '2016-02-01');
INSERT INTO customerInfo VALUES ('398', '73', 'Dave & Bev', 'Kudron', '4372 B Rd', '', 'Bellwood', 'Nebraska', '', '402-563-5492', '', '402-564-7627', '', '', '', '', '3', '', '', '', '', '2016-02-01');
INSERT INTO customerInfo VALUES ('399', '72', 'Shelbey ', 'West ', '55470 HWY 59', '', 'Wausa', 'Nebraska', '68786', '623-680-2841', '', '', '', 'shelbeywest@gmail.com', '', '', '3', '', '', '', '', '2016-02-01');
INSERT INTO customerInfo VALUES ('400', '73', 'Matt', 'Soukup', '3704 20th St.', '', 'Columbus', 'Nebraska', '', '402-910-0098', '', '', '', '', '', '', '3', '', '', '', '', '2016-02-01');
INSERT INTO customerInfo VALUES ('401', '72', 'Gary and Barb', 'Frederick', '1219 East Sherwood Rd ', '', 'Norfolk', 'Nebraska', '68701', '402-649-7879 gary ', '402-649-4087 barb', '', '', '', '', '', '3', '', '', '', '', '2016-02-01');
INSERT INTO customerInfo VALUES ('402', '72', 'Pat & Gretchen', 'O\'Reily', '1216 Grainland Rd', '', 'Wayne', 'Nebraska', '', '402-833-5144', '', '605-670-3116', '605-670-2984', '', '', '', '3', '', '', '', '', '2016-02-01');
INSERT INTO customerInfo VALUES ('403', '72', 'wes ', 'hinze', '', '', 'Norfolk', 'Nebraska', '', '4026494168', '', '', '', '', '', '', '3', '', '', 'satellite central', '', '2016-02-04');
INSERT INTO customerInfo VALUES ('404', '72', 'dean', 'WALLENWABER', '135 1ST STREET', '', 'Utica', 'Nebraska', '', '4026413292', '', '', '', '', '', '', '3', '', '', '', '', '2016-02-04');
INSERT INTO customerInfo VALUES ('405', '72', 'roger', 'garbers', '1866 45th ave', '', 'Columbus', 'Nebraska', '', '4022704097', '', '', '', 'webehuskerfans@gmail.com', '', '', '3', '', '', '', '', '2016-02-04');
INSERT INTO customerInfo VALUES ('406', '72', 'keith ', 'shonka', '4251 d rd ', '', 'Bellwood', 'Nebraska', '', '4029108909', '', '', '', '', '', '', '3', '', '', '', '', '2016-02-04');
INSERT INTO customerInfo VALUES ('407', '72', 'Paul and Dorla ', 'Warneke', '902 E Knolls ', '', 'Norfolk', 'Nebraska', '68701', '402-371-2321', '', '', '', '', '', '', '3', '', '', '', '', '2016-02-04');
INSERT INTO customerInfo VALUES ('408', '72', 'Dominic and Amanda ', 'Votta ', '1230 Blue Stem Circle ', '', 'Norfolk', 'Nebraska', '68701', '402-992-2321', '', '', '', '', '', '', '3', '', '', '', '', '2016-02-04');
INSERT INTO customerInfo VALUES ('409', '73', 'Brent', 'Malena', '38369 100th Ave', '', 'Leigh', 'Nebraska', '', '', '', '402-910-8658', '', '', '', 'On hwy 30  at Ag Spray Solution---go 12 miles north –on the west side', '3', '', '', '', '', '2016-02-05');
INSERT INTO customerInfo VALUES ('410', '72', 'brad', 'easland', '506 s 8th ', '', 'Norfolk', 'Nebraska', '', '506 s 8th', '', '4027506574', '', '', '', '', '3', '', '', '', '', '2016-02-05');


#
# Table structure for table `customerTickets`
#

DROP TABLE IF EXISTS `customerTickets`;
CREATE TABLE `customerTickets` (
  `ticketID` int(11) NOT NULL AUTO_INCREMENT,
  `ticketCustID` varchar(250) DEFAULT NULL,
  `ticketEmpID` varchar(250) DEFAULT NULL,
  `propertyType` varchar(250) DEFAULT NULL,
  `ticketAddress` varchar(250) DEFAULT NULL,
  `ticketSecAddress` varchar(250) DEFAULT NULL,
  `ticketCity` varchar(250) DEFAULT NULL,
  `ticketState` varchar(150) DEFAULT NULL,
  `ticketZip` varchar(6) DEFAULT NULL,
  `ticketStatus` varchar(250) DEFAULT NULL,
  `ticketSSold` date NOT NULL,
  `ticketSOrdered` date NOT NULL,
  `ticketSReceived` date NOT NULL,
  `ticketSInstalled` date NOT NULL,
  `ticketInvoiced` varchar(250) NOT NULL,
  `ticketSInvoiced` date NOT NULL,
  `ticketSPaid` date NOT NULL,
  `ticketSPending` date NOT NULL,
  `ticketSIncomplete` date NOT NULL,
  `ticketSProposalGiven` date NOT NULL,
  `ticketSScheduled` date NOT NULL,
  `ticketLocation` varchar(250) DEFAULT NULL,
  `ticketAssign` varchar(250) DEFAULT NULL,
  `ticketDate` date NOT NULL,
  `ticketOrdDate` date NOT NULL,
  `ticketPO` varchar(250) DEFAULT NULL,
  `ticketLat` varchar(250) DEFAULT NULL,
  `ticketLong` varchar(250) DEFAULT NULL,
  `ticketCOL` varchar(250) DEFAULT NULL,
  `ticketNORF` varchar(250) DEFAULT NULL,
  `ticketSUX` varchar(250) DEFAULT NULL,
  `ticketMI` varchar(250) DEFAULT NULL,
  `ticketMIOrd` varchar(250) DEFAULT NULL,
  `ticketAMI` varchar(250) DEFAULT NULL,
  `ticketDateM` date NOT NULL,
  `ticketRCVD` varchar(250) DEFAULT NULL,
  `ticketColum` date NOT NULL,
  `ticketAMIFO` varchar(250) DEFAULT NULL,
  `ticketFinance` varchar(250) DEFAULT NULL,
  `ticketType` varchar(250) DEFAULT NULL,
  `ticketRelation` varchar(250) DEFAULT NULL,
  `ticketInstall` date NOT NULL,
  `homeYear` varchar(5) DEFAULT NULL,
  `prepLetter` varchar(250) DEFAULT NULL,
  `prepSent` date NOT NULL,
  `leadTest` varchar(8) DEFAULT NULL,
  `leadTestEmp` varchar(40) DEFAULT NULL,
  `leadTestEmpDate` date NOT NULL,
  `pamfill` varchar(5) DEFAULT NULL,
  `pamEmpfill` varchar(20) DEFAULT NULL,
  `pamDate` date NOT NULL,
  `testKit` varchar(5) DEFAULT NULL,
  `testKitEmp` varchar(40) DEFAULT NULL,
  `testDate` date NOT NULL,
  `reno` varchar(5) DEFAULT NULL,
  `renoEmp` varchar(20) DEFAULT NULL,
  `renoDate` date NOT NULL,
  `paymentReceived` varchar(1) DEFAULT NULL,
  `yardSign` varchar(1) DEFAULT NULL,
  `certCompletion` varchar(1) DEFAULT NULL,
  `wrap` varchar(5) DEFAULT NULL,
  `wrapStatus` varchar(20) DEFAULT NULL,
  `wrapColor` varchar(20) DEFAULT NULL,
  `otherWrapColor` varchar(250) DEFAULT NULL,
  `jobLadder` varchar(5) DEFAULT NULL,
  `wrapDetails` text,
  `paidDate` date NOT NULL,
  `checkStatus` varchar(5) DEFAULT NULL,
  `financeStatus` varchar(250) DEFAULT NULL,
  `ticketMonth` varchar(250) DEFAULT NULL,
  `ticketYear` varchar(4) DEFAULT NULL,
  `appLevel` varchar(250) DEFAULT NULL,
  `appSent` varchar(250) DEFAULT NULL,
  `appDate` date NOT NULL,
  `jobName` varchar(250) DEFAULT NULL,
  `diyOrdered` date NOT NULL,
  `diyReceived` date NOT NULL,
  `diyDate` date NOT NULL,
  `jobProduct` varchar(250) DEFAULT NULL,
  `dateInstalled` date NOT NULL,
  `ticketcolMI` varchar(250) DEFAULT NULL,
  `ticketcolMIoOrd` varchar(250) DEFAULT NULL,
  `ticketcolAMI` varchar(250) DEFAULT NULL,
  `ticketcolAMIFO` varchar(250) DEFAULT NULL,
  `paymentMethod` varchar(250) DEFAULT NULL,
  `soldDate` date NOT NULL,
  `downPayment` varchar(250) DEFAULT NULL,
  `downDate` date NOT NULL,
  `finalPayment` varchar(250) DEFAULT NULL,
  `finalDate` date NOT NULL,
  `paymentNotes` text NOT NULL,
  `ticketsHot` varchar(2) DEFAULT NULL,
  PRIMARY KEY (`ticketID`)
) ENGINE=MyISAM AUTO_INCREMENT=529 DEFAULT CHARSET=latin1;

#
# Dumping data for table `customerTickets`
#

INSERT INTO customerTickets VALUES ('27', '10', '', 'Single Property', '303 Aspen Dr.', '', 'Norfolk', 'Nebraska', '68701', 'Rejected', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '0000-00-00', '', '42.0533211', '-97.3570545', '', '1', '', '1', '#26691504', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '1976', '', '0000-00-00', '', 'SDD', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'No', '', '', '', '', '11/9/2015: Scheduled Install Date(Mark) ', '0000-00-00', '', 'Approved', 'September', '2015', '', '', '0000-00-00', 'James Bahm     (1) outside Install', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('26', '9', '', 'Multiple Property', 'Richard Trevors', '', 'Hartington', 'Nebraska', '68739', 'Gift Sent', '2015-12-18', '2015-12-17', '2015-12-17', '2015-12-17', '1', '2016-01-14', '2015-12-17', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '1969-12-31', '1969-12-31', '', '42.6224992', '-97.2644985', '', '2', '', '', '26691224', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-14', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'September', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2015-12-04', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('28', '12', '', 'Single Property', '2401 Valli Hi Road', '', 'Norfolk', 'Nebraska', '68701', 'Sold', '2015-12-18', '2015-12-18', '0000-00-00', '2015-12-18', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', '', '2015-10-31', '1969-12-31', '', '42.0613399', '-97.443127', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '1996', '', '0000-00-00', '', 'SDD', '2015-12-18', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'No', '', '', '', '', '', '1969-12-31', '', '', 'September', '2015', '1', 'No', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('29', '13', '', 'DIY', '', '', 'Tilden', 'Choose One', '68001', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '1', '2016-01-14', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '1969-12-31', '', '42.0613399', '-97.443127', '', '2', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'SDD', '2015-11-24', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'September', '2015', '', '', '0000-00-00', 'Molly Navritil        (DIY:1) ', '1969-12-31', '0000-00-00', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('30', '16', '', 'Multiple Property', '2653 43rd Ave', '', 'Columbus', 'Nebraska', '68601', 'Invoiced', '2015-12-18', '2015-12-18', '2015-12-18', '0000-00-00', '', '2015-12-18', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Jeff ', '2015-10-31', '1969-12-31', '123', '41.4418677', '-97.3796385', '', '4 windows', '', '', '', '4', '0000-00-00', '', '2015-12-11', 'H1432/H1433          072-10144', '', 'Windows w/ Wraps', '', '1969-12-31', '1952', '', '0000-00-00', '', 'HBC', '2015-12-18', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', 'No', '', '', '', 'Brown', '1969-12-31', '', '', 'September', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('31', '17', '', 'Single Property', '1456 N. 3rd St.', '', 'David City', 'Nebraska', '68632', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '2016-01-14', '2016-01-20', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Angi', '2015-10-31', '1969-12-31', '', '41.2641067', '-97.1314499', '', '4', '', '', '', 'Cbus: 4', '0000-00-00', '', '1969-12-31', 'H1440                072-10145', '', 'Windows w/ Wraps', '', '1969-12-31', '1974', '', '0000-00-00', '', 'ak', '2016-01-20', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', 'No', 'Other', 'Brown', '', '', '1969-12-31', '', '', 'September', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('32', '18', '', 'Single Property', '2614 Westside Dr.', '', 'Norfolk', 'Nebraska', '68701', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '1969-12-31', '2016-01-20', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '1969-12-31', '', '42.0340976', '-97.4485376', '', '1', '', '', '', '1', '0000-00-00', '', '1969-12-31', 'H1445           072-10147', '', 'Windows w/ Wraps', '', '1969-12-31', '1981', '', '0000-00-00', '', 'ak', '2016-01-20', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', '', '', '', '', '1969-12-31', '', '', 'September', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('33', '19', '', 'Single Property', '83658 556th Ave', '', 'Norfolk', 'Nebraska', '68701', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '1969-12-31', '1969-12-31', '', '41.9549072', '-97.4071152', '', '2 patio doors', '', '', '', 'H1433/H1432             072-10154', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '1962', '', '0000-00-00', '', 'SDD', '2015-12-04', '1', '', '1969-12-31', '1', '', '1969-12-31', '1', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'September', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2015-12-04', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('34', '9', '', 'DIY', '', '', 'Hartington', 'Choose One', '', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '1', '2016-01-14', '2016-01-14', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '1969-12-31', ' 072-10151', '41.9549072', '-97.4071152', '', '7-Karma Schulte', '', '', '', '7', '0000-00-00', '', '1969-12-31', 'H1487               ', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-14', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'September', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('35', '21', '', 'Single Property', '3960 Lost Creek Dr. ', '', 'Columbus', 'Nebraska', '68601', 'Went To Columbus', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Jeff ', '2015-10-31', '1969-12-31', '', '41.4547767', '-97.3651653', '', '5', '', '5 windows                          072-10152', '#26693547', '', '0000-00-00', '', '1969-12-31', '', '', 'Windows w/ Wraps', '', '1969-12-31', '1999', '', '0000-00-00', '', 'bf', '2015-12-07', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', '', '', '', '', '1969-12-31', '', '', 'September', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('37', '24', '', 'Single Property', '2918 14th St', '', 'Columbus', 'Nebraska', '68601', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '2016-01-14', '2016-01-20', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Angi', '2015-10-31', '1969-12-31', '', '41.4303673', '-97.36341', '', '8', '', '8 windows                                    072-10146', '#26693537', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '?', '', '0000-00-00', '', 'ak', '2016-01-20', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'No', '', '', '', '', 'Insulate Cavities', '1969-12-31', '', 'Contract Sent', 'September', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '4705-0001-0113-5689

11-26-2015: Mailed WF Contract', '');
INSERT INTO customerTickets VALUES ('338', '3', '', 'Single Property', '3006 N. Highway 35', '', 'Norfolk', 'Nebraska', '68701', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', '', '2015-12-18', '1969-12-31', '', '42.0589667', '-97.3545197', '', '23', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2015-12-18', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2015-12-19', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('39', '26', '', 'Single Property', '607 S.Boxelder', '', 'Norfolk', 'Nebraska', '68701', 'Complete', '0000-00-00', '0000-00-00', '0000-00-00', '2016-01-14', '1', '2016-01-21', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '1969-12-31', '', '42.0265479', '-97.3987942', '', '4', '', '', '', '4', '0000-00-00', '', '1969-12-31', 'H1496               072-10153', '', 'Basic', '', '1969-12-31', '1982', '', '0000-00-00', '', 'HBC', '2016-01-20', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'September', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('40', '23', '', 'Single Property', '111 Park St', '', 'Madison', 'Nebraska', '68748', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '2016-01-14', '2016-01-21', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '1969-12-31', '', '41.830679', '-97.4513849', '', '2', '', '2', '#26693538', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '1894', '', '0000-00-00', '', 'kf', '2016-01-21', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'No', '', '', '', '', '', '1969-12-31', '', '', 'September', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('41', '22', '', 'Single Property', '314 Forest Dr', '', 'Norfolk', 'Nebraska', '68701', 'Paid', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '1', '2016-01-21', '2016-02-01', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '1969-12-31', '', '42.0580111', '-97.3516279', '', '7', '', '7', '#26693543', '', '0000-00-00', '', '1969-12-31', '', '', 'Tough Install', '', '1969-12-31', '2006', '', '0000-00-00', '', 'kf', '2016-01-20', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '11/13/2015: Josh scheduled to Install', '1969-12-31', '', '', 'September', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '11/30/2015: Insurance company called. Said they paid Kevin already.', '');
INSERT INTO customerTickets VALUES ('42', '27', '', 'Single Property', '505 DIBBLE ST', '', 'Clearwater', 'Nebraska', '68726', 'Sold', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '1969-12-31', '', '42.1670219', '-98.191772', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Tough Install', '', '1969-12-31', '', '', '0000-00-00', '', 'SDD', '2015-12-07', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'September', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('43', '28', '', '', '84826 561st Ave', '', 'Hoskins', 'Nebraska', '68740', 'Estimate', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mike ', '2015-10-31', '0000-00-00', '', '42.1670219', '-98.191772', '', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Prospective', '0000-00-00', '', '', '0000-00-00', '', 'Angi', '0000-00-00', '', 'Angi', '0000-00-00', '', 'Angi', '0000-00-00', '', 'Angi', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'September', '2015', '', '', '0000-00-00', 'John & Peg Beemer', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('437', '167', '', 'Single Property', '2916 33rd St', '', 'Columbus', 'Nebraska', '68601', 'Ordered', '0000-00-00', '2016-01-18', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Hailey', '2016-01-14', '1969-12-31', '', '41.4483568', '-97.3644818', '', '1 Casement Sash', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-18', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'From Outside: Left Casement
26640325.4
(seal Fail)
', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('45', '29', '', 'Single Property', '1440 Eagle Ridge Circle', '', 'Pierce', 'Nebraska', '68767', 'Incomplete', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '2016-01-05', '0000-00-00', '2016-01-11', '2016-01-26', '0000-00-00', '2016-01-05', 'Norfolk', 'Karla ', '2015-10-31', '1969-12-31', '', '42.199825', '-97.5449479', '', '16', '', '16', '#26693555', '', '0000-00-00', '', '1969-12-31', '', '', 'Windows w/ Wraps', '', '1969-12-31', '2003', '', '0000-00-00', '', 'bf', '2016-01-06', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', '', '', '', '', '1969-12-31', '', '', 'September', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('46', '30', '', 'Single Property', '831 S. 8th St.', '', 'Norfolk', 'Nebraska', '68701', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '1969-12-31', '', '42.0227417', '-97.418011', '', '7', '', '7', '#26678480', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '1911', '', '0000-00-00', '', 'kf', '2016-01-26', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'No', '', '', '', '', '', '1969-12-31', '', '', 'September', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('47', '31', '', '', '305 W. Herman', '', 'Battle Creek', 'Nebraska', '68715', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '1', '2016-01-14', '2016-01-14', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '0000-00-00', '', '42.0227417', '-97.418011', '', '1', '', '1', '#26670612', '', '0000-00-00', '', '0000-00-00', '', 'No', 'Basic', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'Angi', '0000-00-00', '', 'Angi', '0000-00-00', '', 'Angi', '0000-00-00', '', 'Angi', '0000-00-00', '', '', '', 'No', '', '', '', '', '', '0000-00-00', '', '', 'September', '2015', '', '', '0000-00-00', 'Don Wacker', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('48', '32', '', 'Single Property', '511 W. Wayne St.', '', 'Randolph', 'Nebraska', '68771', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '42.3777039', '-97.3636076', '', '1 PD', '', '', '', '1 PD', '0000-00-00', '', '0000-00-00', 'T3959', '', 'Patio', 'Customer', '0000-00-00', '1972', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'No', '', '', '', '', '', '0000-00-00', '', '', 'September', '2015', '', '', '0000-00-00', 'Jack Sauser', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('49', '33', '', 'Single Property', '1105 Charolais', '', 'Norfolk', 'Nebraska', '68701', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '42.0449517', '-97.4387183', '', '12', '', '', '', '12', '0000-00-00', '', '0000-00-00', 'K1705', '', 'Windows w/ Wraps', 'Customer', '0000-00-00', '1988', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', '', '', '', '', '0000-00-00', '', '', 'September', '2015', '', '', '0000-00-00', 'Carol Schlismann', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('50', '34', '', 'Single Property', '306 Oak St.', '', 'Tilden', 'Nebraska', '68781', 'Complete', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '1', '2016-01-14', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '1969-12-31', '', '42.0458582', '-97.831452', '', '3', '', '', '', '3', '0000-00-00', '', '1969-12-31', 'H2308', '', 'Basic', '', '1969-12-31', '1916', '', '0000-00-00', '', 'HBC', '2016-01-14', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'September', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('52', '25', '', 'Single Property', '601 Neuer St', '', 'Clearwater', 'Nebraska', '68726', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '2016-01-19', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '0000-00-00', '', '42.1748291', '-98.1897495', '', '19', '', '19', '#26694062', '', '0000-00-00', '', '0000-00-00', '', '', 'Windows w/ Wraps', 'Customer', '0000-00-00', '1925', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', '', '', '', '11/4/2015: Josh scheduled to Install', '0000-00-00', '', '', 'September', '2015', '', '', '0000-00-00', 'Karol Michaels                (19 windows) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('53', '35', '', 'Single Property', '708 S. 8th St.', '', 'Norfolk', 'Nebraska', '68701', 'Scheduled', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '1969-12-31', '', '42.0250521', '-97.4182343', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Double Hung', '', '1969-12-31', '', '', '0000-00-00', '', 'SDD', '2015-12-07', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'September', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('54', '19', '', 'Single Property', '83658 556th Ave', '', 'Norfolk', 'Nebraska', '68701', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2015-10-31', '0000-00-00', '', '41.9549072', '-97.4071152', '', '4 PD', '', '', '', '4 PD', '0000-00-00', '', '0000-00-00', 'H8015', '', 'Patio', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'September', '2015', '', '', '0000-00-00', 'Steve & Theresa Perry', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('55', '36', '', 'Multiple Property', '', '', 'Madison', 'Nebraska', '68748', 'Paid', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '1', '2016-01-20', '2016-01-19', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '1969-12-31', '', '41.8279842', '-97.4549636', '', '15', '', '15', '#26685136', '', '0000-00-00', '', '1969-12-31', '', '', 'Windows w/ Wraps', '', '1969-12-31', '1880', '', '0000-00-00', '', 'SDD', '2015-12-07', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', 'No', '', '', '', 'Job Installed by Josh', '1969-12-31', '', '', 'September', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('73', '40', '', 'Single Property', '509 E. 22nd St.', '', 'Schuyler', 'Nebraska', '68661', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '1', '2016-01-14', '2016-01-14', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Angi', '2015-10-31', '1969-12-31', '', '41.4596629', '-97.0538058', '', '6', '', '', '', 'Cbus: 6', '0000-00-00', '', '1969-12-31', 'K0641', '', 'Windows w/ Wraps', '', '2015-12-03', '1976', '', '0000-00-00', '', 'HBC', '2016-01-04', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('74', '41', '', 'Single Property', '2675 E. 14th Ave', '', 'Columbus', 'Nebraska', '68601', 'Pending Wrap', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '2016-01-14', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Brent ', '2015-10-31', '1969-12-31', '', '41.4422063', '-97.3103835', '', '24', '', 'Cbus: 24', '#26697162', '', '0000-00-00', '', '1969-12-31', '', '', 'Windows w/ Wraps', '', '1969-12-31', '1935', '', '0000-00-00', '', 'bf', '2015-12-21', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', 'White', '', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('76', '43', '', 'Single Property', '669 11th Ave', '', 'Columbus', 'Nebraska', '68601', 'Paid', '0000-00-00', '0000-00-00', '0000-00-00', '2016-01-27', '1', '2016-01-27', '2016-02-05', '0000-00-00', '0000-00-00', '0000-00-00', '2016-01-14', 'Columbus', 'Karla ', '2015-10-31', '1969-12-31', '', '41.4228784', '-97.3408514', '', '3', '', '', '', 'Cbus: 3', '0000-00-00', '', '1969-12-31', 'K0650', '', 'Tough Install', '', '1969-12-31', '1955', '', '0000-00-00', '', 'bf', '2015-12-21', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'No', '', '', '', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('77', '44', '', 'Single Property', '56 Lakewood Dr.', '', 'Columbus', 'Nebraska', '68601', 'Went To Columbus', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Jeff ', '2015-10-31', '1969-12-31', '', '41.4218055', '-97.3871657', '', '2', '', '', '', 'Cbus: 2', '0000-00-00', '', '1969-12-31', 'K0646', '', 'Windows w/ Wraps', '', '1969-12-31', '1980', '', '0000-00-00', '', 'bf', '2015-12-21', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', 'Other', 'Brown', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('78', '45', '', 'Single Property', '3405  Rolling Hills Drive', '', 'Norfolk', 'Nebraska', '68701', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '2016-01-19', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '0000-00-00', '', '42.0426907', '-97.4628219', '', '1 PD', '', '', '', '1PD', '0000-00-00', '', '0000-00-00', 'W0665', '', 'Patio', 'Customer', '0000-00-00', '1977', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'No', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Jim & Joyce Kuchar', '0000-00-00', '0000-00-00', '0000-00-00', 'Doors', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('79', '46', '', 'Single Property', '1216 N. Lincoln Ave', '', 'York', 'Nebraska', '68467', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '1', '2016-01-14', '2016-01-14', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Angi', '2015-10-31', '1969-12-31', '', '40.8733101', '-97.5927968', '', '15', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'bf', '2015-12-21', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'No', '', '', '', '', 'Needs L\'s', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', 'Check', '1969-12-31', '$4,950.00 PAID IN FULL', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('80', '47', '', 'Single Property', '2161 412th Rd', '', 'Wisner', 'Nebraska', '68791', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '1', '2016-01-14', '2016-01-14', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '1969-12-31', '', '41.9872249', '-96.9142055', '', '8', '', '6 & 2', '#26672021 & #26697607          ', '', '0000-00-00', '', '1969-12-31', '', '', 'Tough Install', '', '1969-12-31', '1900', '', '0000-00-00', '', 'bf', '2016-01-07', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'No', '', '', '', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('81', '48', '', 'Single Property', '', '', 'Norfolk', 'Nebraska', '68701', 'Installed', '0000-00-00', '0000-00-00', '0000-00-00', '2016-01-14', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '1969-12-31', '', '42.0327234', '-97.4137553', '', '3', '', '3', '#26697703', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-14', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('82', '49', '', 'Single Property', '166 D St', '', 'Platte Center', 'Nebraska', '68653', 'Gift Sent', '0000-00-00', '2015-12-21', '0000-00-00', '0000-00-00', '1', '2016-01-14', '2016-01-14', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Angi', '2015-10-31', '1969-12-31', '', '41.540029', '-97.4881294', '', '4', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Windows w/ Wraps', '', '1969-12-31', '1915', '', '0000-00-00', '', 'bf', '2015-12-21', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', '', '', 'Yes', 'clay wraps cutout needs quarter round', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('436', '355', '', 'Single Property', '314 Park', '', 'Magnet', 'Nebraska', '', 'Received', '0000-00-00', '2016-01-14', '2016-02-04', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2016-01-14', '2016-01-14', '072-10314', '42.4539853', '-97.4714431', '', '6', '', '6', '26726992', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '1900', '', '0000-00-00', '', 'HBC', '2016-01-14', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'No', '', '', '', '', '', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2015-12-08', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('84', '50', '', 'Multiple Property', '2812-2816 30th St.', '', 'Columbus', 'Nebraska', '68601', 'Gift Sent', '0000-00-00', '2015-12-21', '0000-00-00', '0000-00-00', '', '1969-12-31', '2016-01-14', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Angi', '2015-10-31', '1969-12-31', '', '41.4455538', '-97.3627315', '', '18', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Windows w/ Wraps', '', '2015-11-24', '1967', '', '0000-00-00', '', 'HBC', '2016-01-14', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', 'No', 'White', '', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', 'Check', '1969-12-31', '2,000.00', '1969-12-31', '', '1969-12-31', 'HC mailed Inv. & PW', '');
INSERT INTO customerTickets VALUES ('85', '52', '', 'Single Property', '407 N. 28th St.', '', 'Norfolk', 'Nebraska', '68701', 'Scheduled', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '42.0375232', '-97.4526986', '', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Prospective', '0000-00-00', '', '', '0000-00-00', '', 'bf', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('86', '54', '', 'Single Property', '904 Lovely Lane', '', 'Norfolk', 'Nebraska', '68701', 'Complete', '0000-00-00', '2016-01-05', '0000-00-00', '0000-00-00', '1', '2016-02-01', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '1969-12-31', '', '42.0430407', '-97.4616871', '', '1', '', '', '', '1', '0000-00-00', '', '1969-12-31', 'K8492', '', 'Windows w/ Wraps', '', '1969-12-31', '1986', '', '0000-00-00', '', 'kf', '2016-01-29', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', '', '', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', 'paid $350.00 on this window - 01/29-16', '');
INSERT INTO customerTickets VALUES ('87', '9', '', 'DIY', '', '', 'Hartington', 'Choose One', '', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', '', '2015-10-31', '1969-12-31', '', '42.0430407', '-97.4616871', '', '1', '', '1', '#26698664', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-14', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', 'Debit Card', '1969-12-31', '', '1969-12-31', '252.63', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('88', '28', '', 'Single Property', '84826 561st Ave', '', 'Hoskins', 'Nebraska', '68740', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '42.1231563', '-97.3101121', '', '1', '', '1', '', '#26698666', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Peg Beemer            (1)', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('89', '9', '', 'DIY', '', '', 'Hartington', 'Choose One', '', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', '', '2015-10-31', '1969-12-31', '', '42.1231563', '-97.3101121', '', '4', '', '4', '#26698670', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-14', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', 'Debit Card', '1969-12-31', '', '1969-12-31', '1182.5', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('91', '55', '', 'DIY', '', '', 'Neligh', 'Choose One', '68756', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '1', '2016-01-14', '2016-01-14', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '1969-12-31', '', '42.1231563', '-97.3101121', '', '4', '', '4', '#26698675', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'hc', '2015-12-14', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', 'Check', '1969-12-31', '', '1969-12-31', '1,433.80', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('92', '58', '', 'Multiple Property', '400 Blaine-Norfolk', '', 'Norfolk', 'Nebraska', '68701', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '1969-12-31', '', '42.0289818', '-97.4045491', '', '9', '', '9', '#26698687', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-19', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('93', '57', '', 'Multiple Property', 'Rental: 2315 22nd St-Columbus', '', 'Columbus', 'Nebraska', '68601', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Jeff ', '2015-10-31', '1969-12-31', '', '41.4376973', '-97.3556704', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'bf', '2015-12-21', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('94', '59', '', 'Single Property', '848th Rd', '', 'Elgin', 'Nebraska', '68636', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '42.118372', '-98.1061808', '', '4', '', '4', '#26698691', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Andy Starman         (4) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('95', '60', '', 'Single Property', '40963 280th ', '', 'Humphrey', 'Nebraska', '68642', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '1969-12-31', '', '41.6778593', '-97.4845666', '', '2', '', '2', '#26698718', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'bf', '2016-01-25', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', '', '', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('96', '61', '', 'Single Property', '1713 RD 9', '', 'Clarkson', 'Nebraska', '68629', 'Incomplete', '0000-00-00', '0000-00-00', '0000-00-00', '2016-01-04', '', '1969-12-31', '0000-00-00', '0000-00-00', '2016-02-05', '0000-00-00', '0000-00-00', 'Columbus', 'Brent ', '2015-10-31', '2015-10-05', '10187', '41.6266398', '-97.0978932', '', '20', '', '20', '#26706699', '', '0000-00-00', '', '2015-12-01', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-02-05', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '1/19/2016: Mailed Inv.', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('97', '62', '', 'Single Property', '705 Linden Lane', '', 'Norfolk', 'Nebraska', '68701', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '42.0399771', '-97.4246744', '', '1', '', '', '', '1', '0000-00-00', '', '0000-00-00', 'K9232', '', 'Windows w/ Wraps', 'Customer', '0000-00-00', '1962', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Richard Grenz             (1) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('98', '63', '', 'Single Property', '55477 834th Rd', '', 'Norfolk', 'Nebraska', '68701', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '2016-01-14', '2016-01-20', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '1969-12-31', ' #10246', '41.9166192', '-97.4314757', '', '5', '', '5 windows', '#26711042', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'ak', '2016-01-20', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('99', '64', '', 'Single Property', '552755 Hwy 20', '', 'Brunswick', 'Nebraska', '68720', 'Sold', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '42.3497435', '-98.0096687', '', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Single-Story', 'Prospective', '0000-00-00', '', '', '0000-00-00', '', 'bf', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', 'Siding', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('100', '65', '', 'Single Property', '1205 8th St.', '', 'Stanton', 'Nebraska', '68779', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '1969-12-31', '10263', '41.9531334', '-97.221461', '', '7', '', '', '', '7 ', '0000-00-00', '', '1969-12-31', 'T6615', '', 'Windows w/ Wraps', '', '1969-12-31', '1918', '', '0000-00-00', '', 'hc', '2015-12-10', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', 'White', '', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('101', '66', '', 'Single Property', '83949 531ST AVE', '', 'Tilden', 'Nebraska', '68781', 'Scheduled', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Jerry ', '2015-10-31', '1969-12-31', '', '42.1057289', '-97.8927389', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-14', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('102', '67', '', 'Single Property', '3404 Prospect', '', 'Norfolk', 'Nebraska', '68701', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '2016-01-19', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '0000-00-00', '', '42.0361457', '-97.4621789', '', '6+1PD', '', '', '', '6 windows 1 patiodoor - 072-10054', '0000-00-00', '', '0000-00-00', 'Y7184', '', 'Tough Install', 'Customer', '0000-00-00', '1999', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', 'White', '', '', 'wrap outside and quarterround inside and expander', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Paul & Deb Allpress          (6+1PD) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('103', '69', '', 'Single Property', '216 N. 5th St.', '', 'Pierce', 'Nebraska', '68767', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '1', '2016-01-14', '2016-01-04', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '1969-12-31', '', '', '', '', '10', '', '10', '#26691225', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '1956', '', '0000-00-00', '', 'bf', '2015-12-23', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', 'No', 'White', '', '', '10/8/15: Still need to wrap(Maybe have Travis)', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('104', '70', '', 'Single Property', '955 N. 9th St', '', 'David City', 'Nebraska', '68632', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '1', '2016-01-14', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Karla ', '2015-10-31', '1969-12-31', '', '', '', '', '3', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'bf', '2015-12-21', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'No', '', '', '', '', 'Needs quarterround.', '1969-12-31', '', 'Paid', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '10/8/15: Mailed WF Contract for $1,150(12 months)(4705-0001-0106-3188)

', '');
INSERT INTO customerTickets VALUES ('105', '71', '', 'Single Property', '312 N. Main St.', '', 'Leigh', 'Nebraska', '68643', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '2016-01-19', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '0000-00-00', '', '', '', '', '4', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Windows w/ Wraps', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', 'Yes', 'White', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Janelle Fischer            (4 windows) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '4', '#26648765', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('106', '72', '', 'Single Property', '2855 40th Ave', '', 'Columbus', 'Nebraska', '68601', 'Complete', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '2016-01-20', '2016-01-20', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '1969-12-31', '', '41.4436363', '-97.3772279', '', '4', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '2006', '', '0000-00-00', '', 'SDD', '2016-01-28', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'No', 'Yes', '', '', '', 'Quarterround Inside', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('107', '73', '', 'Single Property', '3903 14th St.', '', 'Columbus', 'Nebraska', '68601', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '1', '2016-01-14', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Karla ', '2015-10-31', '1969-12-31', '', '', '', '', '11', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '1920', '', '0000-00-00', '', 'bf', '2015-12-21', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'Insulate Cavities
paid in full check and wells fargo - 11/10/15', '1969-12-31', '', 'Contract Sent', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '840', '1969-12-31', '10/12/15: Mailed WF Contract', '');
INSERT INTO customerTickets VALUES ('108', '74', '', 'Single Property', '4714 27th St.', '', 'Columbus', 'Nebraska', '68601', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '2016-01-19', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '0000-00-00', '', '', '', '', '6', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Windows w/ Wraps', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', 'Yes', 'Other', 'Brown or Beige', '', 'Dark Oak QR', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Everlasting Love Church     (6 windows) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '6', 'W0706', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('109', '75', '', 'Single Property', '3520 27th St', '', 'Columbus', 'Nebraska', '68601', 'Complete', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '1', '2016-01-21', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '0000-00-00', '', '', '', '', '1 PD', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Patio', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', 'Yes', 'Other', 'Brown', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Santiago Vasquez         (1 PD) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Doors', '0000-00-00', '', '', '1 PD', 'Z7723', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('110', '76', '', 'Single Property', '701 Main St-Humphrey', '', 'Humphrey', 'Nebraska', '68642', 'Scheduled', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Prospective', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Patty Silva', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('111', '77', '', 'Single Property', '1055 S. 4th St.-Albion', '', 'Albion', 'Nebraska', '', 'Paid', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '2016-01-26', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '0000-00-00', '', '41.68286', '-98.0012715', '', '1 Entry Door', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Entry Door', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'No', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Lanny & Jeannie Young', '0000-00-00', '0000-00-00', '0000-00-00', 'Door Repair', '0000-00-00', '#26657281', '', '', '', 'Check', '0000-00-00', '1,850', '0000-00-00', '1,850', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('112', '78', '', 'Single Property', '56826 825 Rd-Clarkson', '', 'Clarkson', 'Nebraska', '68629', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '2016-01-19', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '1969-12-31', '', '41.7864422', '-97.1697638', '', '8+1PD', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '2015-02-11', '', '', '0000-00-00', '', 'hc', '2015-12-16', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', 'Yes', '', '', '', '', '1969-12-31', '', 'Contract Sent', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '4705-0001-0099-7212
12 months
$5,450
12-16-15: HC mailed contract
', '');
INSERT INTO customerTickets VALUES ('332', '272', '', 'Single Property', '2908 25th St', '', 'Columbus', 'Nebraska', '68601', 'Went To Columbus', '0000-00-00', '2015-12-21', '2016-01-20', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Jeff ', '2015-12-17', '2015-12-17', '072-10297', '41.4409666', '-97.3633298', '', '20 windows', '', '20 ', '26722219', '', '0000-00-00', '', '2016-01-20', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-20', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', '', '', '', '', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2015-12-02', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('113', '81', '', 'Single Property', '531 Colfax', '', 'West Point', 'Nebraska', '68788', 'Proposal Given', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '2015-12-24', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '41.8441856', '-96.7094228', '', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Windows w/ Wraps', 'Prospective', '0000-00-00', '', '', '0000-00-00', '', 'bf', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', 'White', '', '', 'tested for lead already and she signed ', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('114', '82', '', 'Single Property', '618 S Oak ', '', 'West Point', 'Nebraska', '68788', 'Sold', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '41.8341989', '-96.716264', '', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Windows w/ Wraps', 'Prospective', '0000-00-00', '', '', '0000-00-00', '', 'bf', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', 'No', 'Architechal Bronze', '', 'No', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('115', '79', '', 'Single Property', '86602 545 RD', '', 'Osmond', 'Nebraska', '68765', 'Gift Sent', '0000-00-00', '0000-00-00', '2016-01-05', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '1969-12-31', '', '42.3511242', '-97.6207571', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'kf', '2016-01-26', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('116', '83', '', 'Single Property', '406 7th St. ', '', 'Stanton', 'Nebraska', '68779', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2015-10-31', '2015-12-10', '', '41.9461232', '-97.220094', '', '4 Balances', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Other', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2015-12-22', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '(4) Balances for 2 different windows
Original: 123-790645, 644', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('117', '84', '', 'Single Property', '2607 W. Prospect', '', 'Norfolk', 'Nebraska', '68701', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '1', '2016-01-14', '2016-01-14', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '0000-00-00', '', '42.035883', '-97.4484357', '', '1 PD', '', '', '', '1 PD        #10193', '0000-00-00', '', '0000-00-00', '', '', 'Patio', 'Customer', '0000-00-00', '1966', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'No', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Michael Kuester', '0000-00-00', '0000-00-00', '0000-00-00', 'Doors', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('118', '85', '', 'Single Property', '3058 Maple St.', '', 'Emerson', 'Nebraska', '68733', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '2016-01-06', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '0000-00-00', '', '42.2794079', '-96.7225649', '', '5', '', '5      #10192', '#26701055', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Rich & Theresa Anderson (5) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('119', '86', '', 'Single Property', '701 Northdale Dr.', '', 'Norfolk', 'Nebraska', '68701', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '1969-12-31', '1969-12-31', '#10191', '42.0401122', '-97.4260368', '', '3', '', '3    ', '26701054', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '1965', '', '0000-00-00', '', 'hc', '2015-12-04', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'No', '', '', '', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', 'Dave Carter', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('120', '87', '', 'Single Property', '1108 Rose Ln', '', 'Norfolk', 'Nebraska', '68701', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '2016-01-06', '', '0000-00-00', '2016-01-13', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '0000-00-00', '', '42.0212326', '-97.4228721', '', '9', '', '9     #10190', '#26701053', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '1962', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Corey Schmidt       (9) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('121', '82', '', 'Single Property', '618 S Oak ', '', 'West Point', 'Nebraska', '68788', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '2016-01-19', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '0000-00-00', '', '41.8341989', '-96.716264', '', '4', '', '', '', '4             #10189', '0000-00-00', '', '0000-00-00', 'M1541', '', 'Windows w/ Wraps', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Larry Petz                (4) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('122', '88', '', 'Single Property', '201 SHETLAND PATH', '', 'Norfolk', 'Nebraska', '68701', 'Scheduled', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '0000-00-00', '', '42.0561737', '-97.3516342', '', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Prospective', '0000-00-00', '', '', '0000-00-00', '', 'kf', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('123', '89', '', 'Single Property', '1501 Syracuse', '', 'Norfolk', 'Nebraska', '68701', 'Incomplete', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '1969-12-31', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'bf', '2015-12-23', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'sash and screen i already fixed the screen

window is leaeking air bad and dwayne check out downpouts and south side old gutters nails need to be pushed in and something done with extension', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('124', '90', '', 'Single Property', '1703 Sheridan Dr.', '', 'Norfolk', 'Nebraska', '68701', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2015-10-31', '0000-00-00', '', '', '', '', '1 PD', '', '', '', '1 PD', '0000-00-00', '', '0000-00-00', 'C7608', '', 'Patio', 'Customer', '0000-00-00', '1978', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'No', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Chad Jochum       (1PD)', '0000-00-00', '0000-00-00', '0000-00-00', 'Doors', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('125', '91', '', 'Single Property', '610 W. 6th St.', '', 'Wakefield', 'Nebraska', '68784', 'Estimate', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '42.2659935', '-96.873553', '', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Windows w/ Wraps', 'Prospective', '0000-00-00', '1976', '', '0000-00-00', '', 'bf', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', 'No', 'White', '', '', 'need to bring in flush with drywall and new 3 1/4 casing she will pick out from carhart prefinished white ', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Ken Pettit         (Window Estimate)', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('126', '92', '', 'Single Property', '300 Aspen Dr.', '', 'Norfolk', 'Nebraska', '68701', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '2016-01-19', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '0000-00-00', '', '', '', '', '6', '', '6', '#26691502', '', '0000-00-00', '', '0000-00-00', '', '', 'Windows w/ Wraps', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', 'No', 'Other', 'Charcoal Gray', '', 'Needs Dark Gray Trim

11/9/2015: Scheduled Install Date(Mark) ', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Merry Braun    (6)', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('127', '93', '', 'Single Property', '833735 556th Ave', '', 'Norfolk', 'Nebraska', '68701', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '2016-01-13', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-12', '2015-10-12', ' #10129', '41.923988', '-97.406986', '', '2', '', '2                     ', '#26691221', '', '0000-00-00', '', '1969-12-31', '', '', 'Windows w/ Wraps', '', '1969-12-31', '1935', '', '0000-00-00', '', 'hc', '2015-12-04', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', 'Other', 'Green??', '', '12/7/2015: Scheduled to Install(Dwayne) ', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', 'Dennis & Mary Mrsny        (2)', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('128', '95', '', 'Single Property', '310 Brentwood Dr.', '', 'Norfolk', 'Nebraska', '68701', 'Estimate', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '0000-00-00', '', '42.0532943', '-97.3548204', '', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Paul & Shannon Filsinger', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('129', '96', '', 'Single Property', '305 N. Main St.', '', 'Pilger', 'Nebraska', '68768', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '2016-01-19', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '0000-00-00', '', '42.0096731', '-97.0538832', '', '23 SQ', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Two-Story', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Brian Anderson', '0000-00-00', '0000-00-00', '0000-00-00', 'Siding', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('130', '98', '', 'Single Property', '306 W Norfolk Ave', '', 'Norfolk', 'Nebraska', '68701', 'Estimate', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '42.032797', '-97.4106793', '', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Prospective', '0000-00-00', '', '', '0000-00-00', '', 'bf', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('131', '99', '', 'Single Property', '1300 Galeta Unit C', '', 'Norfolk', 'Nebraska', '68701', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '2016-01-19', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '0000-00-00', '', '42.0520576', '-97.4270357', '', '7', '', '7', '#26665554', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Tony Hoffman', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', 'Check', '0000-00-00', '', '0000-00-00', 'Paid In Full', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('132', '100', '', 'Single Property', '303 S. Boyer', '', 'Battle Creek', 'Nebraska', '68715', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '2015-12-28', '2015-12-28', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '1969-12-31', '', '41.9974669', '-97.5956062', '', '4', '', '', '', '4', '0000-00-00', '', '1969-12-31', 'Y5259', '', 'Basic', '', '1969-12-31', '1900', '', '0000-00-00', '', 'ak', '2015-12-28', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'No', '', '', '', '', '', '1969-12-31', '', 'Paid', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '4705-0001-0073-1447
12 Months', '');
INSERT INTO customerTickets VALUES ('133', '101', '', 'Single Property', '430 St               47893 400th St-Lindsay', '', 'Newman Grove', 'Nebraska', '68758', 'Paid', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '2016-01-19', '2016-01-25', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '1969-12-31', '', '', '', '', '3', '', 'Cbus: 3', '#26702195', '', '0000-00-00', '', '1969-12-31', '', '', 'Windows w/ Wraps', '', '1969-12-31', 'X', '', '0000-00-00', '', 'HBC', '2016-01-19', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', '', '', '', '1/19/2016: Mailed Inv.', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('134', '102', '', 'Single Property', '1869 W. Calle Columbo', '', 'Columbus', 'Nebraska', '68601', 'Received', '0000-00-00', '2016-01-25', '2016-02-05', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Stephen ', '2015-10-31', '1969-12-31', '', '41.4338444', '-97.3286062', '', '1 Lower Sash-ASAP', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-02-05', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '1/21/16:  We ordered the wrong sash the first time. need to install right when we get this.

Bottom Sash: 
124-362582
(seal fail)', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('135', '103', '', 'Single Property', '203 S. 4th St.', '', 'Humphrey', 'Nebraska', '68642', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '2016-01-19', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '0000-00-00', '', '', '', '', '6', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Dean Korus', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '6', '26678030', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('136', '106', '', 'Single Property', '119 North 5th st', '', 'Howells', 'Nebraska', '68641', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '', '', '', '14', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Tough Install', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', 'ordered from contractors 10/19/2015 kasey email', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Mary Rocheford           siding (charter oak)(coastal sage)(dutchlap)', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('137', '80', '', 'Single Property', '1009 1st Ave', '', 'Wayne', 'Nebraska', '68787', 'Paid', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '1', '2016-01-26', '2016-01-26', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '0000-00-00', '', '42.2295531', '-97.0301704', '', '1', '', '', '', '1', '0000-00-00', '', '0000-00-00', 'F8541', '', 'Basic', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', 'No Wrap needed-per Jon Arens', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Gena Luhr-Puls            (1 window) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', 'Debit Card', '0000-00-00', '', '0000-00-00', '315', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('138', '107', '', 'Single Property', '505 Kent St.', '', 'Madison', 'Nebraska', '68748', 'Paid', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '1', '2016-01-20', '2016-01-19', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '0000-00-00', '', '41.8256717', '-97.4576261', '', '4', '', '4', '#26665549', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '1900', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'No', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Mick & Kim Vogt         (4)', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('139', '108', '', 'Single Property', '808 Nebraska Ave', '', 'Wayne', 'Nebraska', '68787', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '2016-01-19', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '0000-00-00', '', '42.2366555', '-97.0149014', '', '18', '', '18', '#26691226', '', '0000-00-00', '', '0000-00-00', '', '', 'Windows w/ Wraps', 'Customer', '0000-00-00', '1906', '', '0000-00-00', '', 'hc', '0000-00-00', '1', '', '0000-00-00', '1', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'No', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Chris & Jenn Geidner    (18)', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('140', '109', '', 'Multiple Property', '919 Windom-Wayne', '', 'Wayne', 'Nebraska', '68787', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '2016-01-19', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '0000-00-00', '', '42.2384524', '-97.0131835', '', '1-Used 2 from Sin bin(3 total) ', '', '', '', '3 (used 2 from Sinbin) ', '0000-00-00', '', '0000-00-00', 'F8525(1)            D4154(2)        ', '', 'Basic', 'Prospective', '0000-00-00', 'X', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'No', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Gary Boehle      (3) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('141', '38', '', 'Single Property', '84459  Hwy 35', '', 'Norfolk', 'Nebraska', '68701', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2015-10-31', '2015-10-16', '', '42.0638149', '-97.3477489', '', '2 DO Case Handles', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Other', '', '1969-12-31', '', '', '0000-00-00', '', 'bf', '2015-12-23', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '2 Dark Oak Casement Handles(UNDER HC DESK)', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('142', '111', '', 'Single Property', '413 E. Nebraska Ave', '', 'Norfolk', 'Nebraska', '68701', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '2016-01-19', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '0000-00-00', '', '42.0354252', '-97.400922', '', '3', '', '3', '#26666507', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '1930', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'No', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Andrea Rodriguez       (3 windows) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('143', '110', '', 'Single Property', '405 Ash St', '', 'Creston', 'Nebraska', '', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '2016-01-14', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', '', '2015-10-31', '1969-12-31', '', '41.7053057', '-97.360121', '', '6', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-14', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('144', '110', '', 'Single Property', '405 Ash St', '', 'Creston', 'Nebraska', '', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2015-10-31', '1969-12-31', '', '41.7053057', '-97.360121', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-14', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('145', '100', '', 'Single Property', '303 S. Boyer', '', 'Battle Creek', 'Nebraska', '68715', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2015-10-31', '1969-12-31', '', '41.9974669', '-97.5956062', '', '1 Bottom Sash', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Double Hung', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-19', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '(1) Bottom Sash
Original: 129-154803
Reason: Glass Crack', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('146', '112', '', 'DIY', '', '', 'Norfolk', 'Choose One', '68001', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '0000-00-00', '', '41.9974669', '-97.5956062', '', '1', '', '1', '#26703473', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Lance Novacek      (DIY; 1)', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('147', '114', '', 'Multiple Property', '608 E. 4th St. ', '', 'Neligh', 'Nebraska', '68756', 'Ordered', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2015-10-31', '0000-00-00', '', '42.1285846', '-98.0230695', '', '1', '', '1 WINDOW - 072-10202', '#26704047', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'kf', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Frank Morrison      (1) --cancelled we found window in back', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('148', '115', '', 'Single Property', '300 N. 3rd St.', '', 'Ulysses', 'Nebraska', '68669', 'Installed', '0000-00-00', '0000-00-00', '0000-00-00', '2016-01-19', '', '2016-01-18', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Karla ', '2015-10-31', '2015-10-20', '', '41.073861', '-97.2006123', '', '11', '', '11', '26704048', '1 PD', '0000-00-00', '', '2015-12-07', 'N7266', '', 'Basic', '', '1969-12-31', '2001', '', '0000-00-00', '', 'HBC', '2016-01-19', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'No', '', '', '', '', '1/19/2016: Mailed Inv.', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('149', '116', '', 'Single Property', '4019 13th St.', '', 'Columbus', 'Nebraska', '68601', 'Installed', '0000-00-00', '0000-00-00', '0000-00-00', '2016-02-01', '', '2016-01-20', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '1969-12-31', '#10201', '41.4296466', '-97.3769903', '', '6', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '2015-11-25', '', '', '0000-00-00', '', 'HBC', '2016-02-01', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'No', '', '', '', '', '1/19/2016: Mailed Inv.

2/1/2016: Needs a crank cover and sills finished outside?', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '2/1/16: Waiting for funds to be transferred. Will be paying within the next week & a half.', '');
INSERT INTO customerTickets VALUES ('150', '117', '', 'Single Property', '1811 Imperial Rd', '', 'Norfolk', 'Nebraska', '68701', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '', '', '', '3', '', '', '', '3 - 10200', '0000-00-00', '', '0000-00-00', 'N7250', '', 'Windows w/ Wraps', 'Customer', '0000-00-00', '1984', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', 'Beige', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Curt Nielsen        (3)', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('151', '118', '', 'Single Property', '3406 Foxridge', '', 'Norfolk', 'Nebraska', '68701', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '2016-01-19', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '1969-12-31', '10199', '', '', '', '1', '', '1 WINDOW -', '#26704031', '', '0000-00-00', '', '1969-12-31', '', '', 'Tough Install', '', '2015-12-08', '2004', '', '0000-00-00', '', 'hc', '2015-12-08', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'No', '', '', '', '', '12/10/2015: Mark Scheduled to Install.', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('152', '72', '', 'Single Property', '2855 40th Ave', '', 'Columbus', 'Nebraska', '68601', 'Installed', '0000-00-00', '0000-00-00', '0000-00-00', '2016-01-18', '1', '2016-01-18', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '2015-10-20', '10204', '41.4436363', '-97.3772279', '', '1', '', '', '', '1', '0000-00-00', '', '2015-12-02', 'N7269', '', 'Windows w/ Wraps', '', '2015-12-09', '2006', '', '0000-00-00', '', 'hc', '2015-12-09', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', '', '', '', '12/3/2015: Jeff installed.', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('153', '120', '', 'Single Property', '700 Linden Lane', '', 'Norfolk', 'Nebraska', '68701', 'Paid', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '1', '2016-01-26', '2016-01-26', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '0000-00-00', '', '', '', '', '4', '', '', '', '4', '0000-00-00', '', '0000-00-00', 'L3349', '', 'Basic', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'kf', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Susan Askew      (4 windows) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', 'Check', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('154', '120', '', 'Single Property', '700 Linden Lane', '', 'Norfolk', 'Nebraska', '68701', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '2016-01-19', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '0000-00-00', '', '', '', '', '20 Sq.', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Susan Askew        (siding) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('155', '121', '', 'Single Property', '57985 858 Rd', '', 'Wakefield', 'Nebraska', '68784', 'Incomplete', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '2016-01-27', '0000-00-00', '0000-00-00', '2016-01-28', '0000-00-00', '2016-01-27', 'Norfolk', 'Dwayne', '2015-10-31', '1969-12-31', '', '42.2643061', '-96.8266316', '', '10', '', '9 WINDOWS - 10205', '#26704056', '1 WINDOW - 10205', '0000-00-00', '', '1969-12-31', 'N7311', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-27', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('156', '122', '', 'Single Property', '504 E. Maple', '', 'Norfolk', 'Nebraska', '68701', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '', '', '', '1', '', '', '', '1 WINDOW - 10216', '0000-00-00', '', '0000-00-00', 'N7319', '', 'Basic', 'Customer', '0000-00-00', '1986', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Willard Hart       (1) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('157', '123', '', 'Single Property', '205 S. Birch', '', 'Norfolk', 'Nebraska', '68701', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '2016-01-19', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '0000-00-00', '', '42.0312576', '-97.4003115', '', '2', '', '', '', '2', '0000-00-00', '', '0000-00-00', 'D8795', '', 'Windows w/ Wraps', 'Customer', '0000-00-00', '1920', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', 'No', 'Other', 'Autumn Red', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Sara McClary', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('158', '124', '', 'Single Property', '320 Sherwood Lane', '', 'Norfolk', 'Nebraska', '68701', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '', '', '', '1', '', '1', '#26704279', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'No', '', '', '', '', 'need to pull down siding but he will put new siding up may need to cut back drywall and stool board and quarter round

11/16/2015: Mark scheduled to Instal', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Larry Sohler        (1)          ASAP-Broke Out', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('357', '292', '', 'Single Property', '303 Trailridge Rd', '', 'Norfolk', 'Nebraska', '', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '2016-01-07', 'Norfolk', 'Mark ', '2015-12-21', '1969-12-31', '', '42.053276', '-97.3517179', '', '2 sashes', '', '', '', '', '0000-00-00', '', '1969-12-31', 'New: N8466; 129-298685 129-298483', '', 'Double Hung', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-25', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('160', '126', '', 'Single Property', '1531 7th St', '', 'Duncan', 'Nebraska', '68634', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Brent ', '2015-10-31', '1969-12-31', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'bf', '2015-12-21', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Siding', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('161', '124', '', 'Single Property', '320 Sherwood Lane', '', 'Norfolk', 'Nebraska', '68701', 'Sold', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2015-10-31', '0000-00-00', '', '', '', '', '', '', '1 window- 10207', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Prospective', '0000-00-00', '', '', '0000-00-00', '', 'kf', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('162', '127', '', 'Single Property', '1201 N 25th', '', 'Norfolk', 'Nebraska', '68701', 'Paid', '0000-00-00', '0000-00-00', '0000-00-00', '2016-01-22', '', '2016-01-22', '2016-01-28', '0000-00-00', '0000-00-00', '0000-00-00', '2016-01-07', 'Norfolk', 'Angi', '2015-10-31', '1969-12-31', '', '', '', '', '7', '', '7 - windows - 10209', '#26704592', '', '0000-00-00', '', '1969-12-31', '', '', 'Windows w/ Wraps', '', '1969-12-31', '1966', '', '0000-00-00', '', 'kf', '2016-01-28', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', 'No', 'Other', 'royal brown', 'Yes', 'may need stop for outside kind of weird window', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('163', '128', '', 'DIY', '', '', 'Meadow Grove', 'Choose One', '68752', 'Complete', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '1', '2016-01-21', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '1969-12-31', '', '', '', '', '1', '', '1- 10209', '#26704591', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'hc', '2015-12-14', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'she needs plugs for patio door ordered from mi 
Brent ordered Plugs: 10-21-15', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', 'Check', '1969-12-31', '', '1969-12-31', '268.75', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('291', '239', '', 'Single Property', '1330 w church st ', '', 'Albion', 'Nebraska', '', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '1969-12-31', '', '41.6920682', '-98.0120959', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-26', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '12-10-2015: HC mailed parts to customer', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('165', '130', '', 'Single Property', '2607 E. 38th St. ', '', 'Columbus', 'Nebraska', '68601', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '1', '2016-01-19', '2016-01-19', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '0000-00-00', '', '41.4530969', '-97.2993599', '', '11', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Tough Install', 'Customer', '0000-00-00', '1984', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Nancy Karmann         (11) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '11', '#26687508', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('343', '279', '', 'Single Property', '54482 Hwy 20', '', 'Osmond', 'Nebraska', '', 'Gift Sent', '0000-00-00', '2016-01-05', '2016-01-15', '0000-00-00', '1', '2016-01-18', '2016-01-19', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-12-21', '1969-12-31', '', '42.3516816', '-97.6125173', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2015-12-21', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('167', '132', '', 'Single Property', '54049 841st Rd', '', 'Meadow Grove', 'Nebraska', '68752', 'Sold', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '42.0178129', '-97.7079887', '', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Tough Install', 'Prospective', '0000-00-00', '', '', '0000-00-00', '', 'bf', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', 'bay window need monteray j-channel ', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('168', '134', '', 'Single Property', '3304 Mach 1 Dr.', '', 'Norfolk', 'Nebraska', '68701', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '1969-12-31', '2016-01-19', '0000-00-00', '2016-01-07', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '1969-12-31', '', '42.0439725', '-97.4626426', '', '10 + 1 PD', '', '', '', '10 + 1PD', '0000-00-00', '', '1969-12-31', 'C7594             C7595', '', 'Basic', '', '1969-12-31', '1986', '', '0000-00-00', '', 'bf', '2016-01-07', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', 'White', '', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('169', '135', '', 'Multiple Property', 'Cabin in Monowi', '', 'Pierce', 'Nebraska', '68767', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '2016-01-13', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '0000-00-00', '', '42.19917', '-97.5267247', '', '3', '', '3', '#26645765', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', 'Yes', 'Beige', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Al Collison      (3-Cabin) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('170', '136', '', 'Multiple Property', '3018 28th St.-Columbus', '', 'Columbus', 'Nebraska', '68601', 'Paid', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '1', '2016-01-26', '2016-01-26', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Karla ', '2015-10-31', '1969-12-31', '', '41.4439111', '-97.365413', '', '16', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'bf', '2015-12-21', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', 'Check', '1969-12-31', '', '1969-12-31', '6410', '1969-12-31', 'paid in full 10/31/15', '');
INSERT INTO customerTickets VALUES ('171', '136', '', 'Single Property', '18428 280th St.', '', 'Columbus', 'Nebraska', '68601', 'Ordered', '0000-00-00', '2015-12-21', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Hailey', '2015-10-31', '1969-12-31', '', '41.5112824', '-97.3196798', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'bf', '2015-12-21', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('172', '137', '', 'Single Property', '83441 557th Ave', '', 'Norfolk', 'Nebraska', '68701', 'Paid', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '1', '2016-01-26', '2016-01-26', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '0000-00-00', '', '41.9228772', '-97.3876812', '', '8', '', '8', '#26679186', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '1920', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', '', '', '', 'Job Installed by Dwayne', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Pete & Kathy  Hastreiter              (8 windows) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', 'Debit Card', '0000-00-00', '', '0000-00-00', '3,930.00', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('173', '138', '', 'Single Property', '271 3rd Ave', '', 'Columbus', 'Nebraska', '68601', 'Incomplete', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '1', '2016-01-20', '2016-01-20', '0000-00-00', '2016-01-20', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '41.4188627', '-97.3298099', '', '5+ 1 PD', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', 'Yes', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Deb Kallenbach         (5+1PD)', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '5', '#26644236', '1 PD', 'C4068', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('174', '139', '', 'Multiple Property', '704 Division St-Fullerton', '', 'Genoa', 'Nebraska', '68640', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '2016-01-19', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '0000-00-00', '', '41.3587483', '-97.9735933', '', '7', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '1910', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'No', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Corey Pilakowski      (7)', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '7', '#26679021', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('175', '140', '', 'Single Property', '1010 Grainland', '', 'Wayne', 'Nebraska', '68787', 'Installed', '0000-00-00', '0000-00-00', '0000-00-00', '2016-01-04', '1', '2016-01-04', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '0000-00-00', '', '', '', '', '17', '', '17', '#26691229', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '1920', '', '0000-00-00', '', 'hc', '0000-00-00', '1', '', '0000-00-00', '1', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Tiffani & Lee Stegemann', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('176', '140', '', 'Single Property', '1010 Grainland', '', 'Wayne', 'Nebraska', '68787', 'Installed', '0000-00-00', '0000-00-00', '0000-00-00', '2016-01-04', '1', '2016-01-04', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Prospective', '0000-00-00', '', '', '0000-00-00', '', 'kf', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', 'need to build out window and wrap ', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'natural linene charter oak dutchlap siding ordered from contractors for future 10/23/15', '0000-00-00', '0000-00-00', '0000-00-00', 'Siding', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('177', '142', '', 'Single Property', '604 E Klug', '', 'Norfolk', 'Nebraska', '68701', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2015-10-31', '0000-00-00', '', '', '', '', '1 PD', '', '', '', '1 PD', '0000-00-00', '', '0000-00-00', 'D8759', '', 'Patio', 'Customer', '0000-00-00', '1964', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'No', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Jeff Russo            (1PD) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Doors', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('178', '143', '', 'Single Property', '1205 Eldorado Rd', '', 'Norfolk', 'Nebraska', '68701', 'Ordered', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2015-10-31', '0000-00-00', '', '', '', '', '3', '', '3 windows - 10211', '#26706058', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '1989', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Roger Borgman        (3)', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('179', '144', '', 'Multiple Property', '2904 6th St.-Columbus', '', 'Columbus', 'Nebraska', '68601', 'Paid', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '2016-01-27', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Jeff ', '2015-10-31', '2015-10-21', '10211', '41.4223113', '-97.3635897', '', '4', '', '4', '26706057', '', '0000-00-00', '', '2015-12-07', '', '', 'Basic', '', '1969-12-31', '1900', '', '0000-00-00', '', 'hc', '2015-12-09', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'No', '', '', '', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('180', '145', '', 'Single Property', '13898 T Rd', '', 'Shelby', 'Nebraska', '68662', 'Went To Columbus', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Jeff ', '2015-10-31', '2015-10-26', '10213', '', '', '', '5', '', '', '', '5', '0000-00-00', '', '2015-12-07', 'P8282', '', 'Basic', '', '1969-12-31', '1928', '', '0000-00-00', '', 'hc', '2015-12-09', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', 'No', 'Other', 'Brown', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('181', '146', '', 'Single Property', '2960 18th Ave.', '', 'Columbus', 'Nebraska', '68601', 'Paid', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '1', '2016-01-19', '2016-01-27', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Karla ', '2015-10-31', '2015-10-21', '', '', '', '', '1', '', '', '', '', '0000-00-00', '', '2015-12-07', '', '', 'Windows w/ Wraps', '', '1969-12-31', '1965', '', '0000-00-00', '', 'HBC', '2015-12-23', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', 'No', 'White', '', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('182', '149', '', 'Single Property', '500 W. 6th', '', 'Lindsay', 'Nebraska', '68644', 'Complete', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '1', '2016-01-21', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '2015-10-21', '', '', '', '', '4', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '2015-12-08', '1976', '', '0000-00-00', '', 'HBC', '2016-01-19', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '12/9/2015: Dwayne Scheduled to Install.
1-19-2016: Mailed Inv.', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('183', '148', '', 'Multiple Property', '55016 1/2 Rd-Norfolk', '', 'Norfolk', 'Nebraska', '68701', 'Paid', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '1', '2016-01-21', '2016-01-25', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '0000-00-00', '', '42.033033', '-97.3600425', '', '14', '', '', '', '14', '0000-00-00', '', '0000-00-00', 'F0842', '', 'Basic', 'Customer', '0000-00-00', '?', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Bob Pollack', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('184', '150', '', 'Single Property', '370 10th Ave', '', 'Columbus', 'Nebraska', '68601', 'Paid', '0000-00-00', '0000-00-00', '0000-00-00', '2016-01-14', '1', '2016-01-26', '2016-01-27', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Karla ', '2015-10-31', '2015-10-26', '10215', '', '', '', '3', '', '3', '26706046', '', '0000-00-00', '', '2015-12-09', '', '', 'Basic', '', '1969-12-31', '1920', '', '0000-00-00', '', 'HBC', '2016-01-14', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', 'No', 'White', '', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', 'Jeff Has check.', '');
INSERT INTO customerTickets VALUES ('185', '151', '', 'Single Property', '729 S. 11th St.', '', 'Norfolk', 'Nebraska', '68701', 'Gift Sent', '2015-12-17', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '2015-12-24', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '2015-11-24', '10273', '', '', '', '6 windows', '', '6', '26716407', '', '0000-00-00', '', '1969-12-31', '', '', 'Windows w/ Wraps', '', '2015-12-21', '1915', '', '0000-00-00', '', 'bf', '2015-12-24', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', 'Other', 'Brandy Wine', 'Yes', 'Jerry told Customer we would get installed by end of the year.

12-21-15: Scheduled Install Date(Dwayne) ', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('186', '152', '', 'Multiple Property', '917  Pierce St.', '', 'Norfolk', 'Choose One', '68701', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '2015-10-27', '', '42.0225435', '-97.4057217', '', '1 Upper Sash', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Double Hung', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-25', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '(1) Upper Sash
Original: 125-742958', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('187', '132', '', 'Single Property', '54049 841st Rd', '', 'Meadow Grove', 'Nebraska', '68752', 'Paid', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '1', '2016-01-21', '2016-01-26', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '1969-12-31', '', '42.0178129', '-97.7079887', '', '3', '', '1 bay (3) - 10216', '#26706647', '', '0000-00-00', '', '1969-12-31', '', '', 'Tough Install', '', '1969-12-31', '1989', 'Yes', '2015-12-09', '', 'kf', '2015-12-17', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', '', '', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('188', '64', '', 'Single Property', '552755 Hwy 20', '', 'Brunswick', 'Nebraska', '68720', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '2015-12-18', '2015-12-29', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '1969-12-31', '', '42.3497435', '-98.0096687', '', '10', '', '10 - 10217', '26706352', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '2015-12-17', '1916', '', '0000-00-00', '', 'HBC', '2015-12-18', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'No', '', '', '', '', '12/17/2015: Dwayne scheduled to Install', '1969-12-31', '', 'Contract Sent', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '4705-0001-0114-9979
12 months  $3,700
12-18-2015: Mailed WF Contract', '');
INSERT INTO customerTickets VALUES ('189', '148', '', 'Single Property', '54345 550th Ave', '', 'Norfolk', 'Nebraska', '68701', 'Paid', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '2016-01-25', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '42.039775', '-97.5236946', '', '1', '', '', '', '1 window - 10218', '0000-00-00', '', '0000-00-00', 'P9146', '', 'Basic', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '11-16/2015: Mark Scheduled to Install', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Bob Pollack      (1-short on original order) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('190', '153', '', 'Single Property', '2009 N Eastwood', '', 'Norfolk', 'Nebraska', '68701', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '2015-12-23', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '0000-00-00', '', '42.0291354', '-97.349159', '', '3', '', '3 windows - 10219', '#26706429', '', '0000-00-00', '', '0000-00-00', '', '', 'Windows w/ Wraps', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Brian Lind   (3)', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('191', '141', '', 'Single Property', '522Rd H', '', 'Schuyler', 'Nebraska', '68661', 'Installed', '0000-00-00', '0000-00-00', '0000-00-00', '2015-12-21', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Brent ', '2015-10-31', '1969-12-31', '', '41.4483432', '-97.0597019', '', '9', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '??', '', '0000-00-00', '', 'bf', '2015-12-21', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'No', '', '', '', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('192', '112', '', 'Single Property', '1903 Carmel Dr.', '', 'Norfolk', 'Nebraska', '68701', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '42.036113', '-97.3739855', '', '1', '', '1 - window - 10221', '#26706696', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Prospective', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Lance Novacek    (1) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('193', '154', '', 'Single Property', 'PO Box 516', '', 'Tilden', 'Nebraska', '68781', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '2016-01-19', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '2015-10-27', '10222', '42.0472285', '-97.8339503', '', '1 PD', '', '', '', '1 PD', '0000-00-00', '', '1969-12-31', 'Q1039', '', 'Basic', '', '1969-12-31', '1970', '', '0000-00-00', '', 'hc', '2015-12-08', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'No', '', '', '', '', '12/9/2015: Mark scheduled to Install.', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Doors', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('194', '61', '', 'Single Property', '1713 RD 9', '', 'Clarkson', 'Nebraska', '68629', 'Installed', '0000-00-00', '0000-00-00', '0000-00-00', '2016-02-05', '', '2016-01-04', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Karla ', '2015-10-31', '1969-12-31', '10223', '41.6266398', '-97.0978932', '', '1', '', '1', '#26706699', '', '0000-00-00', '', '2015-12-01', '', '', 'Basic', '', '1969-12-31', '1924', '', '0000-00-00', '', 'HBC', '2016-02-05', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('195', '155', '', 'Single Property', '802 N. Birch', '', 'Norfolk', 'Nebraska', '68701', 'Paid', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '1', '2016-01-21', '2016-01-26', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '1969-12-31', '', '42.0408094', '-97.4009767', '', '3', '', '3 windows - 10224', '#26706700', '', '0000-00-00', '', '1969-12-31', '', '', 'Windows w/ Wraps', '', '1969-12-31', '1990', '', '0000-00-00', '', 'kf', '2015-12-17', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', '', '', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('196', '156', '', 'Single Property', '2303 Prospect Ave', '', 'Norfolk', 'Nebraska', '68701', 'Pending Wrap', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '2016-01-06', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '2015-10-27', '10225', '42.0361254', '-97.4431318', '', '1', '', '1 ', '#26706702', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '1995', '', '0000-00-00', '', 'hc', '2015-12-10', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', '', '', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('197', '48', '', 'Single Property', '', '', 'Norfolk', 'Nebraska', '68701', 'Complete', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '1', '2016-01-21', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '1969-12-31', '', '42.0327234', '-97.4137553', '', '4', '', '4 - windows #10226', '#26707146', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'bf', '2015-12-10', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('198', '158', '', 'Single Property', '211 E. Canfield', '', 'Coleridge', 'Nebraska', '68727', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '2015-12-22', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '1969-12-31', '10228', '42.504378', '-97.201488', '', '2', '', '2 windows - ', '26707359', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '1970', '', '0000-00-00', '', 'HBC', '2015-12-22', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', 'Yes', 'White', '', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', 'Check', '1969-12-31', '', '1969-12-31', '8,215.00', '2015-12-22', '', '');
INSERT INTO customerTickets VALUES ('199', '159', '', 'Single Property', '503 N. Boxelder', '', 'Norfolk', 'Nebraska', '68701', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '2016-01-22', '2016-01-26', '0000-00-00', '0000-00-00', '0000-00-00', '2016-01-22', 'Norfolk', 'Angi', '2015-10-31', '2015-10-28', '10227', '42.0383664', '-97.3975533', '', '6', '', '6 ', '26707255', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '1980', '', '0000-00-00', '', 'kf', '2016-01-26', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', 'Cash', '1969-12-31', '', '1969-12-31', '', '2016-01-26', '', '');
INSERT INTO customerTickets VALUES ('200', '160', '', 'Single Property', '2104 skyline ', '', 'Norfolk', 'Nebraska', '68701', 'Complete', '2015-12-17', '2015-12-17', '0000-00-00', '2015-12-17', '1', '2016-01-14', '2015-12-24', '0000-00-00', '0000-00-00', '0000-00-00', '2016-01-11', 'Norfolk', 'Karla ', '2015-10-31', '2015-12-14', '072-10292', '', '', '', '1 WINDOW', '', '1', '26721141', '', '0000-00-00', '', '1969-12-31', '', '', 'Windows w/ Wraps', '', '1969-12-31', '1975', '', '0000-00-00', '', 'bf', '2015-12-24', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', 'Forest Green', '', 'Yes', 'Sold back in November. Must have forgot to order. Need to install right when this comes in.', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2015-02-11', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('397', '161', '', 'Single Property', '508 logan', '', 'Wayne', 'Nebraska', '68787', 'Ready to Install', '0000-00-00', '2016-01-21', '2016-01-29', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2015-12-23', '1969-12-31', '', '42.2336513', '-97.0163863', '', '4 Sashes', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Double Hung', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-29', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'Upper & Lower for Both
128-583781
128-605236
(Sashes Bowed)', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('202', '162', '', 'Single Property', '2959 18th Ave', '', 'Columbus', 'Nebraska', '68601', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '2016-01-19', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '0000-00-00', '', '', '', '', '3', '', '', '', '3', '0000-00-00', '', '0000-00-00', 'S3573        S3574', '', 'Basic', 'Customer', '0000-00-00', '1977', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Terri Davis       (3) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('203', '163', '', 'Single Property', '2083 300th Ave', '', 'Albion', 'Nebraska', '68620', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '2016-01-19', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '0000-00-00', '', '', '', '', '2', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '1925', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'No', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Wanda Wondercheck      (2)', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '2', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('204', '164', '', 'Single Property', '1922 Keene Dr', '', 'Columbus', 'Nebraska', '68601', 'Paid', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '1', '2016-01-21', '2016-01-26', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Karla ', '2015-10-31', '1969-12-31', '', '', '', '', '3', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Windows w/ Wraps', '', '1969-12-31', '1968', '', '0000-00-00', '', 'bf', '2015-12-21', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', 'Yes', '', '', '', 'paid in full but says on double casement can\'t open either side but filled out her referral letter happy', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('205', '165', '', 'Multiple Property', '205 N. 7th St-Newman Grove', '', 'Humphrey', 'Nebraska', '68642', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '2016-01-19', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '0000-00-00', '', '', '', '', '5', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Windows w/ Wraps', 'Customer', '0000-00-00', '1892', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Justin Wetjen       (5)', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '5', '26687504', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('206', '166', '', 'Single Property', '411 Market Place', '', 'Norfolk', 'Nebraska', '68701', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '2016-01-19', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '0000-00-00', '', '', '', '', '6', '', '6', '#26665551', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '1974', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'No', '', '', '', '', '', '0000-00-00', '', 'Contract Sent', 'October', '2015', '', '', '0000-00-00', 'Robert Oswald        (6) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '4705-0001-0103-7596
$2,750.00
12 months', '');
INSERT INTO customerTickets VALUES ('207', '166', '', 'Single Property', '411 Market Place', '', 'Norfolk', 'Nebraska', '68701', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '2016-01-19', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '0000-00-00', '', '', '', '', '1', '', '1', '26679733', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '1974', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'No', '', '', '', '', '', '0000-00-00', '', 'Contract Sent', 'October', '2015', '', '', '0000-00-00', 'Robert Oswald         (1-had to reorder-used old one on Neighborworks) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '10/29/2015:  HC mailed WF contract
4705-0001-0103-7596
$2,750.00
12 Months', '');
INSERT INTO customerTickets VALUES ('208', '167', '', 'Single Property', '2916 33rd St', '', 'Columbus', 'Nebraska', '68601', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '1', '2016-01-14', '2016-01-14', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Angi', '2015-10-31', '1969-12-31', '', '', '', '', '6 + 1 PD', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Windows w/ Wraps', '', '1969-12-31', '', '', '0000-00-00', '', 'bf', '2015-12-21', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', '', '', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', 'Debit Card', '1969-12-31', '2,500', '1969-12-31', '349', '1969-12-31', '3/27/2015: Paid Downpayment $2,500
8/25/2015: Made payment of $7,000-issues-wont pay balance until issues resolved
10/29/2015: Made Final Payment of $349.00

JOB IS NOW COMPLETE!', '');
INSERT INTO customerTickets VALUES ('209', '168', '', 'Single Property', '2803 Ruthann Circle', '', 'Norfolk', 'Nebraska', '68701', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '2016-01-19', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '0000-00-00', '', '', '', '', '2', '', '', '', '2', '0000-00-00', '', '0000-00-00', 'B5889', '', 'Basic', 'Customer', '0000-00-00', '??', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', 'White', '', '', 'Job Installed by Mark', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Charles & Deb Misfeldt        (2) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('210', '9', '', 'Single Property', '302 S. Madison ', '', 'Hartington', 'Nebraska', '68739', 'Ordered', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2015-10-31', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '10-30-2015: Ordered a new crank mechanism- the gears are slipping. need more than just a handle.', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Jons Mother             (Crank mechanism)', '0000-00-00', '0000-00-00', '0000-00-00', 'Window Repair', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('211', '170', '', 'Single Property', '1020 5th St.', '', 'Columbus', 'Nebraska', '68601', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '2016-01-13', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '0000-00-00', '', '', '', '', '13', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Windows w/ Wraps', 'Customer', '0000-00-00', '1953', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Shauna Seebohm    (13) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '13', '26663431', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('212', '171', '', 'Single Property', '29493 205th Ave', '', 'Columbus', 'Nebraska', '68601', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2015-10-31', '0000-00-00', '', '', '', '', '4', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Tough Install', 'Customer', '0000-00-00', '1998', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'No', '', '', '', '', 'Pull Siding', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Kathy Fadschild     (4) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '4', '#26684972', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('213', '172', '', 'Single Property', '411 E. Park', '', 'Norfolk', 'Nebraska', '68701', 'Estimate', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '0000-00-00', '', '42.0291801', '-97.402617', '', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Prospective', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '059-819941
Casement Sash', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Bryan Bahns      (1 Casement sash) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('214', '173', '', 'Single Property', '764 27th Ave', '', 'Columbus', 'Nebraska', '68601', 'Paid', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '1', '2016-01-26', '2016-01-26', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Karla ', '2015-10-31', '1969-12-31', '', '', '', '', '9', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '1950', '', '0000-00-00', '', 'bf', '2015-12-21', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', 'Yes', '', '', '', 'L\'s
installed by Jeff', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', 'Check', '1969-12-31', '', '1969-12-31', '4115', '1969-12-31', 'paid in full 11/02/15', '');
INSERT INTO customerTickets VALUES ('215', '177', '', 'Single Property', '1004 Redick Ave', '', 'Creighton', 'Nebraska', '', 'Unscheduled', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2015-10-31', '1969-12-31', '', '42.4644447', '-97.9062693', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-22', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('216', '178', '', 'Single Property', '1501 W. Norfolk Ave', '', 'Norfolk', 'Nebraska', '68701', 'Complete', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '1', '2016-01-19', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '0000-00-00', '', '42.032611', '-97.4303004', '', '1 Bay', '', '1 Bay', '26679397', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '?', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'No', '', '', '', '', '11/2/2015: Josh to Install', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Karla Linsteadt         (1 Bay)', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('217', '183', '', 'Single Property', '1204 Meadow Dr', '', 'Norfolk', 'Nebraska', '68701', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '42.0454373', '-97.4296072', '', '1', '', '', '', '1 window - 10233 - norfolk', '0000-00-00', '', '0000-00-00', 'R1442', '', 'Windows w/ Wraps', 'Customer', '0000-00-00', '1966', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', '', '', '', '', '0000-00-00', '', '', 'November', '2015', '', '', '0000-00-00', 'Carrie Brandt      (1) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('218', '184', '', 'Single Property', '', '', 'Columbus', 'Nebraska', '68601', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '2015-12-23', '2016-01-19', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Angi', '2015-10-31', '1969-12-31', '', '41.4302973', '-97.3593904', '', '1', '', 'Cbus: 1', '#26691690', '', '0000-00-00', '', '1969-12-31', '', '', 'Tough Install', '', '1969-12-31', '2012', '', '0000-00-00', '', 'HBC', '2015-12-23', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'No', '', '', '', '', 'Will need to pull siding.', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('219', '179', '', 'Single Property', '2214 Highview Dr.', '', 'Wayne', 'Nebraska', '68787', 'Complete', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '2016-01-21', '0000-00-00', '2016-01-22', '0000-00-00', '0000-00-00', '2016-01-21', 'Norfolk', 'Brent ', '2015-10-31', '1969-12-31', '', '42.2529895', '-97.0316455', '', '2', '', '2 - windows - 10232 - norfolk', '#26708673', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '1977', '', '0000-00-00', '', 'HBC', '2016-01-22', '1', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '1/22/016: Mark took Wrap measurements.

12-3-2015: Told her we could get installed by end of December. She works at school. Will be off for Christmas break near end of month. She will be leaving from Dec 23-29. and she thinks she goes back to school the 7th of January?', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('220', '182', '', 'Single Property', '2921 8th St.', '', 'Columbus', 'Nebraska', '68601', 'Went To Columbus', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Jeff ', '2015-10-31', '2015-11-02', '10231', '41.4241794', '-97.3643072', '', '4', '', '', '', '4 ', '0000-00-00', '', '2015-12-07', 'R1436', '', 'Basic', '', '1969-12-31', '1945', '', '0000-00-00', '', 'hc', '2015-12-09', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', 'White', '', '', '', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('221', '180', '', 'Single Property', '307 Willow', '', 'Norfolk', 'Nebraska', '68701', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '2015-12-18', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '1969-12-31', '10230', '42.0300542', '-97.3961531', '', '1', '', '', '', '1', '0000-00-00', '', '1969-12-31', 'R1431', '', 'Basic', '', '2015-12-11', '1973', '', '0000-00-00', '', 'HBC', '2015-12-18', '1', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', 'Check', '1969-12-31', '', '1969-12-31', '500', '2015-12-15', '', '');
INSERT INTO customerTickets VALUES ('222', '185', '', 'Single Property', '1308  Madison Ave', '', 'Norfolk', 'Nebraska', '68701', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '1', '2016-01-06', '2016-01-06', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '0000-00-00', '', '42.0314233', '-97.4263942', '', '2', '', '', '', '2', '0000-00-00', '', '0000-00-00', 'W2481', '', 'Windows w/ Wraps', 'Customer', '0000-00-00', '1963', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', '', '', '', '', '0000-00-00', '', '', 'November', '2015', '', '', '0000-00-00', 'JoAnn Meyer(2)', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('223', '39', '', 'Single Property', '85043 513th Avenue', '', 'Clearwater', 'Nebraska', '68726', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '2015-12-24', '', '2016-01-13', '2016-01-13', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '1969-12-31', '', '42.1542658', '-98.2429835', '', '6', '', '6', '#26684975', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '??', '', '0000-00-00', '', 'HBC', '2016-01-13', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', '', '', '', '', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('224', '186', '', 'Single Property', '902 Quincy St', '', 'Madison', 'Nebraska', '68748', 'Pending Wrap', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '2015-12-17', '0000-00-00', '2016-01-22', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '1969-12-31', '#10237', '41.8217487', '-97.4504893', '', '3', '', '', '', '3', '0000-00-00', '', '1969-12-31', 'R3936', '', 'Tough Install', '', '2015-12-17', '1875', '', '0000-00-00', '', 'HBC', '2016-01-22', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', 'Other', 'colonial ivory smooth ', '', 'also need two sashes and 1 cherry keeper and patio door rollers

12-18-2015: Mark Scheduled to install', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('225', '186', '', 'Single Property', '902 Quincy St', '', 'Madison', 'Nebraska', '68748', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '1969-12-31', '', '41.8217487', '-97.4504893', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '1875', '', '0000-00-00', '', 'HBC', '2016-01-22', '1', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'ordered 1 keeper rollers and 2 sashes from ami ', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('226', '188', '', 'Single Property', '406 E. Park', '', 'Norfolk', 'Nebraska', '68701', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '2016-01-14', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '0000-00-00', '', '42.0290824', '-97.401857', '', '17 sq', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', 'Siding Installed by Scott', '0000-00-00', '', '', 'November', '2015', '', '', '0000-00-00', 'Dennis Beltz     (siding) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Siding', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('227', '188', '', 'Single Property', '406 E. Park', '', 'Norfolk', 'Nebraska', '68701', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '2016-01-14', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '0000-00-00', '', '', '', '', '1', '', '', '', '1', '0000-00-00', '', '0000-00-00', 'T3963', '', 'Basic', 'Customer', '0000-00-00', '1966', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'November', '2015', '', '', '0000-00-00', 'Dennis Beltz        (1) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('228', '189', '', 'Single Property', '213 S. Maple', '', 'Plainview', 'Nebraska', '', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '2016-01-20', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '1969-12-31', '10248', '', '', '', '3', '', '3 - windows - ', '#26711075', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '1900', '', '0000-00-00', '', 'hc', '2015-11-24', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', 'Tara & Todd Ward         (3) ', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('229', '190', '', 'Single Property', '84981 569th Ave', '', 'Winside', 'Nebraska', '68790', 'Sold', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Windows w/ Wraps', 'Prospective', '0000-00-00', '', '', '0000-00-00', '', 'bf', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', 'White', '', 'Yes', '', '0000-00-00', '', '', 'November', '2015', '', '', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('230', '191', '', 'Single Property', '1783 10th Ave', '', 'Columbus', 'Nebraska', '68601', 'Went To Columbus', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Jeff ', '2015-10-31', '2015-11-02', '10234', '41.4340524', '-97.3383167', '', '2', '', '2', '#26708677', '', '0000-00-00', '', '2015-12-07', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-27', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '12/11/2015: went to install, when we tore the windows out, everything inside was rotten. Have to have a different guy come in and replace that, then we can install. Wont be until spring/summer.', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('231', '181', '', 'Single Property', '805 Irving St.', '', 'Fullerton', 'Nebraska', '68638', 'Went To Columbus', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Jeff ', '2015-10-31', '2015-11-02', '10229', '', '', '', '16', '', '16', '#26708671', '', '0000-00-00', '', '2015-12-07', '', '', 'Basic', '', '1969-12-31', '1900', '', '0000-00-00', '', 'hc', '2015-12-09', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('232', '161', '', 'Single Property', '508 logan', '', 'Wayne', 'Nebraska', '68787', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '2015-12-22', '2016-01-19', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '1969-12-31', '', '', '', '', '4', '', '', '', '4 windows - 10236', '0000-00-00', '', '1969-12-31', 'R3919', '', 'Basic', '', '2015-12-22', '1910', '', '0000-00-00', '', 'HBC', '2015-12-22', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '12/23/2015: Dwayne scheduled to Install', '1969-12-31', '', 'Contract Sent', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '2015-12-22', '', '1969-12-31', '5705-0001-0084-4976
60 months', '');
INSERT INTO customerTickets VALUES ('233', '190', '', 'Single Property', '84981 569th Ave', '', 'Winside', 'Nebraska', '68790', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '', '', '', '1', '', '1 window - #10235', '#26709104', '', '0000-00-00', '', '0000-00-00', '', '', 'Windows w/ Wraps', 'Customer', '0000-00-00', '1920', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', '', '', '', '', '0000-00-00', '', '', 'November', '2015', '', '', '0000-00-00', 'Connie Bargstadt  (1)', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('234', '174', '', 'Single Property', '137 E. Parkway', '', 'Columbus', 'Nebraska', '68601', 'Went To Columbus', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Jeff ', '2015-10-31', '1969-12-31', '', '41.4162159', '-97.3442292', '', '12', '', 'Cbus: 12', '#26687503', '', '0000-00-00', '', '2016-01-01', '', '', 'Windows w/ Wraps', '', '1969-12-31', '', '', '0000-00-00', '', 'jw', '2016-02-05', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', '', '', '', '', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('235', '193', '', 'Single Property', '2836 E. 38th St.', '', 'Columbus', 'Nebraska', '68601', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '2016-01-21', '2016-01-26', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Angi', '2015-10-31', '1969-12-31', '', '41.4531179', '-97.292831', '', '21', '', 'Cbus: 21', '#26691693', '', '0000-00-00', '', '1969-12-31', '', '', 'Windows w/ Wraps', '', '2015-12-08', '', '', '0000-00-00', '', 'kf', '2016-01-26', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', '', '', '', 'Quarterround inside.', '1969-12-31', '', 'Paid', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '2016-01-26', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('236', '126', '', 'Single Property', '1531 7th St', '', 'Duncan', 'Nebraska', '68634', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Jeff ', '2015-10-31', '1969-12-31', '', '', '', '', '8', '', 'Cbus: 8', '#26687505', '', '0000-00-00', '', '1969-12-31', '', '', 'Tough Install', '', '1969-12-31', '2001', '', '0000-00-00', '', 'HBC', '2015-12-21', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('237', '194', '', 'Single Property', '3218 17th St.', '', 'Columbus', 'Nebraska', '68601', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Jeff ', '2015-10-31', '1969-12-31', '', '', '', '', '3', '', 'Cbus: 3', '#26691692', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'bf', '2015-12-21', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'Needs L\'s', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('238', '16', '', 'Multiple Property', '2653 43rd Ave- Columbus', '', 'Saint Edward', 'Nebraska', '68660', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Jeff ', '2015-10-31', '1969-12-31', '', '', '', '', '4', '', '', '', 'Cbus: 4', '0000-00-00', '', '1969-12-31', 'H1433/H1432', '', 'Windows w/ Wraps', '', '1969-12-31', '1952', '', '0000-00-00', '', 'bf', '2016-01-07', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', 'Other', 'Brown', '', '', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('239', '195', '', 'Single Property', '8 Clear Lake Acres', '', 'Columbus', 'Nebraska', '68601', 'Complete', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '1', '2016-01-21', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Karla ', '2015-10-31', '1969-12-31', '', '', '', '', '1', '', '', '', 'Cbus: 1', '0000-00-00', '', '1969-12-31', 'G1196', '', 'Windows w/ Wraps', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-19', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', '', '', '', 'Also wrapping 2 extra windows
1-19-2016: Mailed Inv.
', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('240', '196', '', 'Single Property', '609 Iowa', '', 'Clearwater', 'Nebraska', '68726', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '1', '2016-01-05', '2016-01-13', '0000-00-00', '0000-00-00', '0000-00-00', '2016-01-05', 'Norfolk', 'Angi', '2015-10-31', '0000-00-00', '', '', '', '', '8', '', '8 windows - 10238', '26709176', '', '0000-00-00', '', '0000-00-00', '', '', 'Windows w/ Wraps', 'Customer', '0000-00-00', '1965', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', 'White', '', 'Yes', 'dwayne did first set', '0000-00-00', '', '', 'November', '2015', '', '', '0000-00-00', 'Kathy Patras        (8)', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('241', '197', '', 'Single Property', '', '', 'Emmet', 'Nebraska', '68743', 'Received', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2015-10-31', '1969-12-31', '', '', '', '', '18', '', '15 WINDOWS 10239 AND 1 BAY- 10240', '#26709233        #26709738', '', '0000-00-00', '', '1969-12-31', '', '', 'Tough Install', '', '1969-12-31', '', '', '0000-00-00', '', 'hc', '2015-12-17', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', 'No', 'White', '', 'Yes', '', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('242', '198', '', 'Single Property', '450 15th Rd Lot #1', '', 'West Point', 'Nebraska', '68788', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '', '', '', '10', '', 'Cbus: 10', '#26702189', '', '0000-00-00', '', '0000-00-00', '', '', 'Windows w/ Wraps', 'Customer', '0000-00-00', '??', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', '', '', '', '', '0000-00-00', '', '', 'November', '2015', '', '', '0000-00-00', 'David Nesladek         (10) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('243', '199', '', 'Single Property', '57047 825TH ROAD', '', 'Clarkson', 'Nebraska', '68629', 'Proposal Given', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '2016-01-18', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '1969-12-31', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-18', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('244', '19', '', 'Single Property', '83658 556th Ave', '', 'Norfolk', 'Nebraska', '68701', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '2015-12-21', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '41.9549072', '-97.4071152', '', '12', '', '12 windows - 10243', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'November', '2015', '', '', '0000-00-00', 'Steve & Theresa Perry         (12) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('245', '200', '', 'Single Property', '760 Centennial Pl.', '', 'Columbus', 'Nebraska', '68601', 'Went To Columbus', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Jeff ', '2015-10-31', '2015-11-09', '#10247', '41.4229107', '-97.3359962', '', '6', '', '', '', '5+1PD', '0000-00-00', '', '2015-12-07', 'S4351/S4352', '', 'Windows w/ Wraps', '', '1969-12-31', '1988', '', '0000-00-00', '', 'HBC', '2016-01-27', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', 'Other', 'Brown', '', '', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', 'Debit Card', '1969-12-31', '$2,000.00 ', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('246', '202', '', 'Multiple Property', '306 South 12th St-Norfolk', '', 'Norfolk', 'Nebraska', '68701', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '2015-11-23', '#10269', '42.0297502', '-97.4233178', '', '2', '', '2 windows ', '#26715956', '', '0000-00-00', '', '1969-12-31', '', '', 'Windows w/ Wraps', '', '1969-12-31', '1935', '', '0000-00-00', '', 'hc', '2015-12-10', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', 'No', 'Black', '', '', '', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('247', '203', '', 'Single Property', '201 Main St', '', 'Battle Creek', 'Nebraska', '68715', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '1', '2016-01-19', '2016-01-19', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '0000-00-00', '', '41.999526', '-97.5956403', '', '5', '', '5', '#26696594', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Prospective', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'No', '', '', '', '', 'Need to measure 2 more windows on the south wall; Sunroom when there.', '0000-00-00', '', '', 'November', '2015', '', '', '0000-00-00', 'Wes & Kelly Van Ert      (5) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('373', '305', '', 'Single Property', '51652 Hwy 70', '', 'Elgin', 'Nebraska', '', 'Received', '0000-00-00', '2016-01-25', '2016-02-05', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2015-12-22', '1969-12-31', '', '41.9876561', '-98.2104008', '', '2 Upper Sashes', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Double Hung', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-02-05', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '(2) Top Sashes
126-355106, 109
Reason: Seal Fail
01/25 
(1) top sash
127055127', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('249', '204', '', 'Single Property', '55937 847th Rd', '', 'Hoskins', 'Nebraska', '68740', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '2016-01-19', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '0000-00-00', '', '42.105132', '-97.3419712', '', '20 Sq.', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', 'Contract Sent', 'November', '2015', '', '', '0000-00-00', 'Steve & Sue Falk         (Siding&Gutters)', '0000-00-00', '0000-00-00', '0000-00-00', 'Siding', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '11/6/2015: Mailed WF Contract and Siding warranty.', '');
INSERT INTO customerTickets VALUES ('250', '206', '', 'Single Property', '304 E. Herman', '', 'Battle Creek', 'Nebraska', '', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '2016-01-14', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '0000-00-00', '', '41.9985668', '-97.5943069', '', '2', '', '', '', '1+1PD', '0000-00-00', '', '0000-00-00', 'R1050/51', '', 'Patio', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', 'No', 'Other', 'Cape Cod Gray', '', '11-12-2015: Scheduled Install Date(Dwayne+Matt) ', '0000-00-00', '', '', 'November', '2015', '', '', '0000-00-00', 'Mike Wiedeman                 (1+1PD)', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('251', '207', '', 'DIY', '', '', 'Abie', 'Choose One', '68001', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2015-10-31', '0000-00-00', '', '41.9985668', '-97.5943069', '', '6', '', '5', '26709463', '1 PD', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'November', '2015', '', '', '0000-00-00', 'M&J Roofing      (DIY: 5) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('252', '208', '', 'DIY', '', '', 'Wayne', 'Choose One', '68001', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '1969-12-31', '#10245', '41.9985668', '-97.5943069', '', '2', '', ' ', '', '2 - windows - 10245', '0000-00-00', '', '1969-12-31', 'S4332', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'SDD', '2015-11-24', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', 'Angie Beiermann           (2)', '1969-12-31', '2015-11-23', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', 'Cash', '0000-00-00', '', '1969-12-31', '806.25', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('253', '209', '', 'Single Property', '2580 3rd Ave.', '', 'Columbus', 'Nebraska', '68601', 'Went To Columbus', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Jeff ', '2015-10-31', '1969-12-31', '#10244', '41.4411354', '-97.329758', '', '16', '', '11', '#26711010', '5', '0000-00-00', '', '2015-12-07', 'S4330', '', 'Basic', '', '1969-12-31', '1960', '', '0000-00-00', '', 'hc', '2015-12-09', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', '', '', '', '', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('254', '209', '', 'Single Property', '2580 3rd Ave.', '', 'Columbus', 'Nebraska', '68601', 'Sold', '2015-12-21', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Brent ', '2015-10-31', '1969-12-31', '', '41.4411354', '-97.329758', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Siding', '', '1969-12-31', '1960', '', '0000-00-00', '', 'bf', '2015-12-21', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Siding', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('255', '157', '', 'Single Property', '2616 W. Madison Ave', '', 'Norfolk', 'Nebraska', '68701', 'Scheduled to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '2016-01-11', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '#10250', '42.0319265', '-97.4501696', '', '2', '', '', '', '2 - windows - 10250', '0000-00-00', '', '0000-00-00', 'S6831       S6832', '', 'Basic', '', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', '', '', '', '', '0000-00-00', '', '', 'November', '2015', '', '', '0000-00-00', 'Jeff Jensen    (2) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('256', '63', '', 'Single Property', '55477 834th Rd', '', 'Norfolk', 'Nebraska', '68701', 'Ordered', '2016-01-07', '2016-01-07', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2015-10-31', '1969-12-31', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Two-Story', '', '1969-12-31', '', '', '0000-00-00', '', 'bf', '2016-01-07', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'CALL ELKHORN RURALPOWER ABOUT POWER GOING IN ON EAST SIDE  ', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Siding', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('257', '39', '', 'Single Property', '85043 513th Avenue', '', 'Clearwater', 'Nebraska', '68726', 'Paid', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '1', '2016-01-26', '2016-01-26', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '2015-11-06', '', '', '', '', '1 Screen-WPU if not going that way.', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Other', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-08', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'ordered screen,  she also says one window opens harder than the others ---she will pick up screen if we don\'t have anyone going her way', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('258', '210', '', 'Single Property', '1106 E Sycamore', '', 'Norfolk', 'Nebraska', '68701', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '2015-12-22', '2015-12-23', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '1969-12-31', '', '', '', '', '1', '', '1', '#26711611', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '2015-12-22', '2002', '', '0000-00-00', '', 'HBC', '2015-12-22', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '12/23/2015: Mark Scheduled to Install.', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('259', '212', '', 'Single Property', '2300 Random Rd', '', 'Norfolk', 'Nebraska', '68701', 'Received', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2015-10-31', '2015-11-10', '10251', '', '', '', '10', '', '', '', '10', '0000-00-00', '', '1969-12-31', 'S7310', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'hc', '2015-12-10', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('260', '203', '', 'Single Property', '201 Main St', '', 'Battle Creek', 'Nebraska', '68715', 'Complete', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '1', '2016-01-19', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '1969-12-31', '10253', '', '', '', '2', '', '2 windows - ', '#26711990', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '2015-12-07', '', '', '0000-00-00', '', 'hc', '2015-12-07', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '12/8/2015: Scheduled Install Dat e', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('261', '84', '', 'Single Property', '2607 W. Prospect', '', 'Norfolk', 'Nebraska', '68701', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '2016-01-14', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '1969-12-31', '', '', '', '', '1 PD', '', '', '', '1 patio doo - 10252', '0000-00-00', '', '1969-12-31', 'S9441', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'hc', '2015-12-04', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'first door used on Lyle Lutt', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', 'Michael Kuester      (1PD) ', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('262', '213', '', 'Single Property', '310 Oak St.', '', 'Creston', 'Nebraska', '68631', 'Scheduled', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Prospective', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'November', '2015', '', '', '0000-00-00', 'Zack Linsdley        (estimate)', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('263', '214', '', 'Single Property', '801 W. 10th St.', '', 'Neligh', 'Nebraska', '68756', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '1969-12-31', '2016-01-20', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '1969-12-31', '', '', '', '', '5', '', '4', '#26653051', '1 PD', '0000-00-00', '', '1969-12-31', 'H7420', '', 'Patio', '', '1969-12-31', '', '', '0000-00-00', '', 'ak', '2016-01-20', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', 'Contract Sent', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '11/11/2015: Mailed WF Contract
4705-0001-0102-9247
$3,050', '');
INSERT INTO customerTickets VALUES ('264', '215', '', 'Single Property', '2693 NE39', '', 'Albion', 'Nebraska', '68620', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2015-10-31', '1969-12-31', '', '', '', '', '3', '', '', '', '3 windows - 10260', '0000-00-00', '', '1969-12-31', 'T6605', '', 'Windows w/ Wraps', '', '1969-12-31', '', '', '0000-00-00', '', 'hc', '2015-12-15', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', 'White', '', 'Yes', '', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('265', '216', '', 'Single Property', '107 N 5th', '', 'Newman Grove', 'Nebraska', '68758', 'Paid', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '1', '2016-01-26', '2016-01-26', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '1969-12-31', '', '', '', '', '6', '', '6', '#26712437', '', '0000-00-00', '', '1969-12-31', '', '', 'Tough Install', '', '1969-12-31', '', '', '0000-00-00', '', 'kf', '2015-12-17', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'dont wrap until we do siding just get vinyl stop or exterior quarteround 1 1/4 white interior stop', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('266', '218', '', 'Single Property', '4 Driftwood Dr.', '', 'Columbus', 'Nebraska', '68601', 'Went To Columbus', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Jeff ', '2015-10-31', '2015-11-12', '10254', '41.4172107', '-97.3826709', '', '4', '', '', '', '4 ', '0000-00-00', '', '2015-12-07', 'T1919', '', 'Basic', '', '1969-12-31', '1972', '', '0000-00-00', '', 'HBC', '2016-01-27', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', '', '', '', '', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('267', '220', '', 'DIY', '', '', 'Bellwood', 'Choose One', '68624', 'Paid', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '1', '2016-01-26', '2016-01-26', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '1969-12-31', '', '', '', '', '7', '', '', '', 'Cbus: 7 windows-10257 ', '0000-00-00', '', '1969-12-31', 'T2021', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'hc', '2015-12-07', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '2015-11-12', '2015-12-01', '2015-12-07', 'Windows', '1969-12-31', '', '', '', '', 'Debit Card', '1969-12-31', '', '1969-12-31', '', '2015-12-07', '12/7/2015; Paid in Full.', '');
INSERT INTO customerTickets VALUES ('269', '221', '', 'Single Property', '820 E. Hynes', '', 'O\'Neill', 'Nebraska', '68763', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '1969-12-31', '', '', '', '', '15', '', '14', '#26696265', '1', '0000-00-00', '', '1969-12-31', 'Z1668', '', 'Windows w/ Wraps', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-19', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', '', '', '', 'ordered 1 last cherrywood window from AMI got it on 01/15/16', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('270', '222', '', 'Single Property', '511 N. Pine St', '', 'Norfolk', 'Nebraska', '68701', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '2015-12-30', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '0000-00-00', '', '', '', '', '3', '', '3', '#26696264', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '1953', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'No', '', '', '', '', '', '0000-00-00', '', '', 'November', '2015', '', '', '0000-00-00', 'Bill Lamm        (3) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('271', '223', '', 'Single Property', '1616 W. Berry Hill Dr', '', 'Norfolk', 'Nebraska', '68701', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '2015-12-23', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '0000-00-00', '', '', '', '', '6', '', '6', '#26696266', '', '0000-00-00', '', '0000-00-00', '', '', 'Windows w/ Wraps', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', '', '', '', '11/17/2015: Mark installed', '0000-00-00', '', '', 'November', '2015', '', '', '0000-00-00', 'Jim Wichman        (6) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('272', '224', '', 'Single Property', '84030 562nd Ave', '', 'Stanton', 'Nebraska', '68779', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2015-10-31', '0000-00-00', '', '42.0765342', '-97.2911981', '', '5', '', '5', '#26696209', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '1995', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'No', '', '', '', '', 'CUSTOMER TO FINISH INSIDE & OUT', '0000-00-00', '', 'Approved', 'November', '2015', '', '', '0000-00-00', 'Joel Putters       (5)', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '4705-0001-0112-6811
60 Months', '');
INSERT INTO customerTickets VALUES ('273', '225', '', 'Single Property', '', '', 'Tilden', 'Nebraska', '68781', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '42.0472285', '-97.8339503', '', '3', '', '3', '#26696206', '', '0000-00-00', '', '0000-00-00', '', '', 'Windows w/ Wraps', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', '', '', '', '', '0000-00-00', '', '', 'November', '2015', '', '', '0000-00-00', 'Tilden Housing Authority     (3) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('274', '20', '', 'Single Property', '353 Platte St.', '', 'Platte Center', 'Nebraska', '68653', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '1969-12-31', '', '', '', '', '4', '', '', '', 'Cbus: 4', '0000-00-00', '', '1969-12-31', 'J7667', '', 'Windows w/ Wraps', '', '1969-12-31', '', '', '0000-00-00', '', 'hc', '2015-12-11', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', '', '', '', 'Also has 2 storm doors she wants us to install.', '1969-12-31', '', 'Contract Sent', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '4705-0001-0112-2448
Amount: $2,960
12 months

12/11/2015: HC mailed WF contract.', '');
INSERT INTO customerTickets VALUES ('275', '226', '', 'Single Property', '84953 562nd Ave', '', 'Hoskins', 'Nebraska', '68730', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '1', '2016-01-19', '2016-01-19', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '0000-00-00', '', '', '', '', '2', '', '2', '#26655989', '', '0000-00-00', '', '0000-00-00', '', '', 'Tough Install', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'November', '2015', '', '', '0000-00-00', 'Arvyn & Reta Neuhaus     (2) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('276', '219', '', 'Single Property', '14232 280th St', '', 'Columbus', 'Nebraska', '68601', 'Paid', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '1', '2016-01-21', '2016-01-25', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Karla ', '2015-10-31', '2015-11-12', '10255', '41.5112824', '-97.3196798', '', '11', '', '11', '#26712436', '', '0000-00-00', '', '2015-12-07', '', '', 'Tough Install', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-19', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'No', '', '', '', '', '1/19/2016; Mailed Inv.

Insulate Cavities', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('277', '227', '', 'Single Property', '312 Vroman St', '', 'Winside', 'Nebraska', '68790', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '42.178425', '-97.1765205', '', '8', '', '8', '#26696261           #26702019', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '1910', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'November', '2015', '', '', '0000-00-00', 'Steve Jorgensen       (8)', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('278', '140', '', 'Single Property', '1010 Grainland', '', 'Wayne', 'Nebraska', '68787', 'Installed', '0000-00-00', '0000-00-00', '0000-00-00', '2016-01-04', '1', '2016-01-04', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '0000-00-00', '', '42.2281946', '-97.0295401', '', '', '', '34 sashes     ', '#26705875', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Prospective', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'November', '2015', '', '', '0000-00-00', 'Tiffani Stegeman        (sashes w/ grids) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Window Repair', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('279', '228', '', 'Single Property', '806 S. 5th St.', '', 'Norfolk', 'Nebraska', '68701', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '2016-01-14', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '0000-00-00', '', '42.0243676', '-97.4138031', '', '4', '', '4', '#26679188', '', '0000-00-00', '', '0000-00-00', '', '', 'Cut-In', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', '', '', '', '11/19/15: Scheduled to Install', '0000-00-00', '', '', 'November', '2015', '', '', '0000-00-00', 'Jason Feddern       (4) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('280', '217', '', 'Single Property', '115 S. 9th St. ', '', 'Newman Grove', 'Nebraska', '68758', 'Ordered', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2015-10-31', '0000-00-00', '', '41.7465417', '-97.7731932', '', '1', '', '1 WINDOW - NORFOLK - 10263', '#26713544', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Prospective', '0000-00-00', '1920', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', '', '', '', '', '0000-00-00', '', '', 'November', '2015', '', '', '0000-00-00', 'Mikal Shalikow      (1) RUSH', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('281', '229', '', 'Multiple Property', '207 N. 9th St.-Norfolk', '', 'Norfolk', 'Nebraska', '68701', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '2015-11-16', '10258', '42.0345172', '-97.4192804', '', '3', '', '3', '#26713538', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '1899', '', '0000-00-00', '', 'hc', '2015-12-10', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'No', '', '', '', '', '', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('282', '230', '', 'Multiple Property', '800 E. Klug-Norfolk', '', 'Norfolk', 'Nebraska', '68701', 'Installed', '0000-00-00', '0000-00-00', '0000-00-00', '2016-01-04', '1', '2016-01-04', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '1969-12-31', '', '42.0376777', '-97.3956282', '', '7', '', '7 windows - 10259 - norfolk', '#26713541', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '1977', '', '0000-00-00', '', 'hc', '2015-12-14', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '12/11/215: Josh to install-Hc will mail Inv/Pw later(per Brent)', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('283', '231', '', 'Single Property', '83910 563rd Ave.', '', 'Stanton', 'Nebraska', '68779', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '2015-12-23', '2016-01-19', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '2015-11-16', '10262', '41.9917708', '-97.271736', '', '1', '', '1 ', '#26713543', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '1995', '', '0000-00-00', '', 'HBC', '2015-12-23', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('284', '9', '', 'DIY', '', '', 'Hartington', 'Choose One', '68001', 'Ordered', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2015-10-31', '0000-00-00', '', '41.9917708', '-97.271736', '', '8', '', '', '', '8 window - 10264 - norfolk', '0000-00-00', '', '0000-00-00', 'T7181', '', 'Basic', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'November', '2015', '', '', '0000-00-00', 'Jamie Arens     (8)', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('285', '232', '', 'Multiple Property', 'Apartment Complex: 607 Cedar', '', 'Norfolk', 'Nebraska', '68701', 'Pending Wrap', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '2016-02-04', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2015-10-31', '1969-12-31', '', '42.0327234', '-97.4137553', '', '26', '', '26 windows - 10265- norfolk', '#26713643', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'bf', '2016-01-06', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('286', '233', '', 'Single Property', '2309 18th St.', '', 'Columbus', 'Nebraska', '68601', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '2016-01-19', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '0000-00-00', '', '41.4341267', '-97.3556392', '', '6', '', '', '', 'Cbus: 6', '0000-00-00', '', '0000-00-00', 'B5899', '', 'Basic', 'Customer', '0000-00-00', '1910', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'No', '', '', '', '', '11/17/2015: Jeff to Install', '0000-00-00', '', 'Contract Sent', 'November', '2015', '', '', '0000-00-00', 'Kylee Carey      (6) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '11/16/2015: Mailed Contract
Contract Amount: $2,250.00
4705-0001-0118-1824
12 Months', '');
INSERT INTO customerTickets VALUES ('287', '234', '', 'Single Property', '2907 Dover Dr.', '', 'Norfolk', 'Nebraska', '68701', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '2015-11-16', '10266', '', '', '', '1', '', '', '', '1 ', '0000-00-00', '', '1969-12-31', 'T8920', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'hc', '2015-12-10', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('288', '235', '', 'Single Property', '902 S. Pine St', '', 'Norfolk', 'Nebraska', '68701', 'Estimate', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Prospective', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '11/17/2015: HC mailed a door brochure. Told customer to pick out a style and call us with a model #. We will get the door quoted and have it ready to go with whoever estimates the Picture Window.', '0000-00-00', '', '', 'November', '2015', '', '', '0000-00-00', 'Becky Wulf        (Estimate: 1 Pw/1 Entry Door) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('289', '236', '', 'Single Property', '1305 Sunrise Dr.', '', 'Norfolk', 'Nebraska', '68701', 'Scheduled', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Jerry ', '2015-10-31', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Prospective', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'November', '2015', '', '', '0000-00-00', 'Matt Kampschnieder      (est: 2 basement windows) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('290', '237', '', 'Single Property', '', '', 'Elgin', 'Nebraska', '68636', 'Paid', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '1', '2016-02-01', '2016-02-05', '0000-00-00', '0000-00-00', '0000-00-00', '2016-01-22', 'Norfolk', 'Karla ', '2015-10-31', '2015-11-23', '#10271', '41.9833412', '-98.0836773', '', '10', '', '10', '#26716048', '', '0000-00-00', '', '1969-12-31', '', '', 'Windows w/ Wraps', '', '1969-12-31', '1966', '', '0000-00-00', '', 'kf', '2016-01-28', '1', '', '1969-12-31', '1', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', 'White', '', 'Yes', 'MAY NEED SOME SILLS REPLACED', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', 'paid $4350.00 which is all except the lead and the 2 sills 01/24/16', '');
INSERT INTO customerTickets VALUES ('292', '240', '', 'Single Property', '113 N 5th St.', '', 'Newman Grove', 'Nebraska', '68758', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '2015-11-23', '#10270', '', '', '', '2', '', '2 windows', '#26716047', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '1900', '', '0000-00-00', '', 'hc', '2015-12-14', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'No', '', '', '', '', '12-9-2015: Sent windows w/ Dwayne-He is going to try and install while he is doing Tony Squires windows.', '1969-12-31', '', 'Approved', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '0', '1969-12-31', '', '1969-12-31', 'Approved for: $9,100
4705-0001-0118-6138

12-9-2015: Sent WF Contract(12 months-$920) with Dwayne', '');
INSERT INTO customerTickets VALUES ('293', '230', '', 'Single Property', '116 Norfolk Ave', '', 'Norfolk', 'Nebraska', '68701', 'Installed', '0000-00-00', '0000-00-00', '0000-00-00', '2016-01-04', '1', '2016-01-04', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '2015-11-23', '#10268', '', '', '', '6', '', '6', '#26715956', '', '0000-00-00', '', '1969-12-31', '', '', 'Windows w/ Wraps', '', '1969-12-31', '1960', '', '0000-00-00', '', 'hc', '2015-11-24', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', '', '', '', '', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', 'Jose Leon: 112 E. Klug       (6)', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('294', '241', '', 'Single Property', '510 Hillcrest', '', 'Wayne', 'Nebraska', '68787', 'Installed', '0000-00-00', '0000-00-00', '0000-00-00', '2016-01-22', '', '2016-01-22', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '2016-01-14', 'Norfolk', 'Mark ', '2015-10-31', '2015-11-23', '10267', '42.2402537', '-97.0111274', '', '2', '', '2 windows', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '1953', '', '0000-00-00', '', 'HBC', '2016-01-22', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'No', '', '', '', '', '', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('295', '9', '', 'Multiple Property', 'Lammers', '', 'Hartington', 'Choose One', '68739', 'Paid', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '2016-01-25', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '2015-11-23', '10272', '', '', '', '6', '', '6 ', '26716049', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'hc', '2015-12-14', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', 'Debit Card', '1969-12-31', '', '1969-12-31', '$1,462.00', '2015-12-14', '', '');
INSERT INTO customerTickets VALUES ('296', '243', '', 'Single Property', '913 9th st ', '', 'Wisner', 'Nebraska', '68791', 'Received', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2015-10-31', '2015-11-30', '#10276', '', '', '', '5', '', '5', '#26717126', '', '0000-00-00', '', '1969-12-31', '', '', 'Windows w/ Wraps', '', '1969-12-31', '1968', '', '0000-00-00', '', 'hc', '2015-12-17', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', 'White', '', '', '', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('297', '244', '', 'Single Property', '86530 Old Hwy 81', '', 'Norfolk', 'Nebraska', '68701', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '2015-11-30', '072-10275', '', '', '', '1', '', '', '', '1 window', '0000-00-00', '', '1969-12-31', 'V6279', '', 'Windows w/ Wraps', '', '1969-12-31', '1920', '', '0000-00-00', '', 'hc', '2015-12-14', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', 'White', '', 'No', '', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('298', '245', '', 'Single Property', '1610 W. Benjamin Ave.', '', 'Norfolk', 'Nebraska', '68701', 'Scheduled to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '1', '2016-02-05', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '2016-02-05', 'Norfolk', 'Karla ', '2015-10-31', '2015-11-30', '072-10274', '42.0471332', '-97.4309824', '', '3', '', '3 windows', '#26717124', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '2016-02-05', '1972', '', '0000-00-00', '', 'HBC', '2016-02-05', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '2/5/2016: Josh Scheduled to Install.', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('299', '230', '', 'Multiple Property', '112 klug', '', 'Norfolk', 'Choose One', '68701', 'Complete', '0000-00-00', '0000-00-00', '0000-00-00', '2016-01-04', '', '2016-01-04', '0000-00-00', '2016-01-26', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '2015-11-30', '072-10277', '42.0375938', '-97.394882', '', '4', '', '', '', '4 windows', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'SDD', '2016-01-26', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '1/15/16 girl called for Leon and said we put in a wrong small in the house on 112 (said Norfolk ave.) I\'m assuming Klug as I look at the file  402-992-2612 ', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '1');
INSERT INTO customerTickets VALUES ('300', '246', '', 'Single Property', '207 N 18th ', '', 'Norfolk', 'Nebraska', '68701', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2015-10-31', '1969-12-31', '', '', '', '', '1 Sash', '', '', '', '', '0000-00-00', '', '1969-12-31', 'New: V9657  129-372850', '', 'Double Hung', '', '1969-12-31', '', '', '0000-00-00', '', 'bf', '2015-12-23', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'Sash', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('304', '248', '', 'Single Property', '3658 50th Ave.', '', 'Columbus', 'Nebraska', '68601', 'Went To Columbus', '0000-00-00', '0000-00-00', '2015-12-21', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Jeff ', '2015-12-07', '2015-12-07', '072-10284', '41.4514259', '-97.3915107', '', '1', '', '', '', '1', '0000-00-00', '', '2015-12-22', 'W7471', '', 'Basic', '', '1969-12-31', '1962', '', '0000-00-00', '', 'HBC', '2016-01-27', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2015-12-02', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('305', '249', '', 'Single Property', '2160 24th Ave.', '', 'Columbus', 'Nebraska', '68601', 'Complete', '0000-00-00', '0000-00-00', '2015-12-21', '0000-00-00', '1', '2016-01-14', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Karla ', '2015-12-07', '2015-12-07', '072-10281', '', '', '', '1', '', '', '', '1', '0000-00-00', '', '2015-12-22', 'W7467', '', 'Basic', '', '1969-12-31', '1937', '', '0000-00-00', '', 'HBC', '2015-12-23', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2015-12-02', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('306', '250', '', 'Multiple Property', '1360 30th Ave-Columbus', '', 'Columbus', 'Nebraska', '68601', 'Gift Sent', '0000-00-00', '0000-00-00', '2015-12-22', '0000-00-00', '', '0000-00-00', '2016-01-19', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Angi', '2015-12-07', '2015-12-07', '072-10282', '', '', '', '7', '', '7', '26719328', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2015-12-22', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2015-12-02', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('307', '251', '', 'Single Property', '307 N. 2nd', '', 'Plainview', 'Nebraska', '68769', 'Paid', '0000-00-00', '0000-00-00', '2016-01-18', '0000-00-00', '1', '2016-01-25', '2016-01-26', '0000-00-00', '0000-00-00', '0000-00-00', '2016-01-25', 'Norfolk', 'Karla ', '2015-12-07', '2015-12-07', '072-10280', '', '', '', '1 patio door', '', '', '', '1 PD', '0000-00-00', '', '1969-12-31', 'W7459', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-18', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '1/18/2016: Told this week, or next-depending on weather.', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2015-12-07', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('308', '9', '', 'Multiple Property', 'Folkers', '', 'Hartington', 'Choose One', '68739', 'Gift Sent', '0000-00-00', '0000-00-00', '2015-12-21', '0000-00-00', '', '2015-12-24', '2016-01-14', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-12-07', '2015-12-07', '072-10279', '42.5862849', '-97.394882', '', '6 windows', '', '', '', '6', '0000-00-00', '', '1969-12-31', 'W7458', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2015-12-24', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '2015-12-07', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2015-12-07', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('309', '252', '', 'Single Property', '305 N. 37th St.', '', 'Norfolk', 'Nebraska', '68701', 'Paid', '0000-00-00', '0000-00-00', '2015-12-21', '2016-01-14', '1', '2016-01-14', '2016-02-01', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-12-07', '2015-12-07', '072-10284', '42.0344211', '-97.4656658', '', '2 windows', '', '', '', '2', '0000-00-00', '', '1969-12-31', 'W8091', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'bf', '2016-01-14', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2015-12-07', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('310', '207', '', 'DIY', '', '', 'Abie', 'Choose One', '', 'Invoiced', '0000-00-00', '0000-00-00', '2015-12-24', '0000-00-00', '', '2015-12-24', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2015-12-07', '2015-12-07', '072-10285', '42.0344211', '-97.4656658', '', '2 windows', '', '2', '26719532', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'hc', '2015-12-08', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '2015-12-07', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2015-12-07', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('311', '40', '', 'Single Property', '509 E. 22nd St.', '', 'Schuyler', 'Nebraska', '68661', 'Paid', '0000-00-00', '0000-00-00', '2016-01-04', '0000-00-00', '1', '2016-01-26', '2016-01-27', '0000-00-00', '2016-01-14', '0000-00-00', '2016-01-04', 'Columbus', 'Karla ', '2015-12-08', '2015-12-07', '10278', '41.4596629', '-97.0538058', '', '1', '', '', '', '1', '0000-00-00', '', '1969-12-31', 'W2705', '', 'Basic', '', '1969-12-31', '1976', '', '0000-00-00', '', 'HBC', '2016-01-26', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'MISMEASURE', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', 'Jeff has Cash for this job.', '');
INSERT INTO customerTickets VALUES ('312', '253', '', 'Single Property', '754 7th Ave.', '', 'Columbus', 'Nebraska', '68601', 'Went To Columbus', '0000-00-00', '0000-00-00', '2016-01-04', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Jeff ', '2015-12-08', '2015-12-08', '072-10286', '41.4231852', '-97.3348982', '', '3', '', '', '', '3', '0000-00-00', '', '2016-01-13', 'W9733/W9734', '', 'Tough Install', '', '1969-12-31', '1987', '', '0000-00-00', '', 'HBC', '2016-01-20', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', 'No', '', '', '', '2 WINDOWS AND GARDEN WINDOW', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2015-10-28', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('313', '255', '', 'Single Property', '55034 856 Rd', '', 'Pierce', 'Nebraska', '68767', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '2016-01-19', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-12-08', '1969-12-31', '', '42.235719', '-97.4264491', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '2015-12-08', '', '', '0000-00-00', '', 'hc', '2015-12-08', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Siding', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('314', '257', '', 'Single Property', '2263 Circle Dr', '', 'Columbus', 'Nebraska', '68601', 'Incomplete', '0000-00-00', '0000-00-00', '0000-00-00', '2016-01-08', '', '2016-01-08', '0000-00-00', '0000-00-00', '2016-01-19', '0000-00-00', '0000-00-00', 'Columbus', 'Brent ', '2015-12-08', '2015-07-20', '10028', '41.4376809', '-97.3723077', '', '9', '', '9', '26673921', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '1956', '', '0000-00-00', '', 'HBC', '2016-01-19', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', 'Yes', '', '', '', '', '1969-12-31', '', 'Contract Sent', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '2016-01-08', '', '1969-12-31', '12/8/2015: Mailed Inv.

60 months
$3,300(financing) remaining is $190
4705-0001-0106-6165', '');
INSERT INTO customerTickets VALUES ('315', '258', '', 'Single Property', '420 Exchange St', '', 'Stromsburg', 'Nebraska', '68666', 'Paid', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '1', '2016-01-26', '2016-01-26', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Karla ', '2015-12-08', '2015-06-01', '9941', '41.1143173', '-97.5955667', '', '15', '', '15', '26658732', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '2015-12-08', '1972', '', '0000-00-00', '', 'hc', '2015-12-08', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', 'Yes', '', '', '', '', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '12/8/2015: Mailed Inv.', '');
INSERT INTO customerTickets VALUES ('316', '259', '', 'Single Property', '1972 25th Ave', '', 'Columbus', 'Nebraska', '68601', 'Paid', '0000-00-00', '0000-00-00', '0000-00-00', '2016-01-19', '1', '2016-01-26', '2016-01-26', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Karla ', '2015-12-08', '1969-12-31', '10096', '41.4358228', '-97.3582015', '', '1', '', '1', '26684973', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '2015-12-08', '1890', '', '0000-00-00', '', 'HBC', '2016-01-19', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', 'Yes', '', '', '', '1/19/2016: Mailed Inv.', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '12/8/2015: Mailed Inv.', '');
INSERT INTO customerTickets VALUES ('317', '260', '', 'Multiple Property', '', '', 'Columbus', 'Choose One', '68601', 'Gift Sent', '0000-00-00', '0000-00-00', '2015-12-21', '0000-00-00', '1', '2016-01-22', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Karla ', '2015-12-09', '2015-12-09', '10287', '41.488769', '-97.3084571', '', '5', '', '', '', '5', '0000-00-00', '', '1969-12-31', 'X0468', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'kf', '2016-01-21', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'matching up to the prior windows we installed for them.
1-5-2016: Mailed Inv.
1-19-2016: Mailed Inv.', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '2015-12-09', '2015-12-18', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2015-12-08', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('318', '261', '', 'Single Property', '1400 NORFOLK AVE', '', 'Norfolk', 'Nebraska', '68701', 'Rejected', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', '', '2015-12-09', '1969-12-31', '', '42.0329811', '-97.3677388', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', 'Yes', '2015-12-09', '', 'bf', '2015-12-09', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('319', '261', '', 'Single Property', '1400 NORFOLK AVE', '', 'Norfolk', 'Nebraska', '68701', 'Rejected', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', '', '2015-12-09', '1969-12-31', '', '42.0329811', '-97.3677388', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Single-Story', '', '1969-12-31', '', '', '0000-00-00', '', 'bf', '2015-12-09', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Siding', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('321', '262', '', 'Single Property', '728 E Main', '', 'Pierce', 'Nebraska', '68767', 'Ready to Install', '0000-00-00', '0000-00-00', '2016-01-11', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-12-14', '2015-12-14', '072-10289-ANDERSON', '', '', '', '1', '', '1 ', '26721043', '', '0000-00-00', '', '1969-12-31', '', '', 'Windows w/ Wraps', '', '1969-12-31', '1979', '', '0000-00-00', '', 'HBC', '2016-01-11', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', '', '', '', '1/11/2015: Pw made', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('322', '264', '', 'Single Property', '978 4th Rd', '', 'Wisner', 'Nebraska', '68790', 'Ready to Install', '0000-00-00', '0000-00-00', '2016-01-11', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-12-14', '2015-12-14', '072-10290', '', '', '', '2', '', '2 WINDOWS', '26721138', '', '0000-00-00', '', '1969-12-31', '', '', 'Windows w/ Wraps', '', '1969-12-31', '1922', '', '0000-00-00', '', 'HBC', '2016-01-11', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', 'White', '', '', '1/11/2016: PW made', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('323', '30', '', 'Single Property', '831 S. 8th St.', '', 'Norfolk', 'Nebraska', '68701', 'Complete', '2015-12-18', '0000-00-00', '0000-00-00', '2016-01-22', '', '2016-01-22', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2015-12-14', '2015-12-14', '', '42.0227417', '-97.418011', '', 'Full Job', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-22', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'ordered siding 12-14-15', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Siding', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('324', '266', '', 'Single Property', '505 N 1ST ', '', 'Pierce', 'Nebraska', '68767', 'Ready to Install', '0000-00-00', '0000-00-00', '2016-01-11', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-12-14', '2015-12-15', '072-10294', '', '', '', '8 windows / 3 windows from jose leon - v6286', '', '', '', '8', '0000-00-00', '', '1969-12-31', 'Y0674', '', 'Windows w/ Wraps', '', '1969-12-31', '1957', '', '0000-00-00', '', 'HBC', '2016-01-11', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', '', '', '', '1/11/2015: PW made
do not order until finance approved 
finance approved using 3 jose leon windows from V6286---31 3/4 x 37 1/4 - (3)----129-372950/951/952', '1969-12-31', '', 'Approved', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2015-12-15', '', '1969-12-31', '', '1969-12-31', '4705-0001-0119-5287', '');
INSERT INTO customerTickets VALUES ('325', '267', '', 'Single Property', '311 Brentwood Dr.', '', 'Norfolk', 'Nebraska', '68701', 'Incomplete', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-12-14', '1969-12-31', '', '', '', '', '9', '', '', '', '9', '0000-00-00', '', '1969-12-31', 'F0831', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'hc', '2015-12-14', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('326', '215', '', 'Single Property', '2693 NE39', '', 'Albion', 'Nebraska', '68620', 'Ready to Install', '0000-00-00', '0000-00-00', '2016-01-11', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-12-15', '2015-12-14', '10291', '41.6723187', '-97.9782418', '', '1', '', '', '', '1', '0000-00-00', '', '1969-12-31', 'X8239', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-27', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '1/11/2016: Pw made
*will need L\'s*', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('327', '268', '', 'Single Property', '904 5th St.', '', 'Duncan', 'Nebraska', '', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '2016-01-19', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Angi', '2015-12-15', '2015-11-11', '', '', '', '', 'Active PD Sash', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'bf', '2015-12-24', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('328', '269', '', 'Single Property', '203 S Brown', '', 'Pierce', 'Nebraska', '68767', 'Sold', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2015-12-15', '2015-12-15', '072-10295', '', '', '', '1 window and 1 patiod door', '', '1 window', '', '1 patio door', '0000-00-00', '', '1969-12-31', '', '', 'Windows w/ Wraps', '', '1969-12-31', '', 'Yes', '2015-12-15', '', 'kf', '2015-12-15', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', 'White', '', '', '1 window 1 patio door', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2015-12-15', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('329', '270', '', 'Single Property', '87067 537th Ave', '', 'Creighton', 'Nebraska', '68729', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-12-15', '1969-12-31', '', '', '', '', 'whistling window ', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'ak', '2015-12-15', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'Window is whistling around the frame with directional wind......', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('330', '192', '', 'Single Property', '23122 430th st', '', 'Humphrey', 'Nebraska', '68642', 'Ready to Install', '0000-00-00', '0000-00-00', '2016-01-15', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-12-16', '2015-12-16', '10296', '', '', '', '6', '', '6', '26722059', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '1902', '', '0000-00-00', '', 'HBC', '2016-01-19', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'No', '', '', '', '', 'told her January install', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '1');
INSERT INTO customerTickets VALUES ('331', '269', '', 'Single Property', '203 S Brown', '', 'Pierce', 'Nebraska', '68767', 'Ready to Install', '0000-00-00', '2015-12-18', '2016-01-11', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-12-16', '1969-12-31', '10295', '', '', '', '1+1PD', '', '1', '26721802', '1 PD', '0000-00-00', '', '1969-12-31', 'Y0715', '', 'Windows w/ Wraps', '', '1969-12-31', '1968', '', '0000-00-00', '', 'HBC', '2016-01-11', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', '', '', '', '1/11/2016: PW made', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2015-12-18', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('333', '271', '', 'Single Property', '3451 S Rd', '', 'David City', 'Nebraska', '68632', 'Complete', '0000-00-00', '2015-12-21', '2016-01-20', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Karla ', '2015-12-17', '2015-12-14', '10298', '41.2065368', '-97.1106534', '', '3', '', '3', '26722220', '', '0000-00-00', '', '2016-01-20', '', '', 'Windows w/ Wraps', '', '1969-12-31', '', '', '0000-00-00', '', 'jw', '2016-02-04', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', '', '', '', '', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2015-12-16', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('335', '97', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '', 'Estimate', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', '', '2015-12-17', '1969-12-31', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'SDD', '2015-12-17', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('340', '275', '', 'Single Property', '106 N. Maple St.', '', 'Lindsay', 'Nebraska', '', 'Gift Sent', '0000-00-00', '2016-01-13', '2016-01-14', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '2016-01-25', 'Norfolk', 'Mark ', '2015-12-18', '1969-12-31', '', '41.6999433', '-97.690341', '', '1 PD Panel & Antique Brass Hardware', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'bf', '2016-01-25', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'need a operable panel with cut glass ordered with single prairie came in with double antique brass handle set 
rcvd door panel 01/15/16', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('341', '276', '', 'Single Property', '55491 839 Rd', '', 'Battle Creek', 'Nebraska', '', 'Ready to Install', '2015-12-18', '0000-00-00', '2016-01-20', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-12-18', '1969-12-31', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '1983', '', '0000-00-00', '', 'HBC', '2016-01-20', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', '', '', '', '', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('342', '277', '', 'Single Property', '508 Oak St.', '', 'Stanton', 'Nebraska', '', 'Ready to Install', '0000-00-00', '2015-12-23', '2016-01-20', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-12-18', '2015-12-23', '072-10305', '', '', '', '4 windows', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-20', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '2015-12-23', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2015-12-23', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('344', '280', '', 'Single Property', '55067 878rd', '', 'Wausa', 'Nebraska', '68786', 'Ready to Install', '0000-00-00', '2015-12-21', '2016-01-11', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2015-12-21', '1969-12-31', 'order a part for old garden window ', '42.4994468', '-97.542007', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-25', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '2015-12-21', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('345', '281', '', 'Single Property', '44991 460th Ave', '', 'Lindsay', 'Nebraska', '68644', 'Scheduled to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '2016-01-25', 'Columbus', 'Mark ', '2015-12-21', '2015-11-10', '', '41.7354857', '-97.7151769', '', '1 Glass', '', '', '', '', '0000-00-00', '', '1969-12-31', 'New Glass FO: S8054 129-339769', '', 'Glass', '', '1969-12-31', '', '', '0000-00-00', '', 'bf', '2016-01-25', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('358', '293', '', 'Single Property', '111 Morningside Dr.', '', 'Norfolk', 'Nebraska', '', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2015-12-21', '2015-11-03', '', '42.0327234', '-97.4137553', '', '1 Left Slider Sash', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'bf', '2015-12-23', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'From Outside: Left
122-043356', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('348', '282', '', 'Single Property', '55984 845th Rd', '', 'Norfolk', 'Nebraska', '68701', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2015-12-21', '1969-12-31', '', '42.0765401', '-97.3327039', '', '1 PD Handle', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Other', '', '1969-12-31', '', '', '0000-00-00', '', 'bf', '2015-12-23', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'Patio Door Handle(UNDER HC DESK)', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('349', '284', '', 'Single Property', '1916 W. Prospect Ave', '', 'Norfolk', 'Nebraska', '', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2015-12-21', '2015-04-27', '', '42.0360693', '-97.436088', '', 'Dyad Operator', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '1982', '', '0000-00-00', '', 'bf', '2015-12-23', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'Dyad Operator(UNDER HC DESK)', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('350', '285', '', 'Single Property', '1004 S 3rd St.', '', 'Norfolk', 'Nebraska', '', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '2016-01-07', 'Norfolk', '', '2015-12-21', '2015-10-03', '', '42.0214795', '-97.4097554', '', '4 Balances', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Other', '', '1969-12-31', '1952', '', '0000-00-00', '', 'mp', '2016-01-25', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '(4) Balances.(Under HC Desk)', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('351', '286', '', 'Single Property', '1400 Pierce St.', '', 'Norfolk', 'Nebraska', '', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-12-21', '2015-12-07', '', '42.0170166', '-97.4057687', '', '2 Slider Sashes', '', '', '', '', '0000-00-00', '', '1969-12-31', 'W8288        129-380280,281', '', 'Other', '', '1969-12-31', '', '', '0000-00-00', '', 'bf', '2015-12-23', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '2 Slider Sashes-HE WAS NOT HAPPY WHEN HE CAME IN THE LAST TIME.', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('352', '287', '', 'Single Property', '2061 Brentwood Dr.', '', 'Norfolk', 'Nebraska', '', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2015-12-21', '2015-12-07', '', '42.053498', '-97.354812', '', '1 Upper Sash', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Double Hung', '', '1969-12-31', '1971', '', '0000-00-00', '', 'bf', '2015-12-23', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '(1) Upper sash
Original Serial #: 121-633619
New Serial #: W8296;129-380198

', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('353', '288', '', 'Multiple Property', '603 E. Braasch Ave', '', '', 'Choose One', '', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2015-12-21', '1969-12-31', '', '', '', '', '1 Upper Sash', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Double Hung', '', '1969-12-31', '1962', '', '0000-00-00', '', 'HBC', '2015-12-21', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '(1) Upper Sash
Original: 121-530590
New: X2805; 255-356211', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('354', '289', '', 'Multiple Property', '313 Brentwood Dr.', '', 'Norfolk', 'Nebraska', '68701', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '2016-01-25', 'Norfolk', 'Mark ', '2015-12-21', '2015-08-24', '', '42.0519217', '-97.35466', '', '1 Frame', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Other', '', '1969-12-31', '1990', '', '0000-00-00', '', 'HBC', '2016-01-25', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '1/27/2016: Scheduled to install(home after kids go to school)

(1) Frame
Original: 121-032258
New:C3279; 129-191815', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('355', '290', '', 'Single Property', '2203 Koenigstein Ave', '', 'Norfolk', 'Nebraska', '', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2015-12-21', '1969-12-31', '', '42.034312', '-97.4393299', '', '1 Sash', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Double Hung', '', '1969-12-31', '1969', '', '0000-00-00', '', 'bf', '2015-12-23', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('356', '291', '', 'Single Property', '305 W. Sherwood Rd.', '', 'Norfolk', 'Nebraska', '', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2015-12-21', '2015-10-12', '', '41.9892317', '-97.4105723', '', '1 Glass', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Glass', '', '1969-12-31', '1984', '', '0000-00-00', '', 'bf', '2015-12-23', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '*Also need to look @ Dropping window*

(1) Glass
Original: 122-276592 (SEAL FAIL)', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('359', '294', '', 'Single Property', '201 Shetland Path', '', 'Norfolk', 'Nebraska', '', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2015-12-22', '1969-12-31', '', '42.0561737', '-97.3516342', '', '1 Upper Sash', '', '', '', '', '0000-00-00', '', '1969-12-31', 'New: V4798     129-370159', '', 'Double Hung', '', '1969-12-31', '', '', '0000-00-00', '', 'bf', '2015-12-23', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '(1) Upper Sash
Original 123-911098
Reason: Vandalism

', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('360', '295', '', 'Single Property', '1620 Hackberry', '', 'Norfolk', 'Nebraska', '', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '2016-01-13', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '2016-01-07', 'Norfolk', 'Karla ', '2015-12-22', '2015-11-25', '', '42.051978', '-97.4514305', '', '1 Upper/1 Lower', '', '', '', '', '0000-00-00', '', '1969-12-31', 'New: V4920 129-370160,161', '', 'Double Hung', '', '1969-12-31', '1990', '', '0000-00-00', '', 'HBC', '2016-01-13', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '1 Upper/1 Lower:
Original: Upper 123-536307
             Lower 123-536308
Reason: Seal Fails', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('361', '22', '', 'Single Property', '314 Forest Dr', '', 'Norfolk', 'Nebraska', '68701', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '1', '2016-01-20', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-12-22', '1969-12-31', '', '', '', '', '1 slider sash', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Other', '', '1969-12-31', '', '', '0000-00-00', '', 'ak', '2016-01-04', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'Per Josh 11-24-15:
(1) Left(from outside) Slider Sash
Original: #26693543.2
Reason: Glass Broke
', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('362', '178', '', 'Single Property', '1501 W. Norfolk Ave', '', 'Norfolk', 'Nebraska', '68701', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2015-12-22', '2015-11-09', '', '', '', '', '1 Glass', '', '', 'New: #26711018.1', '', '0000-00-00', '', '1969-12-31', '', '', 'Glass', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2015-12-22', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'PW Glass
Original: #26679397
Reason: Scratches between Panes', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('363', '296', '', 'Single Property', '1004 Nord St.', '', 'Norfolk', 'Nebraska', '', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2015-12-22', '1969-12-31', '', '', '', '', 'WPU: 1 Casement Sash', '', '', '', '', '0000-00-00', '', '1969-12-31', 'New: V4796 129-370150', '', 'Casement', '', '1969-12-31', '', '', '0000-00-00', '', 'bf', '2015-12-23', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '(1) Casement Sash;
From Outside: Left
Original: 127-599060

', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('364', '297', '', 'Single Property', '1305 Sunrise Dr', '', 'Norfolk', 'Nebraska', '68701', 'Paid', '0000-00-00', '2016-01-11', '2016-01-20', '0000-00-00', '1', '2016-01-22', '2016-01-26', '0000-00-00', '0000-00-00', '0000-00-00', '2016-01-22', 'Norfolk', 'Karla ', '2015-12-22', '2015-12-22', '072-10299', '42.0399942', '-97.3866595', '', '2', '', '2', '#26723142', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '1999', '', '0000-00-00', '', 'HBC', '2016-01-22', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', '', '', '', 'told him when they come in i will schedule that day or day after 1-11-16', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('365', '299', '', 'Single Property', '1100 S. 2nd St.', '', 'Norfolk', 'Nebraska', '68701', 'Paid', '0000-00-00', '2016-01-08', '0000-00-00', '2016-01-22', '1', '2016-01-22', '2016-01-25', '0000-00-00', '0000-00-00', '0000-00-00', '2016-01-14', 'Norfolk', 'Karla ', '2015-12-22', '2015-12-22', '072-10301', '', '', '', '4 windows', '', '4', '26723243', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '1915', '', '0000-00-00', '', 'bf', '2016-01-08', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'wife due ', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2012-01-15', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('366', '278', '', 'Multiple Property', 'GRANADA APT: #7', 'bill to plainview', 'Norfolk', 'Nebraska', '68701', 'Installed', '0000-00-00', '2015-12-23', '2016-01-15', '2016-01-27', '', '2016-01-26', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '2016-01-27', 'Norfolk', 'Mark ', '2015-12-22', '2015-12-22', '072-10301', '40.8384376', '-81.3574705', '', '8 windows', '', '8', '26723244', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-27', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'apartment 7', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2015-12-22', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('367', '298', '', 'Single Property', '117 N. Crown Point', '', 'Bloomfield', 'Nebraska', '', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2015-12-22', '2015-11-12', '', '', '', '', 'WPU! 1 Lower Sash', '', '', '', '', '0000-00-00', '', '1969-12-31', 'New: T5269   129-351-954', '', 'Double Hung', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2015-12-22', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '(1) Lower Sash
Original: 123-247949
Reason: Seal Fail', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('368', '300', '', 'Single Property', '56075 854 Rd', '', 'Hoskins', 'Nebraska', '', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2015-12-22', '1969-12-31', '', '', '', '', 'WPU: 1 Upper Sash', '', '', '', '', '0000-00-00', '', '1969-12-31', 'New: N0563   129-298482', '', 'Double Hung', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2015-12-22', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '(1) Upper Sash
Original: 123-941630
', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('369', '301', '', 'Single Property', '601 S. Center St.', '', 'Norfolk', 'Nebraska', '', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', '', '2015-12-22', '1969-12-31', '', '', '', '', '4 Locking Mechanisms', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Other', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2015-12-22', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '(4) locking mechanisms', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('374', '306', '', 'Single Property', '85277 581st Ave', '', 'Wakefield', 'Nebraska', '', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', '', '2015-12-22', '1969-12-31', '', '42.1887973', '-96.9210435', '', '2 sashes/Wrap: 2 doors/1 window-Jon Arens has sashes', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Double Hung', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2015-12-22', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', 'White', '', '', '2 Sashes
Also:
Wrap: 2 doors/1 window(WHITE)', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('371', '302', '', 'Single Property', '700 W. 3rd St.', '', 'Madison', 'Nebraska', '', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-12-22', '2015-10-22', '', '41.8279262', '-97.4620402', '', '12 Balances', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Other', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-27', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('372', '303', '', 'Single Property', '110 Taylor Creek', '', 'Madison', 'Nebraska', '', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-12-22', '1969-12-31', '', '', '', '', '1 Upper Sash', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Double Hung', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-19', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '1/18/2016: Customer Picked Up!

(1) Upper Sash
Original:122-985747', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('375', '307', '', 'Single Property', '1405 Bel Air Rd.', '', 'Norfolk', 'Nebraska', '402-99', 'Gift Sent', '0000-00-00', '2015-12-22', '2016-01-11', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2015-12-22', '2015-12-16', '', '42.0446619', '-97.4286914', '', 'Balances', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Other', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-25', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'Balances for Lower Sash
Original: 125-758484', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('376', '308', '', 'Single Property', '309 N 2nd St.', '', 'Plainview', 'Nebraska', '', 'Ready to Install', '0000-00-00', '2015-12-22', '2015-12-22', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2015-12-22', '2015-12-07', '', '42.3541596', '-97.7864463', '', '1 Upper Sash', '', '', 'New: 26719514.1', '', '0000-00-00', '', '1969-12-31', '', '', 'Double Hung', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2015-12-22', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '(1) Upper Sash
Original: #26696254.4', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('377', '309', '', 'Single Property', '408 Lincoln st ', '', 'Wayne', 'Nebraska', '', 'Ordered', '2015-12-22', '2016-02-01', '0000-00-00', '0000-00-00', '', '0000-00-00', '2016-02-01', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', '', '2015-12-22', '2015-12-22', '', '42.2325645', '-97.0207581', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Tough Install', '', '1969-12-31', '', '', '0000-00-00', '', 'bf', '2015-12-22', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Siding', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('378', '311', '', 'Single Property', '82424 558th Ave.', '', 'Madison', 'Nebraska', '', 'Ready to Install', '0000-00-00', '2015-12-23', '2016-01-20', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-12-22', '2015-12-22', '072-10303', '41.7751808', '-97.3680493', '', '4', '', '4', '26723376', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '?', '', '0000-00-00', '', 'HBC', '2016-01-20', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2015-06-08', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('379', '312', '', 'Single Property', '55491 839 road', '', 'Battle Creek', 'Nebraska', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2015-12-22', '2015-12-22', '10302', '42.0038357', '-97.659381', '', '14', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'kf', '2015-12-22', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2015-01-12', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('380', '72', '', 'Single Property', '2855 40th Ave', '', 'Columbus', 'Nebraska', '68601', 'Received', '0000-00-00', '2015-12-23', '2016-01-20', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Stephen ', '2015-12-22', '2015-12-22', '072-10304', '41.4436363', '-97.3772279', '', '1', '', '', '', '1', '0000-00-00', '', '1969-12-31', 'Z0054', '', 'Basic', '', '1969-12-31', '2006', '', '0000-00-00', '', 'HBC', '2016-01-20', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2015-12-16', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('381', '158', '', 'Single Property', '211 E. Canfield', '', 'Coleridge', 'Nebraska', '68727', 'Gift Sent', '0000-00-00', '0000-00-00', '2015-12-22', '0000-00-00', '', '0000-00-00', '2015-12-23', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-12-22', '2015-12-09', '', '42.504378', '-97.201488', '', '1 Screen', '', '', '', '', '0000-00-00', '', '1969-12-31', 'New: 26720217.1', '', 'Other', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2015-12-22', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'Per Dwayne:
(1) Screen
Original: 26707359.1', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('382', '310', '', 'Single Property', '1709 Bel Air', '', 'Norfolk', 'Nebraska', '', 'Gift Sent', '0000-00-00', '0000-00-00', '2015-12-22', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', '', '2015-12-22', '1969-12-31', '', '42.044394', '-97.4334873', '', 'WPU: 1 sash', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-20', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '(1) Left Sash
Original: #26676605.1


Note: originally ordered a screen as well, factory didnt place that order. had to reordered 12/22/2015', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('383', '310', '', 'Single Property', '1709 Bel Air', '', 'Norfolk', 'Nebraska', '', 'Ready to Install', '0000-00-00', '2015-12-22', '2016-01-20', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2015-12-22', '2015-12-22', '', '42.044394', '-97.4334873', '', '1 Screen-WPU', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Other', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-20', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '(1) Screen
#26676605.1

Note: Angi ordered this back on 12/7/2015,but the factory didnt order it. Had to reorder on 12/22/2015', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('384', '36', '', 'Multiple Property', 'Rental: 308 Kent St-MADISON', '', 'Madison', 'Choose One', '68748', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2015-12-22', '1969-12-31', '', '41.8007023', '-97.394882', '', 'Frame & Sash', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Other', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2015-12-22', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'Frame & Bottom Sash:
Original: 26685136.3', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('396', '316', '', 'Single Property', '2007 Koenigstein Ave', '', 'Norfolk', 'Nebraska', '', 'Scheduled', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-12-23', '1969-12-31', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Attic', '', '1969-12-31', '1966', '', '0000-00-00', '', 'HBC', '2015-12-23', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Solar Zone Attic', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('399', '138', '', 'Single Property', '271 3rd Ave', '', 'Columbus', 'Nebraska', '68601', 'Incomplete', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '2016-01-20', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-12-24', '1969-12-31', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'bf', '2015-12-24', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'Mark needs to put mull on windows', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '1');
INSERT INTO customerTickets VALUES ('400', '322', '', 'Single Property', '402 N 7TH BOX 188', '', 'Plainview', 'Nebraska', '', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Dwayne', '2015-12-24', '1969-12-31', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'bf', '2015-12-24', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '1');
INSERT INTO customerTickets VALUES ('413', '333', '', 'Single Property', '706 n boxelder', '', 'Norfolk', 'Nebraska', '', 'Ready to Install', '0000-00-00', '2016-01-14', '2016-01-29', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2016-01-06', '1969-12-31', '', '42.0398176', '-97.3975106', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-29', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'tear out frames does not want done until it is nicer out
singles', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2016-01-06', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('401', '325', '', 'Single Property', '320 A St.', '', 'Schuyler', 'Nebraska', '', 'Went To Columbus', '0000-00-00', '2016-01-15', '2016-01-18', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Jeff ', '2016-01-04', '2016-01-04', '', '41.439945', '-97.0584955', '', '1 lower sash', '', '', '', '', '0000-00-00', '', '2016-01-20', '', '', 'Double Hung', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-20', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'LOWER SASH', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('402', '44', '', 'Single Property', '56 Lakewood Dr.', '', 'Columbus', 'Nebraska', '68601', 'Need to Order', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Angi', '2016-01-04', '1969-12-31', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-19', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'waiting to talk to jeff on color and Ami vs MI', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Doors', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('403', '327', '', 'Single Property', '53144 865th Rd', '', 'Plainview', 'Nebraska', '68769', 'Installed', '0000-00-00', '2016-01-05', '2016-01-20', '2016-01-25', '', '2016-01-25', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2016-01-05', '2016-01-05', '072-10278', '42.3645694', '-97.9124218', '', '1', '', '1', '26724893', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-25', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2016-01-05', '', '1969-12-31', '', '1969-12-31', 'PAID IN FULL UP FRONT', '');
INSERT INTO customerTickets VALUES ('404', '328', '', 'Multiple Property', '1503 S 4th St.-Norfolk', '', '', 'Choose One', '', 'Scheduled', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2016-01-05', '1969-12-31', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-05', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('405', '29', '', 'Single Property', '1440 Eagle Ridge Circle', '', 'Pierce', 'Nebraska', '68767', 'Ready to Install', '0000-00-00', '2016-01-06', '2016-01-20', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2016-01-05', '1969-12-31', '', '', '', '', '2 Sashes', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Double Hung', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-20', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '1-5-2016: Upper sash came with out grids-reordered via Email.
#26693555.3
1-6-2016: Lower Sash-Broken-Ordered via Email
#26693555.6', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '1');
INSERT INTO customerTickets VALUES ('406', '61', '', 'Single Property', '1713 RD 9', '', 'Clarkson', 'Nebraska', '68629', 'Went To Columbus', '0000-00-00', '2016-01-05', '2016-01-20', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Jeff ', '2016-01-05', '1969-12-31', '', '41.6266398', '-97.0978932', '', '1 Lower Sash', '', '', '', '', '0000-00-00', '', '2016-01-20', '', '', 'Double Hung', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-20', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '1/5/2016: Per Jeff; Ordered Via Email.; Bottom Sash-Broken Glass
26698720.5 ', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '1');
INSERT INTO customerTickets VALUES ('407', '329', '', 'Single Property', '190 Y Rd', '', 'Wisner', 'Nebraska', '', 'Ready to Install', '0000-00-00', '2016-01-05', '2016-01-20', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2016-01-05', '1969-12-31', '', '', '', '', '1 Upper Sash', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Double Hung', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-20', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '1/5/2015: Ordered #26538734.6 
Upper Sash', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('408', '329', '', 'Single Property', '190 Y Rd', '', 'Wisner', 'Nebraska', '', 'Scheduled', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2016-01-05', '1969-12-31', '', '42.0965858', '-96.9435659', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-27', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('422', '47', '', 'Single Property', '2161 412th Rd', '', 'Wisner', 'Nebraska', '68791', 'Scheduled to Install', '0000-00-00', '2016-01-12', '2016-01-27', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '2016-01-29', 'Norfolk', 'Brent ', '2016-01-12', '1969-12-31', '', '41.9872249', '-96.9142055', '', '1 Upper Sash', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '2016-02-04', '', '', '0000-00-00', '', 'HBC', '2016-01-29', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'Upper Sash; Glass Crack
#26672021.4
', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('409', '185', '', 'Single Property', '1308  Madison Ave', '', 'Norfolk', 'Nebraska', '68701', 'Ready to Install', '0000-00-00', '2016-01-20', '2016-01-29', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2016-01-06', '2016-01-19', '10316', '42.0314233', '-97.4263942', '', '1', '', '', '', '1', '0000-00-00', '', '1969-12-31', 'B8313', '', 'Basic', '', '1969-12-31', '1963', '', '0000-00-00', '', 'HBC', '2016-01-29', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'wants as soon as we can not when it warms up
Wants 1-4000-wh/wh double pane slider with full screen.', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2016-01-18', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('410', '330', '', 'Multiple Property', 'Downtown: 426 W. Norfolk Ave:(2nd Act)', '', 'Norfolk', 'Nebraska', '68701', 'Pending Wrap', '0000-00-00', '2016-01-14', '2016-01-29', '0000-00-00', '', '1969-12-31', '0000-00-00', '2016-02-04', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2016-01-06', '1969-12-31', '10310', '42.0327234', '-97.4137553', '', '8', '', '', '', '8', '0000-00-00', '', '1969-12-31', 'B1940', '', 'Tough Install', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-29', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', '', '', '', 'DOWN TOWN BUILDING NEED A LIFT TO WRAP ', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2016-01-06', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('411', '331', '', 'Multiple Property', 'Rental: 305 S. 14th St-Norfolk', '', 'Norfolk', 'Nebraska', '68701', 'Installed', '0000-00-00', '2016-01-27', '2016-02-04', '2016-02-05', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '2016-02-04', 'Norfolk', 'Mark ', '2016-01-06', '1969-12-31', '10312', '42.0327234', '-97.4137553', '', '2', '', '2', '#26726808', '', '0000-00-00', '', '1969-12-31', '', '', 'Windows w/ Wraps', '', '1969-12-31', '1952', '', '0000-00-00', '', 'HBC', '2016-02-05', '1', '', '1969-12-31', '1', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', 'White', '', '', '', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('412', '332', '', 'Single Property', '601 14th', '', 'Stanton', 'Nebraska', '', 'Scheduled to Install', '0000-00-00', '2016-01-14', '2016-02-04', '0000-00-00', '1', '2016-02-05', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '2016-02-05', 'Norfolk', 'Karla ', '2016-01-06', '1969-12-31', '10311', '41.947231', '-97.2293058', '', '4', '', '4', '26726806', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-02-05', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'No', '', '', '', '', 'DO ASAP', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2015-12-23', '', '1969-12-31', '', '1969-12-31', '', '1');
INSERT INTO customerTickets VALUES ('426', '344', '', 'Single Property', '391 Rd X', '', 'Clarkson', 'Nebraska', '', 'Scheduled', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2016-01-13', '1969-12-31', '', '41.728263', '-97.2045919', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Siding', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-02-05', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'We did original siding. Had a tree fall and break their siding. Want a price to fix, so they can determine if they need to turn into insurance or not.

Back side of the house.', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Siding', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('414', '334', '', 'Single Property', '54572 839th Rd', '', 'Battle Creek', 'Nebraska', '', 'Unscheduled', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2016-01-07', '1969-12-31', '', '41.9892215', '-97.5911887', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-20', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '1/7/2016: Gave to Jerry to set up.', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('415', '335', '', 'Single Property', '85879 528TH', '', 'Brunswick', 'Nebraska', '', 'Ordered', '0000-00-00', '2016-01-07', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2016-01-07', '1969-12-31', '', '42.345923', '-97.951154', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'bf', '2016-01-07', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Siding', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('416', '336', '', 'Single Property', '1503 4th st', '', 'Norfolk', 'Nebraska', '', 'Ordered', '0000-00-00', '2016-01-08', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2016-01-08', '1969-12-31', '', '42.0161229', '-97.4117065', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'bf', '2016-01-08', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'he will pay for repairs thought we would bill when we know costs', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '2016-01-08', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('417', '257', '', 'Single Property', '2263 Circle Dr', '', 'Columbus', 'Nebraska', '68601', 'Ordered', '0000-00-00', '2016-01-08', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Hailey', '2016-01-08', '1969-12-31', '', '41.4376809', '-97.3723077', '', 'screens', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-08', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('418', '338', '', 'Single Property', '131 Hillside Drive', '', 'Hadar', 'Nebraska', '', 'Proposal Given', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '2016-01-13', '0000-00-00', 'Norfolk', 'Angi', '2016-01-11', '1969-12-31', '', '42.1019692', '-97.4546204', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-13', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('419', '339', '', 'Single Property', '3322 Brunken', '', 'Columbus', 'Nebraska', '', 'Scheduled', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', '', '2016-01-11', '1969-12-31', '', '41.443285', '-97.3699811', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-11', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('420', '261', '', 'Single Property', '1400 NORFOLK AVE', '', 'Norfolk', 'Nebraska', '68701', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', '', '2016-01-12', '1969-12-31', '', '42.0329811', '-97.3677388', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-27', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'pick up screens from norfolk vac and rescreen', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('421', '340', '', 'Single Property', '101 Calcavechia ', '', 'Laurel', 'Nebraska', '', 'Proposal Given', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '2016-01-12', '0000-00-00', 'Norfolk', '', '2016-01-12', '1969-12-31', '', '42.4284687', '-97.0913752', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'bf', '2016-01-12', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('423', '341', '', 'Single Property', '85919 526th Ave.', '', 'Brunswick', 'Nebraska', '', 'Received', '0000-00-00', '2016-01-29', '2016-02-05', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2016-01-12', '1969-12-31', '', '42.3499498', '-97.9901523', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Double Hung', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-02-05', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '2/5/16: Customer will pick up @ the end of Next week.

NOTE:HE WOULD LIKE PRICE ON ADDING GRIDS BEFORE WE ORDER
Seal Fails: 124-363515(Upper&Lower)
                124-363510(Lower)  

01/25 called and talked to Eugene told him $40 per sash to add grids.....said he  would call back and let us know....holding off on ordering sashes until he calls 
Angi 
01/25 wants to order all 12 windows with grids    total $960   if we install great, but he could pick them up and do it also!  
', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('424', '342', '', 'Single Property', '2700 32nd St.', '', 'Columbus', 'Nebraska', '68601', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '1', '2016-01-14', '2016-01-14', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Angi', '2016-01-13', '1969-12-31', '072-10081', '41.4467843', '-97.3607593', '', '8', '', '', '', '8 ', '0000-00-00', '', '1969-12-31', 'B3252', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-14', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', 'Paid', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2016-01-13', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('425', '343', '', 'Single Property', '56418 hwy 32', '', 'Leigh', 'Nebraska', '', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '2016-01-13', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2016-01-13', '1969-12-31', '', '41.8301991', '-97.2473104', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'kf', '2016-01-13', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Siding', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('427', '345', '', 'Single Property', '305 S. 5th St.', '', 'Battle Creek', 'Nebraska', '', 'Ordered', '2016-01-20', '2016-01-21', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2016-01-13', '2016-01-21', '072-10321', '41.9971132', '-97.6025743', '', '11', '', '11', '26728238', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '1964', '', '0000-00-00', '', 'HBC', '2016-01-21', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'full tear out - take 6000 ami white weephole covers', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2016-01-20', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('428', '346', '', 'Single Property', '754 19th Ave', '', 'Columbus', 'Nebraska', '', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '1', '2016-01-14', '2016-01-14', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2016-01-13', '1969-12-31', '10025', '41.4236746', '-97.3507654', '', '3', '', '3', '26673918', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-14', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('429', '348', '', 'Single Property', '3272 33rd Ave', '', 'Columbus', 'Nebraska', '', 'Paid', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '1', '2016-01-14', '2016-01-25', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Karla ', '2016-01-14', '1969-12-31', '10048', '', '', '', '3', '', '3', '26678082', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-14', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('430', '347', '', 'Single Property', '2877 38th Ave', '', 'Columbus', 'Nebraska', '68601', 'Received', '0000-00-00', '2016-01-14', '2016-01-29', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Stephen ', '2016-01-14', '1969-12-31', '', '41.4443805', '-97.374065', '', '1 Casement Sash', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Casement', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-29', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'order sash #127-081960 left side from outside ', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('431', '350', '', 'Single Property', '315 W. 9th St.', '', 'Schuyler', 'Nebraska', '', 'Paid', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '1', '2016-01-14', '2016-01-25', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Karla ', '2016-01-14', '2015-08-25', '10101', '', '', '', '2', '', '', '', '2', '0000-00-00', '', '1969-12-31', 'C4916', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-14', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('432', '351', '', 'Single Property', '927 South 7th', '', 'Albion', 'Nebraska', '68620', 'Received', '0000-00-00', '2016-01-25', '2016-02-05', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Stephen ', '2016-01-14', '1969-12-31', '', '41.6845192', '-98.0051086', '', '1 Lower Sash', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Double Hung', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-02-05', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'lower    124-187122', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('433', '352', '', 'Single Property', '1556 Rd 11', '', 'Clarkson', 'Nebraska', '', 'Rejected', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2016-01-14', '1969-12-31', '', '41.6588457', '-97.0596031', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-21', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '1/14/2016: Left message-had a request from Vermillion Farm Show for an estimate', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('434', '353', '', 'Single Property', '53567 Hwy 57', '', 'Stanton', 'Nebraska', '68779', 'Ready to Install', '0000-00-00', '2016-01-14', '2016-01-29', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2016-01-14', '1969-12-31', '', '41.9096136', '-97.2139872', '', '4 Sashes', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Other', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-29', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '125-115142
125-115140 
4 sashes (rt/left each)', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('435', '354', '', 'Single Property', '324 W. 4th St.', '', 'Clarkson', 'Nebraska', '', 'Proposal Given', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '2016-01-22', '0000-00-00', 'Norfolk', 'Brent ', '2016-01-14', '1969-12-31', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-14', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'He is a teacher. After 4 is the best times for him.

Scheduled for Thurs Jan 21', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('438', '356', '', 'Multiple Property', 'Rental: 217 Jefferson Ave-Norfolk', '', 'Norfolk', 'Choose One', '68701', 'Ordered', '2016-01-20', '2016-01-21', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2016-01-18', '2016-01-20', '072-10320', '42.0375938', '-97.394882', '', '3', '', '3', '26728236', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '1905', '', '0000-00-00', '', 'HBC', '2016-01-21', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', '', '', '', '', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2016-01-20', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('439', '357', '', 'Multiple Property', '200 South 8th St. ', '', 'Humphrey', 'Nebraska', '68642', 'Scheduled', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Jeff ', '2016-01-18', '1969-12-31', '', '41.6905522', '-97.4905731', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-02-05', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '2/8/2016: new scheduled date for estimate.
2/5/2016: Customer called-HC forgot to put on calendar-Rescheduled
2/5/2016: Scheduled date for estimate.
Schedule Estimate for his sons house....Kevin will be the contact! 

Leaving town Thurs thru next Wed', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('440', '358', '', 'Single Property', '2846 Old Mill Rd', '', 'Albion', 'Nebraska', '68620', 'Received', '0000-00-00', '0000-00-00', '2016-02-05', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Stephen ', '2016-01-18', '1969-12-31', '', '41.7036026', '-98.0403533', '', '1 Glass', '', '', '', '', '0000-00-00', '', '2016-01-20', '', '', 'Glass', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-02-05', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('441', '359', '', 'Single Property', '205 S 3rd', '', 'Battle Creek', 'Nebraska', '', 'Sold', '2016-01-21', '0000-00-00', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2016-01-18', '1969-12-31', '', '41.9985112', '-97.5994183', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Single-Story', '', '1969-12-31', '1987', '', '0000-00-00', '', 'bf', '2016-01-21', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', 'Other', 'royal brown', '', 'wants to wait until around march that is when her farm rent comes in', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Siding', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('442', '360', '', 'Single Property', '85430 521s Ave', '', 'Neligh', 'Nebraska', '', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2016-01-18', '1969-12-31', '', '', '', '', '1 Sash', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Double Hung', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-18', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'WPU! Told customer its in. She requested we put in if we go that way. I told her if we go that way, before she comes to Norfolk, we can take with us.', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('443', '361', '', 'Single Property', '54827 Hwy 20', '', 'Osmond', 'Nebraska', '', 'Unscheduled', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2016-01-18', '1969-12-31', '', '42.3513479', '-97.6139322', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-26', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '1/18/2016: Gave to Jerry.', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('444', '115', '', 'Single Property', '300 N. 3rd St.', '', 'Ulysses', 'Nebraska', '68669', 'Ordered', '0000-00-00', '2016-01-18', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2016-01-18', '2015-12-11', '', '', '', '', '1 Lower Sash', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-18', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '1 Lower sash-Per Jeff', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '1');
INSERT INTO customerTickets VALUES ('445', '362', '', 'Single Property', '82637 547th Ave', '', 'Madison', 'Nebraska', '', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '1969-12-31', '2016-01-20', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2016-01-18', '1969-12-31', '', '41.8017049', '-97.5811579', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Other', '', '1969-12-31', '', '', '0000-00-00', '', 'ak', '2016-01-20', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'NEED TO MOVE THE LOCK ON A WINDOW', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('446', '363', '', 'Single Property', '3168 Kummer Dr', '', 'Columbus', 'Nebraska', '', 'Received', '0000-00-00', '2016-01-19', '2016-01-29', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Stephen ', '2016-01-18', '1969-12-31', '', '41.4465285', '-97.3611243', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Other', '', '1969-12-31', '1979', '', '0000-00-00', '', 'HBC', '2016-01-29', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'Balances for Bottom Sash: 122-085674', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('447', '58', '', 'Single Property', 'P.O. BOX 1833', '', 'Norfolk', 'Nebraska', '68701', 'Received', '0000-00-00', '2016-01-19', '2016-01-19', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', '', '2016-01-19', '2016-01-19', '', '42.0327234', '-97.4137553', '', '8 windows', '', '10315', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'kf', '2016-01-19', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '400 east blaine
use 1 31 3/4 x 37 1/4 window from jose leon job #267-15933.3', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2016-01-15', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('448', '364', '', 'Multiple Property', 'Rental: Madison', '1104 W. 5th St.', 'Madison', 'Nebraska', '68748', 'Proposal Given', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '2016-01-22', '0000-00-00', 'Norfolk', 'Brent ', '2016-01-19', '1969-12-31', '', '41.8279842', '-97.4549636', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-20', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('449', '303', '', 'Single Property', '110 Taylor Creek', '', 'Madison', 'Nebraska', '', 'Ready to Install', '0000-00-00', '2016-01-19', '2016-01-29', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2016-01-19', '1969-12-31', '', '41.8426598', '-97.4570778', '', '1 Upper Sash', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Double Hung', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-29', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '1 Upper Sash: 122-985746 (Seal Fail)', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('450', '357', '', 'Single Property', '41960 220th Ave ', '', 'Humphrey', 'Nebraska', '68642', 'Ready to Install', '0000-00-00', '2016-01-19', '2016-01-29', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2016-01-19', '1969-12-31', '', '41.67819', '-97.406944', '', '3 Upper Sashes', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Double Hung', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-29', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'Upper Sashes:
1; 124-471611
1; 124-471612
1; 124-471616
(Seal Fails)', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('451', '58', '', 'Multiple Property', 'Rental: 402 Blaine-Norfolk', '', '', 'Choose One', '', 'Received', '0000-00-00', '2016-01-19', '2016-02-04', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2016-01-19', '1969-12-31', '10315', '', '', '', '9', '', '9', '8-#26727750     1-#26715955', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'kf', '2016-02-04', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('452', '365', '', 'Multiple Property', '408 LOGAN- EMERSON, NEBRASKA  68733', '', 'Emerson', 'Choose One', '68733', 'Scheduled to Install', '0000-00-00', '2016-01-20', '2016-01-29', '0000-00-00', '1', '2016-02-05', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '2016-02-05', 'Norfolk', 'Karla ', '2016-01-19', '2016-01-19', '072-10317', '42.3041289', '-96.7386946', '', '10', '', '', '', '10', '0000-00-00', '', '1969-12-31', 'B8926 B8927', '', 'Basic', '', '2016-02-10', '', '', '0000-00-00', '', 'HBC', '2016-02-05', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '2/10/16: Josh Scheduled to Install


DAUGHTERS HOUSE MELISSA
south wall', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2016-01-18', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('453', '365', '', 'Multiple Property', '804 8TH ST - WISNER', '', 'Wisner', 'Choose One', '68791', 'Scheduled to Install', '0000-00-00', '2016-01-20', '2016-01-29', '0000-00-00', '', '2016-02-05', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '2016-02-05', 'Norfolk', 'Brent ', '2016-01-19', '2016-01-19', '', '42.0067679', '-96.9423844', '', '9', '', '', '', '9', '0000-00-00', '', '1969-12-31', 'B8933', '', 'Basic', '', '2016-02-10', '', '', '0000-00-00', '', 'HBC', '2016-02-05', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '2/10/2016: Josh scheduled to install

SON JUSTIN HOUSE
north b', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2016-01-18', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('454', '366', '', 'Single Property', '1003 Poplar', '', 'Wayne', 'Nebraska', '', 'Ready to Install', '2016-01-19', '2016-01-20', '2016-01-29', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '2016-01-19', '0000-00-00', 'Norfolk', 'Brent ', '2016-01-19', '2016-01-20', '10319', '42.2371926', '-97.0052111', '', '1', '', '', '', '1', '0000-00-00', '', '1969-12-31', 'B8953', '', 'Tough Install', '', '1969-12-31', '1983', '', '0000-00-00', '', 'HBC', '2016-01-29', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', 'White', '', '', 'NEED 1 1/4 IN DARK OAK TRIM
picture window rack', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('455', '116', '', 'Single Property', '4019 13th St.', '', 'Columbus', 'Nebraska', '68601', 'Went To Columbus', '0000-00-00', '0000-00-00', '2016-01-20', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Jeff ', '2016-01-20', '1969-12-31', '', '41.4296466', '-97.3769903', '', 'Bronze Sill Expander', '', '', '', '', '0000-00-00', '', '2016-01-20', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-20', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('456', '223', '', 'Single Property', '1616 W. Berry Hill Dr', '', 'Norfolk', 'Nebraska', '68701', 'Gift Sent', '0000-00-00', '0000-00-00', '2016-01-20', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2016-01-20', '1969-12-31', '', '42.0513611', '-97.4493864', '', '4 Sashes', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-20', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '#26723256.2
2-left
2-Right', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('457', '367', '', 'Single Property', '911 E. Walnut', '', 'West Point', 'Nebraska', '', 'Scheduled to Install', '0000-00-00', '0000-00-00', '2016-01-20', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '2016-01-29', 'Norfolk', 'Brent ', '2016-01-20', '1969-12-31', '', '41.8420063', '-96.7026489', '', '12 Full Flex Screens', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Other', '', '2016-02-04', '', '', '0000-00-00', '', 'HBC', '2016-01-29', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '2/4/2016: Scheduled Install date', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('458', '356', '', 'Single Property', '', '', 'Norfolk', 'Nebraska', '', 'Sold', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', '', '2016-01-20', '1969-12-31', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'kf', '2016-01-20', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'sold - do siding as soon as possible--karla sent him a color chart 01/20/16 - oddssey dutchlap - jerry thought a dark green, soffit fascia and a little bit of gutters', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Siding', '1969-12-31', '', '', '', '', '', '2016-01-20', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('459', '368', '', 'Single Property', '800 N. Hwy 35', '', 'Norfolk', 'Nebraska', '', 'Ordered', '0000-00-00', '2016-01-25', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2016-01-20', '1969-12-31', '', '42.0244764', '-97.3851472', '', '2 Casement sashes.', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'ak', '2016-01-25', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'Bay: Both Casement sashes
127-534010
127-534011
(seal fails)', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('460', '345', '', 'Single Property', '305 S. 5th St.', '', 'Battle Creek', 'Nebraska', '', 'Received', '0000-00-00', '2016-01-21', '2016-02-05', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2016-01-20', '1969-12-31', '', '41.9971132', '-97.6025743', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-21', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'need to take weep hole covers also 6000 ami

125-019078(upper)', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('461', '369', '', 'DIY', '', '', '', 'Choose One', '', 'Gift Sent', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '2016-01-21', '2016-01-22', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2016-01-21', '1969-12-31', '', '', '', '', 'DIY', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-22', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '2016-01-07', '2016-01-12', '2016-01-21', 'Siding', '1969-12-31', '', '', '', '', 'Check', '1969-12-31', '', '1969-12-31', '150.50', '2016-01-21', '', '');
INSERT INTO customerTickets VALUES ('462', '370', '', 'Single Property', '210 E. 17th Ave', '', 'Schuyler', 'Nebraska', '', 'Scheduled', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Jeff ', '2016-01-21', '1969-12-31', '', '41.4554214', '-97.058091', '', 'Bay', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '1991', '', '0000-00-00', '', 'HBC', '2016-01-26', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'Est: Bay Windows', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('463', '237', '', 'Single Property', '', '', 'Elgin', 'Nebraska', '68636', 'Received', '0000-00-00', '2016-01-28', '2016-02-04', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2016-01-21', '1969-12-31', '', '41.9833412', '-98.0836773', '', '1 screen', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'kf', '2016-02-04', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '1/20/2016: per Dwayne
1; 1/2 screen
#26716048.1
(damaged when we went to install)', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('464', '103', '', 'Single Property', '203 S. 4th St.', '', 'Humphrey', 'Nebraska', '68642', 'Ordered', '0000-00-00', '2016-01-26', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2016-01-22', '2016-01-26', '072-10322', '41.6904069', '-97.4859655', '', '7', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Windows w/ Wraps', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-26', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', 'White', '', '', 'easy but L\'s not full wrap wants josh And mike', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2016-01-21', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('465', '371', '', 'Single Property', '84707 Airport Rd', '', 'Neligh', 'Nebraska', '', 'Need to Order', '2016-02-04', '0000-00-00', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2016-01-22', '1969-12-31', '', '42.1286177', '-98.0297887', '', '7', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-22', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('467', '372', '', 'Single Property', '909 1 ST SE', '', 'Lyons', 'Iowa', '51031', 'Ordered', '0000-00-00', '2016-01-22', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Sioux City', 'Hailey', '2016-01-22', '2016-01-20', '121-2236', '41.9328833', '-96.4786528', '', '5', '', '5', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'sr', '2016-01-22', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', 'Check', '2016-01-20', '1,982.50', '2016-01-20', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('468', '373', '', 'Single Property', '704 CONISTON CR', '', 'Table Rock', 'Iowa', '51054', 'Ordered', '0000-00-00', '2016-01-22', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Sioux City', 'Hailey', '2016-01-22', '2016-01-20', '121-2235', '42.3976322', '-96.3013432', '', '1', '', '1', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Tough Install', '', '1969-12-31', '2002', '', '0000-00-00', '', 'sr', '2016-01-22', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'No', '', '', '', '', 'NEW CONSTURCTION FULL FRAME REMOVAL', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', 'Check', '2016-01-19', '542.50', '2016-01-19', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('469', '374', '', 'Multiple Property', '1425 W WILLIS ST', '', 'Sioux City', 'Choose One', '51101', 'Ordered', '0000-00-00', '2016-01-22', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Sioux City', 'Hailey', '2016-01-22', '2016-01-21', '121-2237', '42.5208298', '-96.4260328', '', '1', '', '1', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '1953', '', '0000-00-00', '', 'sr', '2016-01-22', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'NEED TO TEST FOR LEAD', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', 'Check', '2016-01-21', '195.00', '2016-01-21', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('470', '375', '', 'Single Property', '2671 Pershing', '', 'Columbus', 'Nebraska', '', 'Received', '0000-00-00', '2016-01-25', '2016-02-05', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Stephen ', '2016-01-22', '1969-12-31', '', '41.4418467', '-97.3524594', '', '1 Casement Sash', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Casement', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-02-05', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'Casement Sash:
From Outside-Right
126-866129
(Glass Crack)', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('471', '376', '', 'Single Property', '1833 S CYPRESS ST', '', 'Sioux City', 'Iowa', '51106', 'Ordered', '0000-00-00', '2016-01-22', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Sioux City', 'Hailey', '2016-01-22', '2016-01-22', '121-2238', '42.4720304', '-96.3411448', '', '13', '', '13', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '1955', '', '0000-00-00', '', 'sr', '2016-01-22', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', 'Approved', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2016-01-21', '', '1969-12-31', '', '1969-12-31', 'FINANCING APPROVED UP TO $8300.00', '');
INSERT INTO customerTickets VALUES ('472', '378', '', 'Single Property', '2201 Bel Air Road', '', 'Norfolk', 'Nebraska', '', 'Scheduled', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2016-01-25', '1969-12-31', '', '42.0463748', '-97.4383882', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '1991', '', '0000-00-00', '', 'HBC', '2016-01-25', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('473', '379', '', 'Single Property', '705 W. Pierce St.', '', 'Pierce', 'Nebraska', '', 'Sold', '2016-01-28', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Jerry ', '2016-01-25', '1969-12-31', '', '42.2009471', '-97.5348263', '', '1', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-25', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('474', '380', '', 'Single Property', '5152 83rd St. ', '', 'Columbus', 'Nebraska', '68601', 'Ordered', '2016-01-27', '2016-01-27', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Hailey', '2016-01-25', '2016-01-27', '10326', '41.4967591', '-97.3788153', '', '2', '', '2', '26729396', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '1919', '', '0000-00-00', '', 'HBC', '2016-01-27', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2016-01-27', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('475', '381', '', 'Single Property', '4923 35th st', '', 'Columbus', 'Nebraska', '68601', 'Paid', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '2016-01-26', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', '', '2016-01-26', '2015-08-03', '', '41.4502262', '-97.391061', '', '7 ', '', '26678024', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'kf', '2016-01-26', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('476', '19', '', 'Single Property', '83658 556th Ave', '', 'Norfolk', 'Nebraska', '68701', 'Gift Sent', '0000-00-00', '0000-00-00', '2016-01-29', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2016-01-26', '1969-12-31', '', '41.9549072', '-97.4071152', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-29', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'interlocks for patio door talked to heather trying to get on 1/26/16', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('477', '382', '', 'Single Property', '3171 30th Ave', '', 'Columbus', 'Nebraska', '', 'Scheduled', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Jeff ', '2016-01-26', '1969-12-31', '', '41.4468865', '-97.3651421', '', 'All windows/Doors:entry,storm,patio', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '1979', '', '0000-00-00', '', 'HBC', '2016-01-26', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'prefers around 7 pm', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('478', '281', '', 'Single Property', '44991 460th Ave', '', 'Lindsay', 'Nebraska', '68644', 'Received', '0000-00-00', '2016-01-26', '2016-02-05', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2016-01-26', '1969-12-31', '', '41.7354857', '-97.7151769', '', '1 Right Casement Sash', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-02-05', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '1/26/2016-Per Mark:
From Outside: Right Casement
126-412553
', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('479', '383', '', 'Single Property', '1720 1st St.', '', 'Columbus', 'Nebraska', '', 'Received', '0000-00-00', '2016-01-26', '2016-02-05', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Jeff ', '2016-01-26', '1969-12-31', '', '41.4170487', '-97.3487181', '', '1 Upper Sash', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-02-05', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'Upper Sash:
-Has Grids
124-159746
(glass broke) 

*NOTE: I also told them how to fix a dropping window-may want to check and make sure they got it fixed Ok!', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('480', '384', '', 'Single Property', '2207 16th St.', '', 'Columbus', 'Nebraska', '', 'Scheduled', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Jeff ', '2016-01-26', '1969-12-31', '', '41.431959', '-97.3547443', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-26', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '2/1/2016: Scheduled to measure. Wants to finish up last couple of windows.', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('481', '385', '', 'Single Property', '928 S. 9th St.', '', 'Albion', 'Nebraska', '', 'Unscheduled', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Hailey', '2016-01-26', '1969-12-31', '', '41.684267', '-98.0075681', '', '2', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '1960', '', '0000-00-00', '', 'HBC', '2016-01-27', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '1/27/2016: Wife Bitchy. Stopped into Cbus Showroom, Jeff talked prices, but never actually gave a quote.', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('482', '386', '', 'Single Property', '812 8th St.', '', 'Wisner', 'Nebraska', '', 'Scheduled', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2016-01-26', '1969-12-31', '', '41.9890329', '-96.9087664', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-29', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'He is a trucker. Brent spoke with him prior via phone. ', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('483', '387', '', 'DIY', 'Tim Hellbusch ', '', 'Norfolk', 'Nebraska', '', 'Ordered', '0000-00-00', '2016-01-26', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2016-01-26', '2016-01-26', '072-0232', '', '', '', '1', '', '1 entry door ', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Entry Door', '', '1969-12-31', '', '', '0000-00-00', '', 'ak', '2016-01-26', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'DIY- Tim Hellbusch - job name', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '2016-01-26', '1969-12-31', '1969-12-31', 'Doors', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('484', '142', '', 'Single Property', '604 E Klug', '', 'Norfolk', 'Nebraska', '68701', 'Ordered', '0000-00-00', '2016-01-28', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2016-01-27', '2016-01-27', '10325', '42.0376135', '-97.3989397', '', '1', '', '1', '26729394', '', '0000-00-00', '', '1969-12-31', '', '', 'Windows w/ Wraps', '', '1969-12-31', '1964', '', '0000-00-00', '', 'HBC', '2016-01-28', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2016-01-27', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('485', '388', '', 'Single Property', '2220 28th St', '', 'Columbus', 'Nebraska', '', 'Scheduled', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Hailey', '2016-01-27', '1969-12-31', '', '41.4436044', '-97.3552714', '', '1 PD/1PW', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '1964', '', '0000-00-00', '', 'HBC', '2016-01-29', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('486', '389', '', 'Multiple Property', '', '', 'Wayne', 'Choose One', '68787', 'Unscheduled', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2016-01-27', '1969-12-31', '', '42.2183723', '-83.279547', '', '20+', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'bf', '2016-01-28', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'Wayne Location: has about 20 windows-casements in there now.
Hartington Location: says he has a few there too but didnt have a count.
call end of next week set up timetlked to him 1-28-16', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '1');
INSERT INTO customerTickets VALUES ('487', '390', '', 'Single Property', '708 E. Donegal', '', 'O\'Neill', 'Nebraska', '', 'Unscheduled', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2016-01-27', '1969-12-31', '', '42.4679408', '-98.6430231', '', '1 PD', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Patio', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-27', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Doors', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('492', '346', '', 'Single Property', '754 19th Ave', '', 'Columbus', 'Nebraska', '', 'Ordered', '0000-00-00', '2016-01-27', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Hailey', '2016-01-27', '2016-01-27', '10327', '41.4236746', '-97.3507654', '', '2', '', '2', '26729397', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '1900', '', '0000-00-00', '', 'HBC', '2016-01-27', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'No', '', '', '', '', 'Fix Sills', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2016-01-27', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('490', '391', '', 'Single Property', '170 North Walnut st', '', 'Polk', 'Nebraska', '68654', 'Ordered', '0000-00-00', '2016-01-27', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Hailey', '2016-01-27', '2016-01-27', '072-10328', '41.0763978', '-97.7878755', '', '7', '', '7', '26729413', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '1896', '', '0000-00-00', '', 'HBC', '2016-01-27', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'No', '', '', '', '', '', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2016-01-27', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('491', '392', '', 'Single Property', '3612 13th st', '', 'Columbus', 'Nebraska', '68601', 'Ordered', '0000-00-00', '2016-01-28', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Hailey', '2016-01-27', '2016-01-27', '072-10329', '41.4296268', '-97.3724222', '', '13', '', '13', '26729475', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '1920', '', '0000-00-00', '', 'HBC', '2016-01-28', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'No', '', '', '', '', 'Insulate Cavities', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2016-01-15', '2000.00', '2016-01-15', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('494', '212', '', 'Single Property', '2300 Random Rd', '', 'Norfolk', 'Nebraska', '68701', 'Ordered', '0000-00-00', '2016-01-29', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2016-01-28', '2016-01-28', '072-10330', '42.0376103', '-97.4429921', '', '2', '', '', '', '2', '0000-00-00', '', '1969-12-31', 'D1310', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-29', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2016-01-28', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('495', '393', '', 'Multiple Property', 'DIY: Bussinger', '', '', 'Choose One', '', 'Ordered', '0000-00-00', '2016-01-28', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2016-01-28', '1969-12-31', '', '', '', '', '3 DIY: Bussinger', '', '3', '26729514', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-28', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('496', '201', '', 'Single Property', '86920 574th Ave ', '', 'Laurel', 'Nebraska', '68745', 'Ordered', '0000-00-00', '2016-01-28', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2016-01-28', '2016-01-27', '10323', '42.4268392', '-97.0569112', '', '5', '', '', '', '5', '0000-00-00', '', '1969-12-31', 'D0057', '', 'Basic', '', '1969-12-31', '1993', '', '0000-00-00', '', 'HBC', '2016-01-28', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'No', '', '', '', '', '', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('500', '121', '', 'Single Property', '57985 858 Rd', '', 'Wakefield', 'Nebraska', '68784', 'Ordered', '0000-00-00', '2016-01-28', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2016-01-28', '2016-01-28', '', '42.2643061', '-96.8266316', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Double Hung', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-28', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'per Jon 1/28/2016:
Bottom Sash:
#26704056.2
(Glass broke)', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('499', '9', '', 'Multiple Property', 'Jon Arens(1) ', '', '', 'Choose One', '', 'Ordered', '0000-00-00', '2016-01-28', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2016-01-28', '2016-01-27', '10324', '', '', '', '1 (Jon Arens) ', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-28', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('501', '121', '', 'Single Property', '57985 858 Rd', '', 'Wakefield', 'Nebraska', '68784', 'Ordered', '0000-00-00', '2016-01-28', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2016-01-28', '2016-01-28', '', '42.2643061', '-96.8266316', '', '1 Bottom Sash', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Double Hung', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-28', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'per Jon 1/28/2016:
Bottom Sash:
#26704056.2
(Glass broke)', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('502', '314', '', 'Single Property', '207 West Norfolk Avenue', '', 'Norfolk', 'Nebraska', '68701', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', '', '2016-01-28', '1969-12-31', '', '42.0326883', '-97.4089798', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'SDD', '2016-01-28', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('503', '394', '', 'Single Property', '415 W 11TH', '', 'Wayne', 'Nebraska', '', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2016-01-28', '1969-12-31', '', '42.2400836', '-97.0224439', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'bf', '2016-01-28', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'need to check a window to see if insulation was put in ', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '1');
INSERT INTO customerTickets VALUES ('504', '54', '', 'Single Property', '904 Lovely Lane', '', 'Norfolk', 'Nebraska', '68701', 'Ready to Install', '0000-00-00', '0000-00-00', '2016-01-29', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2016-01-29', '2016-01-05', '072-10307', '42.0430407', '-97.4616871', '', '1', '', 'A0590', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-29', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'picture window rack', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2016-01-05', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('505', '395', '', 'Single Property', '201 Pine St', '', 'Lindsay', 'Nebraska', '68644', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2016-01-29', '1969-12-31', '2 wraps', '41.7000129', '-97.6937511', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'ak', '2016-01-29', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', 'White', '', '', 'needs 2 windows rewrapped in white......Mike was supposed to do this several times but then got ill. upset customer thinks the windows leak....they are 6000 series , insulated cavaties and caulked inside and out, Mike said there is no way they leak. so careful how you handle  this one....... ', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '1');
INSERT INTO customerTickets VALUES ('506', '306', '', 'Single Property', '85277 581st Ave', '', 'Wakefield', 'Nebraska', '', 'Ordered', '0000-00-00', '2016-01-29', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2016-01-29', '1969-12-31', '1 sash', '42.1887973', '-96.9210435', '', '1 Upper Sash', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Double Hung', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-01-29', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '251-318069 upper called in by dwayne 1/19/2016', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('507', '396', '', 'Single Property', '3761 S Rd', '', 'David City', 'Nebraska', '', 'Ordered', '0000-00-00', '2016-02-04', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Hailey', '2016-01-29', '1969-12-31', '', '41.2065368', '-97.1106534', '', '2 Sashes', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Double Hung', '', '1969-12-31', '', '', '0000-00-00', '', 'ak', '2016-02-04', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'Per Jeff: 1/29/2016
1 Upper/1 Lower
124-215331
(we ordered sashes for this, we went to install them and they were a new model or something..apparently they were too skinny and didnt fit inside)', '1969-12-31', '', '', 'January', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('508', '134', '', 'Single Property', '3304 Mach 1 Dr.', '', 'Norfolk', 'Nebraska', '68701', 'Ordered', '0000-00-00', '2016-02-04', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2016-02-01', '1969-12-31', '', '42.0439725', '-97.4626426', '', '1 Slider Sash', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Other', '', '1969-12-31', '', '', '0000-00-00', '', 'ak', '2016-02-04', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '2/1/2016: Customer Call-in
1 Slider Sash
From Outside: Right
129-204036
(glass crack)', '1969-12-31', '', '', 'February', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('509', '397', '', 'Single Property', '81 Cottonwood Dr.', '', 'Columbus', 'Nebraska', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Jeff ', '2016-02-01', '1969-12-31', '', '41.4242966', '-97.388048', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Other', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-02-01', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', '', '', '', '1/28/16: Per Jeff- Need to fix wrap on top of 2 PD-Told her would do when its nicer. Probably April.', '1969-12-31', '', '', 'February', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('510', '398', '', 'Single Property', '4372 B Rd', '', 'Bellwood', 'Nebraska', '', 'Went To Columbus', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Jeff ', '2016-02-01', '1969-12-31', '', '41.336661', '-97.350234', '', '2 Screens', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Other', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-02-01', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '1/29/16: Jeff forgot screens. STILL NEED TO INSTALL SCREENS SOMETIME', '1969-12-31', '', '', 'February', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('511', '227', '', 'Single Property', '312 Vroman St', '', 'Winside', 'Nebraska', '68790', 'Ordered', '0000-00-00', '2016-02-01', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2016-02-01', '2016-02-01', '072-10332', '42.178425', '-97.1765205', '', '2', '', '2', '26730001', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '1910', '', '0000-00-00', '', 'HBC', '2016-02-01', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', '', '', '', '', '1969-12-31', '', '', 'February', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('512', '212', '', 'Single Property', '2300 Random Rd', '', 'Norfolk', 'Nebraska', '68701', 'Ordered', '0000-00-00', '2016-02-01', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2016-02-01', '1969-12-31', '', '42.0376103', '-97.4429921', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'kf', '2016-02-01', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '2 -  pieces mull strips 62 1/2\"- archetectual bronze - ordered online per heather /karla 02/01/16', '1969-12-31', '', '', 'February', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('513', '400', '', 'Single Property', '3704 20th St.', '', 'Columbus', 'Nebraska', '', 'Ordered', '0000-00-00', '2016-02-04', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Angi', '2016-02-01', '1969-12-31', '', '41.4359945', '-97.3738795', '', '1 Frame', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Other', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-02-01', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '2/1/2016: Per Jeff
1 Frame
129-019167
(Broke)', '1969-12-31', '', '', 'February', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('514', '401', '', 'Single Property', '1219 East Sherwood Rd ', '', 'Norfolk', 'Nebraska', '68701', 'Ordered', '0000-00-00', '2016-02-04', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2016-02-01', '1969-12-31', '', '41.9893744', '-97.3891982', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Double Hung', '', '1969-12-31', '', '', '0000-00-00', '', 'ak', '2016-02-04', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '121-759106  left from outside ', '1969-12-31', '', '', 'February', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('515', '309', '', 'Single Property', '408 Lincoln st ', '', 'Wayne', 'Nebraska', '', 'Paid', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '2016-02-01', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2016-02-01', '2015-08-10', '072-10068', '42.2325645', '-97.0207581', '', '26', '', '', '', 'z6836/37', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'kf', '2016-02-01', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'all windows and wraps are paid except for 3 windows still need to be wrapped - they are way up high, brent talked to Friders and we are going to do it when we do soffit and fascis in spring 2016,  the wraps are billed in the computer', '1969-12-31', '', '', 'February', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2015-08-10', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('516', '402', '', 'Single Property', '1216 Grainland Rd', '', 'Wayne', 'Nebraska', '', 'Paid', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '1', '2016-02-01', '2016-02-01', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2016-02-01', '2015-04-24', '9871', '42.2281484', '-97.032687', '', '1', '', '', '', '1', '0000-00-00', '', '1969-12-31', 'E8344', '', 'Windows w/ Wraps', '', '1969-12-31', '1958', '', '0000-00-00', '', 'HBC', '2016-02-01', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'February', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('517', '402', '', 'Single Property', '1216 Grainland Rd', '', 'Wayne', 'Nebraska', '', 'Paid', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '1', '2016-02-01', '2016-02-01', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2016-02-01', '2015-06-22', '', '42.2281484', '-97.032687', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Single-Story', '', '1969-12-31', '1985', '', '0000-00-00', '', 'HBC', '2016-02-01', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'February', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Siding', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('518', '399', '', 'Single Property', '55470 HWY 59', '', 'Wausa', 'Nebraska', '68786', 'Ordered', '0000-00-00', '2016-02-01', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2016-02-01', '2016-02-01', '', '42.4671716', '-97.5909467', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Double Hung', '', '1969-12-31', '', '', '0000-00-00', '', 'ak', '2016-02-01', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '  23845778.5.  upper sash stress crack 
2/01/16 emailed group14', '1969-12-31', '', '', 'February', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('519', '254', '', 'Single Property', '2204 Vernon Ave', '', 'Norfolk', 'Nebraska', '68701', 'Ordered', '0000-00-00', '2016-02-05', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2016-02-01', '2016-02-04', '072-10334', '42.051192', '-97.4418714', '', '11', '', '11', '26730871', '', '0000-00-00', '', '1969-12-31', '', '', 'Windows w/ Wraps', '', '1969-12-31', '1978', '', '0000-00-00', '', 'HBC', '2016-02-05', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'February', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', 'Cash', '2016-02-01', '$2,400 CASH', '2016-02-01', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('520', '403', '', 'Single Property', '', '', 'Norfolk', 'Nebraska', '', 'Need to Order', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', '', '2016-02-04', '1969-12-31', '', '42.0327234', '-97.4137553', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'bf', '2016-02-04', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'needs 6 pieces of millcreek mastic pebblestone clay double 4 
general would have to order 2 square he is checking with husker i told him it would be 50.00 per panel installed', '1969-12-31', '', '', 'February', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Siding Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('521', '404', '', 'Single Property', '135 1ST STREET', '', 'Utica', 'Nebraska', '', 'Ordered', '0000-00-00', '2016-02-04', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Hailey', '2016-02-04', '1969-12-31', '', '40.8948473', '-97.3491337', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'bf', '2016-02-04', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'February', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('522', '405', '', 'Single Property', '1866 45th ave', '', 'Columbus', 'Nebraska', '', 'Need to Order', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Karla ', '2016-02-04', '1969-12-31', '', '41.4347485', '-97.3822752', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'bf', '2016-02-04', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'February', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2016-02-04', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('523', '406', '', 'Single Property', '4251 d rd ', '', 'Bellwood', 'Nebraska', '', 'Unscheduled', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Hailey', '2016-02-04', '1969-12-31', '', '41.3590992', '-97.3116795', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'bf', '2016-02-04', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'February', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '1');
INSERT INTO customerTickets VALUES ('524', '407', '', 'Single Property', '902 E Knolls ', '', 'Norfolk', 'Nebraska', '68701', 'Ordered', '0000-00-00', '2016-02-04', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2016-02-04', '1969-12-31', '', '42.0420065', '-97.385398', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Casement', '', '1969-12-31', '', '', '0000-00-00', '', 'ak', '2016-02-04', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'left sash 129-115866', '1969-12-31', '', '', 'February', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('525', '408', '', 'Single Property', '1230 Blue Stem Circle ', '', 'Norfolk', 'Nebraska', '68701', 'Ordered', '0000-00-00', '2016-02-04', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2016-02-04', '1969-12-31', '', '42.0441293', '-97.3884102', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Casement', '', '1969-12-31', '', '', '0000-00-00', '', 'ak', '2016-02-04', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '252-910131 left casement sash 
is dropping off a screen to get rescreen also ', '1969-12-31', '', '', 'February', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('526', '409', '', 'Single Property', '38369 100th Ave', '', 'Leigh', 'Nebraska', '', 'Unscheduled', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Hailey', '2016-02-05', '1969-12-31', '', '41.630828', '-97.2526264', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2016-02-05', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '2/8/2016: Scheduled estimate date-No set time. ', '1969-12-31', '', '', 'February', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('527', '410', '', 'Single Property', '506 s 8th ', '', 'Norfolk', 'Nebraska', '', 'Scheduled', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '1969-12-31', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', '', '2016-02-05', '1969-12-31', '', '42.0274906', '-97.4180582', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'bf', '2016-02-05', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'sent mark to measure and give price ', '1969-12-31', '', '', 'February', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('528', '286', '', 'Single Property', '1400 Pierce St.', '', 'Norfolk', 'Nebraska', '', 'Ordered', '0000-00-00', '2016-02-05', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2016-02-05', '1969-12-31', '', '42.0170166', '-97.4057687', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Glass', '', '1969-12-31', '', '', '0000-00-00', '', 'ak', '2016-02-05', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'originally 2 sliders were ordered and we needed a glass! ordered the glass on 2/5/16', '1969-12-31', '', '', 'February', '2016', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');


#
# Table structure for table `listToDo`
#

DROP TABLE IF EXISTS `listToDo`;
CREATE TABLE `listToDo` (
  `listID` int(11) NOT NULL AUTO_INCREMENT,
  `listTitle` varchar(250) NOT NULL,
  `listDate` date NOT NULL,
  `listDetails` text NOT NULL,
  `listAssign` varchar(250) DEFAULT NULL,
  `listStatus` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`listID`)
) ENGINE=MyISAM AUTO_INCREMENT=165 DEFAULT CHARSET=latin1;

#
# Dumping data for table `listToDo`
#

INSERT INTO listToDo VALUES ('15', 'go finish connies mull strip', '2015-10-05', '', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('10', 'test', '2015-07-29', 'test', '', '');
INSERT INTO listToDo VALUES ('14', 'Wayne Estimate', '2015-10-01', 'Claudia Ancona
212 Main St. Apt: A
Wayne, NE 
402-287-5018
594-9933

Need to Contact her on Tuesday to let her know when we will be in the area.', 'Hailey', 'Complete');
INSERT INTO listToDo VALUES ('16', 'Richard Stelling', '2015-10-05', 'Go measure a window for Richard Stelling 4029920335

10-13-15: Planned on going there Wed Oct 21. HE said he will see if his boys still want us to look @ it and he will let us know if he wants us to do it.', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('17', 'Ruby Jurgensen-When?', '2015-10-01', 'Wisner: (6)
When?? General Timeframe?? 
Ordered: 7-14-15  
402-529-6576', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('18', 'Pete Hastreiter-When?', '2015-10-16', 'Norfolk: (8)
When??  Told September by jerry
Ordered: 8-7-15   
402-920-0684


HE also called on the 1st of october~', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('19', 'Justin Wetjen-When??', '2015-10-01', 'Newman Grove: (5)
When?? I think he may have gotten forgot about, so may need to try and squeeze in.
Ord: 9-1-15
920-0422', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('47', 'West Point/Wisner Estimates', '2015-10-23', 'West Point:
Lorrie Woodbury: Needs an estimate; Set up when we are in the area;402-649-0615
Wisner:
John Obermeyer: needs an estimate after 415pm; Rental: 509 7th St-wisner 
402-851-1301 or 402-5654338

Tricia Peters: est-basement windows; 913 9th St. Wisner; 518-0675', 'Hailey', 'Complete');
INSERT INTO listToDo VALUES ('20', 'Ryan Baumgard-When?', '2015-10-02', 'Norfolk: (10+1PD)
When?
Ord: 8-21-15
605-595-3293', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('21', 'Stacy Alexander-When?', '2015-10-05', 'Wayne: (6)
When? Told end of October. She would really like a call back.
Ord: 9-15-15
369-2787
', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('22', 'Brian Hohnholt-O\'Neill estimate', '2015-10-05', 'Est: Sun Porch
804 E. Douglas
O\'Neill

402-366-8470
He is available anytime really. In process of buying this house.
May want to call him and feel him out. Maybe quote him over the phone.', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('23', 'Steve McClure-Schedule Columbus estimate', '2015-10-05', '', 'Hailey', 'Complete');
INSERT INTO listToDo VALUES ('24', 'Karla Linsteadt-', '2015-10-05', 'Norfolk: (1 Bay)
told her last week of oct or first part of nov

402-371-9158', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('25', 'Joann Meyer-When??', '2015-10-22', 'Her son called for her yesterday. waitin to finish remodeling, but needs the windows. Karla told them we would get them in next week. need to call them today with a date.

Norfolk: (2)
Was told end of September-Beginning of October. Is she on the list??
Ordered: 7/21/15
402-371-7573
(leave message if no answer)

Also called on 10-5-15
Also called on 10-19-15', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('26', 'Marilyn Parmenter-When?', '2015-10-06', 'Plainview: (3)
When?? Do same time as Norma White. HC told her that you had them in your sights but i wasnt sure of when exactly.
Ord: 8/4/15
402-582-3501
', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('27', 'Gretchen O\'Reily-Siding', '2015-10-07', 'When on siding? would like a general timeframe-they have bushes they are tearing out before we come. She called last week-no call back.
605-670-*1984', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('28', 'Mitch &amp; Neighborworks', '2015-10-09', '750-3240
308 S. Boxelder-Match siding? wasnt sure if you had a chance to look at it yet.', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('29', 'Humphrey Estimate', '2015-10-09', 'Patty Sliva
701 Main
Humphrey
923-1723
Home all day. Wants an estimate when we are in the area. (5 windows) ', 'Hailey', 'Complete');
INSERT INTO listToDo VALUES ('30', 'Mona Michaels(Plainview) ', '2015-10-12', 'Replace Underside of Bay-ASK BRENT!!!!', 'Dwayne', 'Complete');
INSERT INTO listToDo VALUES ('31', 'Frank Morrison', '2015-10-13', 'Darrel Steckelberg is ready for us after today. So whenever!!:', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('32', 'Nick Humphrey        316-0013', '2015-10-14', 'Oversized Gutter Roughly 35 ft.
Price????', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('33', 'steve shoemaker ask mark', '2015-10-16', 'about under window and siding', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('34', 'kathy patras wants estimate on other windows ', '2015-10-16', 'measurements are in the folder', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('35', 'lamili and perry', '2015-10-16', 'check on lamili sash and perrys interlocks and ', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('36', 'Denny Gos-Call him back.', '2015-10-19', '308-942-3110
Said he spoke with you Friday about windows. would like you to call him back.', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('37', 'Marry Braun-When??', '2015-10-19', '649-7326
 Was told October and she would be given a weeks notice. We\'re coming up on the end of October so was just wondering a timeframe.

She called last week as well..

6 windows Ordered: 9-15-15.', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('38', 'Call Lori Uecker', '2015-10-20', '750-9485

She called for you. Please call her back.', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('39', 'Kiddie Corral-Angie Hausman', '1969-12-31', '', 'Karla ', 'Complete');
INSERT INTO listToDo VALUES ('40', 'Kiddie Corral-Angie Hausman      372-8947', '2015-10-20', 'She is mailing remaining $400.00

Wants to know when we can install now. Said the fire marshall stopped by. She asked that you call her.', 'Karla ', 'Complete');
INSERT INTO listToDo VALUES ('41', 'Kiddie Corral-Angie Hausman', '1969-12-31', '', 'Karla ', 'Complete');
INSERT INTO listToDo VALUES ('42', 'TRUDY MOSEL FIGURE OUT A WAY TO DO WINDOWS', '2015-10-21', 'check out porch and see how much to gut it and redo next spring', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('43', 'Paul Alpress wondering when on Windows 402-371-9192   ', '2015-10-21', 'In Norfolk 
6 casements and a patio door  ', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('44', 'gladis 809 s 4th out of balance 4023164634', '2015-10-21', '', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('45', 'jack sauswer called about when on this patio door - he said he hopes before snow flies', '2015-10-22', '', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('46', 'Bob Pollock                 402-640-5058', '2015-10-22', 'When?
(14 windows)
Ordered: 10-12-15
Was just wondering, his renters are moving out now..so if we could get in now, that would be ideal.', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('48', 'Shana Worm', '2015-10-23', 'Mail 2 white casement handles when they come in. AMI', 'Hailey', 'Complete');
INSERT INTO listToDo VALUES ('49', 'Greg Thiele(wife) 649-1210', '2015-10-26', '2614 Westside
Norfolk

You had called once before, she missed your message. She is available this week.
Mon-Wed-Friday: All Day
Tues-Thurs: After lunch', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('50', 'dylan bush wants to order ', '2015-10-26', 'dylan bush wants to order windows 805 irving st fullerton 3085500777 wants everything except wraps', 'Hailey', 'Complete');
INSERT INTO listToDo VALUES ('51', 'jim bahm', '2015-10-26', 'check and see 303 aspen dr 4023718775', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('52', 'sergio deanda', '2015-10-26', 'sergio deanda 2580 3rd ave columbus 402 270 2238 looking for bid called last week jeff has already been there', 'Hailey', 'Complete');
INSERT INTO listToDo VALUES ('53', 'ask mark how many windows they wrapped at mechelle grimes house', '2015-10-26', '', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('54', 'Shellee-Rugosa', '2015-10-27', 'Wanted to tell you she is back from vacation.

Also....408 Pierce St. is not wrapped on front from last year.', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('55', 'MELISSA HYDE 4530 31ST ST COLUMBUS  JEFF SAID NEEDS WARM WEATHER WANTED TO RUSH HER IN  4022768761', '2015-10-28', '', 'Hailey', 'Complete');
INSERT INTO listToDo VALUES ('56', 'FROEHNER,TOM AND  JESSICA 4029423940', '2015-10-28', 'WANTS TO KNOW WHEN', 'Hailey', 'Complete');
INSERT INTO listToDo VALUES ('57', 'SHARON ROBERT  372-3522', '2015-10-29', '123 COLFAX
WEST POINT

has had issue with her windows howling. Brent went and fixed them once before...She called again today. Said the wind was strong this week. and 2 of her windows are howling again..1 is REALLY bad.
she would like us to fix it when we are in the area again.', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('58', 'Kip Duerst', '2015-10-29', 'Need to caulk 1 window.
Sash
Screen

These things need to be done yet @ their rental in eldorado.
His wife called asking about these.', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('59', 'Patty Thiele-Clearwater', '2015-10-30', 'When???

Called last week..never heard anything.', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('60', 'Please schedule estimate for Doris Chrisp....in customers with notes .....I told her probably the week of November 9th ', '2015-10-30', '', 'Hailey', 'Complete');
INSERT INTO listToDo VALUES ('61', 'Set up Estimate for Jim Luedtke in Clarkson ', '2015-10-30', 'Got a ranch style home full of windows....wants to start with 5 in the bedroom.  Hard to schedule because he works with big construction equipment :-/ but could make noon hours work .', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('62', 'steve clearly schedule for whole house', '2015-10-30', '', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('63', 'Matt Klabnes-Rental-Estimate', '2015-11-02', '410 5th St.
Neligh
402-750-9908

Has a house he just bought. Wants a quote on every window in the house. He doesnt want to be there but wants this done asap.
Nobody lives there now.

Windows used to have an arch at the top that was once taken out and framed in with wood. He wants NO wood showing. and he wants the arch back in the windows.', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('64', 'Deb Misfeldt', '1969-12-31', 'trim work not stained-have 2 windows without curtains
when can we finish this??
371-4984', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('65', 'Scott Rutten-measure', '2015-11-02', 'Called to reschedule a measure time-his kid was sick when you were passing through last time.', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('66', 'Ron Gadeken 887-4644', '2015-11-02', 'Said he called last week.
When??
was told october
Ordered: 9/2/15
(5 windows) ', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('67', 'Russ Eggerling-Dropping window; 371-9529', '2015-11-02', '1004 Southern Drive
Norfolk

Elderly gentleman-Window out of balance. needs us to fix for him.', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('68', 'Mike Moeller-Beemer-When??', '2015-11-02', '688 K  Rd
Beemer
(19 windows) 
Ordered: 7/8/15
380-1581

Carrie called 11/04/15 ---said not pushing just wants to know if needs to put up plastic ---her work number is 402-5296878', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('69', 'Lori Forsch', '2015-11-02', 'having screen issues on her patio door.
would like you to call her to discuss them.', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('70', 'lori frasch ask dwayne about screen door', '2015-11-03', '', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('72', 'GARY KOEPITZ WINDOW TRIM BY STANTON', '2015-11-04', '', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('73', 'BRUCE BRESTER--WANTS YOU TO CALL---402-649-5430', '2015-11-04', '', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('74', 'Set up Estimate for Greg and Carla Pippitt Laurel (in the system) 402-375-0622 or 402-256-3635 he\'s a farmer ', '2015-11-05', '', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('75', 'KRIS KNOFF ', '2015-11-05', 'WANTS TO KNOW WHERE HER ESTIMATE IS 3104 40 TH ST COLUMBUS 4022762151', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('76', 'ernest brabec ', '2015-11-06', '121 spruce st clarkson 4028923580 reflective insulation', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('77', 'Carol Michaels 750-0064', '2015-11-06', 'Has a question for you regarding her windows.!! Please call', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('78', 'Wes VanErt          739-1952', '2015-11-10', 'Did we get those other 2 windows ordered?? 1 is broke out and would like installed sooner than later.
Go ahead and order AsAP', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('79', 'dean and pat chapman', '2015-11-10', 'dean and pat chapman - 1501 south chestnut - norfolk ---repeat customer wants a couple more windows told him $350.00 basic install --call and go ---i told we would try to get there yet this week', 'Brent ', 'Processing');
INSERT INTO listToDo VALUES ('80', 'karen fundus 306 south 12th norfolk - 7507727--measure', '2015-11-10', '', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('81', 'Roger Garbers: Columbus called him back 11-11', '2015-11-10', 'Work: 563-7275     You gave him an est(#6809) on 9/28/2015. He would like you to call him about it.', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('82', 'Kent Adkins 379-1022', '2015-11-10', 'Has a window out of balance.
1111 S. 1st St-Norfolk', 'Angi', 'Processing');
INSERT INTO listToDo VALUES ('83', 'Mary Mrsny 640-4922', '2015-11-13', 'Still on for the beginning of December?? she would like a call back.

Also Called on 11/10/2015

', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('84', 'Zack Lindsley-Creston', '2015-11-11', 'You gave him a quote a few weeks ago. Said he hasnt gotten anything yet. If you could email him a copy, he\'d appreciate it. (His email is in quickbooks and in this ticket system as well)', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('85', 'Michael Kuester-When? 640-3957', '2015-11-11', 'Ordered: 1 Patio door on Oct 13. JW when? ', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('87', 'donna ingoglai ', '2015-11-12', 'need scott to do drip cap(can charge for) shutters and check large living room window also run a magnet across lawn ', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('88', 'Call Donna Ingoglia', '2015-11-13', '360-3208 She asked that you call her. ', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('89', 'kendra feddern called again wants to know when--call 640-2339', '2015-11-13', 'adddress is 806 south 5th - norfolk - 4 windows', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('90', 'Chad Huigens in Plainview was checking to see if we still were on for the end of November....I told very good chance.....he\'s not worried or needs a call I just wanted to put it on the radar ', '2015-11-13', '', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('91', 'Chad Huigens in Plainview was checking to see if we still were on for the end of November....I told very good chance.....he\'s not worried or needs a call I just wanted to put it on the radar ', '1969-12-31', '', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('105', 'when tory and kelli berryman - call today or tomorrow if possible 402-750-3609,  norfolk job on birch street - 3 windows', '2015-11-30', '', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('92', 'jeff jensen says go with casement on North matching the living room windows for color ', '2015-11-13', '', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('93', 'Curt Nielsen-----When?? 649-4549', '2015-11-17', '1811 Imperial Rd-Norfolk
Ordered: 10-21-2015(3 windows) ', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('94', 'James Lenz(hi wife)-When??     283-4024', '2015-11-17', '211 E. Canfield-Coleridge
Ordered:10-29-2015(2 windows)', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('95', 'jamie wichman order 1/4 inch smaller sashes', '1969-12-31', '', 'Angi', 'Complete');
INSERT INTO listToDo VALUES ('96', 'SHARON ROBERT  372-3522', '2015-12-16', 'West Point: has another howling window.', 'Brent ', 'Processing');
INSERT INTO listToDo VALUES ('97', 'Ryan Baumgard-When Finish Wraps???', '2015-11-18', 'Stopped in, said we were there recently to put on inside pieces..but still have 3 big windows outside that need wrapped. Been 3 weeks since we installed them. Also: the kitchen window-caulked wrap to the shutter. he took down shutters to paint. That window needs to be caulked to house.', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('98', 'Patty Sliva-Humphrey', '2015-11-20', 'NEver got her estimate. Please mail.', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('99', 'Kelly Muchmore 402-270-9951', '2015-11-23', 'Call ASAP. wants to know if she needs to start tearing off siding.', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('100', 'tom neuman price for a roll of artic fox', '2015-11-23', '', 'Brent ', 'Processing');
INSERT INTO listToDo VALUES ('101', 'Steve Jorgensen-When?? 402-286-4328', '2015-11-23', 'Has 8 windows in Winside. Was jw when? if they are out a while, thats fine. wife just wants to put up  Christmas tree and doesnt want it to be in the way.', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('102', 'Steve Jorgensen-When?? 402-286-4328', '2015-11-23', 'Has 8 windows in Winside. Was jw when? if they are out a while, thats fine. wife just wants to put up  Christmas tree and doesnt want it to be in the way. ', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('103', 'Steve Shoemaker-Gutters called and left message 11-30-15 order door and go with gutters just the run use his downs grids in the door', '2015-11-24', 'He said he had spoke with you one time about doing gutters. They just got their siding bill. was wondering if we were still planning on doing the gutters??', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('104', 'Diane Miller-750-2704', '2015-11-25', 'Has windows(we installed these windows before she moved in) that wont shut. Says she has had us out before to try and help her with her windows. Wont shut after she cleans them. Please help!

Bought from Heppner.', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('106', 'theresa perry called and was worry about her deadline of the 10th---i told i\'m sure your on it', '2015-11-30', '', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('107', 'Kelly Muchmore called and wants you to call her 402-270-9951', '2015-11-30', '', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('108', 'Mitch Neighborworks - estimate at wayne', '2015-12-01', 'Mitch called wants an estimate on Main and 2nd floor, and 4 basement windows at Wayne---the contact to get in the house is Charlie Bonanno at 712-259-0697---wants upper grids with vertical lines like they have', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('109', 'Bob Ziemba - st Paul called and said he has called several times and we are suppose to be getting a sash for him down to Columbus so he can pick it up ', '1969-12-31', 'try and call him 12/02/15 if possible   1-308-750-0532', 'Hailey', 'Complete');
INSERT INTO listToDo VALUES ('110', 'Jerry Johnson  402-368-2243', '2015-12-02', 'Has a double hung window he cant get to lock. It closes but its roughly 1/8 of an inch from locking. Told he we would stop by when in the area. Has to be around 3ish.', 'Brent ', 'Processing');
INSERT INTO listToDo VALUES ('111', 'Karla &amp; Bob Linsteadt 371-9158', '2015-12-03', 'wants to know if there is something that we can do to somewhat fix his bay or if we have to replace the whole thing. They would like to stain the inside if possible but doesnt want to if we\'re going to have to replace the whole thing. Doesnt know what the next step is. Please call him.', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('112', 'Adam &amp; Wendy Brewer      750-8161', '2015-12-04', 'Some spots, gutters leaky. Talked about them before with you. Would like you to follow up.', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('113', 'Muffin Morris-When?? 605-202-0577 called and told her next week if possible or week after xmas check kitchen window when we do window says operates weird ', '2015-12-18', 'Seeing where she is at in line? was hoping to get in before end of year if possible.

Also called: 12-7-15', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('114', 'Tammy Korth-Kevin 402-992-5775', '2015-12-07', 'Had a message that you called to install. Call him back please.', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('115', 'Jeremy Pichler', '2015-12-07', 'He returned your call. It was about 4:45 pm.', 'Karla ', 'Complete');
INSERT INTO listToDo VALUES ('117', 'Deloris Jaeke(1)-when??', '2015-12-08', '371-0069', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('118', 'Tony Squire-Lindsday      276-4690', '2015-12-08', 'When?? was just curious of a time frame.
', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('119', 'Jason Brandt-Pierce 402-360-4297', '2015-12-08', 'You were supposed to measure this at 5pm on Monday Nov. 30. We eneded up having that snowstorm that day. But he never heard anything to reschedule. He was wondering when you can reschedule.', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('120', 'Tom-Carhart in Tilden 368-2202', '2015-12-09', 'He called at 10:25 this morning. would like you to call him please.', 'Karla ', 'Complete');
INSERT INTO listToDo VALUES ('121', 'Call Theresa Perry 841-3996', '2015-12-09', 'Would like you to call her to make sure everything is done.', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('122', 'Les Strong-371-0664', '2015-12-09', 'feels patio door handle is going to fall off soon
-Usually around
-Norfolk Job', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('123', 'Bill Lamm-When??', '2015-12-10', '', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('125', 'Lonnie Forsch-Measure garage siding', '2015-12-10', 'she is selling her  house. wants the garage sided. and matched with whats on her house. we orginally sided her house.

1213 Hayes
Norfolk.', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('126', 'Cory Schmidt-When??', '2015-12-11', '649-8350
Norfolk 

Ordered 10-12-15', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('127', 'jim and pat hostrieter 82424 528th rd madison look for estimate 402 285 0275', '2015-12-11', '', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('128', 'Maria Babel-When? 447-6144', '2015-12-14', '113 N. 5th.
Newman Grove
Wondering When? ', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('129', 'Ron Kallenbach 563-0362', '2015-12-15', 'Anyday next week after 2 works for us to do that Mull.', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('130', 'Call Gary Coolidge 841-4038', '2015-12-16', '', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('131', 'Lisa @ Wesport/Lakewood Apts need to order screen clips from simonton for bennington apt', '2015-12-18', 'Call her. 402-992-1983', 'Brent ', 'Processing');
INSERT INTO listToDo VALUES ('132', 'chad fridder have scott give a price on soffit and fascia ', '2015-12-18', 'chad fridder wants you to call him at 402-369-0369', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('134', 'Theresa Perry', '2015-12-22', 'She sent the papers to insurance guy already. However, its not all done.
There are 4 wraps(that she is paying for) then 2 more wraps above. There is also an issue with one of the patio doors we installed. Apparnetly we keep getting the wrong part?', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('135', 'Ryan Stusse:Floor', '2015-12-22', 'He fixed your floor, take a look at it and let him know what you think. He put the key back under the mat.', 'Karla ', 'Complete');
INSERT INTO listToDo VALUES ('136', 'John Beckner', '2015-12-22', 'Please call:
402-741-1477', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('137', 'Steve @ Guarantee Pest Control', '2015-12-22', 'Call him on his personal cell: 640-1669', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('160', 'Scott-Wells Fargo', '2016-01-29', 'Call Scott  @ Wells Fargo..he returned your call.', 'Angi', 'Processing');
INSERT INTO listToDo VALUES ('152', 'COLUMBUS NEEDS BULB SEAL FOR PATIO DOOR ', '2016-01-19', 'JEFF ASKED FOR', 'Brent ', 'Processing');
INSERT INTO listToDo VALUES ('150', 'Call Leon about small window on 112 E Klug .....girl called and said we put the wrong window in. Leon was in the background 402-992-2612', '2016-01-15', '', 'Brent ', 'Processing');
INSERT INTO listToDo VALUES ('164', 'please call melissa in Emerson to schedule her job - monday morning 02/08/16 (larry herberer daughter)-she called you back friday', '2016-02-05', '', 'Brent ', 'Processing');
INSERT INTO listToDo VALUES ('163', 'bridgett us92 call 4026869062', '2016-02-04', '', 'Angi', 'Processing');


#
# Table structure for table `sinBin`
#

DROP TABLE IF EXISTS `sinBin`;
CREATE TABLE `sinBin` (
  `sinID` int(11) NOT NULL AUTO_INCREMENT,
  `sinName` varchar(250) DEFAULT NULL,
  `sinModel` varchar(250) DEFAULT NULL,
  `sinSize` varchar(250) DEFAULT NULL,
  `sinInterior` varchar(250) DEFAULT NULL,
  `sinExterior` varchar(250) DEFAULT NULL,
  `sinGrid` varchar(250) DEFAULT NULL,
  `sinSerial` varchar(250) DEFAULT NULL,
  `sinNail` varchar(250) DEFAULT NULL,
  `sinPrice` varchar(250) DEFAULT NULL,
  `sinDonated` varchar(250) DEFAULT NULL,
  `sinDate` date NOT NULL,
  PRIMARY KEY (`sinID`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

#
# Dumping data for table `sinBin`
#

INSERT INTO sinBin VALUES ('4', 'Angi Houser', '1675-Casement   Qty: 1', '27 1/4 x 45 1/4', 'White', 'White', 'No', '#26665648.1', 'No', '', '', '2015-10-13');
INSERT INTO sinBin VALUES ('2', 'Test Names', 'Model', 'Size', 'White', 'Tan', 'No', '12345', 'Yes', '125.52', 'Yes', '2015-08-20');
INSERT INTO sinBin VALUES ('5', 'Columbus Aquatic Center', '1650-DH     Qty: 2', '41 1/4 x 41 1/4', 'White', 'White', 'No', '#26687501.1', 'No', '', '', '2015-10-30');
INSERT INTO sinBin VALUES ('6', 'Jim Bahm', '1650-DH   Qty: 1', '39 1/2 x 37 1/4', 'White', 'White', 'No', '#26691504.1', 'No', '', '', '2015-11-23');
INSERT INTO sinBin VALUES ('7', 'Francisco Medina  ', '3002-DH     Qty: 1', '76 3/4 x 35 3/4', 'White', 'White', 'No', '129-272502', 'No', '', '', '2015-12-08');
INSERT INTO sinBin VALUES ('8', 'Jose Leon: Rental ', '1650-DH     Qty: 1', '31 3/4 x 37 1/4- using for Rugosa- Blaine street', 'White', 'White', 'No', '#26715955.3', '', '', '', '2015-12-09');
INSERT INTO sinBin VALUES ('9', 'Walter Johnson', '0751-Awning Qty:1', '31 1/2 x 37 1/2', 'White', 'White', 'No', '129-256670', 'No', '', '', '2015-12-24');
INSERT INTO sinBin VALUES ('10', 'Mike Matteo', '1675-Double Casement  Qty: 1', '47 3/8 x 34 1/2', 'Colonial Cherry', 'White', '', '#26673915.1', 'No', '', '', '2015-12-24');
INSERT INTO sinBin VALUES ('11', 'Matt Soukup', '3002     Qty: 1', '32 1/2 X 16 1/2 ', 'White', 'White', 'No', '129-019167', 'No', '', '', '2016-02-01');


#
# Table structure for table `ticketAttachments`
#

DROP TABLE IF EXISTS `ticketAttachments`;
CREATE TABLE `ticketAttachments` (
  `attachID` int(11) NOT NULL AUTO_INCREMENT,
  `ticketID` varchar(20) DEFAULT NULL,
  `leadTestPDF` varchar(250) NOT NULL,
  `testKitPDF` varchar(250) NOT NULL,
  `renoRecPDF` varchar(250) NOT NULL,
  `measSheetPDF` varchar(250) NOT NULL,
  `invoiceSheetPDF` varchar(250) NOT NULL,
  `leadDate` date NOT NULL,
  `testDate` date NOT NULL,
  `renoTestDate` date NOT NULL,
  `measDate` date NOT NULL,
  `invoicDate` date NOT NULL,
  PRIMARY KEY (`attachID`)
) ENGINE=MyISAM AUTO_INCREMENT=566 DEFAULT CHARSET=latin1;

#
# Dumping data for table `ticketAttachments`
#

INSERT INTO ticketAttachments VALUES ('1', '9', 'lead-9.pdf', 'test-kit-9.pdf', 'renovation-9.pdf', 'measure-9.pdf', 'invoice-9.pdf', '2015-07-22', '2015-07-21', '2015-07-21', '2015-07-21', '2015-07-21');
INSERT INTO ticketAttachments VALUES ('6', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('3', '14', 'lead-14.pdf', 'test-kit-14.pdf', 'renovation-14.pdf', 'measure-14.pdf', 'invoice-14.pdf', '2015-08-19', '2015-08-19', '2015-08-19', '2015-08-19', '2015-08-19');
INSERT INTO ticketAttachments VALUES ('7', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('5', '16', '', '', '', '', '', '1969-12-31', '1969-12-31', '1969-12-31', '1969-12-31', '1969-12-31');
INSERT INTO ticketAttachments VALUES ('8', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('9', '17', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('10', '18', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('11', '19', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('12', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('13', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('14', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('15', '20', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('16', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('17', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('18', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('19', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('20', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('21', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('22', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('23', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('24', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('25', '21', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('26', '22', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('27', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('28', '23', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('29', '24', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('30', '25', '', '', '', '', '', '2015-09-13', '1969-12-31', '1969-12-31', '1969-12-31', '1969-12-31');
INSERT INTO ticketAttachments VALUES ('31', '26', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('32', '27', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('33', '28', '', '', '', '', '', '1969-12-31', '1969-12-31', '1969-12-31', '1969-12-31', '1969-12-31');
INSERT INTO ticketAttachments VALUES ('34', '29', '', '', '', '', '', '1969-12-31', '1969-12-31', '1969-12-31', '1969-12-31', '1969-12-31');
INSERT INTO ticketAttachments VALUES ('35', '30', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('36', '31', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('37', '32', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('38', '33', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('39', '34', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('40', '35', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('41', '36', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('42', '37', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('43', '38', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('44', '39', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('45', '40', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('46', '41', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('47', '42', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('48', '43', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('464', '441', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('50', '45', '', '', '', 'measure-45.pdf', '', '1969-12-31', '1969-12-31', '1969-12-31', '1969-12-31', '1969-12-31');
INSERT INTO ticketAttachments VALUES ('51', '46', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('52', '47', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('53', '48', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('54', '49', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('55', '50', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('465', '442', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('57', '52', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('58', '53', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('59', '54', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('60', '55', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('61', '56', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('62', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('63', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('64', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('65', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('66', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('67', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('68', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('69', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('70', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('71', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('72', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('73', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('74', '57', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('75', '58', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('76', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('77', '59', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('78', '60', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('79', '61', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('80', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('81', '62', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('82', '63', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('83', '64', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('84', '65', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('85', '66', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('86', '67', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('87', '68', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('88', '69', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('89', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('90', '70', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('91', '71', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('463', '440', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('93', '73', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('94', '74', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('461', '438', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('96', '76', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('97', '77', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('98', '78', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('99', '79', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('100', '80', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('101', '81', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('102', '82', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('459', '436', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('104', '84', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('105', '85', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('106', '86', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('107', '87', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('108', '88', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('109', '89', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('460', '437', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('111', '91', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('112', '92', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('113', '93', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('114', '94', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('115', '95', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('116', '96', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('117', '97', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('118', '98', '', '', '', '', '', '1969-12-31', '1969-12-31', '1969-12-31', '1969-12-31', '1969-12-31');
INSERT INTO ticketAttachments VALUES ('119', '99', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('120', '100', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('121', '101', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('122', '102', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('123', '103', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('124', '104', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('125', '105', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('126', '106', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('127', '107', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('128', '108', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('129', '109', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('130', '110', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('131', '111', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('132', '112', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('133', '113', '', '', '', '', '', '1969-12-31', '1969-12-31', '1969-12-31', '1969-12-31', '1969-12-31');
INSERT INTO ticketAttachments VALUES ('134', '114', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('135', '115', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('136', '116', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('137', '117', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('138', '118', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('139', '119', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('140', '120', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('141', '121', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('142', '122', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('143', '123', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('144', '124', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('145', '125', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('146', '126', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('147', '127', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('148', '128', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('149', '129', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('150', '130', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('151', '131', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('152', '132', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('153', '133', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('154', '134', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('155', '135', '', '', '', 'measure-135.pdf', '', '1969-12-31', '1969-12-31', '1969-12-31', '1969-12-31', '1969-12-31');
INSERT INTO ticketAttachments VALUES ('156', '136', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('157', '137', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('158', '138', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('159', '139', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('160', '140', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('161', '141', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('162', '142', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('163', '143', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('164', '144', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('165', '145', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('166', '146', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('167', '147', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('168', '148', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('169', '149', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('170', '150', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('171', '151', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('172', '152', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('173', '153', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('174', '154', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('175', '155', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('176', '156', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('177', '157', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('178', '158', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('377', '357', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('180', '160', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('181', '161', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('182', '162', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('183', '163', '', '', '', '', '', '1969-12-31', '1969-12-31', '1969-12-31', '1969-12-31', '1969-12-31');
INSERT INTO ticketAttachments VALUES ('311', '291', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('185', '165', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('363', '343', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('187', '167', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('188', '168', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('189', '169', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('190', '170', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('191', '171', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('192', '172', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('193', '173', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('194', '174', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('195', '175', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('196', '176', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('197', '177', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('198', '178', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('199', '179', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('200', '180', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('201', '181', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('202', '182', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('203', '183', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('204', '184', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('205', '185', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('206', '186', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('207', '187', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('208', '188', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('209', '189', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('210', '190', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('211', '191', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('212', '192', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('213', '193', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('214', '194', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('215', '195', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('216', '196', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('217', '197', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('218', '198', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('219', '199', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('220', '200', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('418', '397', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('222', '202', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('223', '203', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('224', '204', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('225', '205', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('226', '206', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('227', '207', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('228', '208', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('229', '209', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('230', '210', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('231', '211', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('232', '212', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('233', '213', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('234', '214', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('235', '215', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('236', '216', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('237', '217', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('238', '218', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('239', '219', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('240', '220', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('241', '221', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('242', '222', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('243', '223', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('244', '224', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('245', '225', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('246', '226', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('247', '227', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('248', '228', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('249', '229', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('250', '230', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('251', '231', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('252', '232', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('253', '233', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('254', '234', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('255', '235', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('256', '236', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('257', '237', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('258', '238', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('259', '239', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('260', '240', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('261', '241', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('262', '242', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('263', '243', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('264', '244', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('265', '245', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('266', '246', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('267', '247', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('393', '373', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('269', '249', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('270', '250', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('271', '251', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('272', '252', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('273', '253', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('274', '254', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('275', '255', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('276', '256', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('277', '257', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('278', '258', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('279', '259', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('280', '260', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('281', '261', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('282', '262', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('283', '263', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('284', '264', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('285', '265', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('286', '266', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('287', '267', '', '', '', '', '', '1969-12-31', '1969-12-31', '1969-12-31', '1969-12-31', '1969-12-31');
INSERT INTO ticketAttachments VALUES ('422', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('289', '269', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('290', '270', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('291', '271', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('292', '272', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('293', '273', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('294', '274', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('295', '275', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('296', '276', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('297', '277', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('298', '278', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('299', '279', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('300', '280', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('301', '281', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('302', '282', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('303', '283', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('304', '284', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('305', '285', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('306', '286', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('307', '287', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('308', '288', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('309', '289', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('310', '290', '', '', '', '', '', '1969-12-31', '1969-12-31', '1969-12-31', '1969-12-31', '1969-12-31');
INSERT INTO ticketAttachments VALUES ('312', '292', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('313', '293', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('314', '294', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('315', '295', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('316', '296', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('317', '297', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('318', '298', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('319', '299', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('320', '300', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('321', '301', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('322', '302', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('323', '303', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('324', '304', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('325', '305', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('326', '306', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('327', '307', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('328', '308', '', '', '', '', '', '1969-12-31', '1969-12-31', '1969-12-31', '1969-12-31', '1969-12-31');
INSERT INTO ticketAttachments VALUES ('329', '309', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('330', '310', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('331', '311', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('332', '312', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('333', '313', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('334', '314', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('335', '315', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('336', '316', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('337', '317', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('338', '318', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('339', '319', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('343', '323', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('341', '321', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('342', '322', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('344', '324', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('345', '325', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('346', '326', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('347', '327', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('348', '328', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('349', '329', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('350', '330', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('351', '331', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('352', '332', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('353', '333', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('355', '335', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('356', '336', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('361', '341', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('358', '338', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('360', '340', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('362', '342', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('364', '344', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('365', '345', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('378', '358', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('368', '348', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('369', '349', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('370', '350', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('371', '351', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('372', '352', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('373', '353', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('374', '354', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('375', '355', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('376', '356', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('379', '359', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('380', '360', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('381', '361', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('382', '362', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('383', '363', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('384', '364', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('385', '365', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('386', '366', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('387', '367', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('388', '368', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('389', '369', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('394', '374', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('391', '371', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('392', '372', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('395', '375', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('396', '376', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('397', '377', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('398', '378', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('399', '379', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('400', '380', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('401', '381', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('402', '382', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('403', '383', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('404', '384', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('436', '413', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('416', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('417', '396', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('423', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('420', '399', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('421', '400', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('424', '401', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('425', '402', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('426', '403', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('427', '404', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('428', '405', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('429', '406', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('430', '407', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('431', '408', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('432', '409', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('433', '410', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('434', '411', '', '', '', 'measure-411.pdf', '', '1969-12-31', '1969-12-31', '1969-12-31', '1969-12-31', '1969-12-31');
INSERT INTO ticketAttachments VALUES ('435', '412', '', '', '', 'measure-412.pdf', '', '1969-12-31', '1969-12-31', '1969-12-31', '1969-12-31', '1969-12-31');
INSERT INTO ticketAttachments VALUES ('462', '439', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('437', '414', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('438', '415', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('439', '416', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('440', '417', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('441', '418', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('442', '419', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('443', '420', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('444', '421', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('445', '422', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('446', '423', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('447', '424', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('448', '425', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('449', '426', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('450', '427', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('451', '428', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('452', '429', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('453', '430', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('454', '431', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('455', '432', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('456', '433', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('457', '434', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('458', '435', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('466', '443', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('467', '444', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('468', '445', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('469', '446', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('470', '447', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('471', '448', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('472', '449', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('473', '450', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('474', '451', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('475', '452', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('476', '453', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('477', '454', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('478', '455', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('479', '456', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('480', '457', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('481', '458', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('482', '459', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('483', '460', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('484', '461', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('485', '462', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('486', '463', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('487', '464', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('488', '465', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('490', '467', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('491', '468', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('492', '469', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('493', '470', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('494', '471', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('495', '472', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('496', '473', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('497', '474', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('498', '475', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('499', '476', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('500', '477', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('501', '478', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('502', '479', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('503', '480', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('504', '481', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('505', '482', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('506', '483', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('507', '484', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('508', '485', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('509', '486', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('510', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('511', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('512', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('513', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('514', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('515', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('516', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('517', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('518', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('519', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('520', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('521', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('522', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('523', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('524', '487', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('528', '491', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('527', '490', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('529', '492', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('531', '494', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('532', '495', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('533', '496', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('537', '500', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('536', '499', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('538', '501', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('539', '502', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('540', '503', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('541', '504', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('542', '505', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('543', '506', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('544', '507', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('545', '508', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('546', '509', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('547', '510', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('548', '511', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('549', '512', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('550', '513', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('551', '514', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('552', '515', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('553', '516', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('554', '517', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('555', '518', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('556', '519', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('557', '520', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('558', '521', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('559', '522', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('560', '523', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('561', '524', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('562', '525', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('563', '526', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('564', '527', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('565', '528', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');


#
# Table structure for table `ticketInstallers`
#

DROP TABLE IF EXISTS `ticketInstallers`;
CREATE TABLE `ticketInstallers` (
  `installerID` int(11) NOT NULL AUTO_INCREMENT,
  `ticketID` varchar(250) DEFAULT NULL,
  `installerName` varchar(250) DEFAULT NULL,
  `installerType` varchar(1) DEFAULT NULL,
  `installerNum` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`installerID`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

#
# Dumping data for table `ticketInstallers`
#

INSERT INTO ticketInstallers VALUES ('1', '13', 'Angie', 'C', '35');
INSERT INTO ticketInstallers VALUES ('2', '13', 'Bryant', 'A', '52');
INSERT INTO ticketInstallers VALUES ('3', '13', 'Bryant', 'A', '2');
INSERT INTO ticketInstallers VALUES ('4', '14', 'Angi', 'B', '5');
INSERT INTO ticketInstallers VALUES ('5', '14', 'Bryant', 'C', '54');
INSERT INTO ticketInstallers VALUES ('6', '30', 'Angi', 'A', '');
INSERT INTO ticketInstallers VALUES ('7', '82', 'Angi', 'A', '');
INSERT INTO ticketInstallers VALUES ('8', '145', 'Angi', 'A', '');
INSERT INTO ticketInstallers VALUES ('9', '209', 'Mark ', 'B', '2');
INSERT INTO ticketInstallers VALUES ('10', '209', 'Mark ', 'C', '2');


#
# Table structure for table `ticketTask`
#

DROP TABLE IF EXISTS `ticketTask`;
CREATE TABLE `ticketTask` (
  `taskID` int(11) NOT NULL AUTO_INCREMENT,
  `taskticketID` varchar(250) DEFAULT NULL,
  `taskCust` varchar(250) NOT NULL,
  `taskEmp` varchar(100) DEFAULT NULL,
  `createdBy` varchar(50) DEFAULT NULL,
  `taskNotes` text NOT NULL,
  `taskDate` date NOT NULL,
  `taskStatus` varchar(100) DEFAULT NULL,
  `completeBy` date NOT NULL,
  `ticketRedFlag` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`taskID`)
) ENGINE=MyISAM AUTO_INCREMENT=64 DEFAULT CHARSET=latin1;

#
# Dumping data for table `ticketTask`
#

INSERT INTO ticketTask VALUES ('35', '', '142', 'Brent ', 'Brent ', 'J.D. called wants to order 1 window says we gave him an estimate per window when we quote patio door---i did not have time to look for it but will need to be measured and you would call him and go measure - 402-992-8728', '2015-12-28', 'Complete', '1969-12-31', '');
INSERT INTO ticketTask VALUES ('31', '', '201', 'Brent ', 'Brent ', 'Set up Estimate for Greg and Carla Pippitt Laurel (in the system) 402-375-0622 or 402-256-3635 he\'s a farmer', '2015-12-24', 'Complete', '1969-12-31', '');
INSERT INTO ticketTask VALUES ('32', '', '321', 'Brent ', 'Brent ', 'wants estimate on reflective insulation', '2015-12-24', 'Processing', '1969-12-31', '');
INSERT INTO ticketTask VALUES ('33', '', '314', 'Angi', 'Angi', 'Testing from Power Pages', '2015-12-24', 'Complete', '2015-12-25', '');
INSERT INTO ticketTask VALUES ('34', '', '323', 'Brent ', 'Karla ', 'Brent ---please call Tom Schmitz - Wayne when going that way they stopped into office and want an estimate closing on house next door to them---would be interested in single hungs or keeping it as respnable as possible---possible gutter estimate on garage also,  call him on his cell 402-375-0412', '2015-12-28', 'Complete', '1969-12-31', '');
INSERT INTO ticketTask VALUES ('5', '28', '12', 'Hailey', '', 'Take care of payment when this guy come stops to pick up siding. He should be picking up sometime today.', '2015-09-16', 'Complete', '0000-00-00', '');
INSERT INTO ticketTask VALUES ('6', '42', '27', 'Brent ', 'Hailey', 'JOB TO DO IN SPRING SOLD 9-22-15 TOLD HIM WE WOULD GET HALF DOWN WHEN WE ORDERED WINDOWS', '2016-02-15', 'Complete', '0000-00-00', '');
INSERT INTO ticketTask VALUES ('7', '48', '32', 'Brent ', 'Hailey', 'When??? 1 PD: Ordered 7-6-15
Lives In Randolph', '2015-09-23', 'Complete', '2015-11-21', 'Yes');
INSERT INTO ticketTask VALUES ('9', '56', '35', 'Brent ', '', 'Please call him. He needs an estimate on a bay. Wants to know when you are going to be in Orchard. KF told him you would call him tomorrow with a possible date.', '2015-09-24', 'Complete', '1969-12-31', '');
INSERT INTO ticketTask VALUES ('30', '', '56', 'Brent ', 'Brent ', 'send someone up to figure out price and how to do the porch', '2015-12-24', 'Processing', '1969-12-31', '');
INSERT INTO ticketTask VALUES ('12', '79', '46', 'Hailey', '', 'Need to Schedule this estimate(siding/windows) when we do this job.

Jenny Stevens
128 N. Walnut
Polk
402-710-2209', '2015-10-01', 'Complete', '1969-12-31', '');
INSERT INTO ticketTask VALUES ('13', '86', '54', 'Brent ', '', 'told we will order when new window is out', '2015-10-05', 'Complete', '2015-11-27', '');
INSERT INTO ticketTask VALUES ('14', '111', '77', 'Jeff ', '', 'Put new spring mechanism on front screen door.', '2015-10-09', 'Processing', '0000-00-00', '');
INSERT INTO ticketTask VALUES ('15', '112', '78', 'Brent ', '', 'We didnt finish job. Said we would be back in a week-never came. Have a sash and 1 screen will need rerolled.
', '2015-10-09', 'Complete', '1969-12-31', '');
INSERT INTO ticketTask VALUES ('16', '125', '91', 'Brent ', '', 'Look @ Joel Kracke Gutters', '2015-10-13', 'Complete', '1969-12-31', '');
INSERT INTO ticketTask VALUES ('17', '143', '110', 'Mark ', 'Hailey', 'Josh Job: Ordered New Screen: install when it comes in.
Has 1 window that is \"off set\". Need to look at when we put screen in.
', '2015-10-20', 'Processing', '1969-12-31', '');
INSERT INTO ticketTask VALUES ('18', '132', '100', 'Hailey', '', '129-154803 Bottom sash(stress crack)
Ordered 10-20-15', '2015-10-20', 'Complete', '1969-12-31', '');
INSERT INTO ticketTask VALUES ('29', '', '161', 'Angi', 'Hailey', 'Need to order (4) sashes for Muffin Morris. I have created a ticket already.
Use Ticket #00397', '2015-12-23', 'Complete', '2015-12-25', '');
INSERT INTO ticketTask VALUES ('46', '', '326', 'Angi', 'Angi', 'follow up email ', '2016-01-05', 'Complete', '1969-12-31', '');
INSERT INTO ticketTask VALUES ('22', '186', '152', 'Brent ', 'Angi', 'Look at north window.', '2015-12-04', 'Complete', '2015-12-08', 'Yes');
INSERT INTO ticketTask VALUES ('24', '316', '259', 'Jeff ', 'Hailey', 'Matt moved to a new house!    A screen for this job went to Cbus on 12/7/2015. This needs to be done asap or im sure he wont pay. The window never had a screen.', '2015-12-08', 'Complete', '2015-12-11', 'Yes');
INSERT INTO ticketTask VALUES ('25', '277', '227', 'Brent ', 'Angi', 'Steve wants to add 2 garage windows to the order.....so when we go that direction measure.....if we could get them ordered ASAp so we can do them all at once.', '2015-12-14', 'Complete', '1969-12-31', 'Yes');
INSERT INTO ticketTask VALUES ('26', '325', '267', 'Brent ', 'Hailey', 'Josh needs to finish Sticky expander.', '2015-12-14', 'Complete', '2015-12-23', 'Yes');
INSERT INTO ticketTask VALUES ('48', '', '299', 'Brent ', '', 'wife due rush ', '2016-01-08', 'Complete', '1969-12-31', 'Yes');
INSERT INTO ticketTask VALUES ('62', '', '390', 'Brent ', 'Hailey', 'Said you told him we were going his direction next week. he wanted to stop by the job we were installing and look @ the door. I dont know what you have scheduled for next week. PLEASE CALL.', '2016-01-29', 'Processing', '2016-01-29', '');
INSERT INTO ticketTask VALUES ('36', '', '314', 'Angi', 'Brent ', 'Test for PPGS', '2015-12-28', 'Complete', '2015-12-29', '');
INSERT INTO ticketTask VALUES ('37', '', '179', 'Brent ', 'Karla ', 'peg webster - wayne - wants to know when - 402-369-1118', '2015-12-28', 'Complete', '1969-12-31', '');
INSERT INTO ticketTask VALUES ('38', '', '179', 'Brent ', 'Karla ', 'peg webster - wayne - wants to know when - 402-369-1118', '2015-12-28', 'Complete', '1969-12-31', '');
INSERT INTO ticketTask VALUES ('39', '', '64', 'Angi', 'Karla ', '1/5/2016  talked to her in the morning said she was at work if I could call back at 345pm

i put a refferall letter on your desk and angela\'s folder ---she is not very happy,  i thought maybe you should call her and see if you can settle her down, so she is happy and we can do siding in spring, sounds like a lot of confustion--i would call here but here alone and trying to consentrate on year end stuff ', '2015-12-29', 'Complete', '1969-12-31', 'Yes');
INSERT INTO ticketTask VALUES ('40', '', '186', 'Mark ', 'Karla ', 'Is this done Mark? 

jackie samway called today and said her wraps were not done and she would be gone next week but to go ahead and do it---i would have put this on mark\'s but he is not looking yet so i put it on  your\'s
i talked to mark and he said he knows about this plus he has to do another coat of drywall mud at the randles job', '2015-12-30', 'Processing', '1969-12-31', '');
INSERT INTO ticketTask VALUES ('41', '', '191', 'Jeff ', '', 'CALLED TODAY SAID IF NOT DONE BY JAN 2ND CANCELLING JOB', '2015-12-31', 'Processing', '1969-12-31', '');
INSERT INTO ticketTask VALUES ('42', '', '121', 'Brent ', 'Hailey', 'He called today. wasnt too happy. Said he has been trying for a while not to get a set date for installation. Please Call him.
402-369-2290', '2016-01-04', 'Complete', '2016-01-05', '');
INSERT INTO ticketTask VALUES ('43', '', '325', 'Angi', 'Hailey', 'Seal Fail: 125-361941(Lower Sash)
Customer Called In
', '2016-01-04', 'Complete', '2016-01-13', '');
INSERT INTO ticketTask VALUES ('44', '', '27', 'Brent ', 'Hailey', 'He never received any samples. His wife will be stopping by to pick some up. She comes to norfolk once a week right now.', '2016-01-04', 'Complete', '2016-01-05', 'Yes');
INSERT INTO ticketTask VALUES ('45', '', '160', 'Brent ', 'Karla ', 'this was a rush 1 window  job says do as soon as it comes in, the window came in 01/04/16', '2016-01-04', 'Complete', '1969-12-31', 'Yes');
INSERT INTO ticketTask VALUES ('47', '', '134', 'Mark ', 'Brent ', 'CAULK OUTSIDE OF WINDOW', '2016-01-06', 'Complete', '2016-01-07', 'Yes');
INSERT INTO ticketTask VALUES ('49', '', '148', 'Karla ', 'Hailey', 'Call Ralph Phillips(wells Fargo) at 402-536-2517 Regarding Bob Pollack-ASK BRENT IF YOU HAVE QUESTIONS', '2016-01-08', 'Complete', '2016-01-15', '');
INSERT INTO ticketTask VALUES ('50', '', '337', 'Brent ', '', 'measure couple basement windows when in the area needs to be by first week of feb', '2016-01-08', 'Complete', '1969-12-31', '');
INSERT INTO ticketTask VALUES ('51', '', '297', 'Brent ', 'Hailey', 'was wonder when? this job has a rush on it, but windows are not in as of 1/11/2016
402-992-4610', '2016-01-11', 'Complete', '2016-01-15', '');
INSERT INTO ticketTask VALUES ('52', '', '340', 'Brent ', 'Brent ', 're figure estimate and send to steve smith ', '2016-01-12', 'Complete', '1969-12-31', 'Yes');
INSERT INTO ticketTask VALUES ('53', '', '121', 'Brent ', 'Brent ', 'told him the week of the 24th for install', '1969-12-31', 'Complete', '1969-12-31', '');
INSERT INTO ticketTask VALUES ('54', '', '357', 'Hailey', 'Hailey', 'Told him I would call him sometime next week AFTER Wednesday.', '2016-01-19', 'Complete', '2016-01-29', 'Yes');
INSERT INTO ticketTask VALUES ('55', '', '278', 'Brent ', 'Karla ', 'Adam called today and said his tenants just moved out and that it would be a great time to get windows in,  i told him you would look it over and call him as soon as possible,  his number to call is 402-992-3457', '2016-01-20', 'Complete', '1969-12-31', 'Yes');
INSERT INTO ticketTask VALUES ('56', '', '102', 'Jeff ', 'Hailey', '', '2016-01-21', 'Processing', '2016-02-23', 'Yes');
INSERT INTO ticketTask VALUES ('57', '', '178', 'Mark ', 'Angi', 'Bob called and he thought Thursday or Friday looks great for install:-)   Any possibility that could happen? I told him it could already be scheduled out? ', '2016-01-26', 'Processing', '2016-01-27', 'Yes');
INSERT INTO ticketTask VALUES ('58', '', '354', 'Brent ', 'Hailey', 'Call after 4:15. Wants to go with order, but has some questions.', '2016-01-26', 'Processing', '2016-01-27', '');
INSERT INTO ticketTask VALUES ('59', '', '245', 'Brent ', 'Hailey', 'Was jw when? he was thinking towards the end of december, and hasnt heard anything....please call him  640-6112', '2016-01-26', 'Complete', '2016-01-27', '');
INSERT INTO ticketTask VALUES ('60', '', '389', 'Brent ', 'Hailey', 'Please call him. He is wanting a bid...looks to be a 20+ window job. Kind of feel him out, see if you want Jon to measure for you or make a trip yourself...', '2016-01-27', 'Complete', '2016-01-29', '');
INSERT INTO ticketTask VALUES ('61', '', '390', 'Brent ', 'Hailey', 'Please call him. Wants to discuss R values on the triple vs double pane patio door', '2016-01-27', 'Complete', '2016-01-29', '');
INSERT INTO ticketTask VALUES ('63', '', '406', 'Jeff ', 'Brent ', 'wants more windows ordered ', '2016-02-04', 'Processing', '1969-12-31', 'Yes');


#
# Table structure for table `ticketTimes`
#

DROP TABLE IF EXISTS `ticketTimes`;
CREATE TABLE `ticketTimes` (
  `timeID` int(11) NOT NULL AUTO_INCREMENT,
  `ticketID` varchar(250) DEFAULT NULL,
  `empID` varchar(100) DEFAULT NULL,
  `timeDate` date NOT NULL,
  `timeTime` varchar(250) DEFAULT NULL,
  `timeNotes` text,
  PRIMARY KEY (`timeID`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

#
# Dumping data for table `ticketTimes`
#

INSERT INTO ticketTimes VALUES ('4', '13', 'Bryant', '2015-07-29', '', 'Windows are done. Siding needs to be installed');
INSERT INTO ticketTimes VALUES ('3', '13', 'Bryant', '2015-07-24', '55', 'note');
INSERT INTO ticketTimes VALUES ('5', '14', 'Bryant', '2015-08-19', '55', 'Drove to Columbus');


#
# Table structure for table `users`
#

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

#
# Dumping data for table `users`
#

INSERT INTO users VALUES ('1', 'demouser', '8cb2237d0679ca88db6464eac60da96345513964');
INSERT INTO users VALUES ('2', 'testuser', '8cb2237d0679ca88db6464eac60da96345513964');


#
# Table structure for table `warrantyTransfer`
#

DROP TABLE IF EXISTS `warrantyTransfer`;
CREATE TABLE `warrantyTransfer` (
  `warrantyID` int(11) NOT NULL AUTO_INCREMENT,
  `ticketID` varchar(4) DEFAULT NULL,
  `custID` varchar(250) DEFAULT NULL,
  `oldcustID` varchar(250) NOT NULL,
  `warrantyDate` date NOT NULL,
  `newName` varchar(150) DEFAULT NULL,
  `newPhone` varchar(100) DEFAULT NULL,
  `newEmail` varchar(250) DEFAULT NULL,
  `newNotes` text,
  `newShow` varchar(2) DEFAULT NULL,
  PRIMARY KEY (`warrantyID`)
) ENGINE=MyISAM AUTO_INCREMENT=571 DEFAULT CHARSET=latin1;

#
# Dumping data for table `warrantyTransfer`
#

INSERT INTO warrantyTransfer VALUES ('65', '56', '37', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('64', '55', '36', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('63', '54', '19', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('62', '53', '35', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('61', '52', '25', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('468', '440', '358', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('59', '50', '34', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('58', '49', '33', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('57', '48', '32', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('56', '47', '31', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('55', '46', '30', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('54', '45', '29', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('52', '43', '28', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('51', '42', '27', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('50', '41', '22', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('49', '40', '23', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('48', '39', '26', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('47', '38', '', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('46', '37', '24', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('45', '36', '', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('44', '35', '21', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('43', '34', '9', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('42', '33', '19', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('41', '32', '18', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('40', '31', '17', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('39', '30', '16', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('38', '29', '13', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('37', '28', '12', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('36', '27', '10', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('35', '26', '9', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('34', '25', '7', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('33', '24', '3', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('105', '81', '48', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('104', '80', '47', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('103', '79', '46', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('102', '78', '45', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('10', '0', '8', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('9', '16', '6', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('467', '439', '357', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('97', '73', '40', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('98', '74', '41', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('466', '438', '356', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('100', '76', '43', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('101', '77', '44', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('4', '3', '2', '', '1969-12-31', 'test', '', '', '', '');
INSERT INTO warrantyTransfer VALUES ('106', '82', '49', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('464', '436', '355', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('108', '84', '50', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('109', '85', '52', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('110', '86', '54', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('111', '87', '9', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('112', '88', '28', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('113', '89', '9', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('465', '437', '167', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('115', '91', '55', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('116', '92', '58', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('117', '93', '57', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('118', '94', '59', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('119', '95', '60', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('120', '96', '61', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('121', '97', '62', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('122', '98', '63', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('123', '99', '64', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('124', '100', '65', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('125', '101', '66', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('126', '102', '67', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('127', '103', '69', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('128', '104', '70', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('129', '105', '71', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('130', '106', '72', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('131', '107', '73', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('132', '108', '74', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('133', '109', '75', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('134', '110', '76', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('135', '111', '77', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('136', '112', '78', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('137', '113', '81', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('138', '114', '82', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('139', '115', '79', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('140', '116', '83', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('141', '117', '84', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('142', '118', '85', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('143', '119', '86', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('144', '120', '87', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('145', '121', '82', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('146', '122', '88', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('147', '123', '89', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('148', '124', '90', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('149', '125', '91', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('150', '126', '92', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('151', '127', '93', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('152', '128', '95', '', '2015-10-14', 'Hass & MCKayla Hammond', '640-3796', '', '', '1');
INSERT INTO warrantyTransfer VALUES ('153', '129', '96', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('154', '130', '98', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('155', '131', '99', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('156', '132', '100', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('157', '133', '101', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('158', '134', '102', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('159', '135', '103', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('160', '136', '106', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('161', '137', '80', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('162', '138', '107', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('163', '139', '108', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('164', '140', '109', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('165', '141', '38', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('166', '142', '111', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('167', '143', '110', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('168', '144', '110', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('169', '145', '100', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('170', '146', '112', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('171', '147', '114', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('172', '148', '115', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('173', '149', '116', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('174', '150', '117', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('175', '151', '118', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('176', '152', '72', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('177', '153', '120', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('178', '154', '120', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('179', '155', '121', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('180', '156', '122', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('181', '157', '123', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('182', '158', '124', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('381', '357', '292', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('184', '160', '126', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('185', '161', '124', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('186', '162', '127', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('187', '163', '128', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('315', '291', '239', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('189', '165', '130', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('367', '343', '279', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('191', '167', '132', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('192', '168', '134', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('193', '169', '135', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('194', '170', '136', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('195', '171', '136', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('196', '172', '137', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('197', '173', '138', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('198', '174', '139', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('199', '175', '140', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('200', '176', '140', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('201', '177', '142', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('202', '178', '143', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('203', '179', '144', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('204', '180', '145', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('205', '181', '146', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('206', '182', '149', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('207', '183', '148', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('208', '184', '150', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('209', '185', '151', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('210', '186', '152', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('211', '187', '132', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('212', '188', '64', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('213', '189', '148', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('214', '190', '153', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('215', '191', '141', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('216', '192', '112', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('217', '193', '154', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('218', '194', '61', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('219', '195', '155', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('220', '196', '156', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('221', '197', '48', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('222', '198', '158', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('223', '199', '159', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('224', '200', '160', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('423', '397', '161', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('226', '202', '162', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('227', '203', '163', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('228', '204', '164', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('229', '205', '165', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('230', '206', '166', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('231', '207', '166', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('232', '208', '167', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('233', '209', '168', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('234', '210', '9', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('235', '211', '170', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('236', '212', '171', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('237', '213', '172', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('238', '214', '173', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('239', '215', '177', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('240', '216', '178', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('241', '217', '183', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('242', '218', '184', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('243', '219', '179', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('244', '220', '182', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('245', '221', '180', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('246', '222', '185', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('247', '223', '39', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('248', '224', '186', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('249', '225', '186', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('250', '226', '188', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('251', '227', '188', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('252', '228', '189', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('253', '229', '190', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('254', '230', '191', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('255', '231', '181', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('256', '232', '161', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('257', '233', '190', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('258', '234', '174', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('259', '235', '193', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('260', '236', '126', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('261', '237', '194', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('262', '238', '16', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('263', '239', '195', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('264', '240', '196', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('265', '241', '197', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('266', '242', '198', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('267', '243', '199', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('268', '244', '19', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('269', '245', '200', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('270', '246', '202', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('271', '247', '203', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('397', '373', '305', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('273', '249', '204', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('274', '250', '206', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('275', '251', '207', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('276', '252', '208', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('277', '253', '209', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('278', '254', '209', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('279', '255', '157', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('280', '256', '63', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('281', '257', '39', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('282', '258', '210', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('283', '259', '212', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('284', '260', '203', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('285', '261', '84', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('286', '262', '213', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('287', '263', '214', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('288', '264', '215', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('289', '265', '216', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('290', '266', '218', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('291', '267', '220', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('427', '0', '221', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('293', '269', '221', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('294', '270', '222', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('295', '271', '223', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('296', '272', '224', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('297', '273', '225', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('298', '274', '20', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('299', '275', '226', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('300', '276', '219', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('301', '277', '227', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('302', '278', '140', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('303', '279', '228', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('304', '280', '217', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('305', '281', '229', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('306', '282', '230', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('307', '283', '231', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('308', '284', '9', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('309', '285', '232', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('310', '286', '233', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('311', '287', '234', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('312', '288', '235', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('313', '289', '236', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('314', '290', '237', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('316', '292', '240', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('317', '293', '230', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('318', '294', '241', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('319', '295', '9', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('320', '296', '243', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('321', '297', '244', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('322', '298', '245', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('323', '299', '230', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('324', '300', '246', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('325', '301', '9', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('326', '302', '9', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('327', '303', '9', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('328', '304', '248', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('329', '305', '249', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('330', '306', '250', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('331', '307', '251', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('332', '308', '9', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('333', '309', '252', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('334', '310', '207', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('335', '311', '40', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('336', '312', '253', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('337', '313', '255', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('338', '314', '257', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('339', '315', '258', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('340', '316', '259', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('341', '317', '260', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('342', '318', '261', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('343', '319', '261', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('347', '323', '30', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('345', '321', '262', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('346', '322', '264', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('348', '324', '266', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('349', '325', '267', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('350', '326', '215', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('351', '327', '268', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('352', '328', '269', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('353', '329', '270', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('354', '330', '192', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('355', '331', '269', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('356', '332', '272', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('357', '333', '271', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('359', '335', '97', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('360', '336', '274', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('365', '341', '276', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('362', '338', '3', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('364', '340', '275', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('366', '342', '277', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('368', '344', '280', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('369', '345', '281', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('382', '358', '293', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('372', '348', '282', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('373', '349', '284', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('374', '350', '285', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('375', '351', '286', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('376', '352', '287', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('377', '353', '288', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('378', '354', '289', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('379', '355', '290', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('380', '356', '291', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('383', '359', '294', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('384', '360', '295', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('385', '361', '22', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('386', '362', '178', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('387', '363', '296', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('388', '364', '297', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('389', '365', '299', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('390', '366', '278', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('391', '367', '298', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('392', '368', '300', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('393', '369', '301', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('398', '374', '306', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('395', '371', '302', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('396', '372', '303', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('399', '375', '307', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('400', '376', '308', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('401', '377', '309', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('402', '378', '311', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('403', '379', '312', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('404', '380', '72', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('405', '381', '158', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('406', '382', '310', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('407', '383', '310', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('408', '384', '36', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('441', '413', '333', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('421', '0', '221', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('422', '396', '316', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('428', '0', '221', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('425', '399', '138', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('426', '400', '322', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('429', '401', '325', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('430', '402', '44', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('431', '403', '327', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('432', '404', '328', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('433', '405', '29', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('434', '406', '61', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('435', '407', '329', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('436', '408', '329', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('437', '409', '185', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('438', '410', '330', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('439', '411', '331', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('440', '412', '332', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('442', '414', '334', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('443', '415', '335', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('444', '416', '336', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('445', '417', '257', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('446', '418', '338', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('447', '419', '339', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('448', '420', '261', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('449', '421', '340', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('450', '422', '47', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('451', '423', '341', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('452', '424', '342', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('453', '425', '343', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('454', '426', '344', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('455', '427', '345', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('456', '428', '346', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('457', '429', '348', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('458', '430', '347', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('459', '431', '350', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('460', '432', '351', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('461', '433', '352', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('462', '434', '353', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('463', '435', '354', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('469', '441', '359', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('470', '442', '360', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('471', '443', '361', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('472', '444', '115', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('473', '445', '362', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('474', '446', '363', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('475', '447', '58', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('476', '448', '364', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('477', '449', '303', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('478', '450', '357', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('479', '451', '58', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('480', '452', '365', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('481', '453', '365', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('482', '454', '366', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('483', '455', '116', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('484', '456', '223', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('485', '457', '367', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('486', '458', '356', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('487', '459', '368', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('488', '460', '345', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('489', '461', '369', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('490', '462', '370', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('491', '463', '237', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('492', '464', '103', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('493', '465', '371', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('495', '467', '372', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('496', '468', '373', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('497', '469', '374', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('498', '470', '375', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('499', '471', '376', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('500', '472', '378', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('501', '473', '379', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('502', '474', '380', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('503', '475', '381', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('504', '476', '19', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('505', '477', '382', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('506', '478', '281', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('507', '479', '383', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('508', '480', '384', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('509', '481', '385', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('510', '482', '386', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('511', '483', '387', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('512', '484', '142', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('513', '485', '388', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('514', '486', '389', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('515', '0', '390', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('516', '0', '390', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('517', '0', '390', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('518', '0', '390', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('519', '0', '390', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('520', '0', '390', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('521', '0', '390', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('522', '0', '390', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('523', '0', '390', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('524', '0', '390', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('525', '0', '390', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('526', '0', '390', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('527', '0', '390', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('528', '0', '390', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('529', '487', '390', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('533', '491', '392', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('532', '490', '391', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('534', '492', '346', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('536', '494', '212', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('537', '495', '393', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('538', '496', '201', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('542', '500', '121', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('541', '499', '9', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('543', '501', '121', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('544', '502', '314', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('545', '503', '394', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('546', '504', '54', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('547', '505', '395', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('548', '506', '306', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('549', '507', '396', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('550', '508', '134', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('551', '509', '397', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('552', '510', '398', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('553', '511', '227', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('554', '512', '212', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('555', '513', '400', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('556', '514', '401', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('557', '515', '309', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('558', '516', '402', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('559', '517', '402', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('560', '518', '399', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('561', '519', '254', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('562', '520', '403', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('563', '521', '404', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('564', '522', '405', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('565', '523', '406', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('566', '524', '407', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('567', '525', '408', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('568', '526', '409', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('569', '527', '410', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('570', '528', '286', '', '0000-00-00', '', '', '', '', '0');


