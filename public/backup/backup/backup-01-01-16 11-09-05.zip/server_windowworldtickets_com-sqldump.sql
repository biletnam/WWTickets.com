#
# MySQL database dump
# Created by MySQL_Backup class, ver. 1.0.0
#
# Host: sql5c0c.megasqlservers.com
# Generated: Jan 1, 2016 at 11:09
# MySQL version: 5.5.32-log
# PHP version: 5.3.28
#
# Database: `server_windowworldtickets_com`
#


#
# Table structure for table `VendorAds`
#

DROP TABLE IF EXISTS `VendorAds`;
CREATE TABLE `VendorAds` (
  `adID` int(11) NOT NULL AUTO_INCREMENT,
  `adVendorID` varchar(100) DEFAULT NULL,
  `adName` varchar(250) DEFAULT NULL,
  `adLocation` varchar(250) DEFAULT NULL,
  `adPrice` varchar(15) DEFAULT NULL,
  `adstartContract` date NOT NULL,
  `adendContract` date NOT NULL,
  `adRenewal` date NOT NULL,
  `adPayment` varchar(250) DEFAULT NULL,
  `adNotes` text,
  PRIMARY KEY (`adID`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

#
# Dumping data for table `VendorAds`
#

INSERT INTO VendorAds VALUES ('1', '1', 'Ad Square', 'Newspaper', '500.57', '2015-07-24', '2015-07-24', '2015-07-24', 'Visa/Mastercard', 'Notes goes here about ad.');
INSERT INTO VendorAds VALUES ('5', '4', '2016 farm show ', 'Norfolk', '$420', '2016-01-13', '2016-01-14', '1969-12-31', 'Check', '');
INSERT INTO VendorAds VALUES ('6', '5', '2016  59th Annual Siouxland Home Show ', 'Sioux City', '1425.00  (balan', '2016-02-25', '2016-02-28', '1969-12-31', 'Check', 'made down payment of 635.00 need to make final payment by Jan 10th of 790.');
INSERT INTO VendorAds VALUES ('7', '6', 'Weather sponsorship ', 'Norfolk', '$350 per month', '2015-10-01', '1969-12-31', '1969-12-31', 'Check', 'Live :15 commerials, minimum of 15 per week 7 days a week ');
INSERT INTO VendorAds VALUES ('8', '7', '2016 Columbus Home and Builders Show ', 'Columbus', '$1,400 ', '2016-02-26', '2016-02-28', '1969-12-31', 'Check', '');


#
# Table structure for table `Vendors`
#

DROP TABLE IF EXISTS `Vendors`;
CREATE TABLE `Vendors` (
  `vendorID` int(11) NOT NULL AUTO_INCREMENT,
  `vendorName` varchar(250) DEFAULT NULL,
  `vendorContact` varchar(250) DEFAULT NULL,
  `vendorPhone` varchar(100) DEFAULT NULL,
  `vendorType` varchar(150) DEFAULT NULL,
  `vendorFax` varchar(250) DEFAULT NULL,
  `vendorEmail` varchar(250) DEFAULT NULL,
  `vendorNotes` text,
  `vendorSlug` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`vendorID`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

#
# Dumping data for table `Vendors`
#

INSERT INTO Vendors VALUES ('1', 'Norfolk Daily News', 'Scott DeBoer', '(402) 851-2428', 'Newspaper', '(402) 851-2428', 'Info@Example.com', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptatibus voluptas incidunt hic natus consequuntur nostrum vel, recusandae consequatur sequi, maiores fugit eum, vero voluptate odit deleniti commodi veniam ab possimus.', 'norfolk-daily-news');
INSERT INTO Vendors VALUES ('4', '106 Kix', '', '', 'Newspaper', '', '', '', '');
INSERT INTO Vendors VALUES ('3', 'Power Pages', 'Scott DeBoer', '(402) 851-2428', 'Online', '(402) 379-2428', 'Web-Design@PowerPGS.com', 'Vendor Notes', '');
INSERT INTO Vendors VALUES ('5', 'Home Builders Assoc of Greater Siouxland  (Siouxland Home Show)', 'Nancy Moos', '712-255-3852', 'Outdoor and Transit', '', '', '
', '');
INSERT INTO Vendors VALUES ('6', '94.7 ', 'Gary Farnik', '402-379-0100 / 841-4212', 'Radio', '402-', 'gary@newschannelnebraska.com', '', '');
INSERT INTO Vendors VALUES ('7', 'Columbus Homebuilders Assoc', 'Steve ', '402-562-7068 (steve) / 402-276-0028 (Kelly)', 'Social Media', '', '', '', '');
INSERT INTO Vendors VALUES ('8', 'Norfolk Area Home Builders Assoc. ', 'Jane ', 'mechele 402-992-5946 / jane ', 'Social Media', '', 'nahb@telebeep.com', 'PO Box 558
Norfolk, NE 68702-0558
', '');


#
# Table structure for table `calendar`
#

DROP TABLE IF EXISTS `calendar`;
CREATE TABLE `calendar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(160) NOT NULL,
  `description` text NOT NULL,
  `start` datetime NOT NULL,
  `end` datetime NOT NULL,
  `allDay` varchar(5) NOT NULL,
  `color` varchar(7) NOT NULL,
  `url` varchar(255) NOT NULL,
  `category` varchar(200) NOT NULL,
  `repeat_type` varchar(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `repeat_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

#
# Dumping data for table `calendar`
#

INSERT INTO calendar VALUES ('1', 'Test Event', '', '2015-09-17 00:00:00', '0000-00-00 00:00:00', 'false', '', '?page=', '', 'every_day', '0', '1');
INSERT INTO calendar VALUES ('2', 'Test Event', '', '2015-09-18 00:00:00', '1970-01-01 00:00:00', 'false', '', '?page=', '', 'every_day', '0', '1');
INSERT INTO calendar VALUES ('3', 'Test Event', '', '2015-09-19 00:00:00', '1970-01-02 00:00:00', 'false', '', '?page=', '', 'every_day', '0', '1');
INSERT INTO calendar VALUES ('4', 'Test Event', '', '2015-09-20 00:00:00', '1970-01-03 00:00:00', 'false', '', '?page=', '', 'every_day', '0', '1');
INSERT INTO calendar VALUES ('5', 'Event Two', '', '2015-09-18 00:00:00', '0000-00-00 00:00:00', 'false', '#680000', '?page=', '', 'no', '0', '5');


#
# Table structure for table `cities`
#

DROP TABLE IF EXISTS `cities`;
CREATE TABLE `cities` (
  `city_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `city_name` varchar(100) DEFAULT NULL,
  `city_slug` varchar(100) DEFAULT NULL,
  `city_state` varchar(2) DEFAULT NULL,
  `city_zip` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`city_id`),
  UNIQUE KEY `city_slug` (`city_slug`)
) ENGINE=MyISAM AUTO_INCREMENT=546 DEFAULT CHARSET=latin1;

#
# Dumping data for table `cities`
#

INSERT INTO cities VALUES ('1', 'Norfolk', 'norfolk', 'NE', '68701');
INSERT INTO cities VALUES ('2', 'Pierce', 'pierce', 'NE', '68767');
INSERT INTO cities VALUES ('3', 'Stanton', 'stanton', 'NE', '68779');
INSERT INTO cities VALUES ('4', 'Hadar', 'hadar', 'NE', '68738');
INSERT INTO cities VALUES ('5', 'Battle Creek', 'battle-creek', 'NE', '68715');
INSERT INTO cities VALUES ('6', 'Madison', 'madison', 'NE', '68748');
INSERT INTO cities VALUES ('7', 'Coleridge', 'coleridge', 'NE', '68727');
INSERT INTO cities VALUES ('8', 'Oakdale', 'oakdale', 'NE', '68761');
INSERT INTO cities VALUES ('9', 'Neligh', 'neligh', 'NE', '68756');
INSERT INTO cities VALUES ('10', 'O\'Neill', 'oneill', 'NE', '68763');
INSERT INTO cities VALUES ('11', 'Newman Grove', 'newman-grove', 'NE', '68758');
INSERT INTO cities VALUES ('12', 'Plainview', 'plainview', 'NE', '68769');
INSERT INTO cities VALUES ('13', 'Clearwater', 'clearwater', 'NE', '68726');
INSERT INTO cities VALUES ('14', 'Hartington', 'hartington', 'NE', '68739');
INSERT INTO cities VALUES ('15', 'Creighton', 'creighton', 'NE', '68729');
INSERT INTO cities VALUES ('16', 'Bloomfield', 'bloomfield', 'NE', '68718');
INSERT INTO cities VALUES ('17', 'Wausa', 'wausa', 'NE', '68786');
INSERT INTO cities VALUES ('18', 'Wayne', 'wayne', 'NE', '68787');
INSERT INTO cities VALUES ('19', 'Elgin', 'elgin', 'NE', '68636');
INSERT INTO cities VALUES ('20', 'West Point', 'west-point', 'NE', '68788');
INSERT INTO cities VALUES ('21', 'Royal', 'royal', 'NE', '68773');
INSERT INTO cities VALUES ('22', 'Wisner', 'wisner', 'NE', '68791');
INSERT INTO cities VALUES ('23', 'Beemer', 'beemer', 'NE', '68716');
INSERT INTO cities VALUES ('24', 'Tilden', 'tilden', 'NE', '68781');
INSERT INTO cities VALUES ('25', 'Humphrey', 'humphrey', 'NE', '68642');
INSERT INTO cities VALUES ('26', 'Clarkson', 'clarkson', 'NE', '68629');
INSERT INTO cities VALUES ('27', 'Dodge', 'dodge', 'NE', '68633');
INSERT INTO cities VALUES ('28', 'Meadow Grove', 'meadow-grove', 'NE', '68752');
INSERT INTO cities VALUES ('29', 'Pilger', 'pilger', 'NE', '68768');
INSERT INTO cities VALUES ('30', 'Laurel', 'laurel', 'NE', '68745');
INSERT INTO cities VALUES ('31', 'Albion', 'albion', 'NE', '68620');
INSERT INTO cities VALUES ('32', 'Orchard', 'orchard', 'NE', '68764');
INSERT INTO cities VALUES ('33', 'Winside', 'winside', 'NE', '68790');
INSERT INTO cities VALUES ('34', 'Hoskins', 'hoskins', 'NE', '68740');
INSERT INTO cities VALUES ('35', 'Lindsay', 'lindsay', 'NE', '68644');
INSERT INTO cities VALUES ('36', 'Ewing', 'ewing', 'NE', '68735');
INSERT INTO cities VALUES ('37', 'Carroll', 'carroll', 'NE', '68723');
INSERT INTO cities VALUES ('38', 'Leigh', 'leigh', 'NE', '68643');
INSERT INTO cities VALUES ('39', 'Howells', 'howells', 'NE', '68641');
INSERT INTO cities VALUES ('40', 'Osmond', 'osmond', 'NE', '68765');
INSERT INTO cities VALUES ('41', 'Crofton', 'crofton', 'NE', '68730');
INSERT INTO cities VALUES ('42', 'Columbus', 'columbus', 'NE', '68601');
INSERT INTO cities VALUES ('43', 'Verdigre', 'verdigre', 'NE', '68783');
INSERT INTO cities VALUES ('44', 'Randolph', 'randolph', 'NE', '68771');
INSERT INTO cities VALUES ('45', 'Niobrara', 'niobrara', 'NE', '68760');
INSERT INTO cities VALUES ('46', 'Newcastle', 'newcastle', 'NE', '68757');
INSERT INTO cities VALUES ('47', 'Ponca', 'ponca', 'NE', '68770');
INSERT INTO cities VALUES ('48', 'Wakefield', 'wakefield', 'NE', '68784');
INSERT INTO cities VALUES ('49', 'Winnetoon', 'winnetoon', 'NE', '68789');
INSERT INTO cities VALUES ('50', 'Pender', 'pender', 'NE', '68047');
INSERT INTO cities VALUES ('51', 'Scribner', 'scribner', 'NE', '68057');
INSERT INTO cities VALUES ('52', 'Schuyler', 'schuyler', 'NE', '68661');
INSERT INTO cities VALUES ('53', 'North Bend', 'north-bend', 'NE', '68649');
INSERT INTO cities VALUES ('54', 'Wynot', 'wynot', 'NE', '68792');
INSERT INTO cities VALUES ('55', 'Petersburg', 'petersburg', 'NE', '68652');
INSERT INTO cities VALUES ('56', 'Foster', 'foster', 'NE', '68737');
INSERT INTO cities VALUES ('57', 'Wahoo', 'wahoo', 'NE', '68066');
INSERT INTO cities VALUES ('58', 'Kearney', 'kearney', 'NE', '68845');
INSERT INTO cities VALUES ('59', 'Lincoln', 'lincoln', 'NE', '68501');
INSERT INTO cities VALUES ('60', 'Omaha', 'omaha', 'NE', '68114');
INSERT INTO cities VALUES ('61', 'Dixon', 'dixon', 'NE', '68732');
INSERT INTO cities VALUES ('62', 'Brunswick', 'brunswick', 'NE', '68720');
INSERT INTO cities VALUES ('63', 'Creston', 'creston', 'NE', '68631');
INSERT INTO cities VALUES ('64', 'Grand Island', 'grand-island', 'NE', '68801');
INSERT INTO cities VALUES ('65', 'Duncan', 'duncan', 'NE', '68634');
INSERT INTO cities VALUES ('66', 'Santee', 'santee', 'NE', '68760');
INSERT INTO cities VALUES ('67', 'Center', 'center', 'NE', '68724');
INSERT INTO cities VALUES ('68', 'Sioux City', 'sioux-city', 'IA', '51101');
INSERT INTO cities VALUES ('69', 'Yankton', 'yankton', 'SD', '57078');
INSERT INTO cities VALUES ('70', 'Abie', 'abie', 'NE', '68001');
INSERT INTO cities VALUES ('71', 'Adams', 'adams', 'NE', '68301');
INSERT INTO cities VALUES ('72', 'Ainsworth', 'ainsworth', 'NE', '69210');
INSERT INTO cities VALUES ('73', 'Alda', 'alda', 'NE', '68810');
INSERT INTO cities VALUES ('74', 'Alexandria', 'alexandria', 'NE', '68303');
INSERT INTO cities VALUES ('75', 'Allen', 'allen', 'NE', '68710');
INSERT INTO cities VALUES ('76', 'Alliance', 'alliance', 'NE', '69301');
INSERT INTO cities VALUES ('77', 'Alma', 'alma', 'NE', '68920');
INSERT INTO cities VALUES ('78', 'Alvo', 'alvo', 'NE', '68304');
INSERT INTO cities VALUES ('79', 'Amelia', 'amelia', 'NE', '68711');
INSERT INTO cities VALUES ('80', 'Ames', 'ames', 'NE', '68621');
INSERT INTO cities VALUES ('81', 'Amherst', 'amherst', 'NE', '68812');
INSERT INTO cities VALUES ('82', 'Angora', 'angora', 'NE', '69331');
INSERT INTO cities VALUES ('83', 'Anselmo', 'anselmo', 'NE', '68813');
INSERT INTO cities VALUES ('84', 'Ansley', 'ansley', 'NE', '68814');
INSERT INTO cities VALUES ('85', 'Arapahoe', 'arapahoe', 'NE', '68922');
INSERT INTO cities VALUES ('86', 'Arcadia', 'arcadia', 'NE', '68815');
INSERT INTO cities VALUES ('87', 'Archer', 'archer', 'NE', '68816');
INSERT INTO cities VALUES ('88', 'Arlington', 'arlington', 'NE', '68002');
INSERT INTO cities VALUES ('89', 'Arnold', 'arnold', 'NE', '69120');
INSERT INTO cities VALUES ('90', 'Arthur', 'arthur', 'NE', '69121');
INSERT INTO cities VALUES ('91', 'Ashby', 'ashby', 'NE', '69333');
INSERT INTO cities VALUES ('92', 'Ashland', 'ashland', 'NE', '68003');
INSERT INTO cities VALUES ('93', 'Ashton', 'ashton', 'NE', '68817');
INSERT INTO cities VALUES ('94', 'Atkinson', 'atkinson', 'NE', '68713');
INSERT INTO cities VALUES ('95', 'Atlanta', 'atlanta', 'NE', '68923');
INSERT INTO cities VALUES ('96', 'Auburn', 'auburn', 'NE', '68305');
INSERT INTO cities VALUES ('97', 'Aurora', 'aurora', 'NE', '68818');
INSERT INTO cities VALUES ('98', 'Avoca', 'avoca', 'NE', '68307');
INSERT INTO cities VALUES ('99', 'Axtell', 'axtell', 'NE', '68924');
INSERT INTO cities VALUES ('100', 'Ayr', 'ayr', 'NE', '68925');
INSERT INTO cities VALUES ('101', 'Bancroft', 'bancroft', 'NE', '68004');
INSERT INTO cities VALUES ('102', 'Barneston', 'barneston', 'NE', '68309');
INSERT INTO cities VALUES ('103', 'Bartlett', 'bartlett', 'NE', '68622');
INSERT INTO cities VALUES ('104', 'Bartley', 'bartley', 'NE', '69020');
INSERT INTO cities VALUES ('105', 'Bassett', 'bassett', 'NE', '68714');
INSERT INTO cities VALUES ('106', 'Bayard', 'bayard', 'NE', '69334');
INSERT INTO cities VALUES ('107', 'Beatrice', 'beatrice', 'NE', '68310');
INSERT INTO cities VALUES ('108', 'Beaver City', 'beaver-city', 'NE', '68926');
INSERT INTO cities VALUES ('109', 'Beaver Crossing', 'beaver-crossing', 'NE', '68313');
INSERT INTO cities VALUES ('110', 'Bee', 'bee', 'NE', '68314');
INSERT INTO cities VALUES ('111', 'Belden', 'belden', 'NE', '68717');
INSERT INTO cities VALUES ('112', 'Belgrade', 'belgrade', 'NE', '68623');
INSERT INTO cities VALUES ('113', 'Bellevue', 'bellevue', 'NE', '68005');
INSERT INTO cities VALUES ('114', 'Bellwood', 'bellwood', 'NE', '68624');
INSERT INTO cities VALUES ('115', 'Belvidere', 'belvidere', 'NE', '68315');
INSERT INTO cities VALUES ('116', 'Benedict', 'benedict', 'NE', '68316');
INSERT INTO cities VALUES ('117', 'Benkelman', 'benkelman', 'NE', '69021');
INSERT INTO cities VALUES ('118', 'Bennet', 'bennet', 'NE', '68317');
INSERT INTO cities VALUES ('119', 'Bennington', 'bennington', 'NE', '68007');
INSERT INTO cities VALUES ('120', 'Bertrand', 'bertrand', 'NE', '68927');
INSERT INTO cities VALUES ('121', 'Berwyn', 'berwyn', 'NE', '68819');
INSERT INTO cities VALUES ('122', 'Big Springs', 'big-springs', 'NE', '69122');
INSERT INTO cities VALUES ('123', 'Bingham', 'bingham', 'NE', '69335');
INSERT INTO cities VALUES ('124', 'Bladen', 'bladen', 'NE', '68928');
INSERT INTO cities VALUES ('125', 'Blair', 'blair', 'NE', '68008');
INSERT INTO cities VALUES ('128', 'Blue Hill', 'blue-hill', 'NE', '68930');
INSERT INTO cities VALUES ('129', 'Blue Springs', 'blue-springs', 'NE', '68318');
INSERT INTO cities VALUES ('130', 'Boelus', 'boelus', 'NE', '68820');
INSERT INTO cities VALUES ('131', 'Boys Town', 'boys-town', 'NE', '68010');
INSERT INTO cities VALUES ('132', 'Bradshaw', 'bradshaw', 'NE', '68319');
INSERT INTO cities VALUES ('133', 'Brady', 'brady', 'NE', '69123');
INSERT INTO cities VALUES ('134', 'Brainard', 'brainard', 'NE', '68626');
INSERT INTO cities VALUES ('135', 'Brewster', 'brewster', 'NE', '68821');
INSERT INTO cities VALUES ('136', 'Bridgeport', 'bridgeport', 'NE', '69336');
INSERT INTO cities VALUES ('137', 'Bristow', 'bristow', 'NE', '68719');
INSERT INTO cities VALUES ('138', 'Broadwater', 'broadwater', 'NE', '69125');
INSERT INTO cities VALUES ('139', 'Brock', 'brock', 'NE', '68320');
INSERT INTO cities VALUES ('140', 'Broken Bow', 'broken-bow', 'NE', '68822');
INSERT INTO cities VALUES ('141', 'Brownville', 'brownville', 'NE', '68321');
INSERT INTO cities VALUES ('142', 'Brule', 'brule', 'NE', '69127');
INSERT INTO cities VALUES ('143', 'Bruning', 'bruning', 'NE', '68322');
INSERT INTO cities VALUES ('144', 'Bruno', 'bruno', 'NE', '68014');
INSERT INTO cities VALUES ('145', 'Burchard', 'burchard', 'NE', '68323');
INSERT INTO cities VALUES ('146', 'Burr', 'burr', 'NE', '68324');
INSERT INTO cities VALUES ('147', 'Burwell', 'burwell', 'NE', '68823');
INSERT INTO cities VALUES ('148', 'Bushnell', 'bushnell', 'NE', '69128');
INSERT INTO cities VALUES ('149', 'Butte', 'butte', 'NE', '68722');
INSERT INTO cities VALUES ('150', 'Byron', 'byron', 'NE', '68325');
INSERT INTO cities VALUES ('151', 'Cairo', 'cairo', 'NE', '68824');
INSERT INTO cities VALUES ('152', 'Callaway', 'callaway', 'NE', '68825');
INSERT INTO cities VALUES ('153', 'Cambridge', 'cambridge', 'NE', '69022');
INSERT INTO cities VALUES ('154', 'Campbell', 'campbell', 'NE', '68932');
INSERT INTO cities VALUES ('155', 'Carleton', 'carleton', 'NE', '68326');
INSERT INTO cities VALUES ('156', 'Cedar Bluffs', 'cedar-bluffs', 'NE', '68015');
INSERT INTO cities VALUES ('157', 'Cedar Creek', 'cedar-creek', 'NE', '68016');
INSERT INTO cities VALUES ('158', 'Cedar Rapids', 'cedar-rapids', 'NE', '68627');
INSERT INTO cities VALUES ('159', 'Central City', 'central-city', 'NE', '68826');
INSERT INTO cities VALUES ('160', 'Ceresco', 'ceresco', 'NE', '68017');
INSERT INTO cities VALUES ('161', 'Chadron', 'chadron', 'NE', '69337');
INSERT INTO cities VALUES ('162', 'Chambers', 'chambers', 'NE', '68725');
INSERT INTO cities VALUES ('163', 'Champion', 'champion', 'NE', '69023');
INSERT INTO cities VALUES ('164', 'Chapman', 'chapman', 'NE', '68827');
INSERT INTO cities VALUES ('165', 'Chappell', 'chappell', 'NE', '69129');
INSERT INTO cities VALUES ('166', 'Chester', 'chester', 'NE', '68327');
INSERT INTO cities VALUES ('167', 'Clarks', 'clarks', 'NE', '68628');
INSERT INTO cities VALUES ('168', 'Clatonia', 'clatonia', 'NE', '68328');
INSERT INTO cities VALUES ('169', 'Clay Center', 'clay-center', 'NE', '68933');
INSERT INTO cities VALUES ('170', 'Cody', 'cody', 'NE', '69211');
INSERT INTO cities VALUES ('171', 'Colon', 'colon', 'NE', '68018');
INSERT INTO cities VALUES ('172', 'Comstock', 'comstock', 'NE', '68828');
INSERT INTO cities VALUES ('173', 'Concord', 'concord', 'NE', '68728');
INSERT INTO cities VALUES ('174', 'Cook', 'cook', 'NE', '68329');
INSERT INTO cities VALUES ('175', 'Cordova', 'cordova', 'NE', '68330');
INSERT INTO cities VALUES ('176', 'Cortland', 'cortland', 'NE', '68331');
INSERT INTO cities VALUES ('177', 'Cozad', 'cozad', 'NE', '69130');
INSERT INTO cities VALUES ('178', 'Crab Orchard', 'crab-orchard', 'NE', '68332');
INSERT INTO cities VALUES ('179', 'Craig', 'craig', 'NE', '68019');
INSERT INTO cities VALUES ('180', 'Crawford', 'crawford', 'NE', '69339');
INSERT INTO cities VALUES ('181', 'Crete', 'crete', 'NE', '68333');
INSERT INTO cities VALUES ('182', 'Crookston', 'crookston', 'NE', '69212');
INSERT INTO cities VALUES ('183', 'Culbertson', 'culbertson', 'NE', '69024');
INSERT INTO cities VALUES ('184', 'Curtis', 'curtis', 'NE', '69025');
INSERT INTO cities VALUES ('185', 'Dakota City', 'dakota-city', 'NE', '68731');
INSERT INTO cities VALUES ('186', 'Dalton', 'dalton', 'NE', '69131');
INSERT INTO cities VALUES ('187', 'Danbury', 'danbury', 'NE', '69026');
INSERT INTO cities VALUES ('188', 'Dannebrog', 'dannebrog', 'NE', '68831');
INSERT INTO cities VALUES ('189', 'Davenport', 'davenport', 'NE', '68335');
INSERT INTO cities VALUES ('190', 'Davey', 'davey', 'NE', '68336');
INSERT INTO cities VALUES ('191', 'David City', 'david-city', 'NE', '68632');
INSERT INTO cities VALUES ('192', 'Dawson', 'dawson', 'NE', '68337');
INSERT INTO cities VALUES ('193', 'Daykin', 'daykin', 'NE', '68338');
INSERT INTO cities VALUES ('194', 'De Witt', 'de-witt', 'NE', '68341');
INSERT INTO cities VALUES ('195', 'Decatur', 'decatur', 'NE', '68020');
INSERT INTO cities VALUES ('196', 'Denton', 'denton', 'NE', '68339');
INSERT INTO cities VALUES ('197', 'Deshler', 'deshler', 'NE', '68340');
INSERT INTO cities VALUES ('198', 'Deweese', 'deweese', 'NE', '68934');
INSERT INTO cities VALUES ('199', 'Dickens', 'dickens', 'NE', '69132');
INSERT INTO cities VALUES ('200', 'Diller', 'diller', 'NE', '68342');
INSERT INTO cities VALUES ('201', 'Dix', 'dix', 'NE', '69133');
INSERT INTO cities VALUES ('202', 'Doniphan', 'doniphan', 'NE', '68832');
INSERT INTO cities VALUES ('203', 'Dorchester', 'dorchester', 'NE', '68343');
INSERT INTO cities VALUES ('204', 'Douglas', 'douglas', 'NE', '68344');
INSERT INTO cities VALUES ('205', 'Du Bois', 'du-bois', 'NE', '68345');
INSERT INTO cities VALUES ('206', 'Dunbar', 'dunbar', 'NE', '68346');
INSERT INTO cities VALUES ('207', 'Dunning', 'dunning', 'NE', '68833');
INSERT INTO cities VALUES ('208', 'Dwight', 'dwight', 'NE', '68635');
INSERT INTO cities VALUES ('209', 'Eagle', 'eagle', 'NE', '68347');
INSERT INTO cities VALUES ('210', 'Eddyville', 'eddyville', 'NE', '68834');
INSERT INTO cities VALUES ('211', 'Edgar', 'edgar', 'NE', '68935');
INSERT INTO cities VALUES ('212', 'Edison', 'edison', 'NE', '68936');
INSERT INTO cities VALUES ('213', 'Elba', 'elba', 'NE', '68835');
INSERT INTO cities VALUES ('214', 'Elk Creek', 'elk-creek', 'NE', '68348');
INSERT INTO cities VALUES ('215', 'Elkhorn', 'elkhorn', 'NE', '68022');
INSERT INTO cities VALUES ('216', 'Ellsworth', 'ellsworth', 'NE', '69340');
INSERT INTO cities VALUES ('217', 'Elm Creek', 'elm-creek', 'NE', '68836');
INSERT INTO cities VALUES ('218', 'Elmwood', 'elmwood', 'NE', '68349');
INSERT INTO cities VALUES ('219', 'Elsie', 'elsie', 'NE', '69134');
INSERT INTO cities VALUES ('220', 'Elsmere', 'elsmere', 'NE', '69135');
INSERT INTO cities VALUES ('221', 'Elwood', 'elwood', 'NE', '68937');
INSERT INTO cities VALUES ('222', 'Elyria', 'elyria', 'NE', '68837');
INSERT INTO cities VALUES ('223', 'Emerson', 'emerson', 'NE', '68733');
INSERT INTO cities VALUES ('224', 'Emmet', 'emmet', 'NE', '68734');
INSERT INTO cities VALUES ('225', 'Enders', 'enders', 'NE', '69027');
INSERT INTO cities VALUES ('226', 'Endicott', 'endicott', 'NE', '68350');
INSERT INTO cities VALUES ('227', 'Ericson', 'ericson', 'NE', '68637');
INSERT INTO cities VALUES ('228', 'Eustis', 'eustis', 'NE', '69028');
INSERT INTO cities VALUES ('229', 'Exeter', 'exeter', 'NE', '68351');
INSERT INTO cities VALUES ('230', 'Fairbury', 'fairbury', 'NE', '68352');
INSERT INTO cities VALUES ('231', 'Fairfield', 'fairfield', 'NE', '68938');
INSERT INTO cities VALUES ('232', 'Fairmont', 'fairmont', 'NE', '68354');
INSERT INTO cities VALUES ('233', 'Falls City', 'falls-city', 'NE', '68355');
INSERT INTO cities VALUES ('234', 'Farnam', 'farnam', 'NE', '69029');
INSERT INTO cities VALUES ('235', 'Farwell', 'farwell', 'NE', '68838');
INSERT INTO cities VALUES ('236', 'Filley', 'filley', 'NE', '68357');
INSERT INTO cities VALUES ('237', 'Firth', 'firth', 'NE', '68358');
INSERT INTO cities VALUES ('238', 'Fordyce', 'fordyce', 'NE', '68736');
INSERT INTO cities VALUES ('239', 'Fort Calhoun', 'fort-calhoun', 'NE', '68023');
INSERT INTO cities VALUES ('240', 'Franklin', 'franklin', 'NE', '68939');
INSERT INTO cities VALUES ('241', 'Fremont', 'fremont', 'NE', '68025');
INSERT INTO cities VALUES ('243', 'Friend', 'friend', 'NE', '68359');
INSERT INTO cities VALUES ('244', 'Fullerton', 'fullerton', 'NE', '68638');
INSERT INTO cities VALUES ('245', 'Funk', 'funk', 'NE', '68940');
INSERT INTO cities VALUES ('246', 'Garland', 'garland', 'NE', '68360');
INSERT INTO cities VALUES ('247', 'Geneva', 'geneva', 'NE', '68361');
INSERT INTO cities VALUES ('248', 'Genoa', 'genoa', 'NE', '68640');
INSERT INTO cities VALUES ('249', 'Gering', 'gering', 'NE', '69341');
INSERT INTO cities VALUES ('250', 'Gibbon', 'gibbon', 'NE', '68840');
INSERT INTO cities VALUES ('251', 'Gilead', 'gilead', 'NE', '68362');
INSERT INTO cities VALUES ('252', 'Giltner', 'giltner', 'NE', '68841');
INSERT INTO cities VALUES ('253', 'Glenvil', 'glenvil', 'NE', '68941');
INSERT INTO cities VALUES ('254', 'Goehner', 'goehner', 'NE', '68364');
INSERT INTO cities VALUES ('255', 'Gordon', 'gordon', 'NE', '69343');
INSERT INTO cities VALUES ('256', 'Gothenburg', 'gothenburg', 'NE', '69138');
INSERT INTO cities VALUES ('257', 'Grafton', 'grafton', 'NE', '68365');
INSERT INTO cities VALUES ('258', 'Grant', 'grant', 'NE', '69140');
INSERT INTO cities VALUES ('259', 'Greeley', 'greeley', 'NE', '68842');
INSERT INTO cities VALUES ('260', 'Greenwood', 'greenwood', 'NE', '68366');
INSERT INTO cities VALUES ('261', 'Gresham', 'gresham', 'NE', '68367');
INSERT INTO cities VALUES ('262', 'Gretna', 'gretna', 'NE', '68028');
INSERT INTO cities VALUES ('263', 'Guide Rock', 'guide-rock', 'NE', '68942');
INSERT INTO cities VALUES ('264', 'Gurley', 'gurley', 'NE', '69141');
INSERT INTO cities VALUES ('265', 'Haigler', 'haigler', 'NE', '69030');
INSERT INTO cities VALUES ('266', 'Hallam', 'hallam', 'NE', '68368');
INSERT INTO cities VALUES ('267', 'Halsey', 'halsey', 'NE', '69142');
INSERT INTO cities VALUES ('268', 'Hamlet', 'hamlet', 'NE', '69031');
INSERT INTO cities VALUES ('269', 'Hampton', 'hampton', 'NE', '68843');
INSERT INTO cities VALUES ('270', 'Hardy', 'hardy', 'NE', '68943');
INSERT INTO cities VALUES ('271', 'Harrisburg', 'harrisburg', 'NE', '69345');
INSERT INTO cities VALUES ('272', 'Harrison', 'harrison', 'NE', '69346');
INSERT INTO cities VALUES ('273', 'Harvard', 'harvard', 'NE', '68944');
INSERT INTO cities VALUES ('274', 'Hastings', 'hastings', 'NE', '68901');
INSERT INTO cities VALUES ('276', 'Hay Springs', 'hay-springs', 'NE', '69347');
INSERT INTO cities VALUES ('277', 'Hayes Center', 'hayes-center', 'NE', '69032');
INSERT INTO cities VALUES ('278', 'Hazard', 'hazard', 'NE', '68844');
INSERT INTO cities VALUES ('279', 'Heartwell', 'heartwell', 'NE', '68945');
INSERT INTO cities VALUES ('280', 'Hebron', 'hebron', 'NE', '68370');
INSERT INTO cities VALUES ('281', 'Hemingford', 'hemingford', 'NE', '69348');
INSERT INTO cities VALUES ('282', 'Henderson', 'henderson', 'NE', '68371');
INSERT INTO cities VALUES ('283', 'Hendley', 'hendley', 'NE', '68946');
INSERT INTO cities VALUES ('284', 'Henry', 'henry', 'NE', '69349');
INSERT INTO cities VALUES ('285', 'Herman', 'herman', 'NE', '68029');
INSERT INTO cities VALUES ('286', 'Hershey', 'hershey', 'NE', '69143');
INSERT INTO cities VALUES ('287', 'Hickman', 'hickman', 'NE', '68372');
INSERT INTO cities VALUES ('288', 'Hildreth', 'hildreth', 'NE', '68947');
INSERT INTO cities VALUES ('289', 'Holbrook', 'holbrook', 'NE', '68948');
INSERT INTO cities VALUES ('290', 'Holdrege', 'holdrege', 'NE', '68949');
INSERT INTO cities VALUES ('291', 'Holmesville', 'holmesville', 'NE', '68374');
INSERT INTO cities VALUES ('292', 'Holstein', 'holstein', 'NE', '68950');
INSERT INTO cities VALUES ('293', 'Homer', 'homer', 'NE', '68030');
INSERT INTO cities VALUES ('294', 'Hooper', 'hooper', 'NE', '68031');
INSERT INTO cities VALUES ('295', 'Hordville', 'hordville', 'NE', '68846');
INSERT INTO cities VALUES ('296', 'Hubbard', 'hubbard', 'NE', '68741');
INSERT INTO cities VALUES ('297', 'Hubbell', 'hubbell', 'NE', '68375');
INSERT INTO cities VALUES ('298', 'Humboldt', 'humboldt', 'NE', '68376');
INSERT INTO cities VALUES ('299', 'Hyannis', 'hyannis', 'NE', '69350');
INSERT INTO cities VALUES ('300', 'Imperial', 'imperial', 'NE', '69033');
INSERT INTO cities VALUES ('301', 'Inavale', 'inavale', 'NE', '68952');
INSERT INTO cities VALUES ('302', 'Indianola', 'indianola', 'NE', '69034');
INSERT INTO cities VALUES ('303', 'Inland', 'inland', 'NE', '68954');
INSERT INTO cities VALUES ('304', 'Inman', 'inman', 'NE', '68742');
INSERT INTO cities VALUES ('305', 'Ithaca', 'ithaca', 'NE', '68033');
INSERT INTO cities VALUES ('306', 'Jackson', 'jackson', 'NE', '68743');
INSERT INTO cities VALUES ('307', 'Jansen', 'jansen', 'NE', '68377');
INSERT INTO cities VALUES ('308', 'Ohnson', 'ohnson', 'NE', '68378');
INSERT INTO cities VALUES ('309', 'Johnstown', 'johnstown', 'NE', '69214');
INSERT INTO cities VALUES ('310', 'Juniata', 'juniata', 'NE', '68955');
INSERT INTO cities VALUES ('311', 'Kenesaw', 'kenesaw', 'NE', '68956');
INSERT INTO cities VALUES ('312', 'Kennard', 'kennard', 'NE', '68034');
INSERT INTO cities VALUES ('313', 'Keystone', 'keystone', 'NE', '69144');
INSERT INTO cities VALUES ('314', 'Kilgore', 'kilgore', 'NE', '69216');
INSERT INTO cities VALUES ('315', 'Kimball', 'kimball', 'NE', '69145');
INSERT INTO cities VALUES ('316', 'La Vista', 'la-vista', 'NE', '68128');
INSERT INTO cities VALUES ('317', 'Lakeside', 'lakeside', 'NE', '69351');
INSERT INTO cities VALUES ('318', 'Lawrence', 'lawrence', 'NE', '68957');
INSERT INTO cities VALUES ('319', 'Lebanon', 'lebanon', 'NE', '69036');
INSERT INTO cities VALUES ('320', 'Lemoyne', 'lemoyne', 'NE', '69146');
INSERT INTO cities VALUES ('321', 'Leshara', 'leshara', 'NE', '68035');
INSERT INTO cities VALUES ('322', 'Lewellen', 'lewellen', 'NE', '69147');
INSERT INTO cities VALUES ('323', 'Lewiston', 'lewiston', 'NE', '68380');
INSERT INTO cities VALUES ('324', 'Lexington', 'lexington', 'NE', '68850');
INSERT INTO cities VALUES ('325', 'Liberty', 'liberty', 'NE', '68381');
INSERT INTO cities VALUES ('326', 'Linwood', 'linwood', 'NE', '68036');
INSERT INTO cities VALUES ('327', 'Lisco', 'lisco', 'NE', '69148');
INSERT INTO cities VALUES ('328', 'Litchfield', 'litchfield', 'NE', '68852');
INSERT INTO cities VALUES ('329', 'Lodgepole', 'lodgepole', 'NE', '69149');
INSERT INTO cities VALUES ('330', 'Long Pine', 'long-pine', 'NE', '69217');
INSERT INTO cities VALUES ('331', 'Loomis', 'loomis', 'NE', '68958');
INSERT INTO cities VALUES ('332', 'Lorton', 'lorton', 'NE', '68382');
INSERT INTO cities VALUES ('333', 'Louisville', 'louisville', 'NE', '68037');
INSERT INTO cities VALUES ('334', 'Loup City', 'loup-city', 'NE', '68853');
INSERT INTO cities VALUES ('335', 'Lyman', 'lyman', 'NE', '69352');
INSERT INTO cities VALUES ('336', 'Lynch', 'lynch', 'NE', '68746');
INSERT INTO cities VALUES ('337', 'Lyons', 'lyons', 'NE', '68038');
INSERT INTO cities VALUES ('338', 'Macy', 'macy', 'NE', '68039');
INSERT INTO cities VALUES ('339', 'Madrid', 'madrid', 'NE', '69150');
INSERT INTO cities VALUES ('340', 'Magnet', 'magnet', 'NE', '68749');
INSERT INTO cities VALUES ('341', 'Malcolm', 'malcolm', 'NE', '68402');
INSERT INTO cities VALUES ('342', 'Malmo', 'malmo', 'NE', '68040');
INSERT INTO cities VALUES ('343', 'Manley', 'manley', 'NE', '68403');
INSERT INTO cities VALUES ('344', 'Marquette', 'marquette', 'NE', '68854');
INSERT INTO cities VALUES ('345', 'Marsland', 'marsland', 'NE', '69354');
INSERT INTO cities VALUES ('346', 'Martell', 'martell', 'NE', '68404');
INSERT INTO cities VALUES ('347', 'Maskell', 'maskell', 'NE', '68751');
INSERT INTO cities VALUES ('348', 'Mason City', 'mason-city', 'NE', '68855');
INSERT INTO cities VALUES ('349', 'Max', 'max', 'NE', '69037');
INSERT INTO cities VALUES ('350', 'Maxwell', 'maxwell', 'NE', '69151');
INSERT INTO cities VALUES ('351', 'Maywood', 'maywood', 'NE', '69038');
INSERT INTO cities VALUES ('352', 'Mccook', 'mccook', 'NE', '69001');
INSERT INTO cities VALUES ('353', 'Mccool Junction', 'mccool-junction', 'NE', '68401');
INSERT INTO cities VALUES ('354', 'Mcgrew', 'mcgrew', 'NE', '69353');
INSERT INTO cities VALUES ('355', 'Mclean', 'mclean', 'NE', '68747');
INSERT INTO cities VALUES ('356', 'Mead', 'mead', 'NE', '68041');
INSERT INTO cities VALUES ('357', 'Melbeta', 'melbeta', 'NE', '69355');
INSERT INTO cities VALUES ('358', 'Memphis', 'memphis', 'NE', '68042');
INSERT INTO cities VALUES ('359', 'Merna', 'merna', 'NE', '68856');
INSERT INTO cities VALUES ('360', 'Merriman', 'merriman', 'NE', '69218');
INSERT INTO cities VALUES ('361', 'Milford', 'milford', 'NE', '68405');
INSERT INTO cities VALUES ('362', 'Miller', 'miller', 'NE', '68858');
INSERT INTO cities VALUES ('363', 'Milligan', 'milligan', 'NE', '68406');
INSERT INTO cities VALUES ('364', 'Mills', 'mills', 'NE', '68753');
INSERT INTO cities VALUES ('365', 'Minatare', 'minatare', 'NE', '69356');
INSERT INTO cities VALUES ('366', 'Minden', 'minden', 'NE', '68959');
INSERT INTO cities VALUES ('367', 'Mitchell', 'mitchell', 'NE', '69357');
INSERT INTO cities VALUES ('368', 'Monroe', 'monroe', 'NE', '68647');
INSERT INTO cities VALUES ('369', 'Moorefield', 'moorefield', 'NE', '69039');
INSERT INTO cities VALUES ('370', 'Morrill', 'morrill', 'NE', '69358');
INSERT INTO cities VALUES ('371', 'Morse Bluff', 'morse-bluff', 'NE', '68648');
INSERT INTO cities VALUES ('372', 'Mullen', 'mullen', 'NE', '69152');
INSERT INTO cities VALUES ('373', 'Murdock', 'murdock', 'NE', '68407');
INSERT INTO cities VALUES ('374', 'Murray', 'murray', 'NE', '68409');
INSERT INTO cities VALUES ('375', 'Naper', 'naper', 'NE', '68755');
INSERT INTO cities VALUES ('376', 'Naponee', 'naponee', 'NE', '68960');
INSERT INTO cities VALUES ('377', 'Nebraska City', 'nebraska-city', 'NE', '68410');
INSERT INTO cities VALUES ('378', 'Nehawka', 'nehawka', 'NE', '68413');
INSERT INTO cities VALUES ('379', 'Nelson', 'nelson', 'NE', '68961');
INSERT INTO cities VALUES ('380', 'Nemaha', 'nemaha', 'NE', '68414');
INSERT INTO cities VALUES ('381', 'Nenzel', 'nenzel', 'NE', '69219');
INSERT INTO cities VALUES ('382', 'Newport', 'newport', 'NE', '68759');
INSERT INTO cities VALUES ('383', 'Nickerson', 'nickerson', 'NE', '68044');
INSERT INTO cities VALUES ('384', 'Norman', 'norman', 'NE', '68963');
INSERT INTO cities VALUES ('385', 'North Loup', 'north-loup', 'NE', '68859');
INSERT INTO cities VALUES ('386', 'North Platte', 'north-platte', 'NE', '69101');
INSERT INTO cities VALUES ('387', 'Oak', 'oak', 'NE', '68964');
INSERT INTO cities VALUES ('388', 'Oakland', 'oakland', 'NE', '68045');
INSERT INTO cities VALUES ('389', 'Oconto', 'oconto', 'NE', '68860');
INSERT INTO cities VALUES ('390', 'Odell', 'odell', 'NE', '68415');
INSERT INTO cities VALUES ('391', 'Odessa', 'odessa', 'NE', '68861');
INSERT INTO cities VALUES ('392', 'Offutt AFB', 'offutt-afb', 'NE', '68113');
INSERT INTO cities VALUES ('393', 'Ogallala', 'ogallala', 'NE', '69153');
INSERT INTO cities VALUES ('394', 'Ohiowa', 'ohiowa', 'NE', '68416');
INSERT INTO cities VALUES ('395', 'Ong', 'ong', 'NE', '68452');
INSERT INTO cities VALUES ('396', 'Ord', 'ord', 'NE', '68862');
INSERT INTO cities VALUES ('397', 'Orleans', 'orleans', 'NE', '68966');
INSERT INTO cities VALUES ('398', 'Osceola', 'osceola', 'NE', '68651');
INSERT INTO cities VALUES ('399', 'Oshkosh', 'oshkosh', 'NE', '69154');
INSERT INTO cities VALUES ('401', 'Otoe', 'otoe', 'NE', '68417');
INSERT INTO cities VALUES ('402', 'Overton', 'overton', 'NE', '68863');
INSERT INTO cities VALUES ('403', 'Oxford', 'oxford', 'NE', '68967');
INSERT INTO cities VALUES ('404', 'Page', 'page', 'NE', '68766');
INSERT INTO cities VALUES ('405', 'Palisade', 'palisade', 'NE', '69040');
INSERT INTO cities VALUES ('406', 'Palmer', 'palmer', 'NE', '68864');
INSERT INTO cities VALUES ('407', 'Palmyra', 'palmyra', 'NE', '68418');
INSERT INTO cities VALUES ('408', 'Panama', 'panama', 'NE', '68419');
INSERT INTO cities VALUES ('409', 'Papillion', 'papillion', 'NE', '68046');
INSERT INTO cities VALUES ('410', 'Parks', 'parks', 'NE', '69041');
INSERT INTO cities VALUES ('411', 'Pawnee City', 'pawnee-city', 'NE', '68420');
INSERT INTO cities VALUES ('412', 'Paxton', 'paxton', 'NE', '69155');
INSERT INTO cities VALUES ('413', 'Peru', 'peru', 'NE', '68421');
INSERT INTO cities VALUES ('414', 'Phillips', 'phillips', 'NE', '68865');
INSERT INTO cities VALUES ('415', 'Pickrell', 'pickrell', 'NE', '68422');
INSERT INTO cities VALUES ('416', 'Platte Center', 'platte-center', 'NE', '68653');
INSERT INTO cities VALUES ('417', 'Plattsmouth', 'plattsmouth', 'NE', '68048');
INSERT INTO cities VALUES ('418', 'Pleasant Dale', 'pleasant-dale', 'NE', '68423');
INSERT INTO cities VALUES ('419', 'Pleasanton', 'pleasanton', 'NE', '68866');
INSERT INTO cities VALUES ('420', 'Plymouth', 'plymouth', 'NE', '68424');
INSERT INTO cities VALUES ('421', 'Polk', 'polk', 'NE', '68654');
INSERT INTO cities VALUES ('422', 'Potter', 'potter', 'NE', '69156');
INSERT INTO cities VALUES ('423', 'Prague', 'prague', 'NE', '68050');
INSERT INTO cities VALUES ('424', 'Primrose', 'primrose', 'NE', '68655');
INSERT INTO cities VALUES ('425', 'Purdum', 'purdum', 'NE', '69157');
INSERT INTO cities VALUES ('426', 'Ragan', 'ragan', 'NE', '68969');
INSERT INTO cities VALUES ('427', 'Ravenna', 'ravenna', 'NE', '68869');
INSERT INTO cities VALUES ('428', 'Raymond', 'raymond', 'NE', '68428');
INSERT INTO cities VALUES ('429', 'Red Cloud', 'red-cloud', 'NE', '68970');
INSERT INTO cities VALUES ('430', 'Republican City', 'republican-city', 'NE', '68971');
INSERT INTO cities VALUES ('431', 'Reynolds', 'reynolds', 'NE', '68429');
INSERT INTO cities VALUES ('432', 'Richfield', 'richfield', 'NE', '68054');
INSERT INTO cities VALUES ('433', 'Rising City', 'rising-city', 'NE', '68658');
INSERT INTO cities VALUES ('434', 'Riverdale', 'riverdale', 'NE', '68870');
INSERT INTO cities VALUES ('435', 'Riverton', 'riverton', 'NE', '68972');
INSERT INTO cities VALUES ('436', 'Roca', 'roca', 'NE', '68430');
INSERT INTO cities VALUES ('437', 'Rockville', 'rockville', 'NE', '68871');
INSERT INTO cities VALUES ('438', 'Rogers', 'rogers', 'NE', '68659');
INSERT INTO cities VALUES ('439', 'Rosalie', 'rosalie', 'NE', '68055');
INSERT INTO cities VALUES ('440', 'Rose', 'rose', 'NE', '68772');
INSERT INTO cities VALUES ('441', 'Roseland', 'roseland', 'NE', '68973');
INSERT INTO cities VALUES ('442', 'Rulo', 'rulo', 'NE', '68431');
INSERT INTO cities VALUES ('443', 'Rushville', 'rushville', 'NE', '69360');
INSERT INTO cities VALUES ('444', 'Ruskin', 'ruskin', 'NE', '68974');
INSERT INTO cities VALUES ('445', 'Saint Edward', 'saint-edward', 'NE', '68660');
INSERT INTO cities VALUES ('446', 'Saint Helena', 'saint-helena', 'NE', '68774');
INSERT INTO cities VALUES ('447', 'Saint Libory', 'saint-libory', 'NE', '68872');
INSERT INTO cities VALUES ('448', 'Saint Paul', 'saint-paul', 'NE', '68873');
INSERT INTO cities VALUES ('449', 'Salem', 'salem', 'NE', '68433');
INSERT INTO cities VALUES ('450', 'Sargent', 'sargent', 'NE', '68874');
INSERT INTO cities VALUES ('451', 'Saronville', 'saronville', 'NE', '68975');
INSERT INTO cities VALUES ('452', 'Scotia', 'scotia', 'NE', '68875');
INSERT INTO cities VALUES ('453', 'Scottsbluff', 'scottsbluff', 'NE', '69361');
INSERT INTO cities VALUES ('454', 'Seneca', 'seneca', 'NE', '69161');
INSERT INTO cities VALUES ('455', 'Seward', 'seward', 'NE', '68434');
INSERT INTO cities VALUES ('456', 'Shelby', 'shelby', 'NE', '68662');
INSERT INTO cities VALUES ('457', 'Shelton', 'shelton', 'NE', '68876');
INSERT INTO cities VALUES ('458', 'Shickley', 'shickley', 'NE', '68436');
INSERT INTO cities VALUES ('459', 'Shubert', 'shubert', 'NE', '68437');
INSERT INTO cities VALUES ('460', 'Sidney', 'sidney', 'NE', '69160');
INSERT INTO cities VALUES ('462', 'Silver Creek', 'silver-creek', 'NE', '68663');
INSERT INTO cities VALUES ('463', 'Smithfield', 'smithfield', 'NE', '68976');
INSERT INTO cities VALUES ('464', 'Snyder', 'snyder', 'NE', '68664');
INSERT INTO cities VALUES ('465', 'South Bend', 'south-bend', 'NE', '68058');
INSERT INTO cities VALUES ('466', 'South Sioux City', 'south-sioux-city', 'NE', '68776');
INSERT INTO cities VALUES ('467', 'Spalding', 'spalding', 'NE', '68665');
INSERT INTO cities VALUES ('468', 'Sparks', 'sparks', 'NE', '69220');
INSERT INTO cities VALUES ('469', 'Spencer', 'spencer', 'NE', '68777');
INSERT INTO cities VALUES ('470', 'Sprague', 'sprague', 'NE', '68438');
INSERT INTO cities VALUES ('471', 'Springfield', 'springfield', 'NE', '68059');
INSERT INTO cities VALUES ('472', 'Springview', 'springview', 'NE', '68778');
INSERT INTO cities VALUES ('473', 'St Columbans', 'st-columbans', 'NE', '68056');
INSERT INTO cities VALUES ('474', 'Stamford', 'stamford', 'NE', '68977');
INSERT INTO cities VALUES ('475', 'Staplehurst', 'staplehurst', 'NE', '68439');
INSERT INTO cities VALUES ('476', 'Stapleton', 'stapleton', 'NE', '69163');
INSERT INTO cities VALUES ('477', 'Steele City', 'steele-city', 'NE', '68440');
INSERT INTO cities VALUES ('478', 'Steinauer', 'steinauer', 'NE', '68441');
INSERT INTO cities VALUES ('479', 'Stella', 'stella', 'NE', '68442');
INSERT INTO cities VALUES ('480', 'Sterling', 'sterling', 'NE', '68443');
INSERT INTO cities VALUES ('481', 'Stockville', 'stockville', 'NE', '69042');
INSERT INTO cities VALUES ('482', 'Strang', 'strang', 'NE', '68444');
INSERT INTO cities VALUES ('483', 'Stratton', 'stratton', 'NE', '69043');
INSERT INTO cities VALUES ('484', 'Stromsburg', 'stromsburg', 'NE', '68666');
INSERT INTO cities VALUES ('485', 'Stuart', 'stuart', 'NE', '68780');
INSERT INTO cities VALUES ('486', 'Sumner', 'sumner', 'NE', '68878');
INSERT INTO cities VALUES ('487', 'Superior', 'superior', 'NE', '68978');
INSERT INTO cities VALUES ('488', 'Surprise', 'surprise', 'NE', '68667');
INSERT INTO cities VALUES ('489', 'Sutherland', 'sutherland', 'NE', '69165');
INSERT INTO cities VALUES ('490', 'Sutton', 'sutton', 'NE', '68979');
INSERT INTO cities VALUES ('491', 'Swanton', 'swanton', 'NE', '68445');
INSERT INTO cities VALUES ('492', 'Syracuse', 'syracuse', 'NE', '68446');
INSERT INTO cities VALUES ('493', 'Table Rock', 'table-rock', 'NE', '68447');
INSERT INTO cities VALUES ('494', 'Talmage', 'talmage', 'NE', '68448');
INSERT INTO cities VALUES ('495', 'Taylor', 'taylor', 'NE', '68879');
INSERT INTO cities VALUES ('496', 'Tecumseh', 'tecumseh', 'NE', '68450');
INSERT INTO cities VALUES ('497', 'Tekamah', 'tekamah', 'NE', '68061');
INSERT INTO cities VALUES ('498', 'Thedford', 'thedford', 'NE', '69166');
INSERT INTO cities VALUES ('499', 'Thurston', 'thurston', 'NE', '68062');
INSERT INTO cities VALUES ('500', 'Tobias', 'tobias', 'NE', '68453');
INSERT INTO cities VALUES ('501', 'Trenton', 'trenton', 'NE', '69044');
INSERT INTO cities VALUES ('502', 'Trumbull', 'trumbull', 'NE', '68980');
INSERT INTO cities VALUES ('503', 'Tryon', 'tryon', 'NE', '69167');
INSERT INTO cities VALUES ('504', 'Uehling', 'uehling', 'NE', '68063');
INSERT INTO cities VALUES ('505', 'Ulysses', 'ulysses', 'NE', '68669');
INSERT INTO cities VALUES ('506', 'Unadilla', 'unadilla', 'NE', '68454');
INSERT INTO cities VALUES ('507', 'Union', 'union', 'NE', '68455');
INSERT INTO cities VALUES ('508', 'Upland', 'upland', 'NE', '68981');
INSERT INTO cities VALUES ('509', 'Utica', 'utica', 'NE', '68456');
INSERT INTO cities VALUES ('510', 'Valentine', 'valentine', 'NE', '69201');
INSERT INTO cities VALUES ('511', 'Valley', 'valley', 'NE', '68064');
INSERT INTO cities VALUES ('512', 'Valparaiso', 'valparaiso', 'NE', '68065');
INSERT INTO cities VALUES ('513', 'Venango', 'venango', 'NE', '69168');
INSERT INTO cities VALUES ('514', 'Verdon', 'verdon', 'NE', '68457');
INSERT INTO cities VALUES ('515', 'Virginia', 'virginia', 'NE', '68458');
INSERT INTO cities VALUES ('516', 'Waco', 'waco', 'NE', '68460');
INSERT INTO cities VALUES ('517', 'Wallace', 'wallace', 'NE', '69169');
INSERT INTO cities VALUES ('518', 'Walthill', 'walthill', 'NE', '68067');
INSERT INTO cities VALUES ('519', 'Walton', 'walton', 'NE', '68461');
INSERT INTO cities VALUES ('520', 'Washington', 'washington', 'NE', '68068');
INSERT INTO cities VALUES ('521', 'Waterbury', 'waterbury', 'NE', '68785');
INSERT INTO cities VALUES ('522', 'Waterloo', 'waterloo', 'NE', '68069');
INSERT INTO cities VALUES ('523', 'Wauneta', 'wauneta', 'NE', '69045');
INSERT INTO cities VALUES ('524', 'Waverly', 'waverly', 'NE', '68462');
INSERT INTO cities VALUES ('525', 'Weeping Water', 'weeping-water', 'NE', '68463');
INSERT INTO cities VALUES ('526', 'Weissert', 'weissert', 'NE', '68880');
INSERT INTO cities VALUES ('527', 'Wellfleet', 'wellfleet', 'NE', '69170');
INSERT INTO cities VALUES ('528', 'Western', 'western', 'NE', '68464');
INSERT INTO cities VALUES ('529', 'Westerville', 'westerville', 'NE', '68881');
INSERT INTO cities VALUES ('530', 'Weston', 'weston', 'NE', '68070');
INSERT INTO cities VALUES ('531', 'Whiteclay', 'whiteclay', 'NE', '69365');
INSERT INTO cities VALUES ('532', 'Whitman', 'whitman', 'NE', '69366');
INSERT INTO cities VALUES ('533', 'Whitney', 'whitney', 'NE', '69367');
INSERT INTO cities VALUES ('534', 'Wilber', 'wilber', 'NE', '68465');
INSERT INTO cities VALUES ('535', 'Wilcox', 'wilcox', 'NE', '68982');
INSERT INTO cities VALUES ('536', 'Willow Island', 'willow-island', 'NE', '69171');
INSERT INTO cities VALUES ('537', 'Wilsonville', 'wilsonville', 'NE', '69046');
INSERT INTO cities VALUES ('538', 'Winnebago', 'winnebago', 'NE', '68071');
INSERT INTO cities VALUES ('539', 'Winslow', 'winslow', 'NE', '68072');
INSERT INTO cities VALUES ('540', 'Wolbach', 'wolbach', 'NE', '68882');
INSERT INTO cities VALUES ('541', 'Wood Lake', 'wood-lake', 'NE', '69221');
INSERT INTO cities VALUES ('542', 'Wood River', 'wood-river', 'NE', '68883');
INSERT INTO cities VALUES ('543', 'Wymore', 'wymore', 'NE', '68466');
INSERT INTO cities VALUES ('544', 'York', 'york', 'NE', '68467');
INSERT INTO cities VALUES ('545', 'Yutan', 'yutan', 'NE', '68073');


#
# Table structure for table `cmsUsers`
#

DROP TABLE IF EXISTS `cmsUsers`;
CREATE TABLE `cmsUsers` (
  `ID` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `firstName` varchar(100) DEFAULT NULL,
  `lastName` varchar(100) DEFAULT NULL,
  `initials` varchar(3) DEFAULT NULL,
  `usertype` enum('Author','Designer','Coder','Owner','Administrator') DEFAULT NULL,
  `dateLogin` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=39 DEFAULT CHARSET=latin1;

#
# Dumping data for table `cmsUsers`
#

INSERT INTO cmsUsers VALUES ('1', 'admin', 'pci2428', 'Power', 'Pages', 'SDD', 'Administrator', '2015-12-31 14:54:30');
INSERT INTO cmsUsers VALUES ('17', 'angi', 'kruse', 'Angi', 'Kruse', 'ak', 'Administrator', '2015-12-29 18:44:30');
INSERT INTO cmsUsers VALUES ('27', 'karla', 'frey', 'Karla ', 'Frey ', 'kf', 'Administrator', '2015-12-31 13:12:58');
INSERT INTO cmsUsers VALUES ('26', 'brent', 'frey', 'Brent ', 'Frey', 'bf', 'Administrator', '2015-12-31 11:33:08');
INSERT INTO cmsUsers VALUES ('28', 'hailey', 'christiansen', 'Hailey', 'Christiansen', 'HBC', 'Administrator', '2015-12-28 08:17:52');
INSERT INTO cmsUsers VALUES ('29', 'mark', 'peterson ', 'Mark ', 'Peterson', 'mp', 'Administrator', '2015-09-15 14:31:21');
INSERT INTO cmsUsers VALUES ('30', 'tyler', 'leinbaugh', 'Tyler ', 'Leinbaugh', 'tl', 'Administrator', '2015-09-15 14:31:41');
INSERT INTO cmsUsers VALUES ('31', 'sue', 'roach', 'Sue ', 'Roach', 'sr', 'Administrator', '2015-12-23 15:51:24');
INSERT INTO cmsUsers VALUES ('32', 'dwayne ', 'cornett', 'Dwayne', 'Cornett', 'dc ', 'Administrator', '2015-12-23 15:52:09');
INSERT INTO cmsUsers VALUES ('33', 'matthew', 'bilek', 'Matthew ', 'Bilek', 'mb', 'Administrator', '2015-09-15 14:35:30');
INSERT INTO cmsUsers VALUES ('34', 'jons', 'arens ', 'Jons', 'Arens ', 'ja', 'Administrator', '2015-09-15 14:41:06');
INSERT INTO cmsUsers VALUES ('35', 'stephen ', 'halovec', 'Stephen ', 'Havolec ', 'sh', 'Administrator', '2015-09-15 14:44:26');
INSERT INTO cmsUsers VALUES ('36', 'jeff', 'white', 'Jeff ', 'White ', 'jw', 'Administrator', '2015-09-15 14:47:46');
INSERT INTO cmsUsers VALUES ('37', 'mike', 'funkhouser', 'Mike ', 'Funkhouser', 'mf', 'Administrator', '2015-09-15 14:48:39');
INSERT INTO cmsUsers VALUES ('38', 'jerry', 'Pospisil', 'Jerry ', 'Pospisil', 'jp', 'Administrator', '2015-09-23 09:56:53');


#
# Table structure for table `customerInfo`
#

DROP TABLE IF EXISTS `customerInfo`;
CREATE TABLE `customerInfo` (
  `custID` int(11) NOT NULL AUTO_INCREMENT,
  `storeID` varchar(10) DEFAULT NULL,
  `custFName` varchar(40) DEFAULT NULL,
  `custLName` varchar(40) DEFAULT NULL,
  `custBillAdd` varchar(50) DEFAULT NULL,
  `custSecAdd` varchar(100) DEFAULT NULL,
  `custCity` varchar(80) DEFAULT NULL,
  `custState` varchar(40) DEFAULT NULL,
  `custZip` varchar(40) DEFAULT NULL,
  `custPhone` varchar(40) DEFAULT NULL,
  `custFax` varchar(40) NOT NULL,
  `custMobile` varchar(40) DEFAULT NULL,
  `custWork` varchar(40) DEFAULT NULL,
  `custEmail` varchar(40) DEFAULT NULL,
  `custEmail2` varchar(40) DEFAULT NULL,
  `custNotes` text,
  `custRank` varchar(10) DEFAULT NULL,
  `custPrimaryF` varchar(100) DEFAULT NULL,
  `custPrimPhone` varchar(100) DEFAULT NULL,
  `custComp` varchar(150) DEFAULT NULL,
  `referralType` varchar(250) DEFAULT NULL,
  `dateCreated` date NOT NULL,
  PRIMARY KEY (`custID`)
) ENGINE=MyISAM AUTO_INCREMENT=324 DEFAULT CHARSET=latin1;

#
# Dumping data for table `customerInfo`
#

INSERT INTO customerInfo VALUES ('3', '72', 'John', 'Avidano', '3006 N. Highway 35', '', 'Norfolk', 'Nebraska', '68701', '(402) 882-0025', '', '(402) 882-0025', '(402) 851-2428', 'JohnAvidano@Gmail.com', 'Info@Powerpgs.com', 'Large front windows, Brent indicated there was stucco would be a very difficult job.', '1', 'Amanda Avidano', '(402) 750-7142', 'Amanda Inc.', '106 Kix - Radio Ad', '2015-08-19');
INSERT INTO customerInfo VALUES ('4', '', 'Angi', 'Kruse', '1302 Hillview Dr', '', 'Norfolk', 'Nebraska', '68701', '402-379-2238', '', '402-992-1947', '', 'akruse@q.com', '', '', '5', 'Angi ', '', '', '', '0000-00-00');
INSERT INTO customerInfo VALUES ('6', '72', 'Tim', 'Davy', '1217 Koenigstein ', '', 'Norfolk', 'Nebraska', '68701', '402-316-8282', '', '841-7632', '', '', '', '', '4', '', '', '', 'Norfolk Daily News - Ad Square', '0000-00-00');
INSERT INTO customerInfo VALUES ('31', '72', 'Don', 'Wacker', '305 W. Herman', '305 W. Herman', 'Battle Creek', 'Nebraska', '68715', '402-675-3595', '', '', '', '', '', '', '1', '', '', '', '', '2015-09-23');
INSERT INTO customerInfo VALUES ('7', '112', 'Tyler and Emily ', 'Leinbaugh', '4501 Cherrywood Lane', '', 'Sioux City', 'Iowa', '51106', '712-223-4198', '', '712-223-4198', '', 'tyler@windowworldnen.com', '', '', '1', 'Tyler ', '712-223-4198', '', '106 Kix - Radio Ad', '2015-09-03');
INSERT INTO customerInfo VALUES ('9', '72', 'Jon', 'Arens', '302 S. Madison ', '', 'Hartington', 'Nebraska', '68739', '605-661-5704', '', '', '', 'jarens@hartel.net', '', '', '5', 'Jon Arens ', '605-661-5704', '', 'Power Pages - ', '2015-09-15');
INSERT INTO customerInfo VALUES ('10', '72', 'James', 'Bahm', '303 Aspen Dr.', '', 'Norfolk', 'Nebraska', '68701', '371-8775', '', '', '', '', '', '', '3', 'James Bahm', '371-8775', '', 'Power Pages - ', '2015-09-15');
INSERT INTO customerInfo VALUES ('11', '72', 'Scott', 'DeBoer', '207 W. Norfolk Ave', '', 'Norfolk', 'Nebraska', '68701', '(402) 851-2428', '', '', '', 'Info@PowerPgs.com', '', '', '5', 'Scott DeBoer', '', 'Power Pages', '', '2015-09-15');
INSERT INTO customerInfo VALUES ('12', '72', 'Jon', 'Kleinschmidt', '2401 Valli Hi Road', '', 'Norfolk', 'Nebraska', '68701', '402 640-7262', '', '', '', '', '', 'DIY', '3', 'Jon ', '402-640-7262', '', 'Power Pages - ', '2015-09-16');
INSERT INTO customerInfo VALUES ('13', '72', 'Molly', 'Navritil', '100 W 4th St.', '', 'Tilden', 'Nebraska', '68758', '402-651-3370', '', '', '', '', '', 'estimate', '1', '', '', '', '', '2015-09-16');
INSERT INTO customerInfo VALUES ('14', '72', 'Battle Creek Coop', '', '86411 Hwy 121', 'PO Box 10     Battle Creek, NE', 'Osmond', 'Nebraska', '', '748-3371', '', '', '', '', '', '', '1', '', '', 'Battle Creek Coop', '', '2015-09-17');
INSERT INTO customerInfo VALUES ('16', '72', 'Patty', 'Score', '', 'PO Box 268    ', 'Saint Edward', 'Nebraska', '68661', '913-645-7070', '', '', '', '', '', '', '3', '', '', '', '', '2015-09-21');
INSERT INTO customerInfo VALUES ('17', '72', 'Maxine', 'Birkel', '1456 N. 3rd St.', '', 'David City', 'Nebraska', '68632', '402-367-3459', '', '', '', '', '', '', '3', '', '', '', '', '2015-09-21');
INSERT INTO customerInfo VALUES ('18', '72', 'Greg & Ellen ', 'Thiele', '2614 Westside Dr.', '', 'Norfolk', 'Nebraska', '68701', '402-649-1210', '', '', '', '', '', '', '1', '', '', '', '', '2015-09-21');
INSERT INTO customerInfo VALUES ('19', '72', 'Theresa & Steve', 'Perry', '83658 556th Ave', '83658 556th Ave', 'Norfolk', 'Nebraska', '68701', '402-841-3996', '', '', '', '', '', '', '3', '', '', '', '', '2015-09-21');
INSERT INTO customerInfo VALUES ('20', '72', 'Doris', 'Kocina', '353 Platte St.', '', 'Platte Center', 'Nebraska', '68653', '402-276-3945', '', '', '', '', '', '', '3', '', '', '', '', '2015-09-21');
INSERT INTO customerInfo VALUES ('21', '72', 'Josie', 'Renze', '3960 Lost Creek Dr. ', '', 'Columbus', 'Nebraska', '68601', '402-606-9516', '', '', '', '', '', '', '3', '', '', '', '', '2015-09-22');
INSERT INTO customerInfo VALUES ('22', '72', 'Kevin', 'Gray', '314 Forest Dr', '', 'Norfolk', 'Nebraska', '68701', '402-992-8634', '', '', '', '', '', '', '3', '', '', '', '', '2015-09-22');
INSERT INTO customerInfo VALUES ('23', '72', 'Josh', 'Kruger', '111 Park St', '111 Park St.', 'Madison', 'Nebraska', '68748', '402-841-4392', '', '', '', '', '', '', '1', '', '', '', '', '2015-09-22');
INSERT INTO customerInfo VALUES ('24', '72', 'Kevin', 'Ingemansen', '2918 14th St', '', 'Columbus', 'Nebraska', '68601', '402-564-5568', '', '', '', '', '', '', '1', '', '', '', '', '2015-09-22');
INSERT INTO customerInfo VALUES ('25', '72', 'Karol', 'Michael', '601 Neuer St', '601 Neuer St', 'Clearwater', 'Nebraska', '68726', '402-485-2813', '', '402-750-0064', '', '', '', '', '3', '', '', '', '', '2015-09-22');
INSERT INTO customerInfo VALUES ('30', '72', 'Leland', 'Wilson', '831 S. 8th St.', '', 'Norfolk', 'Nebraska', '68701', '402-379-3865', '', '', '', '', '', '', '1', '', '', '', '', '2015-09-23');
INSERT INTO customerInfo VALUES ('26', '72', 'Kirk & Carol ', 'Griffith', '607 S.Boxelder', '607 S. Boxelder', 'Norfolk', 'Nebraska', '68701', '402-640-7770', '', '', '', '', '', '', '5', '', '', '', '', '2015-09-22');
INSERT INTO customerInfo VALUES ('27', '72', 'JEREMY', 'SANNE', '505 DIBBLE ST', '', 'Clearwater', 'Nebraska', '68726', '4028877286', '', '', '4024854646', 'SANNE_SERVICE@YAHOO.COM', '', '', '1', '', '', '', '', '2015-09-22');
INSERT INTO customerInfo VALUES ('28', '72', 'John & Peg', 'Beemer', '84826 561st Ave', '', 'Hoskins', 'Nebraska', '68740', '402-640-1618', '', '', '', '', '', '', '3', '', '', '', '', '2015-09-22');
INSERT INTO customerInfo VALUES ('29', '72', 'Bruce', 'Brester', '1440 Eagle Ridge Circle', '', 'Pierce', 'Nebraska', '68767', '402-649-5430', '', '', '', 'bresterb@midwestbank.com', '', '', '1', '', '', '', '', '2015-09-22');
INSERT INTO customerInfo VALUES ('32', '72', 'Jack', 'Sauser', '511 W. Wayne St.', '', 'Randolph', 'Nebraska', '68771', '402-485-2813', '', '', '', '', '', '', '1', '', '', '', '', '2015-09-23');
INSERT INTO customerInfo VALUES ('33', '72', 'Carol', 'Schlisman', '1105 Charolais', '', 'Norfolk', 'Nebraska', '68701', '402-440-2822', '', '', '', '', '', '', '3', '', '', '', '', '2015-09-23');
INSERT INTO customerInfo VALUES ('34', '72', 'Justin & Carla', 'Wilkinson', '306 Oak St.', '', 'Tilden', 'Nebraska', '68781', 'Justin: 841-9204', '', 'Carla: 841-9267', '', '', '', '', '1', '', '', '', '', '2015-09-23');
INSERT INTO customerInfo VALUES ('35', '72', 'Geraldine', 'Timperley', '708 S. 8th St.', '', 'Norfolk', 'Nebraska', '68701', '371-3144', '', '', '', '', '', '', '1', '', '', '', '', '2015-09-23');
INSERT INTO customerInfo VALUES ('36', '72', 'Mark', 'Ramaeker', '34211 430th St. ', '34211 430th St.', 'Humphrey', 'Nebraska', '68642', '402-920-0099', '', '', '', '', '', '', '3', '', '', '', '', '2015-09-24');
INSERT INTO customerInfo VALUES ('37', '72', 'Richard', 'Stelling', '51303 861st Rd', '51303 861st Rd', 'Orchard', 'Nebraska', '68764', '', '', '402-929-0335', '', '', '', '', '1', '', '', '', '', '2015-09-24');
INSERT INTO customerInfo VALUES ('38', '72', 'Michael', 'Dusek', '84459  Hwy 35', '', 'Norfolk', 'Nebraska', '68701', '402-841-0625', '', '', '', '', '', '', '1', '', '', '', '', '2015-09-24');
INSERT INTO customerInfo VALUES ('39', '72', 'Patty', 'Thiele', '85043 513th Avenue', '', 'Clearwater', 'Nebraska', '68726', '(402) 640-3335', '', '', '', '', '', '', '3', '', '', '', '', '2015-09-24');
INSERT INTO customerInfo VALUES ('40', '72', 'Francisco', 'Medina', '509 E. 22nd St.', '', 'Schuyler', 'Nebraska', '68661', '615-4089', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-01');
INSERT INTO customerInfo VALUES ('41', '72', 'Jessica', 'Froehner', '2675 E. 14th Ave', '', 'Columbus', 'Nebraska', '68601', '562-8735', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-01');
INSERT INTO customerInfo VALUES ('42', '72', 'Doug', 'Storm', '3008 295th Ave', '', 'Albion', 'Nebraska', '68620', '678-3444', '', '', '', '', '', '', '1', '', '', '', '', '2015-10-01');
INSERT INTO customerInfo VALUES ('43', '72', 'Jordan ', 'Turpen', '669 11th Ave', '', 'Columbus', 'Nebraska', '68601', '599-0703', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-01');
INSERT INTO customerInfo VALUES ('44', '72', 'Laura', 'McGuinnis', '56 Lakewood Dr.', '', 'Columbus', 'Nebraska', '68601', '699-2519', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-01');
INSERT INTO customerInfo VALUES ('45', '72', 'Jim & Joyce', 'Kuchar', '3405  Rolling Hills Drive', '', 'Norfolk', 'Nebraska', '68701', '371-0355', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-01');
INSERT INTO customerInfo VALUES ('46', '72', 'Jayson', 'Vice', '1216 N. Lincoln Ave', '', 'York', 'Nebraska', '68467', '363-8308', '', '710-1635', '', '', '', '', '3', '', '', '', '', '2015-10-01');
INSERT INTO customerInfo VALUES ('47', '72', 'Ruby', 'Jurgensen', '2161 412th Rd', 'Wisner', 'Wisner', 'Nebraska', '68791', '529-6576', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-02');
INSERT INTO customerInfo VALUES ('48', '72', 'Kathy', 'Love', '', '', 'Norfolk', 'Nebraska', '68701', '', '', '', '', '', '', '', '5', '', '', 'Custom Heating', '', '2015-10-02');
INSERT INTO customerInfo VALUES ('49', '72', 'Kevin ', 'Jarecki', '166 D St', '', 'Platte Center', 'Nebraska', '68653', '4022705935', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-02');
INSERT INTO customerInfo VALUES ('50', '72', 'Brad', 'Reisdorf', '', '14022 X Rd', 'Shelby', 'Nebraska', '68662', '910-2064', '', '', '', '', '', '', '1', '', '', '', '', '2015-10-02');
INSERT INTO customerInfo VALUES ('51', '72', 'Keith', 'Dostal', '57479 823 Rd', '', 'Howells', 'Nebraska', '68641', '750-8219', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-02');
INSERT INTO customerInfo VALUES ('52', '72', 'john ', 'gorrell', '407 n 28th', '', 'Norfolk', 'Nebraska', '68701', '4027501347', '', '', '', '', '', '', '1', '', '', '', '', '2015-10-02');
INSERT INTO customerInfo VALUES ('53', '72', 'Richard', 'Stelling', '', '', 'Abie', 'Nebraska', '', '4029920335', '', '', '', '', '', '', '1', '', '', '', '', '2015-10-05');
INSERT INTO customerInfo VALUES ('54', '72', 'Dave & Jennifer', 'Timmerman', '904 Lovely Lane', '', 'Norfolk', 'Nebraska', '68701', '402-750-6962', '', '', '', '', '', '', '4', '', '', '', '', '2015-10-05');
INSERT INTO customerInfo VALUES ('55', '72', 'Jose', 'Parra', '405 N St.      Apt: 15', '', 'Neligh', 'Nebraska', '68756', '640-0429', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-05');
INSERT INTO customerInfo VALUES ('56', '72', 'Trudy', 'Mosel ', '207 North Elm', '', 'Plainview', 'Nebraska', '68769', '402-841-1041', '', '', '', '', '', 'Sun Porch ', '1', '', '', '', '', '2015-10-05');
INSERT INTO customerInfo VALUES ('57', '72', 'Steve', 'McClure', '', '105 Morton Rd. Columbus, NE ', 'Columbus', 'Nebraska', '68601', '402-563-1803', '', '', '', '', '', 'Rental: 2315 22nd St.', '1', '', '', '', '', '2015-10-05');
INSERT INTO customerInfo VALUES ('58', '72', 'Rugosa LLC', '', 'P.O. BOX 1833', '', 'Norfolk', 'Nebraska', '68701', '', '', '', '', '', '', '', '5', 'SHELLEE  HONICEK', '', 'RUGOSA LLC', '', '2015-10-05');
INSERT INTO customerInfo VALUES ('59', '72', 'Andy', 'Starman', '848th Rd', '', 'Elgin', 'Nebraska', '68636', '402-843-6521', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-05');
INSERT INTO customerInfo VALUES ('60', '72', 'Crystal', 'Foltz', '40963 280th ', '', 'Humphrey', 'Nebraska', '68642', '402-920-2339', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-05');
INSERT INTO customerInfo VALUES ('61', '72', 'Shelly', 'Schnelle', '1713 RD 9', '', 'Clarkson', 'Nebraska', '68629', '402-942-2252', '', '', '', '', '', '', '4', '', '', '', '', '2015-10-05');
INSERT INTO customerInfo VALUES ('62', '72', 'Richard', 'Grenz', '705 Linden Lane', '', 'Norfolk', 'Nebraska', '68701', '402-371-8284', '', '', '', '', '', 'WANTS TO INSTALL (1 window) IN APRIL.', '3', '', '', '', '', '2015-10-05');
INSERT INTO customerInfo VALUES ('63', '72', 'Richard ', 'Buckendahl', '55477 834th Rd', '', 'Norfolk', 'Nebraska', '68701', '371-6640', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-05');
INSERT INTO customerInfo VALUES ('64', '72', 'Angela', 'Petersen', '552755 Hwy 20', '', 'Brunswick', 'Nebraska', '68720', '402-649-0929', '', '', '', 'angiepetersen73@plvwtelco.net', '', '1/4 mile east of brunswick turn  north side', '3', '', '', '', '', '2015-10-06');
INSERT INTO customerInfo VALUES ('65', '72', 'Scott', 'Rutten', '1205 8th St.', '', 'Stanton', 'Nebraska', '68779', '402-649-4436', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-06');
INSERT INTO customerInfo VALUES ('195', '72', 'Audrey', 'Forney', '8 Clear Lake Acres', '', 'Columbus', 'Nebraska', '68601', '402-270-7720', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-03');
INSERT INTO customerInfo VALUES ('66', '72', 'MANETTE', 'RICHARDSON', '83949 531ST AVE', '', 'Tilden', 'Nebraska', '68781', '402-368-2928', '', '', '', '', '', 'FROM PDQ- 3 MILES SOUTH ON HWY 45 TO 840TH ROAD - 3 WEST ON 840TH ROAD TO 531ST AVE - 1/2 SOUTH', '1', '', '', '', '', '2015-10-07');
INSERT INTO customerInfo VALUES ('67', '72', 'Paul & Deb', 'Allpress', '3404 Prospect', '', 'Norfolk', 'Nebraska', '68701', '402-371-9192', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-08');
INSERT INTO customerInfo VALUES ('68', '72', 'kevin', 'ingemansen', '2918 14th st', '', 'Columbus', 'Nebraska', '68601', '402-564-5568', '', '', '', '', '', '', '1', '', '', '', '', '2015-10-08');
INSERT INTO customerInfo VALUES ('69', '72', 'Barb ', 'Douglas', '216 N. 5th St.', '', 'Pierce', 'Nebraska', '68767', '', '', '', '', '', '', '', '1', '', '', '', '', '2015-10-08');
INSERT INTO customerInfo VALUES ('70', '72', 'Heather & Hans', 'Goeschel', '955 N. 9th St', '', 'David City', 'Nebraska', '68632', '367-3024', '', '', '', '', '', '', '1', '', '', '', '', '2015-10-08');
INSERT INTO customerInfo VALUES ('71', '72', 'Janelle ', 'Fischer', '312 N. Main St.', 'PO Box 216', 'Leigh', 'Nebraska', '68643', '487-2737', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-08');
INSERT INTO customerInfo VALUES ('72', '72', 'Golden Living Center', '', '2855 40th Ave', '', 'Columbus', 'Nebraska', '68601', '', '', '', '', '', '', '', '3', 'Terry', '402-750-8799', 'Golden Living Center', '', '2015-10-08');
INSERT INTO customerInfo VALUES ('73', '72', 'Bob ', 'Taylor', '3903 14th St.', '', 'Columbus', 'Nebraska', '68601', '276-3030', '', '', '', '', '', '', '1', '', '', '', '', '2015-10-08');
INSERT INTO customerInfo VALUES ('74', '72', 'Everlasting Love Church', '', '4714 27th St.', '', 'Columbus', 'Nebraska', '68601', '', '', '', '', '', '', '', '1', 'Pat Cool', '402-270-1744', 'Everlasting Love Church', '', '2015-10-08');
INSERT INTO customerInfo VALUES ('75', '72', 'Santiago', 'Vasquez', '3520 27th St', '', 'Columbus', 'Nebraska', '68601', '276-6049', '', '', '', '', '', '', '1', '', '', '', '', '2015-10-08');
INSERT INTO customerInfo VALUES ('76', '72', 'Patty', 'Sliva', '701 Main St-Humphrey', '', 'Humphrey', 'Nebraska', '68642', '923-1723', '', '', '', '', '', '', '1', '', '', '', '', '2015-10-09');
INSERT INTO customerInfo VALUES ('77', '72', 'Lanny & Jeannie', 'Young', '1055 S. 4th St.-Albion', '', 'Albion', 'Nebraska', '', '395-6329', '', '', '', '', '', '', '1', '', '', '', '', '2015-10-09');
INSERT INTO customerInfo VALUES ('78', '72', 'Tim &  Michelle', 'Brabec', '56826 825 Rd-Clarkson', '', 'Clarkson', 'Nebraska', '68629', '402-892-3461', '', '', '', '', '', '', '1', '', '', '', '', '2015-10-09');
INSERT INTO customerInfo VALUES ('79', '72', 'Larry', 'Krohn', '86602 545 RD', '', 'Osmond', 'Nebraska', '68765', '402-748-3676', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-09');
INSERT INTO customerInfo VALUES ('80', '72', 'Gena', 'Luhr-Puls', '1009 1st Ave', '', 'Wayne', 'Nebraska', '68787', '375-4936', '', '', '', '', '', '', '1', '', '', '', '', '2015-10-09');
INSERT INTO customerInfo VALUES ('81', '72', 'mary', 'erb', '531 Colfax', '', 'West Point', 'Nebraska', '68788', '4023804204', '', '', '', '', '', 'referred by son DAVE ERB
466 SOUTH COLFAX
WEST POINT, NE 68788', '1', '', '', '', '', '2015-10-09');
INSERT INTO customerInfo VALUES ('82', '72', 'Larry ', 'Petz', '618 S Oak ', '', 'West Point', 'Nebraska', '68788', '402-372-3915', '', '', '', '', '', '', '1', '', '', '', '', '2015-10-09');
INSERT INTO customerInfo VALUES ('83', '72', 'Al', 'Jenkins', '406 7th St. ', '', 'Stanton', 'Nebraska', '68779', '439-2555', '', '841-7453', '', '', '', '', '3', '', '', '', '', '2015-10-12');
INSERT INTO customerInfo VALUES ('84', '72', 'Michael', 'Kuester', '2607 W. Prospect', '', 'Norfolk', 'Nebraska', '68701', '402-640-3597', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-12');
INSERT INTO customerInfo VALUES ('85', '72', 'Rich & Theresa', 'Anderson', '3058 Maple St.', '', 'Emerson', 'Nebraska', '68733', '402-695-2471', '', 'Theresa Cell: 402-369-0119', '', '', '', '', '5', '', '', '', '', '2015-10-12');
INSERT INTO customerInfo VALUES ('86', '72', 'Dave', 'Carter', '701 Northdale Dr.', '', 'Norfolk', 'Nebraska', '68701', '314-3526', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-12');
INSERT INTO customerInfo VALUES ('87', '72', 'Cory', 'Schmidt', '1108 Rose Ln', '', 'Norfolk', 'Nebraska', '68701', '402-649-8350', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-12');
INSERT INTO customerInfo VALUES ('88', '72', 'DERRICK', 'NELSON', '201 SHETLAND PATH', '', 'Norfolk', 'Nebraska', '68701', '402-851-0349', '', '750-5933', '', '', '', '', '1', '', '', '', '', '2015-10-12');
INSERT INTO customerInfo VALUES ('89', '72', 'Donna ', 'Ingoglia ', '1501 Syracuse', '', 'Norfolk', 'Nebraska', '68701', '402-360-3208', '', '', '', '', '', '', '5', '', '', '', '', '2015-10-12');
INSERT INTO customerInfo VALUES ('90', '72', 'Chad', 'Jochum', '1703 Sheridan Dr.', '', 'Norfolk', 'Nebraska', '68701', '640-6933', '', '402-637-3010', '', '', '', '', '3', '', '', '', '', '2015-10-12');
INSERT INTO customerInfo VALUES ('91', '72', 'Ken  & Eileen', 'Petit', '610 W. 6th St.', '', 'Wakefield', 'Nebraska', '68784', '287-2362', '', '369-3513', '', '', '', 'Wife Usually Home during the day.
Referred by Son: Bill Miller(Newman Grove) 
', '5', '', '', '', '', '2015-10-13');
INSERT INTO customerInfo VALUES ('92', '72', 'Merry', 'Braun', '300 Aspen Dr.', '', 'Norfolk', 'Nebraska', '68701', '649-7326', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-13');
INSERT INTO customerInfo VALUES ('93', '72', 'Dennis & Mary', 'Mrsny', '833735 556th Ave', '', 'Norfolk', 'Nebraska', '68701', '371-7914', '', '640-4922', '', '', '', '', '3', '', '', '', '', '2015-10-13');
INSERT INTO customerInfo VALUES ('94', '72', 'Dennis & Mary', 'Mrsny', '833735 556th Ave', '', 'Norfolk', 'Nebraska', '68701', '371-7914', '', '640-4922', '', '', '', '', '3', '', '', '', '', '2015-10-13');
INSERT INTO customerInfo VALUES ('95', '72', 'Paul & Shannon', 'Filsinger', '310 Brentwood Dr.', '', 'Norfolk', 'Nebraska', '68701', '379-3911', '', '', '', '', '', '', '1', '', '', '', '', '2015-10-14');
INSERT INTO customerInfo VALUES ('96', '72', 'Brian', 'Anderson', '305 N. Main St.', '', 'Pilger', 'Nebraska', '68768', '369-0033', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-14');
INSERT INTO customerInfo VALUES ('98', '72', 'Danielle ', 'Kubes', '306 W Norfolk Ave', '', 'Norfolk', 'Nebraska', '68701', '402649-3075', '', '', '', 'djkubes@gmail.com', '', '', '5', '', '', '', '', '2015-10-15');
INSERT INTO customerInfo VALUES ('99', '72', 'Tony ', 'Hoffman', '1300 Galeta Unit C', '', 'Norfolk', 'Nebraska', '68701', '649-1956', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-16');
INSERT INTO customerInfo VALUES ('100', '72', 'Bob', 'Hering', '303 S. Boyer', '', 'Battle Creek', 'Nebraska', '68715', '706-564-6936', '', '', '', '', '', '', '5', '', '', '', '', '2015-10-16');
INSERT INTO customerInfo VALUES ('101', '72', 'Looking Glass Methodist Church', '', '430 St               47893 400th St-Lindsay', '', 'Newman Grove', 'Nebraska', '68758', '', '', '', '', '', '', '', '3', 'Charles Borg', '428-4975        920-1783', 'Looking Glass Methodist Church', '', '2015-10-16');
INSERT INTO customerInfo VALUES ('102', '72', 'Rita & John', 'Hoebbing', '1869 W. Calle Columbo', '', 'Columbus', 'Nebraska', '68601', '563-2238', '', '270-3146', '', '', '', '', '1', '', '', '', '', '2015-10-16');
INSERT INTO customerInfo VALUES ('103', '72', 'Dean ', 'Korus', '203 S. 4th St.', '', 'Humphrey', 'Nebraska', '68642', '910-8842', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-16');
INSERT INTO customerInfo VALUES ('104', '72', 'Dean ', 'Korus', '203 S. 4th St.', '', 'Humphrey', 'Nebraska', '68642', '910-8842', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-16');
INSERT INTO customerInfo VALUES ('105', '72', 'Tracy ', 'Cook', '3302 Mach 1 ', '', 'Norfolk', 'Nebraska', '68701', '402-316-7710', '', '402-860-5780', '', '', '', 'broken patio door estimate for new scheduled for Jerry on Oct 19th at 930am ', '3', '', '', '', '', '2015-10-16');
INSERT INTO customerInfo VALUES ('106', '72', 'Mary', 'Rocheford', '119 North 5th st', '', 'Howells', 'Nebraska', '68641', '', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-19');
INSERT INTO customerInfo VALUES ('107', '72', 'Mick & Kim', 'Vogt', '505 Kent St.', '', 'Madison', 'Nebraska', '68748', '454-2930', '', '', '', '', '', '', '1', '', '', '', '', '2015-10-19');
INSERT INTO customerInfo VALUES ('108', '72', 'Chris & Jenn', 'Geidner', '808 Nebraska Ave', '', 'Wayne', 'Nebraska', '68787', '402-375-8487', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-19');
INSERT INTO customerInfo VALUES ('109', '72', 'Gary', 'Boehle', '', '1120 Douglas St-Wayne NE 68787', 'Abie', 'Nebraska', '', '402-375-2511', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-19');
INSERT INTO customerInfo VALUES ('110', '72', 'Travis ', 'Wemhoff', '405 Ash St', '', 'Creston', 'Nebraska', '', '920-0870', '', '', '', '', '', '', '1', '', '', '', '', '2015-10-19');
INSERT INTO customerInfo VALUES ('111', '72', 'Andrea', 'Rodriguez', '413 E. Nebraska Ave', '', 'Norfolk', 'Nebraska', '68701', '750-9676', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-19');
INSERT INTO customerInfo VALUES ('112', '72', 'Lance', 'Novacek', '1903 Carmel Dr.', '', 'Norfolk', 'Nebraska', '68701', '308-750-4245', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-20');
INSERT INTO customerInfo VALUES ('113', '72', 'KARLA', 'FREY', '85824 519TH AVE.', '', 'Clearwater', 'Nebraska', '68726', '', '', '', '', '', '', '', '1', '', '', '', '', '2015-10-20');
INSERT INTO customerInfo VALUES ('114', '72', 'Frank', 'Morrison', '85824 519th Ave.', '', 'Clearwater', 'Nebraska', '68726', '402-929-0387', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-20');
INSERT INTO customerInfo VALUES ('115', '72', 'Katrina', 'Lange', '300 N. 3rd St.', '', 'Ulysses', 'Nebraska', '68669', '310-2131', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-20');
INSERT INTO customerInfo VALUES ('116', '72', 'Karin', 'Phillips', '4019 13th St.', '', 'Columbus', 'Nebraska', '68601', '402-276-1154', '', '', '', '', '', '', '1', '', '', '', '', '2015-10-20');
INSERT INTO customerInfo VALUES ('117', '72', 'Curt', 'Nielsen', '1811 Imperial Rd', '', 'Norfolk', 'Nebraska', '68701', '', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-20');
INSERT INTO customerInfo VALUES ('118', '72', 'DJ', 'Denn', '3406 Foxridge', '', 'Norfolk', 'Nebraska', '68701', '402-371-2127', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-20');
INSERT INTO customerInfo VALUES ('119', '73', 'TERRY', '', '2855 40TH AVE.', '', 'Columbus', 'Nebraska', '68601', '402-750-8799', '', '', '', '', '', '', '1', '', '', 'GOLDEN LIVING CENTER', '', '2015-10-20');
INSERT INTO customerInfo VALUES ('120', '72', 'Susan', 'Askew', '700 Linden Lane', '', 'Norfolk', 'Nebraska', '68701', '992-8109', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-20');
INSERT INTO customerInfo VALUES ('121', '72', 'Sandra Bruns', 'Joel Kratke', '57985 858 Rd', '', 'Wakefield', 'Nebraska', '68784', '402-369-1041', '', '402-369-2290', '', '', '', '', '3', '', '', '', '', '2015-10-20');
INSERT INTO customerInfo VALUES ('122', '72', 'Willard', 'Hart', '504 E. Maple', '', 'Norfolk', 'Nebraska', '68701', '402-371-5599', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-20');
INSERT INTO customerInfo VALUES ('123', '72', 'Sara ', 'McClary', '205 S. Birch', '', 'Norfolk', 'Nebraska', '68701', '841-3233', '', '', '371-5300', '', '', '', '3', '', '', '', '', '2015-10-20');
INSERT INTO customerInfo VALUES ('124', '72', 'Larry ', 'Sohler', '320 Sherwood Lane', '', 'Norfolk', 'Nebraska', '68701', '4029927998', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-20');
INSERT INTO customerInfo VALUES ('125', '72', 'Mike', 'Hines', '303 Trailridge ', '', 'Norfolk', 'Nebraska', '68701', '4029923370', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-20');
INSERT INTO customerInfo VALUES ('126', '72', 'Kelly', 'Muchmore', '1531 7th St', '', 'Duncan', 'Nebraska', '68634', '402-270-9951', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-20');
INSERT INTO customerInfo VALUES ('127', '72', 'Gilbert', 'Grimm', '1201 N 25th', '', 'Norfolk', 'Nebraska', '68701', '4023710749', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-20');
INSERT INTO customerInfo VALUES ('128', '72', 'Robert and Lori', 'Uecker', '84378 541st Ave', '', 'Meadow Grove', 'Nebraska', '68752', '4026342365', '', '4027509485', '', '', '', '', '5', '', '', '', '', '2015-10-20');
INSERT INTO customerInfo VALUES ('129', '72', 'gilbert', 'grimm', '1201 north 25th', '', 'Norfolk', 'Nebraska', '68701', '402-371-0749', '', '', '', '', '', '', '1', '', '', '', '', '2015-10-21');
INSERT INTO customerInfo VALUES ('130', '72', 'Nancy', 'Karmann', '2607 E. 38th St. ', '', 'Columbus', 'Nebraska', '68601', '276-5885 Melody Hataway', '', '276-5799 Dave Hataway', '', '', '', '', '1', '', '', '', '', '2015-10-21');
INSERT INTO customerInfo VALUES ('132', '72', 'Neil', 'McClary', '54049 841st Rd', '', 'Meadow Grove', 'Nebraska', '68752', '4026342969', '', '', '', '', '', 'curve before meadow grove by bridge south to 841st rd west 1st place 1/2 mile northside ', '3', '', '', '', '', '2015-10-21');
INSERT INTO customerInfo VALUES ('133', '72', 'dean', 'brewer', '109 ash st', '', 'Lindsay', 'Nebraska', '68644', '402-920-1967', '', '402-920-1186', '', '', '', '', '1', '', '', '', '', '2015-10-22');
INSERT INTO customerInfo VALUES ('134', '72', 'Ryan', 'Baumgard', '3304 Mach 1 Dr.', '', 'Norfolk', 'Nebraska', '68701', '605-595-3293', '', '', '', '', '', '', '1', '', '', '', '', '2015-10-22');
INSERT INTO customerInfo VALUES ('135', '72', 'Al', 'Collison', '426 S. 5th St. ', '', 'Pierce', 'Nebraska', '68767', '402-379-9695', '', '', '', '', '', '', '5', '', '', '', '', '2015-10-22');
INSERT INTO customerInfo VALUES ('136', '72', 'Mary ', 'Loseke', '18428 280th St.', '', 'Columbus', 'Nebraska', '68601', '563-2985', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-22');
INSERT INTO customerInfo VALUES ('137', '72', 'Pete & Kathy', 'Hastreiter', '83441 557th Ave', '', 'Norfolk', 'Nebraska', '68701', '920-0684', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-23');
INSERT INTO customerInfo VALUES ('138', '72', 'Deb', 'Kallenbach', '271 3rd Ave', '', 'Columbus', 'Nebraska', '68601', '563-0362', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-23');
INSERT INTO customerInfo VALUES ('139', '72', 'Corey', 'Pilakowski', '', 'PO Box 245', 'Genoa', 'Nebraska', '68640', '948-0206', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-23');
INSERT INTO customerInfo VALUES ('140', '72', 'Tiffani & Lee', 'Stegeman', '1010 Grainland', '', 'Wayne', 'Nebraska', '68787', '605-759-0915', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-23');
INSERT INTO customerInfo VALUES ('141', '72', 'Kristie ', 'Kolb', '522Rd H', '', 'Schuyler', 'Nebraska', '68661', '402-942-2604', '', '', '', '', '', 'north of hwy 30 to rd h the only house between rd 5 and rd 6', '3', '', '', '', '', '2015-10-23');
INSERT INTO customerInfo VALUES ('142', '72', 'Jeff', 'Russo', '604 E Klug', '', 'Norfolk', 'Nebraska', '68701', '992-8728', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-26');
INSERT INTO customerInfo VALUES ('143', '72', 'Roger', 'Borgman', '1205 Eldorado Rd', '', 'Norfolk', 'Nebraska', '68701', '402-379-0677', '', '402-379-9695', '', '', '', '', '3', '', '', '', '', '2015-10-26');
INSERT INTO customerInfo VALUES ('144', '72', 'Jon', 'Zavadil', '', '315 Pershing Rd', 'Columbus', 'Nebraska', '68601', '402-270-3091', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-26');
INSERT INTO customerInfo VALUES ('145', '72', 'Duane', 'Bright', '13898 T Rd', '', 'Shelby', 'Nebraska', '68662', '402-527-5622', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-26');
INSERT INTO customerInfo VALUES ('146', '72', 'Lanny', 'Fisher', '2960 18th Ave.', '', 'Columbus', 'Nebraska', '68601', '402-920-0321', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-26');
INSERT INTO customerInfo VALUES ('147', '72', 'lanny', 'fischer', '2960 18th ave.', '', 'Columbus', 'Nebraska', '68601', '402-920-0321', '', '', '', '', '', '', '1', '', '', '', '', '2015-10-26');
INSERT INTO customerInfo VALUES ('148', '72', 'Bob ', 'Pollock', '54345 550th Ave', '', 'Norfolk', 'Nebraska', '68701', '640-5058', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-26');
INSERT INTO customerInfo VALUES ('149', '72', 'Tony', 'Squire', '500 W. 6th', '', 'Lindsay', 'Nebraska', '68644', '402-608-0337', '', '402-276-4690', '', '', '', '', '3', '', '', '', '', '2015-10-26');
INSERT INTO customerInfo VALUES ('150', '72', 'Roy', 'Walter', '370 10th Ave', '', 'Columbus', 'Nebraska', '68601', '402-270-1019', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-26');
INSERT INTO customerInfo VALUES ('151', '72', 'Brendan', 'Janssen', '729 S. 11th St.', '', 'Norfolk', 'Nebraska', '68701', '402-649-7086', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-26');
INSERT INTO customerInfo VALUES ('152', '72', 'Ponca Housing', '', '', '1501 Michigan Ave', 'Norfolk', 'Nebraska', '68701', 'Office: 379-8224', '', '', '', '', '', '', '5', 'Alex', '402-649-0978', 'Ponca Housing', '', '2015-10-26');
INSERT INTO customerInfo VALUES ('153', '72', 'Brian', 'Lind', '2009 N Eastwood', '', 'Norfolk', 'Nebraska', '68701', '302-4509', '', '379-2590-Deb', '', '', '', '', '3', '', '', '', '', '2015-10-26');
INSERT INTO customerInfo VALUES ('154', '72', 'Steve & Linda', 'Eggers', 'PO Box 516', '84254 535th Ave', 'Tilden', 'Nebraska', '68781', 'Holly: 841-0766', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-27');
INSERT INTO customerInfo VALUES ('155', '72', 'Kelli', 'Berryman', '802 N. Birch', '', 'Norfolk', 'Nebraska', '68701', '402-750-3629', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-27');
INSERT INTO customerInfo VALUES ('156', '72', 'John & Ashley', 'Lammli', '2303 Prospect Ave', '', 'Norfolk', 'Nebraska', '68701', '913-302-7706', '', '', '', '', '', '', '5', '', '', '', '', '2015-10-27');
INSERT INTO customerInfo VALUES ('157', '72', 'Jeff', 'Jensen', '2616 W. Madison Ave', '', 'Norfolk', 'Nebraska', '68701', '750-9009', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-28');
INSERT INTO customerInfo VALUES ('158', '72', 'James', 'Lentz', '211 E. Canfield', '', 'Coleridge', 'Nebraska', '68727', '402-283-4024', '', '308-258-0013', '', '', '', '', '3', '', '', '', '', '2015-10-28');
INSERT INTO customerInfo VALUES ('159', '72', 'Jared', 'Michaels', '503 N. Boxelder', '', 'Norfolk', 'Nebraska', '68701', '750-8997', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-28');
INSERT INTO customerInfo VALUES ('160', '72', 'Paula ', 'Hoeft', '2104 skyline ', '', 'Norfolk', 'Nebraska', '68701', '3032040250', '', '', '', 'paula.hoeft@icloud.com', '', '', '3', 'Paula', '', '', '', '2015-10-28');
INSERT INTO customerInfo VALUES ('161', '72', 'Muffin ', 'Morris', '508 logan', '', 'Wayne', 'Nebraska', '68787', '6052020577', '', '', '', 'mumorris1@wsc.edu', '', '', '3', '', '', '', '', '2015-10-28');
INSERT INTO customerInfo VALUES ('162', '72', 'Terri', 'Davis', '2959 18th Ave', '', 'Columbus', 'Nebraska', '68601', '402-910-3246', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-29');
INSERT INTO customerInfo VALUES ('163', '72', 'Wanda', 'Wondercheck', '2083 300th Ave', '', 'Albion', 'Nebraska', '68620', '402-395-2287', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-29');
INSERT INTO customerInfo VALUES ('164', '72', 'Doug', 'Demuth', '1922 Keene Dr', '', 'Columbus', 'Nebraska', '68601', '402-910-2264', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-29');
INSERT INTO customerInfo VALUES ('165', '72', 'Justin ', 'Wetjen', '', 'PO Box 417       ', 'Humphrey', 'Nebraska', '68642', '923-0606', '', '920-0422', '', '', '', '', '3', '', '', '', '', '2015-10-29');
INSERT INTO customerInfo VALUES ('166', '72', 'Robert ', 'Oswald', '411 Market Place', '', 'Norfolk', 'Nebraska', '68701', '430-9725', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-29');
INSERT INTO customerInfo VALUES ('167', '72', 'Ron', 'Tuma', '2916 33rd St', '', 'Columbus', 'Nebraska', '68601', '564-7634', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-29');
INSERT INTO customerInfo VALUES ('168', '72', 'Charles & Deb ', 'Misfeldt', '2803 Ruthann Circle', '', 'Norfolk', 'Nebraska', '68701', '371-4984', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-29');
INSERT INTO customerInfo VALUES ('321', '72', 'Ernest ', 'Brabec', '121 Spruce St', '', 'Clarkson', 'Nebraska', '', '4028923580', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-24');
INSERT INTO customerInfo VALUES ('322', '72', 'Mona ', 'Michaels', '402 N 7TH BOX 188', '', 'Plainview', 'Nebraska', '', '', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-24');
INSERT INTO customerInfo VALUES ('170', '72', 'Shauna', 'Seebohm', '1020 5th St.', '', 'Columbus', 'Nebraska', '68601', '276-2780', '', '', '', '', '', '', '4', '', '', '', '', '2015-10-30');
INSERT INTO customerInfo VALUES ('171', '72', 'Kathy', 'Fadschild', '29493 205th Ave', '', 'Columbus', 'Nebraska', '68601', '402-910-3479', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-30');
INSERT INTO customerInfo VALUES ('172', '72', 'Bryan ', 'Bahns', '411 E. Park', '', 'Norfolk', 'Nebraska', '68701', '860-0264', '', '', '', '', '', '(Matt Claussen original owner)-No warranty was transferred', '3', '', '', '', '', '2015-10-30');
INSERT INTO customerInfo VALUES ('173', '72', 'Deloris', 'Kneifel', '764 27th Ave', '', 'Columbus', 'Nebraska', '68601', '564-3067', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-30');
INSERT INTO customerInfo VALUES ('174', '72', 'Tim', 'Parker', '137 E. Parkway', '', 'Columbus', 'Nebraska', '68601', '562-6450', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-30');
INSERT INTO customerInfo VALUES ('175', '72', 'Doris (Dorri)', 'Chrisp', '3172 Fairlane Ave', '', 'Columbus', 'Nebraska', '68601', '402-563-1928', '', '', '', '', '', 'built in 1981 will pay cash;-)', '1', '', '', '', '', '2015-10-30');
INSERT INTO customerInfo VALUES ('176', '72', 'Jim ', 'Luedtke', '56721 822nd Rd', '', 'Clarkson', 'Nebraska', '68629', '402-920-0204', '', '', '', '', '', '1970-72 house  from 91/57 intersection - 2 miles north and 1 1/4 East  ', '3', '', '402-920-0204', '', '', '2015-10-30');
INSERT INTO customerInfo VALUES ('177', '72', 'Rick ', 'Wilmes', '1004 Redick Ave', '', 'Creighton', 'Nebraska', '', '402-929-3955', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-30');
INSERT INTO customerInfo VALUES ('178', '72', 'Karla', 'Linsteadt', '1501 W. Norfolk Ave', '', 'Norfolk', 'Nebraska', '68701', '402-371-9158', '', '', '', '', '', '', '3', '', '', '', '', '2015-10-30');
INSERT INTO customerInfo VALUES ('179', '72', 'Peg', 'Webster', '2214 Highview Dr.', '', 'Wayne', 'Nebraska', '68787', '402-369-1118', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-02');
INSERT INTO customerInfo VALUES ('180', '72', 'Delores', 'Jaeke', '307 Willow', '', 'Norfolk', 'Nebraska', '68701', '402-371-0069', '', '', '', '', '', '', '3', '', '371-0069', '', '', '2015-11-02');
INSERT INTO customerInfo VALUES ('181', '72', 'Dillon & Whitney', 'Busch', '805 Irving St.', '', 'Fullerton', 'Nebraska', '68638', '308-550-0777', '', '741-2828', '', '', '', '', '3', '', '', '', '', '2015-11-02');
INSERT INTO customerInfo VALUES ('182', '72', 'Glenda', 'Liebig', '2921 8th St.', '', 'Columbus', 'Nebraska', '68601', '402-270-4195', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-02');
INSERT INTO customerInfo VALUES ('183', '72', 'Carrie', 'Brandt', '1204 Meadow Dr', '', 'Norfolk', 'Nebraska', '68701', '402-750-9112', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-02');
INSERT INTO customerInfo VALUES ('184', '72', 'Melissa ', 'Hyde', '', '4530 31st St.', 'Columbus', 'Nebraska', '68601', '276-8761', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-02');
INSERT INTO customerInfo VALUES ('185', '72', 'JoAnn', 'Meyer', '1308  Madison Ave', '', 'Norfolk', 'Nebraska', '68701', '371-7573', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-02');
INSERT INTO customerInfo VALUES ('186', '72', 'Jackie ', 'Samway', '902 Quincy St', '', 'Madison', 'Nebraska', '68748', '4027505526', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-02');
INSERT INTO customerInfo VALUES ('303', '72', 'Todd', 'Kasik', '110 Taylor Creek', '', 'Madison', 'Nebraska', '', '402-454-2351', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-22');
INSERT INTO customerInfo VALUES ('188', '72', 'Dennis', 'Beltz', '406 E. Park', '', 'Norfolk', 'Nebraska', '68701', '402-640-5555', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-02');
INSERT INTO customerInfo VALUES ('189', '72', 'Tara', 'Ward', '213 S. Maple', '', 'Plainview', 'Nebraska', '', '402-929-3858', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-02');
INSERT INTO customerInfo VALUES ('190', '72', 'Randall and Connie', 'Bargstadt', '84981 569th Ave', '', 'Winside', 'Nebraska', '68790', '4022864951', '', '4026402747', '', '', '', '', '3', '', '', '', '', '2015-11-02');
INSERT INTO customerInfo VALUES ('191', '73', 'Columbus Aquatic Center', '', '1783 10th Ave', '', 'Columbus', 'Nebraska', '68601', '563-3222', '', '', '', '', '', '', '3', '', '', 'Columbus Aquatic Center       ', '', '2015-11-02');
INSERT INTO customerInfo VALUES ('192', '72', 'Jeanette ', 'Helmer', '23122 430th st', '', 'Humphrey', 'Nebraska', '68642', '4029200078', '', '', '', 'jeanette@bellerandbackes.com', '', '', '3', '', '', '', '', '2015-11-02');
INSERT INTO customerInfo VALUES ('193', '72', 'Wanda', 'Borowiak', '2836 E. 38th St.', '', 'Columbus', 'Nebraska', '68601', '402-276-5546', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-03');
INSERT INTO customerInfo VALUES ('194', '72', 'John', 'Badje', '3218 17th St.', '', 'Columbus', 'Nebraska', '68601', '402-942-9501', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-03');
INSERT INTO customerInfo VALUES ('196', '72', 'Kathy ', 'Patras', '609 Iowa', '', 'Clearwater', 'Nebraska', '68726', '4024852552', '', '4028416544', '', 'kspatras@nntc.net', '', '', '3', '', '', '', '', '2015-11-03');
INSERT INTO customerInfo VALUES ('197', '72', 'Marg', 'Houston', '', '', 'Emmet', 'Nebraska', '68743', '4023401903', '', '', '', '', '', '2 1/2 miles west of Emmet hog barns south side turn south west right away that is the driveway  white house', '3', '', '', '', '', '2015-11-03');
INSERT INTO customerInfo VALUES ('198', '72', 'David ', 'Nesladek', '450 15th Rd Lot #1', '', 'West Point', 'Nebraska', '68788', 'Dan: 380-2133', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-03');
INSERT INTO customerInfo VALUES ('199', '72', 'Ken', 'Gall', '57047 825TH ROAD', '', 'Clarkson', 'Nebraska', '68629', '402-750-7486', '', '', '', '', '', '', '1', '', '', '', '', '2015-11-04');
INSERT INTO customerInfo VALUES ('200', '72', 'Richard', 'Smith', '760 Centennial Pl.', '', 'Columbus', 'Nebraska', '68601', '402-606-8486', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-04');
INSERT INTO customerInfo VALUES ('201', '72', 'Greg and Carla ', 'Pippitt', '86920 574th Ave ', '', 'Laurel', 'Nebraska', '68745', '402-256-3635', '', '402-375-0622 (Greg)', '', '', '', 'He\'s a farmer, Carla called in but Greg will be the one to set up with ', '1', '', '', '', '', '2015-11-05');
INSERT INTO customerInfo VALUES ('202', '72', 'Karen ', 'Fundus', '308 South 12th St ', '', 'Norfolk', 'Nebraska', '67801', '402-750-77207', '', '', '', '', '', 'rental house repeat customer', '3', '', '', '', '', '2015-11-05');
INSERT INTO customerInfo VALUES ('203', '72', 'Wes & Kelly ', 'Van Ert', '201 Main St', '', 'Battle Creek', 'Nebraska', '68715', '739-1952', '', '', '', '', '', '', '4', '', '', '', '', '2015-11-06');
INSERT INTO customerInfo VALUES ('204', '72', 'Steve & Sue ', 'Falk', '55937 847th Rd', '', 'Hoskins', 'Nebraska', '68740', '402-841-7920', '', '', '', '', '', '', '5', '', '', '', '', '2015-11-06');
INSERT INTO customerInfo VALUES ('205', '72', 'Leon and Pamela ', 'Handke', '83937 Eagle Ridge rd', '', 'Norfolk', 'Nebraska', '68701', '', '', '', '', '', '', '', '1', '', '402-649-2350', '', '', '2015-11-06');
INSERT INTO customerInfo VALUES ('206', '72', 'Mike', 'Wiedeman', '304 E. Herman', '', 'Battle Creek', 'Nebraska', '', '', '', '', '', '', '', '', '1', '', '', '', '', '2015-11-06');
INSERT INTO customerInfo VALUES ('207', '72', 'M&J Roofing', '', '', '', 'Norfolk', 'Nebraska', '', '649-6422', '', '', '', '', '', '', '3', '', '', 'M&J Roofing', '', '2015-11-06');
INSERT INTO customerInfo VALUES ('208', '72', 'Angie', 'Beiermann', '621 W 1st St', '', 'Wayne', 'Nebraska', '68787', '518-8184', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-09');
INSERT INTO customerInfo VALUES ('209', '72', 'Sergio', 'Deanda', '2580 3rd Ave.', '', 'Columbus', 'Nebraska', '68601', '402-270-2238', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-09');
INSERT INTO customerInfo VALUES ('210', '72', 'Deb', 'Arter', '1106 E Sycamore', '', 'Norfolk', 'Nebraska', '68701', '303-517-9921', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-10');
INSERT INTO customerInfo VALUES ('211', '72', 'dean and pat', 'chapman', '1501 south chestnut', '', 'Norfolk', 'Nebraska', '68701', '402-379-2046', '', '', '', '', '', '', '1', '', '', '', '', '2015-11-10');
INSERT INTO customerInfo VALUES ('212', '72', 'Jason', 'Doelle', '2300 Random Rd', '', 'Norfolk', 'Nebraska', '68701', '371-3100', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-11');
INSERT INTO customerInfo VALUES ('213', '72', 'Zack', 'Lindsley', '310 Oak St.', '', 'Creston', 'Nebraska', '68631', '910-0959', '', '', '', 'zack.linsdley@doane.edu', '', '', '3', '', '', '', '', '2015-11-11');
INSERT INTO customerInfo VALUES ('214', '72', 'Rob & Corrie ', 'Starkey', '801 W. 10th St.', '', 'Neligh', 'Nebraska', '68756', '402-929-3907', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-11');
INSERT INTO customerInfo VALUES ('215', '72', 'Judy ', 'Merten', '2693 NE39', '', 'Albion', 'Nebraska', '68620', '4027411720', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-11');
INSERT INTO customerInfo VALUES ('216', '72', 'Laura ', 'Nelson', '107 N 5th', '', 'Newman Grove', 'Nebraska', '68758', '4029201181', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-11');
INSERT INTO customerInfo VALUES ('217', '72', 'Mikal', 'Shalikow', '115 S. 9th St. ', '', 'Newman Grove', 'Nebraska', '68758', '402-750-5697', '', '', '402-447-6294', '', '', '', '3', '', '', '', '', '2015-11-12');
INSERT INTO customerInfo VALUES ('218', '72', 'Steve ', 'Anderson', '4 Driftwood Dr.', '', 'Columbus', 'Nebraska', '68601', '402-910-1858', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-12');
INSERT INTO customerInfo VALUES ('219', '72', 'Eldon', 'Christensen', '14232 280th St', '', 'Columbus', 'Nebraska', '68601', '402-910-1761', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-12');
INSERT INTO customerInfo VALUES ('220', '72', 'Keith', 'Shonka', '4251 D Rd', '', 'Bellwood', 'Nebraska', '68624', '402-910-8909', '', '', '', '', '', 'Call when comes to Norfolk-He may pick up from Norfolk. Needs them ASAP', '3', '', '', '', '', '2015-11-12');
INSERT INTO customerInfo VALUES ('221', '72', 'Walter & Dorothy', 'Johnson', '820 E. Hynes', '', 'O\'Neill', 'Nebraska', '68763', '340-6224', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-12');
INSERT INTO customerInfo VALUES ('222', '72', 'Bill ', 'Lamm', '511 N. Pine St', '', 'Norfolk', 'Nebraska', '68701', '640-8112', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-12');
INSERT INTO customerInfo VALUES ('223', '72', 'Jim ', 'Wichman', '1616 W. Berry Hill Dr', '', 'Norfolk', 'Nebraska', '68701', '640-7146', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-12');
INSERT INTO customerInfo VALUES ('224', '72', 'Joel', 'Putters', '84030 562nd Ave', '', 'Stanton', 'Nebraska', '68779', '402-750-0735', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-12');
INSERT INTO customerInfo VALUES ('225', '72', 'Tilden Housing Authority', '', '', '600 Gile Creek', 'Tilden', 'Nebraska', '68781', '649-2960', '', '', '', '', '', '', '4', '', '', 'Tilden Housing Authority', '', '2015-11-12');
INSERT INTO customerInfo VALUES ('226', '72', 'Arvyn & Reta ', 'Neuhaus', '84953 562nd Ave', '', 'Hoskins', 'Nebraska', '68730', '750-6656', '', '565-4864', '', '', '', '', '3', '', '', '', '', '2015-11-12');
INSERT INTO customerInfo VALUES ('227', '72', 'Steve', 'Jorgensen', '312 Vroman St', '', 'Winside', 'Nebraska', '68790', '286-4328', '', '402-480-5513', '', '', '', 'Customer would like to wait until After January 1, 2016 to install her windows. Doesnt want to have to move around her Christmas tree....she will have it down by the 1st.', '3', '', '', '', '', '2015-11-13');
INSERT INTO customerInfo VALUES ('228', '72', 'Jason ', 'Feddern', '806 S. 5th St.', '', 'Norfolk', 'Nebraska', '68701', '640-7845', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-16');
INSERT INTO customerInfo VALUES ('229', '72', 'Charlotte', 'Reifert', '55956 845 Rd', '', 'Norfolk', 'Nebraska', '68701', '402-860-0891', '', '', '', '', '', '', '4', '', '', '', '', '2015-11-16');
INSERT INTO customerInfo VALUES ('230', '72', 'Jose & Odilia', 'Leon', '116 Norfolk Ave', '', 'Norfolk', 'Nebraska', '68701', '371-4778', '', '402-992-2612', '', '', '', '', '4', '', '', '', '', '2015-11-16');
INSERT INTO customerInfo VALUES ('231', '72', 'Gary', 'Kopietz', '83910 563rd Ave.', '', 'Stanton', 'Nebraska', '68779', '402-640-4885', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-16');
INSERT INTO customerInfo VALUES ('232', '72', 'Don', 'Maguire', '607 Cedar', '', 'Norfolk', 'Nebraska', '68701', '402-649-4553', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-16');
INSERT INTO customerInfo VALUES ('233', '72', 'Kylee & Tyler', 'Carey', '2309 18th St.', '', 'Columbus', 'Nebraska', '68601', '308-390-4642', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-16');
INSERT INTO customerInfo VALUES ('234', '72', 'Randy & Jody', 'Peters', '2907 Dover Dr.', '', 'Norfolk', 'Nebraska', '68701', '402-760-4765', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-17');
INSERT INTO customerInfo VALUES ('235', '72', 'Becky', 'Wulf', '902 S. Pine St', '', 'Norfolk', 'Nebraska', '68701', '640-4573', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-17');
INSERT INTO customerInfo VALUES ('236', '72', 'Matt', 'Kampschneider', '1305 Sunrise Dr.', '', 'Norfolk', 'Nebraska', '68701', '402-992-4610', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-17');
INSERT INTO customerInfo VALUES ('237', '72', 'Dale', 'Pelster', '', '', 'Elgin', 'Nebraska', '68636', '402-929-0597', '', '', '', '', '', 'NORTH OF ELGIN HOUSE RIGHT BY THE POPULATION SIGN WHITE WEST SIDE OF HWY', '3', '', '', '', '', '2015-11-20');
INSERT INTO customerInfo VALUES ('275', '72', 'Joan ', 'Melcher', '106 n maple st ', '', 'Lindsay', 'Nebraska', '', '4026495738', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-18');
INSERT INTO customerInfo VALUES ('276', '72', 'Pam', 'Schlote', '55491 839 Rd', '', 'Battle Creek', 'Nebraska', '', '402-675-6002', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-18');
INSERT INTO customerInfo VALUES ('239', '72', 'rick ', 'schack ', '1330 w church st ', '', 'Albion', 'Nebraska', '', '4023952115', '', '4023952205', '', '', '', '', '3', '', '', '', '', '2015-11-23');
INSERT INTO customerInfo VALUES ('240', '72', 'Maria', 'Babel', '113 N 5th St.', 'P.O. Box 216', 'Newman Grove', 'Nebraska', '68758', '402-447-6144', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-23');
INSERT INTO customerInfo VALUES ('241', '72', 'Dave', 'Braun', '510 Hillcrest', '', 'Wayne', 'Nebraska', '68787', '402-369-1472', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-23');
INSERT INTO customerInfo VALUES ('242', '72', 'Tyler ', 'Schmidt', '500 South 6th St', '', 'Norfolk', 'Nebraska', '68701', '402-992-2128', '', '', '', '', '', 'Estimate Big Window, Big Front Window ', '1', '', '', '', '', '2015-11-25');
INSERT INTO customerInfo VALUES ('243', '72', 'Trisha ', 'Peters', '913 9th st ', '', 'Wisner', 'Nebraska', '68791', '4025180675', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-25');
INSERT INTO customerInfo VALUES ('244', '72', 'Laine', 'Wiegard', '86530 Old Hwy 81', '', 'Norfolk', 'Nebraska', '68701', '379-3027', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-25');
INSERT INTO customerInfo VALUES ('245', '72', 'Dave', 'Freudenburg', '1610 W. Benjamin Ave.', '', 'Norfolk', 'Nebraska', '68701', '402-640-6112', '', '', '', '', '', '', '3', '', '', '', '', '2015-11-30');
INSERT INTO customerInfo VALUES ('246', '72', 'Steve ', 'Shoemaker', '207 N 18th ', '', 'Norfolk', 'Nebraska', '68701', '402-379-1277', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-01');
INSERT INTO customerInfo VALUES ('323', '72', 'Tom', 'Schmitz', '414 Walnut - rental', '412 Walnut - Home address', 'Wayne', 'Nebraska', '', 'cell - 402-375-0412', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-28');
INSERT INTO customerInfo VALUES ('248', '72', 'Jerry & Kathy', 'Pfeifer', '3658 50th Ave.', '', 'Columbus', 'Nebraska', '68601', '402-910-2421', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-07');
INSERT INTO customerInfo VALUES ('249', '72', 'Tami', 'Kruse', '2160 24th Ave.', '', 'Columbus', 'Nebraska', '68601', '402-942-2876', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-07');
INSERT INTO customerInfo VALUES ('250', '72', 'Chris', 'Scholl', '2469 53rd Ave', '', 'Columbus', 'Nebraska', '68601', '402-910-4875', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-07');
INSERT INTO customerInfo VALUES ('251', '72', 'Joslen', 'Anson', '307 N. 2nd', '', 'Plainview', 'Nebraska', '68769', '', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-07');
INSERT INTO customerInfo VALUES ('252', '72', 'Jim', 'Gaylen', '305 N. 37th St.', '', 'Norfolk', 'Nebraska', '68701', '520-909-3922-ed mack', '', '', '', '', '', '', '4', '', '', 'Sunny Meadow Clinic', '', '2015-12-07');
INSERT INTO customerInfo VALUES ('253', '72', 'John & Nancy', 'Blezek', '754 7th Ave.', '', 'Columbus', 'Nebraska', '68601', '402-564-8109', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-08');
INSERT INTO customerInfo VALUES ('254', '72', 'Jamie', 'Winter ', '2204 Vernon Ave', '', 'Norfolk', 'Nebraska', '68701', '402-649-8651', '', '', '', '', '', '', '1', '', '', '', '', '2015-12-08');
INSERT INTO customerInfo VALUES ('255', '72', 'Gerald', 'Carstens', '55034 856 Rd', '', 'Pierce', 'Nebraska', '68767', '329-4461', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-08');
INSERT INTO customerInfo VALUES ('257', '72', 'Brent', 'Vandiest', '2263 Circle Dr', '', 'Columbus', 'Nebraska', '68601', '', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-08');
INSERT INTO customerInfo VALUES ('258', '72', 'Linda', 'Delk', '420 Exchange St', '', 'Stromsburg', 'Nebraska', '68666', '745-0188', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-08');
INSERT INTO customerInfo VALUES ('259', '72', 'Matt', 'Gonka', '1972 25th Ave', '', 'Columbus', 'Nebraska', '68601', '606-9058', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-08');
INSERT INTO customerInfo VALUES ('260', '73', 'Olivia (Dorothy)', 'Finecy', '', '', 'Columbus', 'Nebraska', '68601', '276-1086', '', '564-0178', '', '', '', '', '3', '', '', '', '', '2015-12-09');
INSERT INTO customerInfo VALUES ('261', '72', 'RICHARD AND RONALD ', 'BRAND', '1400 NORFOLK AVE', '', 'Norfolk', 'Nebraska', '68701', '4023713706', '', '', '', '', '', '', '3', '', '', 'VON ALAN INVESTMENT', '', '2015-12-09');
INSERT INTO customerInfo VALUES ('262', '72', 'Galen & Diane', 'Anderson', '728 E Main', '', 'Pierce', 'Nebraska', '68767', '402-329-4778', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-10');
INSERT INTO customerInfo VALUES ('263', '72', 'GALEN AND DIANE', '', '', '', 'Norfolk', 'Nebraska', '', '', '', '', '', '', '', '', '1', '', '', '', '', '2015-12-14');
INSERT INTO customerInfo VALUES ('264', '72', 'Colleen', 'Wolverton', '978 4th Rd', '', 'Wisner', 'Nebraska', '68790', '402-640-3052', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-14');
INSERT INTO customerInfo VALUES ('302', '72', 'Battle Creek Farmer\'s Pride', '', '700 W. 3rd St.', '', 'Madison', 'Nebraska', '', '', '', '', '', '', '', '', '3', 'Julie Freudenberg', '402-454-2999', 'Battle Creek Farmer\'s Pride', '', '2015-12-22');
INSERT INTO customerInfo VALUES ('266', '72', 'Nevada ', 'Claussen', '505 N 1ST ', '', 'Pierce', 'Nebraska', '68767', '', '', '4027508247', '', '', '', '', '3', '', '', '', '', '2015-12-14');
INSERT INTO customerInfo VALUES ('267', '72', 'Tammy', 'Korth', '311 Brentwood Dr.', '', 'Norfolk', 'Nebraska', '68701', '860-3532', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-14');
INSERT INTO customerInfo VALUES ('268', '72', 'Kayla ', 'Humlicek', '904 5th St.', '', 'Duncan', 'Nebraska', '', '276-3192', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-15');
INSERT INTO customerInfo VALUES ('269', '72', 'Jason ', 'Brandt', '203 S Brown', '', 'Pierce', 'Nebraska', '68767', '4023604297', '', '', '', 'bjasonbrandt@gmail.com', '', '', '3', '', '', '', '', '2015-12-15');
INSERT INTO customerInfo VALUES ('270', '72', 'Gary and Liz ', 'Doerr', '87067 537th Ave', '', 'Creighton', 'Nebraska', '68729', '402-582-3582', '', '', '', '', '', 'Directions:   6 1/2  miles north of Plainview on 9th st/ 537th Ave, west side, grey with white trim ', '3', '', '', '', '', '2015-12-15');
INSERT INTO customerInfo VALUES ('271', '73', 'Joe', 'Yindrick', '3451 S Rd', '', 'David City', 'Nebraska', '68632', '', '', '', '', '', '', '', '3', 'Jim Sylvester', '367-3391', '', '', '2015-12-15');
INSERT INTO customerInfo VALUES ('272', '72', 'Fred', 'Neemeyer', '2908 25th St', '3377 Fairlane Ave', 'Columbus', 'Nebraska', '68601', '564-7452', '', '', '', '', '', '', '3', '', '', 'F&D Rentals', '', '2015-12-17');
INSERT INTO customerInfo VALUES ('277', '72', 'John ', 'Becker', '508 Oak St.', '1920 320th Street - Albion, NE  68620', 'Stanton', 'Nebraska', '', '402-741-1477', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-18');
INSERT INTO customerInfo VALUES ('278', '72', 'Adam ', 'Hinton ', '86641 533rd Ave', '', 'Plainview', 'Nebraska', '68769', '402-992-3457', '', '', '', '', '', 'Granda Apts - Prior $375 a window wh/whi 6000(ami) with quarter round ', '5', '', '', 'HT INvestment ', '', '2015-12-18');
INSERT INTO customerInfo VALUES ('279', '72', 'Tim', 'Krienert', '54482 Hwy 20', '', 'Osmond', 'Nebraska', '', '', '', '402-992-1003', '', '', '', '', '3', '', '', '', '', '2015-12-21');
INSERT INTO customerInfo VALUES ('280', '72', 'Steve ', 'Banks ', '55067 878rd', '', 'Wausa', 'Nebraska', '68786', '402-360-1706', '', '402-360-1653', '', '', '', '', '3', '', '', '', '', '2015-12-21');
INSERT INTO customerInfo VALUES ('281', '73', 'Dwayne ', 'Lindhorst', '44991 460th Ave', '', 'Lindsay', 'Nebraska', '68644', '402-428-5605', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-21');
INSERT INTO customerInfo VALUES ('282', '72', 'Tracy', 'Gradert', '55984 845th Rd', '', 'Norfolk', 'Nebraska', '68701', '', '', '402-841-8947', '', '', '', '', '3', '', '', '', '', '2015-12-21');
INSERT INTO customerInfo VALUES ('283', '72', 'Emily', 'Miller', '84459 N. Hwy 35', '', 'Norfolk', 'Nebraska', '', '', '', '', '402-841-0625', '', '', '', '3', 'Emily Miller', '402-841-0625', 'Michael Dusek', '', '2015-12-21');
INSERT INTO customerInfo VALUES ('284', '72', 'Seth & Brittney', 'Fevold', '1916 W. Prospect Ave', '', 'Norfolk', 'Nebraska', '', 'Seth: 515-570-9901', '', 'Brittney: 515-351-9703', '', '', '', '', '3', '', '', '', '', '2015-12-21');
INSERT INTO customerInfo VALUES ('285', '72', 'Dennis & Barb', 'Brandt', '1004 S 3rd St.', '', 'Norfolk', 'Nebraska', '', '402-844-5926', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-21');
INSERT INTO customerInfo VALUES ('286', '72', 'John', 'Kruid', '1400 Pierce St.', '', 'Norfolk', 'Nebraska', '', '419-305-2292', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-21');
INSERT INTO customerInfo VALUES ('287', '72', 'Cindy', 'Voichoskie', '2061 Brentwood Dr.', '', 'Norfolk', 'Nebraska', '', '379-2577', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-21');
INSERT INTO customerInfo VALUES ('288', '72', 'Bill & Jeanne', 'Tichota', '210 N. Boxelder', '', 'Norfolk', 'Nebraska', '', '402-750-6739', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-21');
INSERT INTO customerInfo VALUES ('289', '72', 'Dwayne', 'Thies', '56027 Hwy 98', '', 'Hoskins', 'Nebraska', '', '750-9522', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-21');
INSERT INTO customerInfo VALUES ('290', '72', 'Dan & Karen', 'Jackson', '2203 Koenigstein Ave', '', 'Norfolk', 'Nebraska', '', '402-640-6121', '', 'Karen: 841-7457', '', '', '', '', '3', '', '', '', '', '2015-12-21');
INSERT INTO customerInfo VALUES ('291', '72', 'Steve & Cindy', 'Ganskow', '305 W. Sherwood Rd.', '', 'Norfolk', 'Nebraska', '', '402-371-2044', '', '402-640-6649', '', '', '', '', '3', '', '', '', '', '2015-12-21');
INSERT INTO customerInfo VALUES ('292', '72', 'Mike', 'Hines', '303 Trailridge Rd', '', 'Norfolk', 'Nebraska', '', '402-992-3370', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-21');
INSERT INTO customerInfo VALUES ('293', '72', 'Jason & Kristina', 'King', '111 Morningside Dr.', '', 'Norfolk', 'Nebraska', '', '402-644-8329', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-21');
INSERT INTO customerInfo VALUES ('294', '72', 'Amy', 'Nielsen', '201 Shetland Path', '', 'Norfolk', 'Nebraska', '', '402-750-5933', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-22');
INSERT INTO customerInfo VALUES ('295', '72', 'Greg & LeAnn ', 'Rathke', '1620 Hackberry', '', 'Norfolk', 'Nebraska', '', 'LeAnn: 316-0123', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-22');
INSERT INTO customerInfo VALUES ('296', '72', 'Andrew', 'Linnaus', '1004 Nord St.', '', 'Norfolk', 'Nebraska', '', '402-843-0134', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-22');
INSERT INTO customerInfo VALUES ('297', '72', 'Matt', 'Hampschneider', '1305 Sunrise Dr', '', 'Norfolk', 'Nebraska', '68701', '402-992-4610', '', '', '', '', '', '', '1', '', '', '', '', '2015-12-22');
INSERT INTO customerInfo VALUES ('298', '72', 'Richard', 'Kuchar', '117 N. Crown Point', '', 'Bloomfield', 'Nebraska', '', '402-640-5828', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-22');
INSERT INTO customerInfo VALUES ('299', '72', 'Reid', 'Rosendahl', '1100 S. 2nd St.', '', 'Norfolk', 'Nebraska', '68701', '402-920-3786', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-22');
INSERT INTO customerInfo VALUES ('300', '72', 'Tim', 'Koepke', '56075 854 Rd', 'PO Box 6449', 'Hoskins', 'Nebraska', '', '402-750-6026', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-22');
INSERT INTO customerInfo VALUES ('301', '72', 'Kylie', 'Eckert', '601 S. Center St.', '', 'Norfolk', 'Nebraska', '', '402-851-1136', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-22');
INSERT INTO customerInfo VALUES ('305', '72', ' Connie', 'Beckman', '51652 Hwy 70', '', 'Elgin', 'Nebraska', '', '402-843-5463', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-22');
INSERT INTO customerInfo VALUES ('306', '72', 'Levi', 'Trautman', '85277 581st Ave', '', 'Wakefield', 'Nebraska', '', '402-841-1119', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-22');
INSERT INTO customerInfo VALUES ('307', '72', 'Jeff', 'Windeshausen', '1405 Bel Air Rd.', '', 'Norfolk', 'Nebraska', '402-992-0320', '', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-22');
INSERT INTO customerInfo VALUES ('308', '72', 'Chad & Amanda', 'Huigens', '309 N 2nd St.', '', 'Plainview', 'Nebraska', '', '', '', 'Chad Cell: 402-843-8409', 'Chad Work: 402-843-2146', '', '', '', '3', '', '', '', '', '2015-12-22');
INSERT INTO customerInfo VALUES ('309', '72', 'Chad and Gwen', 'Friders', '408 Lincoln st ', '', 'Wayne', 'Nebraska', '', '4023692768', '', '4023692762', '', '', '', '', '3', '', '', '', '', '2015-12-22');
INSERT INTO customerInfo VALUES ('310', '72', 'Brian', 'Lampert', '1709 Bel Air', '', 'Norfolk', 'Nebraska', '', '402-860-4055', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-22');
INSERT INTO customerInfo VALUES ('311', '72', 'Jim', 'Hastreiter', '82424 558th Ave.', '', 'Madison', 'Nebraska', '', '402-285-0275', '', '', '', '', '', '', '3', '', '', '', '', '2015-12-22');
INSERT INTO customerInfo VALUES ('312', '72', 'Pam', 'Scholte', '55491 839 road', '', 'Battle Creek', 'Nebraska', '', '402-675-6002', '', '', '', '', '', '', '1', '', '', '', '', '2015-12-22');
INSERT INTO customerInfo VALUES ('314', '72', 'John', 'Stappert', '207 West Norfolk Avenue', '', 'Norfolk', 'Nebraska', '68701', '(402) 851-2428', '', '', '', 'webdesign@powerpgs.com', '', 'Test Profile for Power Pages', '3', '', '', 'Power Computing Inc', '', '2015-12-23');
INSERT INTO customerInfo VALUES ('316', '72', 'Brook', 'Bugenhagen', '2007 Koenigstein Ave', '', 'Norfolk', 'Nebraska', '', ' 402-649-0796', '', '', '', 'bbugenhagen@outlook.com', '', '', '3', '', '', '', '', '2015-12-23');


#
# Table structure for table `customerTickets`
#

DROP TABLE IF EXISTS `customerTickets`;
CREATE TABLE `customerTickets` (
  `ticketID` int(11) NOT NULL AUTO_INCREMENT,
  `ticketCustID` varchar(250) DEFAULT NULL,
  `ticketEmpID` varchar(250) DEFAULT NULL,
  `propertyType` varchar(250) DEFAULT NULL,
  `ticketAddress` varchar(250) DEFAULT NULL,
  `ticketSecAddress` varchar(250) DEFAULT NULL,
  `ticketCity` varchar(250) DEFAULT NULL,
  `ticketState` varchar(150) DEFAULT NULL,
  `ticketZip` varchar(6) DEFAULT NULL,
  `ticketStatus` varchar(250) DEFAULT NULL,
  `ticketSSold` date NOT NULL,
  `ticketSOrdered` date NOT NULL,
  `ticketSReceived` date NOT NULL,
  `ticketSInstalled` date NOT NULL,
  `ticketInvoiced` varchar(250) NOT NULL,
  `ticketSInvoiced` date NOT NULL,
  `ticketSPaid` date NOT NULL,
  `ticketSPending` date NOT NULL,
  `ticketSIncomplete` date NOT NULL,
  `ticketSProposalGiven` date NOT NULL,
  `ticketSScheduled` date NOT NULL,
  `ticketLocation` varchar(250) DEFAULT NULL,
  `ticketAssign` varchar(250) DEFAULT NULL,
  `ticketDate` date NOT NULL,
  `ticketOrdDate` date NOT NULL,
  `ticketPO` varchar(250) DEFAULT NULL,
  `ticketLat` varchar(250) DEFAULT NULL,
  `ticketLong` varchar(250) DEFAULT NULL,
  `ticketCOL` varchar(250) DEFAULT NULL,
  `ticketNORF` varchar(250) DEFAULT NULL,
  `ticketSUX` varchar(250) DEFAULT NULL,
  `ticketMI` varchar(250) DEFAULT NULL,
  `ticketMIOrd` varchar(250) DEFAULT NULL,
  `ticketAMI` varchar(250) DEFAULT NULL,
  `ticketDateM` date NOT NULL,
  `ticketRCVD` varchar(250) DEFAULT NULL,
  `ticketColum` date NOT NULL,
  `ticketAMIFO` varchar(250) DEFAULT NULL,
  `ticketFinance` varchar(250) DEFAULT NULL,
  `ticketType` varchar(250) DEFAULT NULL,
  `ticketRelation` varchar(250) DEFAULT NULL,
  `ticketInstall` date NOT NULL,
  `homeYear` varchar(5) DEFAULT NULL,
  `prepLetter` varchar(250) DEFAULT NULL,
  `prepSent` date NOT NULL,
  `leadTest` varchar(8) DEFAULT NULL,
  `leadTestEmp` varchar(40) DEFAULT NULL,
  `leadTestEmpDate` date NOT NULL,
  `pamfill` varchar(5) DEFAULT NULL,
  `pamEmpfill` varchar(20) DEFAULT NULL,
  `pamDate` date NOT NULL,
  `testKit` varchar(5) DEFAULT NULL,
  `testKitEmp` varchar(40) DEFAULT NULL,
  `testDate` date NOT NULL,
  `reno` varchar(5) DEFAULT NULL,
  `renoEmp` varchar(20) DEFAULT NULL,
  `renoDate` date NOT NULL,
  `paymentReceived` varchar(1) DEFAULT NULL,
  `yardSign` varchar(1) DEFAULT NULL,
  `certCompletion` varchar(1) DEFAULT NULL,
  `wrap` varchar(5) DEFAULT NULL,
  `wrapStatus` varchar(20) DEFAULT NULL,
  `wrapColor` varchar(20) DEFAULT NULL,
  `otherWrapColor` varchar(250) DEFAULT NULL,
  `jobLadder` varchar(5) DEFAULT NULL,
  `wrapDetails` text,
  `paidDate` date NOT NULL,
  `checkStatus` varchar(5) DEFAULT NULL,
  `financeStatus` varchar(250) DEFAULT NULL,
  `ticketMonth` varchar(250) DEFAULT NULL,
  `ticketYear` varchar(4) DEFAULT NULL,
  `appLevel` varchar(250) DEFAULT NULL,
  `appSent` varchar(250) DEFAULT NULL,
  `appDate` date NOT NULL,
  `jobName` varchar(250) DEFAULT NULL,
  `diyOrdered` date NOT NULL,
  `diyReceived` date NOT NULL,
  `diyDate` date NOT NULL,
  `jobProduct` varchar(250) DEFAULT NULL,
  `dateInstalled` date NOT NULL,
  `ticketcolMI` varchar(250) DEFAULT NULL,
  `ticketcolMIoOrd` varchar(250) DEFAULT NULL,
  `ticketcolAMI` varchar(250) DEFAULT NULL,
  `ticketcolAMIFO` varchar(250) DEFAULT NULL,
  `paymentMethod` varchar(250) DEFAULT NULL,
  `soldDate` date NOT NULL,
  `downPayment` varchar(250) DEFAULT NULL,
  `downDate` date NOT NULL,
  `finalPayment` varchar(250) DEFAULT NULL,
  `finalDate` date NOT NULL,
  `paymentNotes` text NOT NULL,
  `ticketsHot` varchar(2) DEFAULT NULL,
  PRIMARY KEY (`ticketID`)
) ENGINE=MyISAM AUTO_INCREMENT=401 DEFAULT CHARSET=latin1;

#
# Dumping data for table `customerTickets`
#

INSERT INTO customerTickets VALUES ('27', '10', '', 'Single Property', '303 Aspen Dr.', '', 'Norfolk', 'Nebraska', '68701', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '0000-00-00', '', '', '', '', '1', '', '1', '#26691504', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '1976', '', '0000-00-00', '', 'SDD', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'No', '', '', '', '', '11/9/2015: Scheduled Install Date(Mark) ', '0000-00-00', '', 'Approved', 'September', '2015', '', '', '0000-00-00', 'James Bahm     (1) outside Install', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('26', '9', '', 'Multiple Property', 'smith', '', 'Hartington', 'Nebraska', '68739', 'Scheduled', '2015-12-18', '2015-12-17', '2015-12-17', '2015-12-17', '', '2015-12-17', '2015-12-17', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '1969-12-31', '1969-12-31', '', '', '', '', '2', '', '', '26691224', '', '0000-00-00', '', '2015-11-24', '', '', 'Attic', '', '1969-12-31', '', '', '0000-00-00', '', 'SDD', '2015-12-17', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'September', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2015-12-04', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('28', '12', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68701', 'Sold', '2015-12-18', '2015-12-18', '0000-00-00', '2015-12-18', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', '', '2015-10-31', '1969-12-31', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '1996', '', '0000-00-00', '', 'SDD', '2015-12-18', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'No', '', '', '', '', '', '1969-12-31', '', '', 'September', '2015', '1', 'No', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('29', '13', '', 'DIY', '', '', 'Tilden', 'Choose One', '68001', 'Old Proposals', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '1969-12-31', '', '', '', '', '2', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'SDD', '2015-11-24', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'September', '2015', '', '', '0000-00-00', 'Molly Navritil        (DIY:1) ', '1969-12-31', '0000-00-00', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('30', '16', '', 'Multiple Property', '2653 43rd Ave', 'PO Box 268       St. Edward, NE 68661', 'Columbus', 'Nebraska', '68601', 'Invoiced', '2015-12-18', '2015-12-18', '2015-12-18', '0000-00-00', '', '2015-12-18', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Jeff ', '2015-10-31', '1969-12-31', '123', '', '', '', '4 windows', '', '', '', '4', '0000-00-00', '', '2015-12-11', 'H1432/H1433          072-10144', '', 'Windows w/ Wraps', '', '1969-12-31', '1952', '', '0000-00-00', '', 'HBC', '2015-12-18', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', 'No', '', '', '', 'Brown', '1969-12-31', '', '', 'September', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('31', '17', '', 'Single Property', '1456 N. 3rd St.', '', 'David City', 'Nebraska', '68632', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Jeff ', '2015-10-31', '1969-12-31', '', '', '', '', '4', '', '', '', 'Cbus: 4', '0000-00-00', '', '1969-12-31', 'H1440                072-10145', '', 'Windows w/ Wraps', '', '1969-12-31', '1974', '', '0000-00-00', '', 'bf', '2015-12-21', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', 'No', 'Other', 'Brown', '', '', '1969-12-31', '', '', 'September', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('32', '18', '', 'Single Property', '2614 West Side', '', 'Norfolk', 'Choose One', '68701', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '0000-00-00', '', '', '', '', '1', '', '', '', '1', '0000-00-00', '', '0000-00-00', 'H1445           072-10147', '', 'Windows w/ Wraps', 'Customer', '0000-00-00', '1981', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', '', '', '', '', '0000-00-00', '', '', 'September', '2015', '', '', '0000-00-00', 'Greg & Ellen Thiele           (1) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('33', '19', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68701', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '1969-12-31', '1969-12-31', '', '', '', '', '2 patio doors', '', '', '', 'H1433/H1432             072-10154', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '1962', '', '0000-00-00', '', 'SDD', '2015-12-04', '1', '', '1969-12-31', '1', '', '1969-12-31', '1', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'September', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2015-12-04', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('34', '9', '', 'Single Property', '', '', 'Hartington', 'Choose One', '68001', 'Ordered', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2015-10-31', '1969-12-31', '', '', '', '', '7', '', '', '', '7', '0000-00-00', '', '1969-12-31', 'H1487                072-10151', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'ak', '2015-12-07', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'September', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('35', '21', '', 'Single Property', '3960 Lost Creek Dr.', '', 'Columbus', 'Nebraska', '68601', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Jeff ', '2015-10-31', '1969-12-31', '', '', '', '', '5', '', '5 windows                          072-10152', '#26693547', '', '0000-00-00', '', '1969-12-31', '', '', 'Windows w/ Wraps', '', '1969-12-31', '1999', '', '0000-00-00', '', 'bf', '2015-12-07', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', '', '', '', '', '1969-12-31', '', '', 'September', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('37', '24', '', 'Single Property', '2918 14th St.-Columbus', '', 'Columbus', 'Choose One', '68601', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Jeff ', '2015-10-31', '1969-12-31', '', '', '', '', '8', '', '8 windows                                    072-10146', '#26693537', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '?', '', '0000-00-00', '', 'bf', '2015-12-21', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'No', '', '', '', '', 'Insulate Cavities', '1969-12-31', '', 'Contract Sent', 'September', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '4705-0001-0113-5689

11-26-2015: Mailed WF Contract', '');
INSERT INTO customerTickets VALUES ('338', '3', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68701', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', '', '2015-12-18', '1969-12-31', '', '', '', '', '23', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2015-12-18', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2015-12-19', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('39', '26', '', '', '607 S. Boxelder', '', 'Norfolk', 'Nebraska', '68701', 'Ordered', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2015-10-31', '0000-00-00', '', '42.0265479', '-97.3987942', '', '4', '', '', '', '4', '0000-00-00', '', '0000-00-00', 'H1496               072-10153', '', 'Basic', 'Customer', '0000-00-00', '1982', '', '0000-00-00', '', 'Angi', '0000-00-00', '', 'Angi', '0000-00-00', '', 'Angi', '0000-00-00', '', 'Angi', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'September', '2015', '', '', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('40', '23', '', 'Single Property', '111 Park St.-Madison', '111 Park St.-Madison, NE 68748', 'Madison', 'Nebraska', '68748', 'Received', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '', '', '', '2', '', '2', '#26693538', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '1894', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'No', '', '', '', '', '', '0000-00-00', '', '', 'September', '2015', '', '', '0000-00-00', 'Josh Kruger', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('41', '22', '', 'Single Property', '314 Forest Dr', '', 'Norfolk', 'Nebraska', '68701', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '1969-12-31', '', '', '', '', '7', '', '7', '#26693543', '', '0000-00-00', '', '1969-12-31', '', '', 'Tough Install', '', '1969-12-31', '2006', '', '0000-00-00', '', 'hc', '2015-11-30', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '11/13/2015: Josh scheduled to Install', '1969-12-31', '', '', 'September', '2015', '', '', '0000-00-00', 'Kevin Gray', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '1969-12-31', '11/30/2015: Insurance company called. Said they paid Kevin already.', '');
INSERT INTO customerTickets VALUES ('42', '27', '', 'Single Property', '', '', 'Clearwater', 'Choose One', '68001', 'Sold', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '1969-12-31', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Tough Install', '', '1969-12-31', '', '', '0000-00-00', '', 'SDD', '2015-12-07', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'September', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('43', '28', '', '', '84826 561st Ave', '', 'Hoskins', 'Nebraska', '68740', 'Estimate', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mike ', '2015-10-31', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Prospective', '0000-00-00', '', '', '0000-00-00', '', 'Angi', '0000-00-00', '', 'Angi', '0000-00-00', '', 'Angi', '0000-00-00', '', 'Angi', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'September', '2015', '', '', '0000-00-00', 'John & Peg Beemer', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('44', '27', '', 'Single Property', '', '', 'Clearwater', 'Choose One', '68001', 'Sold', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '1969-12-31', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Single-Story', '', '1969-12-31', '', '', '0000-00-00', '', 'SDD', '2015-12-07', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'September', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('45', '29', '', 'Single Property', '1440 Eagle Ridge Circle', '', 'Pierce', 'Nebraska', '68767', 'Received', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '', '', '', '16', '', '16', '#26693555', '', '0000-00-00', '', '0000-00-00', '', '', 'Windows w/ Wraps', 'Customer', '0000-00-00', '2003', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', '', '', '', '', '0000-00-00', '', '', 'September', '2015', '', '', '0000-00-00', 'Bruce Brester', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('46', '30', '', 'Single Property', '831 S. 8th St.', '', 'Norfolk', 'Nebraska', '68701', 'Scheduled', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Dwayne', '2015-10-31', '1969-12-31', '', '', '', '', '7', '', '7', '#26678480', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '1911', '', '0000-00-00', '', 'SDD', '2015-12-07', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'No', '', '', '', '', '', '1969-12-31', '', '', 'September', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('47', '31', '', '', '305 W. Herman', '', 'Battle Creek', 'Nebraska', '68715', 'Scheduled', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Dwayne', '2015-10-31', '0000-00-00', '', '41.9985394', '-97.5995143', '', '1', '', '1', '#26670612', '', '0000-00-00', '', '0000-00-00', '', 'No', 'Basic', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'Angi', '0000-00-00', '', 'Angi', '0000-00-00', '', 'Angi', '0000-00-00', '', 'Angi', '0000-00-00', '', '', '', 'No', '', '', '', '', '', '0000-00-00', '', '', 'September', '2015', '', '', '0000-00-00', 'Don Wacker', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('48', '32', '', 'Single Property', '511 W. Wayne St', '', 'Randolph', 'Choose One', '68771', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '', '', '', '1 PD', '', '', '', '1 PD', '0000-00-00', '', '0000-00-00', 'T3959', '', 'Patio', 'Customer', '0000-00-00', '1972', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'No', '', '', '', '', '', '0000-00-00', '', '', 'September', '2015', '', '', '0000-00-00', 'Jack Sauser', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('49', '33', '', 'Single Property', '1105 Charolais Ave', '', 'Norfolk', 'Nebraska', '68701', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '', '', '', '12', '', '', '', '12', '0000-00-00', '', '0000-00-00', 'K1705', '', 'Windows w/ Wraps', 'Customer', '0000-00-00', '1988', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', '', '', '', '', '0000-00-00', '', '', 'September', '2015', '', '', '0000-00-00', 'Carol Schlismann', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('50', '34', '', 'Single Property', '306 Oak St.', '', 'Tilden', 'Nebraska', '68781', 'Received', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '', '', '', '3', '', '', '', '3', '0000-00-00', '', '0000-00-00', 'H2308', '', 'Basic', 'Customer', '0000-00-00', '1916', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'September', '2015', '', '', '0000-00-00', 'Justin Wilkinson', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('51', '34', '', 'Single Property', '306 Oak St.', '', 'Tilden', 'Choose One', '68781', 'Ordered', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2015-10-31', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Other', 'Prospective', '0000-00-00', '', '', '0000-00-00', '', 'kf', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'September', '2015', '', '', '0000-00-00', 'Justin Wilkinson', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('52', '25', '', 'Single Property', '601 Neuer St.', '', 'Clearwater', 'Nebraska', '68726', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '0000-00-00', '', '', '', '', '19', '', '19', '#26694062', '', '0000-00-00', '', '0000-00-00', '', '', 'Windows w/ Wraps', 'Customer', '0000-00-00', '1925', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', '', '', '', '11/4/2015: Josh scheduled to Install', '0000-00-00', '', '', 'September', '2015', '', '', '0000-00-00', 'Karol Michaels                (19 windows) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('53', '35', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68001', 'Scheduled', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '1969-12-31', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Double Hung', '', '1969-12-31', '', '', '0000-00-00', '', 'SDD', '2015-12-07', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'September', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('54', '19', '', 'Single Property', '', '', 'Norfolk', 'Nebraska', '68701', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2015-10-31', '0000-00-00', '', '', '', '', '4 PD', '', '', '', '4 PD', '0000-00-00', '', '0000-00-00', 'H8015', '', 'Patio', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'September', '2015', '', '', '0000-00-00', 'Steve & Theresa Perry', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('55', '36', '', 'Multiple Property', '', '308 Kent St', 'Madison', 'Nebraska', '68748', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '1969-12-31', '', '', '', '', '15', '', '15', '#26685136', '', '0000-00-00', '', '1969-12-31', '', '', 'Windows w/ Wraps', '', '1969-12-31', '1880', '', '0000-00-00', '', 'SDD', '2015-12-07', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', 'No', '', '', '', 'Job Installed by Josh', '1969-12-31', '', '', 'September', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('72', '4', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68001', 'Estimate', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Prospective', '0000-00-00', '', 'Yes', '2015-12-14', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'September', '2015', '', '', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', 'Window Repair', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('73', '40', '', 'Single Property', '', '', 'Schuyler', 'Choose One', '68661', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Karla ', '2015-10-31', '1969-12-31', '', '', '', '', '6', '', '', '', 'Cbus: 6', '0000-00-00', '', '1969-12-31', 'K0641', '', 'Windows w/ Wraps', '', '2015-12-03', '1976', '', '0000-00-00', '', 'hc', '2015-12-09', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('74', '41', '', 'Single Property', '', '', 'Columbus', 'Choose One', '68601', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Jeff ', '2015-10-31', '1969-12-31', '', '', '', '', '24', '', 'Cbus: 24', '#26697162', '', '0000-00-00', '', '1969-12-31', '', '', 'Windows w/ Wraps', '', '1969-12-31', '1935', '', '0000-00-00', '', 'bf', '2015-12-21', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', 'White', '', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('75', '41', '', 'Single Property', '', '', 'Columbus', 'Choose One', '68601', 'Ordered', '0000-00-00', '2015-12-21', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Hailey', '2015-10-31', '1969-12-31', '', '', '', '', '24', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Windows w/ Wraps', '', '1969-12-31', '', '', '0000-00-00', '', 'bf', '2015-12-21', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', 'White', '', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('76', '43', '', 'Single Property', '', '', 'Columbus', 'Choose One', '68601', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Jeff ', '2015-10-31', '1969-12-31', '', '', '', '', '3', '', '', '', 'Cbus: 3', '0000-00-00', '', '1969-12-31', 'K0650', '', 'Tough Install', '', '1969-12-31', '1955', '', '0000-00-00', '', 'bf', '2015-12-21', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'No', '', '', '', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('77', '44', '', 'Single Property', '', '', 'Columbus', 'Choose One', '68601', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Jeff ', '2015-10-31', '1969-12-31', '', '', '', '', '2', '', '', '', 'Cbus: 2', '0000-00-00', '', '1969-12-31', 'K0646', '', 'Windows w/ Wraps', '', '1969-12-31', '1980', '', '0000-00-00', '', 'bf', '2015-12-21', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', 'Other', 'Brown', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('78', '45', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68001', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '0000-00-00', '', '', '', '', '1 PD', '', '', '', '1PD', '0000-00-00', '', '0000-00-00', 'W0665', '', 'Patio', 'Customer', '0000-00-00', '1977', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'No', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Jim & Joyce Kuchar', '0000-00-00', '0000-00-00', '0000-00-00', 'Doors', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('79', '46', '', 'Single Property', '', '', 'York', 'Choose One', '68467', 'Complete', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', '', '2015-10-31', '1969-12-31', '', '', '', '', '15', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'bf', '2015-12-21', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'No', '', '', '', '', 'Needs L\'s', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', 'Check', '1969-12-31', '$4,950.00 PAID IN FULL', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('80', '47', '', 'Single Property', '', '', 'Wisner', 'Choose One', '68001', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '', '', '', '8', '', '6 & 2', '#26672021 & #26697607          ', '', '0000-00-00', '', '0000-00-00', '', '', 'Tough Install', 'Customer', '0000-00-00', '1900', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'No', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Ruby Jurgensen', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('81', '48', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68001', 'Installed', '0000-00-00', '0000-00-00', '0000-00-00', '2015-12-21', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '', '', '', '3', '', '3', '#26697703', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Custom Heating           (3) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('82', '49', '', 'Single Property', '', '', 'Platte Center', 'Choose One', '68653', 'Ordered', '0000-00-00', '2015-12-21', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Hailey', '2015-10-31', '1969-12-31', '', '', '', '', '4', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Windows w/ Wraps', '', '1969-12-31', '1915', '', '0000-00-00', '', 'bf', '2015-12-21', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', '', '', 'Yes', 'clay wraps cutout needs quarter round', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('83', '50', '', 'Multiple Property', '2812-2816 30th St.', '14022 X Rd        Shelby, NE 68662', 'Columbus', 'Nebraska', '68601', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Jeff ', '2015-10-31', '1969-12-31', '', '', '', '', '18', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Windows w/ Wraps', '', '1969-12-31', '1967', '', '0000-00-00', '', 'bf', '2015-12-21', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', 'White', '', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('84', '50', '', 'Multiple Property', '2812-2816 30th St.', '14022 X Rd       Shelby, NE 68662', 'Columbus', 'Nebraska', '68601', 'Ordered', '0000-00-00', '2015-12-21', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Karla ', '2015-10-31', '1969-12-31', '', '', '', '', '18', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Windows w/ Wraps', '', '2015-11-24', '1967', '', '0000-00-00', '', 'bf', '2015-12-21', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', 'No', 'White', '', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', 'Check', '1969-12-31', '2,000.00', '1969-12-31', '', '1969-12-31', 'HC mailed Inv. & PW', '');
INSERT INTO customerTickets VALUES ('85', '52', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68001', 'Scheduled', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Prospective', '0000-00-00', '', '', '0000-00-00', '', 'bf', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('86', '54', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68001', 'Proposal', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '', '', '', '1', '', '', '', '1', '0000-00-00', '', '0000-00-00', 'K8492', '', 'Windows w/ Wraps', 'Customer', '0000-00-00', '1986', '', '0000-00-00', '', 'SDD', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Dave & Jennifer Timmerman      (1) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('87', '9', '', 'DIY', '', '', 'Hartington', 'Choose One', '68001', 'Complete', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '0000-00-00', '', '', '', '', '1', '', '1', '#26698664', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'DONNA MEIER', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', 'Debit Card', '0000-00-00', '', '0000-00-00', '252.63', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('88', '28', '', 'Single Property', '', '', 'Hoskins', 'Choose One', '68001', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '', '', '', '1', '', '1', '', '#26698666', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Peg Beemer            (1)', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('89', '9', '', 'DIY', '', '', 'Hartington', 'Choose One', '68001', 'Complete', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '0000-00-00', '', '', '', '', '4', '', '4', '#26698670', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Prospective', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'FRANK ARENS', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', 'Debit Card', '0000-00-00', '', '0000-00-00', '1182.5', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('90', '49', '', 'Single Property', '', '', 'Platte Center', 'Choose One', '68653', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Brent ', '2015-10-31', '1969-12-31', '', '', '', '', '4', '', '', '', '4', '0000-00-00', '', '1969-12-31', 'K8525', '', 'Basic', '', '1969-12-31', '1915', '', '0000-00-00', '', 'bf', '2015-12-21', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', 'Desert Clay', '', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('91', '55', '', 'DIY', '', '', 'Neligh', 'Choose One', '68756', 'Complete', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', '', '2015-10-31', '1969-12-31', '', '', '', '', '4', '', '4', '#26698675', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'hc', '2015-12-14', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', 'Check', '1969-12-31', '', '1969-12-31', '1,433.80', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('92', '58', '', 'Multiple Property', '400 Blaine-Norfolk', 'PO Box 1833-Norfolk', 'Norfolk', 'Nebraska', '68701', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '0000-00-00', '', '', '', '', '9', '', '9', '#26698687', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Prospective', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'RUGOSA-400 BLAINE', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('93', '57', '', 'Multiple Property', 'Rental: 2315 22nd St-Columbus', '105 Morton Rd-Columbus', 'Columbus', 'Nebraska', '68601', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Jeff ', '2015-10-31', '1969-12-31', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'bf', '2015-12-21', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('94', '59', '', 'Single Property', '', '', 'Elgin', 'Choose One', '68001', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '', '', '', '4', '', '4', '#26698691', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Andy Starman         (4) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('95', '60', '', 'Single Property', '', '', 'Humphrey', 'Choose One', '68001', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '', '', '', '2', '', '2', '#26698718', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Crystal Foltz    (2) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('96', '61', '', 'Single Property', '', '', 'Clarkson', 'Choose One', '68629', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Jeff ', '2015-10-31', '2015-10-05', '10187', '', '', '', '20', '', '20', '#26706699', '', '0000-00-00', '', '2015-12-01', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'hc', '2015-12-09', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('97', '62', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68001', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '', '', '', '1', '', '', '', '1', '0000-00-00', '', '0000-00-00', 'K9232', '', 'Windows w/ Wraps', 'Customer', '0000-00-00', '1962', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Richard Grenz             (1) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('98', '63', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68001', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '1969-12-31', ' #10246', '', '', '', '5', '', '5 windows', '#26711042', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'hc', '2015-11-24', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', 'Richard Buckendahl            (5) ', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('99', '64', '', 'Single Property', '', '', 'Brunswick', 'Choose One', '68001', 'Sold', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Single-Story', 'Prospective', '0000-00-00', '', '', '0000-00-00', '', 'bf', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', 'Siding', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('100', '65', '', 'Single Property', '', '', 'Stanton', 'Choose One', '68779', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '1969-12-31', '10263', '', '', '', '7', '', '', '', '7 ', '0000-00-00', '', '1969-12-31', 'T6615', '', 'Windows w/ Wraps', '', '1969-12-31', '1918', '', '0000-00-00', '', 'hc', '2015-12-10', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', 'White', '', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('101', '66', '', 'Single Property', '', '', 'Tilden', 'Choose One', '68001', 'Scheduled', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Prospective', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('102', '67', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68001', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '0000-00-00', '', '', '', '', '6+1PD', '', '', '', '6 windows 1 patiodoor - 072-10054', '0000-00-00', '', '0000-00-00', 'Y7184', '', 'Tough Install', 'Customer', '0000-00-00', '1999', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', 'White', '', '', 'wrap outside and quarterround inside and expander', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Paul & Deb Allpress          (6+1PD) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('103', '69', '', 'Single Property', '216 N. 5th St.', '', 'Pierce', 'Nebraska', '68767', 'Pending Wrap', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '1969-12-31', '', '42.2001066', '-97.5298144', '', '10', '', '10', '#26691225', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '1956', '', '0000-00-00', '', 'bf', '2015-12-23', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', 'No', 'White', '', '', '10/8/15: Still need to wrap(Maybe have Travis)', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('104', '70', '', 'Single Property', '', '', 'David City', 'Choose One', '68632', 'Complete', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Karla ', '2015-10-31', '1969-12-31', '', '', '', '', '3', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'bf', '2015-12-21', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'No', '', '', '', '', 'Needs quarterround.', '1969-12-31', '', 'Paid', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '10/8/15: Mailed WF Contract for $1,150(12 months)(4705-0001-0106-3188)

', '');
INSERT INTO customerTickets VALUES ('105', '71', '', 'Single Property', '', '', 'Leigh', 'Choose One', '68001', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '0000-00-00', '', '', '', '', '4', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Windows w/ Wraps', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', 'Yes', 'White', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Janelle Fischer            (4 windows) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '4', '#26648765', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('106', '72', '', 'Single Property', '', '', 'Columbus', 'Choose One', '68001', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '0000-00-00', '', '', '', '', '4', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '2006', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'No', 'Yes', '', '', '', 'Quarterround Inside', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Golden Living Center        (4 windows) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '4', 'B3247', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('107', '73', '', 'Single Property', '', '', 'Columbus', 'Choose One', '68601', 'Complete', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Karla ', '2015-10-31', '1969-12-31', '', '', '', '', '11', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '1920', '', '0000-00-00', '', 'bf', '2015-12-21', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'Insulate Cavities
paid in full check and wells fargo - 11/10/15', '1969-12-31', '', 'Contract Sent', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '840', '1969-12-31', '10/12/15: Mailed WF Contract', '');
INSERT INTO customerTickets VALUES ('108', '74', '', 'Single Property', '', '', 'Columbus', 'Choose One', '68001', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '0000-00-00', '', '', '', '', '6', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Windows w/ Wraps', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', 'Yes', 'Other', 'Brown or Beige', '', 'Dark Oak QR', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Everlasting Love Church     (6 windows) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '6', 'W0706', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('109', '75', '', 'Single Property', '', '', 'Columbus', 'Choose One', '68001', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '0000-00-00', '', '', '', '', '1 PD', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Patio', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', 'Yes', 'Other', 'Brown', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Santiago Vasquez         (1 PD) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Doors', '0000-00-00', '', '', '1 PD', 'Z7723', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('110', '76', '', 'Single Property', '', '', 'Humphrey', 'Choose One', '68001', 'Scheduled', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Prospective', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Patty Silva', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('111', '77', '', 'Single Property', '', '', 'Albion', 'Choose One', '68001', 'Complete', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '0000-00-00', '', '', '', '', '1 Entry Door', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Entry Door', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'No', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Lanny & Jeannie Young', '0000-00-00', '0000-00-00', '0000-00-00', 'Door Repair', '0000-00-00', '#26657281', '', '', '', 'Check', '0000-00-00', '1,850', '0000-00-00', '1,850', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('112', '78', '', 'Single Property', '', '', 'Clarkson', 'Choose One', '68629', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '1969-12-31', '', '', '', '', '8+1PD', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '2015-02-11', '', '', '0000-00-00', '', 'hc', '2015-12-16', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', 'Yes', '', '', '', '', '1969-12-31', '', 'Contract Sent', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '4705-0001-0099-7212
12 months
$5,450
12-16-15: HC mailed contract
', '');
INSERT INTO customerTickets VALUES ('332', '272', '', 'Single Property', '', '', 'Columbus', 'Choose One', '68601', 'Ordered', '0000-00-00', '2015-12-21', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Hailey', '2015-12-17', '2015-12-17', '072-10297', '', '', '', '20 windows', '', '20 ', '26722219', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'bf', '2015-12-21', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', '', '', '', '', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2015-12-02', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('113', '81', '', 'Single Property', '', '', 'West Point', 'Choose One', '68001', 'Proposal Given', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '2015-12-24', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Windows w/ Wraps', 'Prospective', '0000-00-00', '', '', '0000-00-00', '', 'bf', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', 'White', '', '', 'tested for lead already and she signed ', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('114', '82', '', 'Single Property', '', '', 'West Point', 'Choose One', '68001', 'Sold', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Windows w/ Wraps', 'Prospective', '0000-00-00', '', '', '0000-00-00', '', 'bf', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', 'No', 'Architechal Bronze', '', 'No', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('115', '79', '', 'Single Property', '', '', 'Osmond', 'Choose One', '68001', 'Ordered', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2015-10-31', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Larry Krohn                (Sash) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Window Repair', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('116', '83', '', 'Single Property', '', '', 'Stanton', 'Choose One', '68779', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2015-10-31', '2015-12-10', '', '', '', '', '4 Balances', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Other', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2015-12-22', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '(4) Balances for 2 different windows
Original: 123-790645, 644', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('117', '84', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68001', 'Ordered', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2015-10-31', '0000-00-00', '', '', '', '', '1 PD', '', '', '', '1 PD        #10193', '0000-00-00', '', '0000-00-00', '', '', 'Patio', 'Customer', '0000-00-00', '1966', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'No', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Michael Kuester', '0000-00-00', '0000-00-00', '0000-00-00', 'Doors', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('118', '85', '', 'Single Property', '', '', 'Emerson', 'Choose One', '68001', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '', '', '', '5', '', '5      #10192', '#26701055', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Rich & Theresa Anderson (5) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('119', '86', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68001', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '1969-12-31', '1969-12-31', '#10191', '', '', '', '3', '', '3    ', '26701054', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '1965', '', '0000-00-00', '', 'hc', '2015-12-04', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'No', '', '', '', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', 'Dave Carter', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('120', '87', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68001', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '', '', '', '9', '', '9     #10190', '#26701053', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '1962', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Corey Schmidt       (9) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('121', '82', '', 'Single Property', '', '', 'West Point', 'Choose One', '68001', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '0000-00-00', '', '', '', '', '4', '', '', '', '4             #10189', '0000-00-00', '', '0000-00-00', 'M1541', '', 'Windows w/ Wraps', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Larry Petz                (4) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('122', '88', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68001', 'Scheduled', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Prospective', '0000-00-00', '', '', '0000-00-00', '', 'kf', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('123', '89', '', 'Single Property', '1501 Syracuse', '', 'Norfolk', 'Nebraska', '68701', 'Incomplete', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '1969-12-31', '', '42.0487587', '-97.4303159', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'bf', '2015-12-23', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'sash and screen i already fixed the screen

window is leaeking air bad and dwayne check out downpouts and south side old gutters nails need to be pushed in and something done with extension', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('124', '90', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68001', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2015-10-31', '0000-00-00', '', '', '', '', '1 PD', '', '', '', '1 PD', '0000-00-00', '', '0000-00-00', 'C7608', '', 'Patio', 'Customer', '0000-00-00', '1978', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'No', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Chad Jochum       (1PD)', '0000-00-00', '0000-00-00', '0000-00-00', 'Doors', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('125', '91', '', 'Single Property', '', '', 'Wakefield', 'Choose One', '68001', 'Estimate', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Windows w/ Wraps', 'Prospective', '0000-00-00', '1976', '', '0000-00-00', '', 'bf', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', 'No', 'White', '', '', 'need to bring in flush with drywall and new 3 1/4 casing she will pick out from carhart prefinished white ', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Ken Pettit         (Window Estimate)', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('126', '92', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68001', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '0000-00-00', '', '', '', '', '6', '', '6', '#26691502', '', '0000-00-00', '', '0000-00-00', '', '', 'Windows w/ Wraps', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', 'No', 'Other', 'Charcoal Gray', '', 'Needs Dark Gray Trim

11/9/2015: Scheduled Install Date(Mark) ', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Merry Braun    (6)', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('127', '93', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68001', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-12', '2015-10-12', ' #10129', '', '', '', '2', '', '2                     ', '#26691221', '', '0000-00-00', '', '1969-12-31', '', '', 'Windows w/ Wraps', '', '1969-12-31', '1935', '', '0000-00-00', '', 'hc', '2015-12-04', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', 'Other', 'Green??', '', '12/7/2015: Scheduled to Install(Dwayne) ', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', 'Dennis & Mary Mrsny        (2)', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('128', '95', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68001', 'Estimate', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Paul & Shannon Filsinger', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('129', '96', '', 'Single Property', '', '', 'Pilger', 'Choose One', '68001', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '0000-00-00', '', '', '', '', '23 SQ', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Two-Story', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Brian Anderson', '0000-00-00', '0000-00-00', '0000-00-00', 'Siding', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('130', '98', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68001', 'Estimate', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Prospective', '0000-00-00', '', '', '0000-00-00', '', 'bf', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('131', '99', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68001', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '0000-00-00', '', '', '', '', '7', '', '7', '#26665554', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Tony Hoffman', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', 'Check', '0000-00-00', '', '0000-00-00', 'Paid In Full', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('132', '100', '', 'Single Property', '303 S. Boyer', '', 'Battle Creek', 'Nebraska', '68715', 'Paid', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '2015-12-28', '2015-12-28', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '1969-12-31', '', '41.9974669', '-97.5956062', '', '4', '', '', '', '4', '0000-00-00', '', '1969-12-31', 'Y5259', '', 'Basic', '', '1969-12-31', '1900', '', '0000-00-00', '', 'ak', '2015-12-28', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'No', '', '', '', '', '', '1969-12-31', '', 'Paid', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '4705-0001-0073-1447
12 Months', '');
INSERT INTO customerTickets VALUES ('133', '101', '', 'Single Property', '430 St               47893 400th St-Lindsay', '', 'Newman Grove', 'Nebraska', '68758', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '2015-12-23', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '1969-12-31', '', '41.7500096', '-97.7753327', '', '3', '', 'Cbus: 3', '#26702195', '', '0000-00-00', '', '1969-12-31', '', '', 'Windows w/ Wraps', '', '1969-12-31', 'X', '', '0000-00-00', '', 'HBC', '2015-12-23', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', '', '', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('134', '102', '', 'Single Property', '', '', 'Columbus', 'Choose One', '68601', 'Ordered', '0000-00-00', '2015-12-21', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Hailey', '2015-10-31', '1969-12-31', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'bf', '2015-12-21', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('135', '103', '', 'Single Property', '', '', 'Humphrey', 'Choose One', '68001', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '0000-00-00', '', '', '', '', '6', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Dean Korus', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '6', '26678030', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('136', '106', '', 'Single Property', '', '', 'Howells', 'Choose One', '68001', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '', '', '', '14', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Tough Install', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', 'ordered from contractors 10/19/2015 kasey email', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Mary Rocheford           siding (charter oak)(coastal sage)(dutchlap)', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('137', '80', '', 'Single Property', '', '', 'Wayne', 'Choose One', '68001', 'Complete', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '0000-00-00', '', '', '', '', '1', '', '', '', '1', '0000-00-00', '', '0000-00-00', 'F8541', '', 'Basic', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', 'No Wrap needed-per Jon Arens', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Gena Luhr-Puls            (1 window) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', 'Debit Card', '0000-00-00', '', '0000-00-00', '315', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('138', '107', '', 'Single Property', '', '', 'Madison', 'Choose One', '68001', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '0000-00-00', '', '', '', '', '4', '', '4', '#26665549', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '1900', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'No', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Mick & Kim Vogt         (4)', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('139', '108', '', 'Single Property', '', '', 'Wayne', 'Choose One', '68001', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '0000-00-00', '', '', '', '', '18', '', '18', '#26691226', '', '0000-00-00', '', '0000-00-00', '', '', 'Windows w/ Wraps', 'Customer', '0000-00-00', '1906', '', '0000-00-00', '', 'hc', '0000-00-00', '1', '', '0000-00-00', '1', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'No', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Chris & Jenn Geidner    (18)', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('140', '109', '', 'Multiple Property', '919 Windom-Wayne', '1120 Douglas', 'Wayne', 'Nebraska', '68787', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '0000-00-00', '', '', '', '', '1-Used 2 from Sin bin(3 total) ', '', '', '', '3 (used 2 from Sinbin) ', '0000-00-00', '', '0000-00-00', 'F8525(1)            D4154(2)        ', '', 'Basic', 'Prospective', '0000-00-00', 'X', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'No', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Gary Boehle      (3) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('141', '38', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68701', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2015-10-31', '2015-10-16', '', '', '', '', '2 DO Case Handles', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Other', '', '1969-12-31', '', '', '0000-00-00', '', 'bf', '2015-12-23', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '2 Dark Oak Casement Handles(UNDER HC DESK)', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('142', '111', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68001', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '0000-00-00', '', '', '', '', '3', '', '3', '#26666507', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '1930', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'No', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Andrea Rodriguez       (3 windows) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('143', '110', '', 'Single Property', '', '', 'Creston', 'Choose One', '68001', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '0000-00-00', '', '', '', '', '6', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Travis Wemhoff            (6)', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '6', '#26679183', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('144', '110', '', 'Single Property', '', '', 'Creston', 'Choose One', '68001', 'Ordered', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2015-10-31', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Travis Wemhoff           (Screen) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Window Repair', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('145', '100', '', 'Single Property', '', '', 'Battle Creek', 'Choose One', '68715', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2015-10-31', '1969-12-31', '', '', '', '', '1 Bottom Sash', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Double Hung', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2015-12-22', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '(1) Bottom Sash
Original: 129-154803
Reason: Glass Crack', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('146', '112', '', 'DIY', '', '', 'Norfolk', 'Choose One', '68001', 'Complete', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2015-10-31', '0000-00-00', '', '', '', '', '1', '', '1', '#26703473', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Lance Novacek      (DIY; 1)', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('147', '114', '', 'Multiple Property', '608 E. 4th St. ', '', 'Neligh', 'Nebraska', '68756', 'Ordered', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2015-10-31', '0000-00-00', '', '', '', '', '1', '', '1 WINDOW - 072-10202', '#26704047', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'kf', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Frank Morrison      (1) --cancelled we found window in back', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('148', '115', '', 'Single Property', '', '', 'Ulysses', 'Choose One', '68669', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Jeff ', '2015-10-31', '2015-10-20', '', '', '', '', '11', '', '11', '26704048', '1 PD', '0000-00-00', '', '2015-12-07', 'N7266', '', 'Basic', '', '1969-12-31', '2001', '', '0000-00-00', '', 'hc', '2015-12-09', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'No', '', '', '', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('149', '116', '', 'Single Property', '', '', 'Columbus', 'Choose One', '68601', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '1969-12-31', '#10201', '', '', '', '6', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '2015-11-25', '', '', '0000-00-00', '', 'hc', '2015-12-14', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'No', '', '', '', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('150', '117', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68001', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '', '', '', '3', '', '', '', '3 - 10200', '0000-00-00', '', '0000-00-00', 'N7250', '', 'Windows w/ Wraps', 'Customer', '0000-00-00', '1984', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', 'Beige', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Curt Nielsen        (3)', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('151', '118', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68701', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '1969-12-31', '10199', '', '', '', '1', '', '1 WINDOW -', '#26704031', '', '0000-00-00', '', '1969-12-31', '', '', 'Tough Install', '', '2015-12-08', '2004', '', '0000-00-00', '', 'hc', '2015-12-08', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'No', '', '', '', '', '12/10/2015: Mark Scheduled to Install.', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('152', '72', '', 'Single Property', '', '', 'Columbus', 'Choose One', '68601', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '2015-10-20', '10204', '', '', '', '1', '', '', '', '1', '0000-00-00', '', '2015-12-02', 'N7269', '', 'Windows w/ Wraps', '', '2015-12-09', '2006', '', '0000-00-00', '', 'hc', '2015-12-09', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', '', '', '', '12/3/2015: Jeff installed.', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('153', '120', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68001', 'Complete', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '0000-00-00', '', '', '', '', '4', '', '', '', '4', '0000-00-00', '', '0000-00-00', 'L3349', '', 'Basic', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'kf', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Susan Askew      (4 windows) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', 'Check', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('154', '120', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68001', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '0000-00-00', '', '', '', '', '20 Sq.', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Susan Askew        (siding) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('155', '121', '', 'Single Property', '', '', 'Wakefield', 'Choose One', '68001', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '', '', '', '10', '', '9 WINDOWS - 10205', '#26704056', '1 WINDOW - 10205', '0000-00-00', '', '0000-00-00', 'N7311', '', 'Basic', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Joel Kratke /Sandra Bruns            (10)', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('156', '122', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68001', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '', '', '', '1', '', '', '', '1 WINDOW - 10216', '0000-00-00', '', '0000-00-00', 'N7319', '', 'Basic', 'Customer', '0000-00-00', '1986', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Willard Hart       (1) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('157', '123', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68001', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '0000-00-00', '', '', '', '', '2', '', '', '', '2', '0000-00-00', '', '0000-00-00', 'D8795', '', 'Windows w/ Wraps', 'Customer', '0000-00-00', '1920', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', 'No', 'Other', 'Autumn Red', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Sara McClary', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('158', '124', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68001', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '', '', '', '1', '', '1', '#26704279', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'No', '', '', '', '', 'need to pull down siding but he will put new siding up may need to cut back drywall and stool board and quarter round

11/16/2015: Mark scheduled to Instal', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Larry Sohler        (1)          ASAP-Broke Out', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('357', '292', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68701', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2015-12-21', '1969-12-31', '', '', '', '', '2 sashes', '', '', '', '', '0000-00-00', '', '1969-12-31', 'New: N8466; 129-298685 129-298483', '', 'Double Hung', '', '1969-12-31', '', '', '0000-00-00', '', 'bf', '2015-12-23', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('160', '126', '', 'Single Property', '', '', 'Duncan', 'Choose One', '68634', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Brent ', '2015-10-31', '1969-12-31', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'bf', '2015-12-21', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Siding', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('161', '124', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68001', 'Sold', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2015-10-31', '0000-00-00', '', '', '', '', '', '', '1 window- 10207', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Prospective', '0000-00-00', '', '', '0000-00-00', '', 'kf', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('162', '127', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68001', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '', '', '', '7', '', '7 - windows - 10209', '#26704592', '', '0000-00-00', '', '0000-00-00', '', '', 'Windows w/ Wraps', 'Customer', '0000-00-00', '1966', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', 'No', 'Other', 'royal brown', 'Yes', 'may need stop for outside kind of weird window', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Gilbert Grimm          (7)', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('163', '128', '', 'DIY', '', '', 'Meadow Grove', 'Choose One', '68752', 'Complete', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', '', '2015-10-31', '1969-12-31', '', '', '', '', '1', '', '1- 10209', '#26704591', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'hc', '2015-12-14', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'she needs plugs for patio door ordered from mi 
Brent ordered Plugs: 10-21-15', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', 'Check', '1969-12-31', '', '1969-12-31', '268.75', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('291', '239', '', 'Single Property', '', '', 'Albion', 'Choose One', '68620', 'Complete', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', '', '2015-10-31', '1969-12-31', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'hc', '2015-12-11', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '12-10-2015: HC mailed parts to customer', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('165', '130', '', 'Single Property', '', '', 'Columbus', 'Choose One', '68001', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '0000-00-00', '', '', '', '', '11', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Tough Install', 'Customer', '0000-00-00', '1984', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Nancy Karmann         (11) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '11', '#26687508', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('343', '279', '', 'Single Property', '', '', 'Osmond', 'Choose One', '', 'Need Estimate', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-12-21', '1969-12-31', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2015-12-21', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('167', '132', '', 'Single Property', '', '', 'Meadow Grove', 'Choose One', '68001', 'Sold', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Tough Install', 'Prospective', '0000-00-00', '', '', '0000-00-00', '', 'bf', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', 'bay window need monteray j-channel ', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('168', '134', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68001', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '0000-00-00', '', '', '', '', '10 + 1 PD', '', '', '', '10 + 1PD', '0000-00-00', '', '0000-00-00', 'C7594             C7595', '', 'Basic', 'Prospective', '0000-00-00', '1986', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', 'White', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Ryan Baumgard          (10+1PD) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('169', '135', '', 'Multiple Property', 'Cabin in Monowi', '426 S 5th St.', 'Pierce', 'Nebraska', '68767', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '0000-00-00', '', '', '', '', '3', '', '3', '#26645765', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', 'Yes', 'Beige', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Al Collison      (3-Cabin) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('170', '136', '', 'Multiple Property', '3018 28th St.-Columbus', '18428 280th St.', 'Columbus', 'Nebraska', '68601', 'Complete', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Karla ', '2015-10-31', '1969-12-31', '', '', '', '', '16', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'bf', '2015-12-21', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', 'Check', '1969-12-31', '', '1969-12-31', '6410', '1969-12-31', 'paid in full 10/31/15', '');
INSERT INTO customerTickets VALUES ('171', '136', '', 'Single Property', '', '', 'Columbus', 'Choose One', '68601', 'Ordered', '0000-00-00', '2015-12-21', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Hailey', '2015-10-31', '1969-12-31', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'bf', '2015-12-21', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('172', '137', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68001', 'Complete', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '0000-00-00', '', '', '', '', '8', '', '8', '#26679186', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '1920', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', '', '', '', 'Job Installed by Dwayne', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Pete & Kathy  Hastreiter              (8 windows) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', 'Debit Card', '0000-00-00', '', '0000-00-00', '3,930.00', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('173', '138', '', 'Single Property', '', '', 'Columbus', 'Choose One', '68001', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '2015-12-24', '0000-00-00', '0000-00-00', '2015-12-24', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '0000-00-00', '', '', '', '', '5+ 1 PD', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', 'Yes', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Deb Kallenbach         (5+1PD)', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '5', '#26644236', '1 PD', 'C4068', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('174', '139', '', 'Multiple Property', '704 Division St-Fullerton', 'PO Box 245', 'Genoa', 'Nebraska', '68640', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '0000-00-00', '', '', '', '', '7', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '1910', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'No', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Corey Pilakowski      (7)', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '7', '#26679021', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('175', '140', '', 'Single Property', '', '', 'Wayne', 'Choose One', '68001', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '0000-00-00', '', '', '', '', '17', '', '17', '#26691229', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '1920', '', '0000-00-00', '', 'hc', '0000-00-00', '1', '', '0000-00-00', '1', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Tiffani & Lee Stegemann', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('176', '140', '', 'Single Property', '', '', 'Wayne', 'Choose One', '68001', 'Ordered', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Prospective', '0000-00-00', '', '', '0000-00-00', '', 'kf', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', 'need to build out window and wrap ', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'natural linene charter oak dutchlap siding ordered from contractors for future 10/23/15', '0000-00-00', '0000-00-00', '0000-00-00', 'Siding', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('177', '142', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68001', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2015-10-31', '0000-00-00', '', '', '', '', '1 PD', '', '', '', '1 PD', '0000-00-00', '', '0000-00-00', 'D8759', '', 'Patio', 'Customer', '0000-00-00', '1964', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'No', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Jeff Russo            (1PD) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Doors', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('178', '143', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68001', 'Ordered', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2015-10-31', '0000-00-00', '', '', '', '', '3', '', '3 windows - 10211', '#26706058', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '1989', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Roger Borgman        (3)', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('179', '144', '', 'Multiple Property', '2904 6th St.-Columbus', '315 Pershing Rd', 'Columbus', 'Nebraska', '68601', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Jeff ', '2015-10-31', '2015-10-21', '10211', '', '', '', '4', '', '4', '26706057', '', '0000-00-00', '', '2015-12-07', '', '', 'Basic', '', '1969-12-31', '1900', '', '0000-00-00', '', 'hc', '2015-12-09', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'No', '', '', '', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('180', '145', '', 'Single Property', '', '', 'Shelby', 'Choose One', '68662', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Jeff ', '2015-10-31', '2015-10-26', '10213', '', '', '', '5', '', '', '', '5', '0000-00-00', '', '2015-12-07', 'P8282', '', 'Basic', '', '1969-12-31', '1928', '', '0000-00-00', '', 'hc', '2015-12-09', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', 'No', 'Other', 'Brown', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('181', '146', '', 'Single Property', '2960 18th Ave.', '', 'Columbus', 'Nebraska', '68601', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '2015-12-23', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Karla ', '2015-10-31', '2015-10-21', '', '41.4449853', '-97.3494501', '', '1', '', '', '', '', '0000-00-00', '', '2015-12-07', '', '', 'Windows w/ Wraps', '', '1969-12-31', '1965', '', '0000-00-00', '', 'HBC', '2015-12-23', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', 'No', 'White', '', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('182', '149', '', 'Single Property', '', '', 'Lindsay', 'Choose One', '68644', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '2015-10-21', '', '', '', '', '4', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '2015-12-08', '1976', '', '0000-00-00', '', 'hc', '2015-12-08', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '12/9/2015: Dwayne Scheduled to Install.', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('183', '148', '', 'Multiple Property', '55016 1/2 Rd-Norfolk', '54345 550th Rd', 'Norfolk', 'Nebraska', '68701', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '0000-00-00', '', '', '', '', '14', '', '', '', '14', '0000-00-00', '', '0000-00-00', 'F0842', '', 'Basic', 'Customer', '0000-00-00', '?', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Bob Pollack', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('184', '150', '', 'Single Property', '', '', 'Columbus', 'Choose One', '68601', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Jeff ', '2015-10-31', '2015-10-26', '10215', '', '', '', '3', '', '3', '26706046', '', '0000-00-00', '', '2015-12-09', '', '', 'Basic', '', '1969-12-31', '1920', '', '0000-00-00', '', 'hc', '2015-12-09', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', 'No', 'White', '', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('185', '151', '', 'Single Property', '729 S. 11th St.', '', 'Norfolk', 'Nebraska', '68701', 'Paid', '2015-12-17', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '2015-12-24', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '2015-11-24', '10273', '42.0239193', '-97.4215677', '', '6 windows', '', '6', '26716407', '', '0000-00-00', '', '1969-12-31', '', '', 'Windows w/ Wraps', '', '2015-12-21', '1915', '', '0000-00-00', '', 'bf', '2015-12-24', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', 'Other', 'Brandy Wine', 'Yes', 'Jerry told Customer we would get installed by end of the year.

12-21-15: Scheduled Install Date(Dwayne) ', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('186', '152', '', 'Multiple Property', '917  Pierce St.', '', 'Norfolk', 'Choose One', '68701', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2015-10-31', '2015-10-27', '', '', '', '', '1 Upper Sash', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Double Hung', '', '1969-12-31', '', '', '0000-00-00', '', 'bf', '2015-12-23', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '(1) Upper Sash
Original: 125-742958', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('187', '132', '', 'Single Property', '', '', 'Meadow Grove', 'Choose One', '68752', 'Complete', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2015-10-31', '1969-12-31', '', '', '', '', '3', '', '1 bay (3) - 10216', '#26706647', '', '0000-00-00', '', '1969-12-31', '', '', 'Tough Install', '', '1969-12-31', '1989', 'Yes', '2015-12-09', '', 'kf', '2015-12-17', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', '', '', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('188', '64', '', 'Single Property', '', '', 'Brunswick', 'Choose One', '68720', 'Paid', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '2015-12-18', '2015-12-29', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '1969-12-31', '', '', '', '', '10', '', '10 - 10217', '26706352', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '2015-12-17', '1916', '', '0000-00-00', '', 'HBC', '2015-12-18', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'No', '', '', '', '', '12/17/2015: Dwayne scheduled to Install', '1969-12-31', '', 'Contract Sent', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '4705-0001-0114-9979
12 months  $3,700
12-18-2015: Mailed WF Contract', '');
INSERT INTO customerTickets VALUES ('189', '148', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68001', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '', '', '', '1', '', '', '', '1 window - 10218', '0000-00-00', '', '0000-00-00', 'P9146', '', 'Basic', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '11-16/2015: Mark Scheduled to Install', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Bob Pollack      (1-short on original order) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('190', '153', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68001', 'Paid', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '2015-12-23', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '', '', '', '3', '', '3 windows - 10219', '#26706429', '', '0000-00-00', '', '0000-00-00', '', '', 'Windows w/ Wraps', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Brian Lind   (3)', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('191', '141', '', 'Single Property', '', '', 'Schuyler', 'Choose One', '68661', 'Installed', '0000-00-00', '0000-00-00', '0000-00-00', '2015-12-21', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Brent ', '2015-10-31', '1969-12-31', '', '', '', '', '9', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '??', '', '0000-00-00', '', 'bf', '2015-12-21', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'No', '', '', '', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('192', '112', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68001', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '', '', '', '1', '', '1 - window - 10221', '#26706696', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Prospective', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Lance Novacek    (1) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('193', '154', '', 'Single Property', '', '', 'Tilden', 'Choose One', '68781', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '2015-10-27', '10222', '', '', '', '1 PD', '', '', '', '1 PD', '0000-00-00', '', '1969-12-31', 'Q1039', '', 'Basic', '', '1969-12-31', '1970', '', '0000-00-00', '', 'hc', '2015-12-08', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'No', '', '', '', '', '12/9/2015: Mark scheduled to Install.', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Doors', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('194', '61', '', 'Single Property', '', '', 'Clarkson', 'Choose One', '68629', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Jeff ', '2015-10-31', '1969-12-31', '10223', '', '', '', '1', '', '1', '#26706699', '', '0000-00-00', '', '2015-12-01', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'hc', '2015-12-09', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('195', '155', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68701', 'Complete', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '1969-12-31', '', '', '', '', '3', '', '3 windows - 10224', '#26706700', '', '0000-00-00', '', '1969-12-31', '', '', 'Windows w/ Wraps', '', '1969-12-31', '1990', '', '0000-00-00', '', 'kf', '2015-12-17', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', '', '', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('196', '156', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68701', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '2015-10-27', '10225', '', '', '', '1', '', '1 ', '#26706702', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '1995', '', '0000-00-00', '', 'hc', '2015-12-10', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', '', '', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('197', '48', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68701', 'Complete', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '1969-12-31', '', '', '', '', '4', '', '4 - windows #10226', '#26707146', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'bf', '2015-12-10', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('198', '158', '', 'Single Property', '', '', 'Coleridge', 'Choose One', '68727', 'Paid', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '2015-12-22', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '1969-12-31', '10228', '', '', '', '2', '', '2 windows - ', '26707359', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '1970', '', '0000-00-00', '', 'HBC', '2015-12-22', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', 'Yes', 'White', '', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', 'Check', '1969-12-31', '', '1969-12-31', '8,215.00', '2015-12-22', '', '');
INSERT INTO customerTickets VALUES ('199', '159', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68701', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '2015-10-28', '10227', '', '', '', '6', '', '6 ', '26707255', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '1980', '', '0000-00-00', '', 'hc', '2015-12-10', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('200', '160', '', 'Single Property', '2104 skyline ', '', 'Norfolk', 'Nebraska', '68701', 'Paid', '2015-12-17', '2015-12-17', '0000-00-00', '2015-12-17', '', '0000-00-00', '2015-12-24', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '2015-12-14', '072-10292', '42.0448138', '-97.4397417', '', '1 WINDOW', '', '1', '26721141', '', '0000-00-00', '', '1969-12-31', '', '', 'Windows w/ Wraps', '', '1969-12-31', '1975', '', '0000-00-00', '', 'bf', '2015-12-24', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', 'Forest Green', '', 'Yes', 'Sold back in November. Must have forgot to order. Need to install right when this comes in.', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2015-02-11', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('397', '161', '', 'Single Property', '508 logan', '', 'Wayne', 'Nebraska', '68787', 'Needs Measured', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-12-23', '1969-12-31', '', '42.2336513', '-97.0163863', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Double Hung', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2015-12-23', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '1');
INSERT INTO customerTickets VALUES ('202', '162', '', 'Single Property', '', '', 'Columbus', 'Choose One', '68001', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '0000-00-00', '', '', '', '', '3', '', '', '', '3', '0000-00-00', '', '0000-00-00', 'S3573        S3574', '', 'Basic', 'Customer', '0000-00-00', '1977', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Terri Davis       (3) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('203', '163', '', 'Single Property', '', '', 'Albion', 'Choose One', '68001', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '0000-00-00', '', '', '', '', '2', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '1925', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'No', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Wanda Wondercheck      (2)', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '2', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('204', '164', '', 'Single Property', '', '', 'Columbus', 'Choose One', '68601', 'Complete', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Karla ', '2015-10-31', '1969-12-31', '', '', '', '', '3', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Windows w/ Wraps', '', '1969-12-31', '1968', '', '0000-00-00', '', 'bf', '2015-12-21', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', 'Yes', '', '', '', 'paid in full but says on double casement can\'t open either side but filled out her referral letter happy', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('205', '165', '', 'Multiple Property', '205 N. 7th St-Newman Grove', 'PO Box 417', 'Humphrey', 'Nebraska', '68642', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '0000-00-00', '', '', '', '', '5', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Windows w/ Wraps', 'Customer', '0000-00-00', '1892', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Justin Wetjen       (5)', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '5', '26687504', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('206', '166', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68001', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '0000-00-00', '', '', '', '', '6', '', '6', '#26665551', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '1974', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'No', '', '', '', '', '', '0000-00-00', '', 'Contract Sent', 'October', '2015', '', '', '0000-00-00', 'Robert Oswald        (6) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '4705-0001-0103-7596
$2,750.00
12 months', '');
INSERT INTO customerTickets VALUES ('207', '166', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68001', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '0000-00-00', '', '', '', '', '1', '', '1', '26679733', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '1974', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'No', '', '', '', '', '', '0000-00-00', '', 'Contract Sent', 'October', '2015', '', '', '0000-00-00', 'Robert Oswald         (1-had to reorder-used old one on Neighborworks) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '10/29/2015:  HC mailed WF contract
4705-0001-0103-7596
$2,750.00
12 Months', '');
INSERT INTO customerTickets VALUES ('208', '167', '', 'Single Property', '', '', 'Columbus', 'Choose One', '68601', 'Complete', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Karla ', '2015-10-31', '1969-12-31', '', '', '', '', '6 + 1 PD', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Windows w/ Wraps', '', '1969-12-31', '', '', '0000-00-00', '', 'bf', '2015-12-21', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', '', '', '', '', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', 'Debit Card', '1969-12-31', '2,500', '1969-12-31', '349', '1969-12-31', '3/27/2015: Paid Downpayment $2,500
8/25/2015: Made payment of $7,000-issues-wont pay balance until issues resolved
10/29/2015: Made Final Payment of $349.00

JOB IS NOW COMPLETE!', '');
INSERT INTO customerTickets VALUES ('209', '168', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68001', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '0000-00-00', '', '', '', '', '2', '', '', '', '2', '0000-00-00', '', '0000-00-00', 'B5889', '', 'Basic', 'Customer', '0000-00-00', '??', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', 'White', '', '', 'Job Installed by Mark', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Charles & Deb Misfeldt        (2) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('210', '9', '', 'Single Property', '', '', 'Hartington', 'Choose One', '68001', 'Ordered', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2015-10-31', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '10-30-2015: Ordered a new crank mechanism- the gears are slipping. need more than just a handle.', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Jons Mother             (Crank mechanism)', '0000-00-00', '0000-00-00', '0000-00-00', 'Window Repair', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('211', '170', '', 'Single Property', '', '', 'Columbus', 'Choose One', '68001', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '0000-00-00', '', '', '', '', '13', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Windows w/ Wraps', 'Customer', '0000-00-00', '1953', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Shauna Seebohm    (13) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '13', '26663431', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('212', '171', '', 'Single Property', '', '', 'Columbus', 'Choose One', '68001', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2015-10-31', '0000-00-00', '', '', '', '', '4', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Tough Install', 'Customer', '0000-00-00', '1998', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'No', '', '', '', '', 'Pull Siding', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Kathy Fadschild     (4) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '4', '#26684972', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('213', '172', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68001', 'Estimate', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Prospective', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '059-819941
Casement Sash', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Bryan Bahns      (1 Casement sash) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('214', '173', '', 'Single Property', '', '', 'Columbus', 'Choose One', '68601', 'Complete', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Karla ', '2015-10-31', '1969-12-31', '', '', '', '', '9', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '1950', '', '0000-00-00', '', 'bf', '2015-12-21', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', 'Yes', '', '', '', 'L\'s
installed by Jeff', '1969-12-31', '', '', 'October', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', 'Check', '1969-12-31', '', '1969-12-31', '4115', '1969-12-31', 'paid in full 11/02/15', '');
INSERT INTO customerTickets VALUES ('215', '177', '', 'Single Property', '', '', 'Creighton', 'Choose One', '68001', 'Unscheduled', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Prospective', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Rick Wilmes   (Est: 3) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('216', '178', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68001', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '0000-00-00', '', '', '', '', '1 Bay', '', '1 Bay', '26679397', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '?', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'No', '', '', '', '', '11/2/2015: Josh to Install', '0000-00-00', '', '', 'October', '2015', '', '', '0000-00-00', 'Karla Linsteadt         (1 Bay)', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('217', '183', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68001', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '', '', '', '1', '', '', '', '1 window - 10233 - norfolk', '0000-00-00', '', '0000-00-00', 'R1442', '', 'Windows w/ Wraps', 'Customer', '0000-00-00', '1966', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', '', '', '', '', '0000-00-00', '', '', 'November', '2015', '', '', '0000-00-00', 'Carrie Brandt      (1) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('218', '184', '', 'Single Property', '', '', 'Columbus', 'Nebraska', '68601', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '2015-12-23', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Karla ', '2015-10-31', '1969-12-31', '', '41.4302973', '-97.3593904', '', '1', '', 'Cbus: 1', '#26691690', '', '0000-00-00', '', '1969-12-31', '', '', 'Tough Install', '', '1969-12-31', '2012', '', '0000-00-00', '', 'HBC', '2015-12-23', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'No', '', '', '', '', 'Will need to pull siding.', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('219', '179', '', 'Single Property', '', '', 'Wayne', 'Choose One', '68001', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '1969-12-31', '', '', '', '', '2', '', '2 - windows - 10232 - norfolk', '#26708673', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'hc', '2015-12-03', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '12-3-2015: Told her we could get installed by end of December. She works at school. Will be off for Christmas break near end of month. She will be leaving from Dec 23-29. and she thinks she goes back to school the 7th of January?', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', 'Peg Webster        (2) ', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('220', '182', '', 'Single Property', '', '', 'Columbus', 'Choose One', '68601', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Jeff ', '2015-10-31', '2015-11-02', '10231', '', '', '', '4', '', '', '', '4 ', '0000-00-00', '', '2015-12-07', 'R1436', '', 'Basic', '', '1969-12-31', '1945', '', '0000-00-00', '', 'hc', '2015-12-09', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', 'White', '', '', '', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('221', '180', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68701', 'Paid', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '2015-12-18', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '1969-12-31', '10230', '', '', '', '1', '', '', '', '1', '0000-00-00', '', '1969-12-31', 'R1431', '', 'Basic', '', '2015-12-11', '1973', '', '0000-00-00', '', 'HBC', '2015-12-18', '1', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', 'Check', '1969-12-31', '', '1969-12-31', '500', '2015-12-15', '', '');
INSERT INTO customerTickets VALUES ('222', '185', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68001', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '0000-00-00', '', '', '', '', '2', '', '', '', '2', '0000-00-00', '', '0000-00-00', 'W2481', '', 'Windows w/ Wraps', 'Customer', '0000-00-00', '1963', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', '', '', '', '', '0000-00-00', '', '', 'November', '2015', '', '', '0000-00-00', 'JoAnn Meyer(2)', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('223', '39', '', 'Single Property', '', '', 'Clearwater', 'Choose One', '68001', 'Complete', '0000-00-00', '0000-00-00', '0000-00-00', '2015-12-24', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '0000-00-00', '', '', '', '', '6', '', '6', '#26684975', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '??', '', '0000-00-00', '', 'kf', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', '', '', '', '10/3/2015: Josh installed
paid in full but still has screen ordered', '0000-00-00', '', '', 'November', '2015', '', '', '0000-00-00', 'Patty Thiele     (6) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('224', '186', '', 'Single Property', '', '', 'Madison', 'Choose One', '68748', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '2015-12-17', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '1969-12-31', '#10237', '', '', '', '3', '', '', '', '3', '0000-00-00', '', '1969-12-31', 'R3936', '', 'Tough Install', '', '2015-12-17', '1875', '', '0000-00-00', '', 'hc', '2015-12-17', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', 'Other', 'colonial ivory smooth ', '', 'also need two sashes and 1 cherry keeper and patio door rollers

12-18-2015: Mark Scheduled to install', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('225', '186', '', 'Single Property', '', '', 'Madison', 'Choose One', '68001', 'Ordered', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Prospective', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', 'ordered 1 keeper rollers and 2 sashes from ami ', '0000-00-00', '', '', 'November', '2015', '', '', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', 'Window Repair', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('226', '188', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68001', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '0000-00-00', '', '', '', '', '17 sq', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', 'Siding Installed by Scott', '0000-00-00', '', '', 'November', '2015', '', '', '0000-00-00', 'Dennis Beltz     (siding) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Siding', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('227', '188', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68001', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '0000-00-00', '', '', '', '', '1', '', '', '', '1', '0000-00-00', '', '0000-00-00', 'T3963', '', 'Basic', 'Customer', '0000-00-00', '1966', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'November', '2015', '', '', '0000-00-00', 'Dennis Beltz        (1) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('228', '189', '', 'Single Property', '', '', 'Plainview', 'Choose One', '68001', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '1969-12-31', '10248', '', '', '', '3', '', '3 - windows - ', '#26711075', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '1900', '', '0000-00-00', '', 'hc', '2015-11-24', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', 'Tara & Todd Ward         (3) ', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('229', '190', '', 'Single Property', '', '', 'Winside', 'Choose One', '68001', 'Sold', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Windows w/ Wraps', 'Prospective', '0000-00-00', '', '', '0000-00-00', '', 'bf', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', 'White', '', 'Yes', '', '0000-00-00', '', '', 'November', '2015', '', '', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('230', '191', '', 'Single Property', '', '', 'Columbus', 'Choose One', '68601', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Jeff ', '2015-10-31', '2015-11-02', '10234', '', '', '', '2', '', '2', '#26708677', '', '0000-00-00', '', '2015-12-07', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'hc', '2015-12-09', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('231', '181', '', 'Single Property', '', '', 'Fullerton', 'Choose One', '68638', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Jeff ', '2015-10-31', '2015-11-02', '10229', '', '', '', '16', '', '16', '#26708671', '', '0000-00-00', '', '2015-12-07', '', '', 'Basic', '', '1969-12-31', '1900', '', '0000-00-00', '', 'hc', '2015-12-09', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('232', '161', '', 'Single Property', '', '', 'Wayne', 'Choose One', '68787', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '2015-12-22', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '1969-12-31', '', '', '', '', '4', '', '', '', '4 windows - 10236', '0000-00-00', '', '1969-12-31', 'R3919', '', 'Basic', '', '2015-12-22', '1910', '', '0000-00-00', '', 'HBC', '2015-12-22', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '12/23/2015: Dwayne scheduled to Install', '1969-12-31', '', 'Contract Sent', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '2015-12-22', '', '1969-12-31', '5705-0001-0084-4976
60 months', '');
INSERT INTO customerTickets VALUES ('233', '190', '', 'Single Property', '', '', 'Winside', 'Choose One', '68001', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '', '', '', '1', '', '1 window - #10235', '#26709104', '', '0000-00-00', '', '0000-00-00', '', '', 'Windows w/ Wraps', 'Customer', '0000-00-00', '1920', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', '', '', '', '', '0000-00-00', '', '', 'November', '2015', '', '', '0000-00-00', 'Connie Bargstadt  (1)', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('234', '174', '', 'Single Property', '', '', 'Columbus', 'Choose One', '68601', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Jeff ', '2015-10-31', '1969-12-31', '', '', '', '', '12', '', 'Cbus: 12', '#26687503', '', '0000-00-00', '', '1969-12-31', '', '', 'Windows w/ Wraps', '', '1969-12-31', '', '', '0000-00-00', '', 'bf', '2015-12-21', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', '', '', '', '', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('235', '193', '', 'Single Property', '', '', 'Columbus', 'Choose One', '68601', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Karla ', '2015-10-31', '1969-12-31', '', '', '', '', '21', '', 'Cbus: 21', '#26691693', '', '0000-00-00', '', '1969-12-31', '', '', 'Windows w/ Wraps', '', '2015-12-08', '', '', '0000-00-00', '', 'hc', '2015-12-09', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', '', '', '', 'Quarterround inside.', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('236', '126', '', 'Single Property', '', '', 'Duncan', 'Choose One', '68634', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Jeff ', '2015-10-31', '1969-12-31', '', '', '', '', '8', '', 'Cbus: 8', '#26687505', '', '0000-00-00', '', '1969-12-31', '', '', 'Tough Install', '', '1969-12-31', '2001', '', '0000-00-00', '', 'HBC', '2015-12-21', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('237', '194', '', 'Single Property', '', '', 'Columbus', 'Choose One', '68601', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Jeff ', '2015-10-31', '1969-12-31', '', '', '', '', '3', '', 'Cbus: 3', '#26691692', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'bf', '2015-12-21', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'Needs L\'s', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('238', '16', '', 'Multiple Property', '2653 43rd Ave- Columbus', 'PO Box 268', 'Saint Edward', 'Nebraska', '68660', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Jeff ', '2015-10-31', '0000-00-00', '', '', '', '', '4', '', '', '', 'Cbus: 4', '0000-00-00', '', '0000-00-00', 'H1433/H1432', '', 'Windows w/ Wraps', 'Prospective', '0000-00-00', '1952', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', 'Other', 'Brown', '', '', '0000-00-00', '', '', 'November', '2015', '', '', '0000-00-00', 'Patty Score; Rental             (4) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('239', '195', '', 'Single Property', '', '', 'Columbus', 'Choose One', '68601', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Jeff ', '2015-10-31', '1969-12-31', '', '', '', '', '1', '', '', '', 'Cbus: 1', '0000-00-00', '', '1969-12-31', 'G1196', '', 'Windows w/ Wraps', '', '1969-12-31', '', '', '0000-00-00', '', 'bf', '2015-12-21', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', '', '', '', 'Also wrapping 1 extra window', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('240', '196', '', 'Single Property', '', '', 'Clearwater', 'Choose One', '68001', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '', '', '', '8', '', '8 windows - 10238', '26709176', '', '0000-00-00', '', '0000-00-00', '', '', 'Windows w/ Wraps', 'Customer', '0000-00-00', '1965', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', 'White', '', 'Yes', 'dwayne did first set', '0000-00-00', '', '', 'November', '2015', '', '', '0000-00-00', 'Kathy Patras        (8)', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('241', '197', '', 'Single Property', '', '', 'Emmet', 'Choose One', '68734', 'Received', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2015-10-31', '1969-12-31', '', '', '', '', '18', '', '15 WINDOWS 10239 AND 1 BAY- 10240', '#26709233        #26709738', '', '0000-00-00', '', '1969-12-31', '', '', 'Tough Install', '', '1969-12-31', '', '', '0000-00-00', '', 'hc', '2015-12-17', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', 'No', 'White', '', 'Yes', '', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('242', '198', '', 'Single Property', '', '', 'West Point', 'Choose One', '68001', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '', '', '', '10', '', 'Cbus: 10', '#26702189', '', '0000-00-00', '', '0000-00-00', '', '', 'Windows w/ Wraps', 'Customer', '0000-00-00', '??', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', '', '', '', '', '0000-00-00', '', '', 'November', '2015', '', '', '0000-00-00', 'David Nesladek         (10) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('243', '199', '', 'Single Property', '', '', 'Clarkson', 'Choose One', '68001', 'Estimate', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Prospective', '0000-00-00', '', '', '0000-00-00', '', 'kf', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'November', '2015', '', '', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('244', '19', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68001', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '2015-12-21', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '', '', '', '12', '', '12 windows - 10243', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'November', '2015', '', '', '0000-00-00', 'Steve & Theresa Perry         (12) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('245', '200', '', 'Single Property', '', '', 'Columbus', 'Choose One', '68601', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Jeff ', '2015-10-31', '2015-11-09', '#10247', '', '', '', '6', '', '', '', '5+1PD', '0000-00-00', '', '2015-12-07', 'S4351/S4352', '', 'Windows w/ Wraps', '', '1969-12-31', '1988', '', '0000-00-00', '', 'hc', '2015-12-09', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', 'Other', 'Brown', '', '', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', 'Debit Card', '1969-12-31', '$2,000.00 ', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('246', '202', '', 'Multiple Property', '306 South 12th St-Norfolk', '308 S. 12th St.', 'Norfolk', 'Nebraska', '68701', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '2015-11-23', '#10269', '', '', '', '2', '', '2 windows ', '#26715956', '', '0000-00-00', '', '1969-12-31', '', '', 'Windows w/ Wraps', '', '1969-12-31', '1935', '', '0000-00-00', '', 'hc', '2015-12-10', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', 'No', 'Black', '', '', '', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('247', '203', '', 'Single Property', '', '', 'Battle Creek', 'Choose One', '68001', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '0000-00-00', '', '', '', '', '5', '', '5', '#26696594', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Prospective', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'No', '', '', '', '', 'Need to measure 2 more windows on the south wall; Sunroom when there.', '0000-00-00', '', '', 'November', '2015', '', '', '0000-00-00', 'Wes & Kelly Van Ert      (5) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('373', '305', '', 'Single Property', '', '', 'Elgin', 'Choose One', '', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2015-12-22', '1969-12-31', '', '', '', '', '2 Upper Sashes', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Double Hung', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2015-12-22', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '(2) Top Sashes
126-355106, 109
Reason: Seal Fail', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('249', '204', '', 'Single Property', '', '', 'Hoskins', 'Choose One', '68001', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '0000-00-00', '', '', '', '', '20 Sq.', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', 'Contract Sent', 'November', '2015', '', '', '0000-00-00', 'Steve & Sue Falk         (Siding&Gutters)', '0000-00-00', '0000-00-00', '0000-00-00', 'Siding', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '11/6/2015: Mailed WF Contract and Siding warranty.', '');
INSERT INTO customerTickets VALUES ('250', '206', '', 'Single Property', '', '', 'Battle Creek', 'Choose One', '68001', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '0000-00-00', '', '', '', '', '2', '', '', '', '1+1PD', '0000-00-00', '', '0000-00-00', 'R1050/51', '', 'Patio', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', 'No', 'Other', 'Cape Cod Gray', '', '11-12-2015: Scheduled Install Date(Dwayne+Matt) ', '0000-00-00', '', '', 'November', '2015', '', '', '0000-00-00', 'Mike Wiedeman                 (1+1PD)', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('251', '207', '', 'DIY', '', '', 'Abie', 'Choose One', '68001', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2015-10-31', '0000-00-00', '', '', '', '', '6', '', '5', '26709463', '1 PD', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'November', '2015', '', '', '0000-00-00', 'M&J Roofing      (DIY: 5) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('252', '208', '', 'DIY', '', '', 'Wayne', 'Choose One', '68001', 'Complete', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '1969-12-31', '#10245', '', '', '', '2', '', ' ', '', '2 - windows - 10245', '0000-00-00', '', '1969-12-31', 'S4332', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'SDD', '2015-11-24', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', 'Angie Beiermann           (2)', '1969-12-31', '2015-11-23', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', 'Cash', '0000-00-00', '', '1969-12-31', '806.25', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('253', '209', '', 'Single Property', '', '', 'Columbus', 'Choose One', '68601', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Jeff ', '2015-10-31', '1969-12-31', '#10244', '', '', '', '16', '', '11', '#26711010', '5', '0000-00-00', '', '2015-12-07', 'S4330', '', 'Basic', '', '1969-12-31', '1960', '', '0000-00-00', '', 'hc', '2015-12-09', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', '', '', '', '', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('254', '209', '', 'Single Property', '', '', 'Columbus', 'Choose One', '68601', 'Sold', '2015-12-21', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Brent ', '2015-10-31', '1969-12-31', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Siding', '', '1969-12-31', '1960', '', '0000-00-00', '', 'bf', '2015-12-21', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Siding', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('255', '157', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68001', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '#10250', '', '', '', '2', '', '', '', '2 - windows - 10250', '0000-00-00', '', '0000-00-00', 'S6831       S6832', '', 'Basic', '', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', '', '', '', '', '0000-00-00', '', '', 'November', '2015', '', '', '0000-00-00', 'Jeff Jensen    (2) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('256', '63', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68001', 'Sold', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'November', '2015', '', '', '0000-00-00', 'Richard Buckendahl          (siding) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('257', '39', '', 'Single Property', '', '', 'Clearwater', 'Choose One', '68726', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2015-10-31', '2015-11-06', '', '', '', '', '1 Screen-WPU if not going that way.', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Other', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2015-12-22', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'ordered screen,  she also says one window opens harder than the others ---she will pick up screen if we don\'t have anyone going her way', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('258', '210', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68701', 'Paid', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '2015-12-22', '2015-12-23', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '1969-12-31', '', '', '', '', '1', '', '1', '#26711611', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '2015-12-22', '2002', '', '0000-00-00', '', 'HBC', '2015-12-22', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '12/23/2015: Mark Scheduled to Install.', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('259', '212', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68701', 'Received', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2015-10-31', '2015-11-10', '10251', '', '', '', '10', '', '', '', '10', '0000-00-00', '', '1969-12-31', 'S7310', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'hc', '2015-12-10', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('260', '203', '', 'Single Property', '', '', 'Battle Creek', 'Choose One', '68715', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '1969-12-31', '10253', '', '', '', '2', '', '2 windows - ', '#26711990', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '2015-12-07', '', '', '0000-00-00', '', 'hc', '2015-12-07', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '12/8/2015: Scheduled Install Dat e', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('261', '84', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68001', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '1969-12-31', '', '', '', '', '1 PD', '', '', '', '1 patio doo - 10252', '0000-00-00', '', '1969-12-31', 'S9441', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'hc', '2015-12-04', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'first door used on Lyle Lutt', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', 'Michael Kuester      (1PD) ', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('262', '213', '', 'Single Property', '', '', 'Creston', 'Choose One', '68001', 'Scheduled', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Prospective', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'November', '2015', '', '', '0000-00-00', 'Zack Linsdley        (estimate)', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('263', '214', '', 'Single Property', '', '', 'Neligh', 'Choose One', '68001', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '0000-00-00', '', '', '', '', '5', '', '4', '#26653051', '1 PD', '0000-00-00', '', '0000-00-00', 'H7420', '', 'Patio', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', 'Contract Sent', 'November', '2015', '', '', '0000-00-00', 'Rob & Corrie Starkey        (4+1PD) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '11/11/2015: Mailed WF Contract
4705-0001-0102-9247
$3,050', '');
INSERT INTO customerTickets VALUES ('264', '215', '', 'Single Property', '', '', 'Albion', 'Choose One', '68620', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2015-10-31', '1969-12-31', '', '', '', '', '3', '', '', '', '3 windows - 10260', '0000-00-00', '', '1969-12-31', 'T6605', '', 'Windows w/ Wraps', '', '1969-12-31', '', '', '0000-00-00', '', 'hc', '2015-12-15', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', 'White', '', 'Yes', '', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('265', '216', '', 'Single Property', '', '', 'Newman Grove', 'Choose One', '68758', 'Complete', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2015-10-31', '1969-12-31', '', '', '', '', '6', '', '6', '#26712437', '', '0000-00-00', '', '1969-12-31', '', '', 'Tough Install', '', '1969-12-31', '', '', '0000-00-00', '', 'kf', '2015-12-17', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'dont wrap until we do siding just get vinyl stop or exterior quarteround 1 1/4 white interior stop', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('266', '218', '', 'Single Property', '', '', 'Columbus', 'Choose One', '68601', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Jeff ', '2015-10-31', '2015-11-12', '10254', '', '', '', '4', '', '', '', '4 ', '0000-00-00', '', '2015-12-07', 'T1919', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'hc', '2015-12-09', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', '', '', '', '', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('267', '220', '', 'DIY', '', '', 'Bellwood', 'Choose One', '68624', 'Complete', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', '', '2015-10-31', '1969-12-31', '', '', '', '', '7', '', '', '', 'Cbus: 7 windows-10257 ', '0000-00-00', '', '1969-12-31', 'T2021', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'hc', '2015-12-07', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '2015-11-12', '2015-12-01', '2015-12-07', 'Windows', '1969-12-31', '', '', '', '', 'Debit Card', '1969-12-31', '', '1969-12-31', '', '2015-12-07', '12/7/2015; Paid in Full.', '');
INSERT INTO customerTickets VALUES ('269', '221', '', 'Single Property', '820 E. Hynes', '', 'O\'Neill', 'Nebraska', '68763', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '1969-12-31', '', '42.4650095', '-98.6411862', '', '15', '', '14', '#26696265', '1', '0000-00-00', '', '1969-12-31', 'J5751', '', 'Windows w/ Wraps', '', '1969-12-31', '', '', '0000-00-00', '', 'ak', '2015-12-28', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', '', '', '', '', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('270', '222', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68001', 'Paid', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '2015-12-30', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '', '', '', '3', '', '3', '#26696264', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '1953', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'No', '', '', '', '', '', '0000-00-00', '', '', 'November', '2015', '', '', '0000-00-00', 'Bill Lamm        (3) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('271', '223', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68001', 'Paid', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '2015-12-23', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '', '', '', '6', '', '6', '#26696266', '', '0000-00-00', '', '0000-00-00', '', '', 'Windows w/ Wraps', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', '', '', '', '11/17/2015: Mark installed', '0000-00-00', '', '', 'November', '2015', '', '', '0000-00-00', 'Jim Wichman        (6) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('272', '224', '', 'Single Property', '', '', 'Stanton', 'Choose One', '68001', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2015-10-31', '0000-00-00', '', '', '', '', '5', '', '5', '#26696209', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '1995', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'No', '', '', '', '', 'CUSTOMER TO FINISH INSIDE & OUT', '0000-00-00', '', 'Approved', 'November', '2015', '', '', '0000-00-00', 'Joel Putters       (5)', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '4705-0001-0112-6811
60 Months', '');
INSERT INTO customerTickets VALUES ('273', '225', '', 'Single Property', '', '', 'Tilden', 'Choose One', '68001', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '', '', '', '3', '', '3', '#26696206', '', '0000-00-00', '', '0000-00-00', '', '', 'Windows w/ Wraps', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', '', '', '', '', '0000-00-00', '', '', 'November', '2015', '', '', '0000-00-00', 'Tilden Housing Authority     (3) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('274', '20', '', 'Single Property', '', '', 'Platte Center', 'Choose One', '68653', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '1969-12-31', '', '', '', '', '4', '', '', '', 'Cbus: 4', '0000-00-00', '', '1969-12-31', 'J7667', '', 'Windows w/ Wraps', '', '1969-12-31', '', '', '0000-00-00', '', 'hc', '2015-12-11', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', '', '', '', 'Also has 2 storm doors she wants us to install.', '1969-12-31', '', 'Contract Sent', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '4705-0001-0112-2448
Amount: $2,960
12 months

12/11/2015: HC mailed WF contract.', '');
INSERT INTO customerTickets VALUES ('275', '226', '', 'Single Property', '', '', 'Hoskins', 'Choose One', '68001', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '0000-00-00', '', '', '', '', '2', '', '2', '#26655989', '', '0000-00-00', '', '0000-00-00', '', '', 'Tough Install', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'November', '2015', '', '', '0000-00-00', 'Arvyn & Reta Neuhaus     (2) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('276', '219', '', 'Single Property', '14232 280th St', '', 'Columbus', 'Nebraska', '68601', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '2015-12-23', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Karla ', '2015-10-31', '2015-11-12', '10255', '41.5112824', '-97.3196798', '', '11', '', '11', '#26712436', '', '0000-00-00', '', '2015-12-07', '', '', 'Tough Install', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2015-12-23', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'No', '', '', '', '', 'Insulate Cavities', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('277', '227', '', 'Single Property', '', '', 'Winside', 'Choose One', '68001', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '', '', '', '8', '', '8', '#26696261           #26702019', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '1910', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'November', '2015', '', '', '0000-00-00', 'Steve Jorgensen       (8)', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('278', '140', '', 'Single Property', '', '', 'Wayne', 'Choose One', '68001', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '0000-00-00', '', '', '', '', '', '', '34 sashes     ', '#26705875', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Prospective', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'November', '2015', '', '', '0000-00-00', 'Tiffani Stegeman        (sashes w/ grids) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Window Repair', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('279', '228', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68001', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '0000-00-00', '', '', '', '', '4', '', '4', '#26679188', '', '0000-00-00', '', '0000-00-00', '', '', 'Cut-In', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', '', '', '', '11/19/15: Scheduled to Install', '0000-00-00', '', '', 'November', '2015', '', '', '0000-00-00', 'Jason Feddern       (4) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('280', '217', '', 'Single Property', '', '', 'Newman Grove', 'Choose One', '68001', 'Ordered', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2015-10-31', '0000-00-00', '', '', '', '', '1', '', '1 WINDOW - NORFOLK - 10263', '#26713544', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Prospective', '0000-00-00', '1920', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'Yes', '', '', '', '', '', '0000-00-00', '', '', 'November', '2015', '', '', '0000-00-00', 'Mikal Shalikow      (1) RUSH', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('281', '229', '', 'Multiple Property', '207 N. 9th St.-Norfolk', '55956 845 Rd', 'Norfolk', 'Nebraska', '68701', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '2015-11-16', '10258', '', '', '', '3', '', '3', '#26713538', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '1899', '', '0000-00-00', '', 'hc', '2015-12-10', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'No', '', '', '', '', '', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('282', '230', '', 'Multiple Property', '800 E. Klug-Norfolk', '116 Norfolk Ave', 'Norfolk', 'Nebraska', '68701', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '1969-12-31', '', '', '', '', '7', '', '7 windows - 10259 - norfolk', '#26713541', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '1977', '', '0000-00-00', '', 'hc', '2015-12-14', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '12/11/215: Josh to install-Hc will mail Inv/Pw later(per Brent)', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('283', '231', '', 'Single Property', '83910 563rd Ave.', '', 'Stanton', 'Nebraska', '68779', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '2015-12-23', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '2015-11-16', '10262', '41.9917708', '-97.271736', '', '1', '', '1 ', '#26713543', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '1995', '', '0000-00-00', '', 'HBC', '2015-12-23', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('284', '9', '', 'DIY', '', '', 'Hartington', 'Choose One', '68001', 'Ordered', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2015-10-31', '0000-00-00', '', '', '', '', '8', '', '', '', '8 window - 10264 - norfolk', '0000-00-00', '', '0000-00-00', 'T7181', '', 'Basic', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'November', '2015', '', '', '0000-00-00', 'Jamie Arens     (8)', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('285', '232', '', 'Multiple Property', 'Apartment Complex: 607 Cedar', '', 'Abie', 'Nebraska', '68001', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2015-10-31', '0000-00-00', '', '', '', '', '26', '', '26 windows - 10265- norfolk', '#26713643', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Customer', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'November', '2015', '', '', '0000-00-00', 'Don Maguire   (26) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('286', '233', '', 'Single Property', '', '', 'Columbus', 'Choose One', '68001', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-10-31', '0000-00-00', '', '', '', '', '6', '', '', '', 'Cbus: 6', '0000-00-00', '', '0000-00-00', 'B5899', '', 'Basic', 'Customer', '0000-00-00', '1910', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', 'No', '', '', '', '', '11/17/2015: Jeff to Install', '0000-00-00', '', 'Contract Sent', 'November', '2015', '', '', '0000-00-00', 'Kylee Carey      (6) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '11/16/2015: Mailed Contract
Contract Amount: $2,250.00
4705-0001-0118-1824
12 Months', '');
INSERT INTO customerTickets VALUES ('287', '234', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68701', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '2015-11-16', '10266', '', '', '', '1', '', '', '', '1 ', '0000-00-00', '', '1969-12-31', 'T8920', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'hc', '2015-12-10', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('288', '235', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68001', 'Estimate', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Angi', '2015-10-31', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Prospective', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '11/17/2015: HC mailed a door brochure. Told customer to pick out a style and call us with a model #. We will get the door quoted and have it ready to go with whoever estimates the Picture Window.', '0000-00-00', '', '', 'November', '2015', '', '', '0000-00-00', 'Becky Wulf        (Estimate: 1 Pw/1 Entry Door) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('289', '236', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68001', 'Scheduled', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Jerry ', '2015-10-31', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Basic', 'Prospective', '0000-00-00', '', '', '0000-00-00', '', 'hc', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'November', '2015', '', '', '0000-00-00', 'Matt Kampschnieder      (est: 2 basement windows) ', '0000-00-00', '0000-00-00', '0000-00-00', 'Windows', '0000-00-00', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '');
INSERT INTO customerTickets VALUES ('290', '237', '', 'Single Property', '', '', 'Elgin', 'Choose One', '68636', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '2015-11-23', '#10271', '', '', '', '10', '', '10', '#26716048', '', '0000-00-00', '', '1969-12-31', '', '', 'Windows w/ Wraps', '', '1969-12-31', '?', '', '0000-00-00', '', 'hc', '2015-12-10', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', 'White', '', 'Yes', 'MAY NEED SOME SILLS REPLACED', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('292', '240', '', 'Single Property', '', '', 'Newman Grove', 'Choose One', '68758', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '2015-11-23', '#10270', '', '', '', '2', '', '2 windows', '#26716047', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '1900', '', '0000-00-00', '', 'hc', '2015-12-14', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'No', '', '', '', '', '12-9-2015: Sent windows w/ Dwayne-He is going to try and install while he is doing Tony Squires windows.', '1969-12-31', '', 'Approved', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '0', '1969-12-31', '', '1969-12-31', 'Approved for: $9,100
4705-0001-0118-6138

12-9-2015: Sent WF Contract(12 months-$920) with Dwayne', '');
INSERT INTO customerTickets VALUES ('293', '230', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68001', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2015-10-31', '2015-11-23', '#10268', '', '', '', '6', '', '6', '#26715956', '', '0000-00-00', '', '1969-12-31', '', '', 'Windows w/ Wraps', '', '1969-12-31', '1960', '', '0000-00-00', '', 'hc', '2015-11-24', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', '', '', '', '', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', 'Jose Leon: 112 E. Klug       (6)', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('294', '241', '', 'Single Property', '', '', 'Wayne', 'Choose One', '68787', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '2015-11-23', '10267', '', '', '', '2', '', '2 windows', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '1953', '', '0000-00-00', '', 'hc', '2015-12-10', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'No', '', '', '', '', '', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('295', '9', '', 'Multiple Property', 'Lammers', '', 'Hartington', 'Choose One', '68739', 'Complete', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', '', '2015-10-31', '2015-11-23', '10272', '', '', '', '6', '', '6 ', '26716049', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'hc', '2015-12-14', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', 'Debit Card', '1969-12-31', '', '1969-12-31', '$1,462.00', '2015-12-14', '', '');
INSERT INTO customerTickets VALUES ('296', '243', '', 'Single Property', '', '', 'Wisner', 'Choose One', '68791', 'Received', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2015-10-31', '2015-11-30', '#10276', '', '', '', '5', '', '5', '#26717126', '', '0000-00-00', '', '1969-12-31', '', '', 'Windows w/ Wraps', '', '1969-12-31', '1968', '', '0000-00-00', '', 'hc', '2015-12-17', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', 'White', '', '', '', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('297', '244', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68701', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-10-31', '2015-11-30', '072-10275', '', '', '', '1', '', '', '', '1 window', '0000-00-00', '', '1969-12-31', 'V6279', '', 'Windows w/ Wraps', '', '1969-12-31', '1920', '', '0000-00-00', '', 'hc', '2015-12-14', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', 'White', '', 'No', '', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('298', '245', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68701', 'Received', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2015-10-31', '2015-11-30', '072-10274', '', '', '', '3', '', '3 windows', '#26717124', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '1972', '', '0000-00-00', '', 'hc', '2015-12-17', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('299', '230', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68001', 'Estimate', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2015-10-31', '2015-11-30', '072-10277', '', '', '', '4', '', '', '', '4 windows', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'kf', '2015-11-30', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'November', '2015', '', '', '0000-00-00', '600 east klug', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('300', '246', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68701', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2015-10-31', '1969-12-31', '', '', '', '', '1 Sash', '', '', '', '', '0000-00-00', '', '1969-12-31', 'New: V9657  129-372850', '', 'Double Hung', '', '1969-12-31', '', '', '0000-00-00', '', 'bf', '2015-12-23', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'Sash', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('304', '248', '', 'Single Property', '3658 50th Ave.', '', 'Columbus', 'Nebraska', '68601', 'Ready to Install', '0000-00-00', '0000-00-00', '2015-12-21', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Jeff ', '2015-12-07', '2015-12-07', '072-10284', '41.4514259', '-97.3915107', '', '1', '', '', '', '1', '0000-00-00', '', '2015-12-22', 'W7471', '', 'Basic', '', '1969-12-31', '1962', '', '0000-00-00', '', 'HBC', '2015-12-23', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2015-12-02', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('305', '249', '', 'Single Property', '2160 24th Ave.', '', 'Columbus', 'Nebraska', '68601', 'Ready to Install', '0000-00-00', '0000-00-00', '2015-12-21', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Jeff ', '2015-12-07', '2015-12-07', '072-10281', '41.437402', '-97.3567335', '', '1', '', '', '', '1', '0000-00-00', '', '2015-12-22', 'W7467', '', 'Basic', '', '1969-12-31', '1937', '', '0000-00-00', '', 'HBC', '2015-12-23', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2015-12-02', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('306', '250', '', 'Multiple Property', '1360 30th Ave-Columbus', '2469 53rd Ave', 'Columbus', 'Nebraska', '68601', 'Received', '0000-00-00', '0000-00-00', '2015-12-22', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Stephen ', '2015-12-07', '2015-12-07', '072-10282', '', '', '', '7', '', '7', '26719328', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2015-12-22', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2015-12-02', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('307', '251', '', 'Single Property', '', '', 'Plainview', 'Choose One', '68769', 'Received', '0000-00-00', '0000-00-00', '2015-12-21', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2015-12-07', '2015-12-07', '072-10280', '', '', '', '1 patio door', '', '', '', '1 PD', '0000-00-00', '', '1969-12-31', 'W7459', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'hc', '2015-12-08', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2015-12-07', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('308', '9', '', 'Multiple Property', 'Folkers', '', 'Hartington', 'Choose One', '68739', 'Invoiced', '0000-00-00', '0000-00-00', '2015-12-21', '0000-00-00', '', '2015-12-24', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-12-07', '2015-12-07', '072-10279', '42.5862849', '-97.394882', '', '6 windows', '', '', '', '6', '0000-00-00', '', '1969-12-31', 'W7458', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2015-12-24', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '2015-12-07', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2015-12-07', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('309', '252', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68701', 'Received', '0000-00-00', '0000-00-00', '2015-12-21', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2015-12-07', '2015-12-07', '072-10284', '', '', '', '2 windows', '', '', '', '2', '0000-00-00', '', '1969-12-31', 'W8091', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'hc', '2015-12-08', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2015-12-07', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('310', '207', '', 'DIY', '', '', 'Abie', 'Choose One', '', 'Invoiced', '0000-00-00', '0000-00-00', '2015-12-24', '0000-00-00', '', '2015-12-24', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2015-12-07', '2015-12-07', '072-10285', '', '', '', '2 windows', '', '2', '26719532', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'hc', '2015-12-08', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '2015-12-07', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2015-12-07', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('311', '40', '', 'Single Property', '', '', 'Schuyler', 'Choose One', '68661', 'Received', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Mike ', '2015-12-08', '2015-12-07', '10278', '', '', '', '1', '', '', '', '1', '0000-00-00', '', '1969-12-31', 'W2705', '', 'Basic', '', '1969-12-31', '1976', '', '0000-00-00', '', 'hc', '2015-12-14', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'MISMEASURE', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '1');
INSERT INTO customerTickets VALUES ('312', '253', '', 'Single Property', '', '', 'Columbus', 'Choose One', '68601', 'Ordered', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Hailey', '2015-12-08', '2015-12-08', '072-10286', '', '', '', '3', '', '', '', '3', '0000-00-00', '', '1969-12-31', 'W9733/W9734', '', 'Tough Install', '', '1969-12-31', '1987', '', '0000-00-00', '', 'hc', '2015-12-09', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', 'No', '', '', '', '2 WINDOWS AND GARDEN WINDOW', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2015-10-28', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('313', '255', '', 'Single Property', '', '', 'Pierce', 'Choose One', '', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Karla ', '2015-12-08', '1969-12-31', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '2015-12-08', '', '', '0000-00-00', '', 'hc', '2015-12-08', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Siding', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('314', '257', '', 'Single Property', '', '', 'Columbus', 'Choose One', '', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Karla ', '2015-12-08', '2015-07-20', '10028', '', '', '', '9', '', '9', '26673921', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '1956', '', '0000-00-00', '', 'hc', '2015-12-08', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', 'Yes', '', '', '', '', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '12/8/2015: Mailed Inv.', '');
INSERT INTO customerTickets VALUES ('315', '258', '', 'Single Property', '', '', 'Stromsburg', 'Choose One', '', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Karla ', '2015-12-08', '2015-06-01', '9941', '', '', '', '15', '', '15', '26658732', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '2015-12-08', '1972', '', '0000-00-00', '', 'hc', '2015-12-08', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', 'Yes', '', '', '', '', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '12/8/2015: Mailed Inv.', '');
INSERT INTO customerTickets VALUES ('316', '259', '', 'Single Property', '', '', 'Columbus', 'Choose One', '', 'Invoiced', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Karla ', '2015-12-08', '1969-12-31', '10096', '', '', '', '1', '', '1', '26684973', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '2015-12-08', '1890', '', '0000-00-00', '', 'hc', '2015-12-08', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', 'Yes', '', '', '', '', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '12/8/2015: Mailed Inv.', '');
INSERT INTO customerTickets VALUES ('317', '260', '', 'DIY', '', '', 'Abie', 'Choose One', '68001', 'Received', '0000-00-00', '0000-00-00', '2015-12-21', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Hailey', '2015-12-09', '2015-12-09', '10287', '', '', '', '5', '', '', '', '5', '0000-00-00', '', '1969-12-31', 'X0468', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2015-12-21', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'matching up to the prior windows we installed for them.', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '2015-12-09', '2015-12-18', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2015-12-08', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('318', '261', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '', 'Estimate', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', '', '2015-12-09', '1969-12-31', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', 'Yes', '2015-12-09', '', 'bf', '2015-12-09', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('319', '261', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '', 'Estimate', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', '', '2015-12-09', '1969-12-31', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Single-Story', '', '1969-12-31', '', '', '0000-00-00', '', 'bf', '2015-12-09', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Siding', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('321', '262', '', 'Single Property', '', '', 'Pierce', 'Choose One', '68767', 'Ordered', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2015-12-14', '2015-12-14', '072-10289-ANDERSON', '', '', '', '1', '', '1 ', '26721043', '', '0000-00-00', '', '1969-12-31', '', '', 'Windows w/ Wraps', '', '1969-12-31', '1979', '', '0000-00-00', '', 'hc', '2015-12-14', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', '', '', '', '', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('322', '264', '', 'Single Property', '', '', 'Wisner', 'Choose One', '68791', 'Ordered', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2015-12-14', '2015-12-14', '072-10290', '', '', '', '2', '', '2 WINDOWS', '26721138', '', '0000-00-00', '', '1969-12-31', '', '', 'Windows w/ Wraps', '', '1969-12-31', '1922', '', '0000-00-00', '', 'hc', '2015-12-14', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', 'White', '', '', '', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('323', '30', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68701', 'Sold', '2015-12-18', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', '', '2015-12-14', '2015-12-14', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2015-12-18', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'ordered siding 12-14-15', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Siding', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('324', '266', '', 'Single Property', '', '', 'Pierce', 'Choose One', '68767', 'Ordered', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2015-12-14', '2015-12-15', '072-10294', '', '', '', '8 windows / 3 windows from jose leon - v6286', '', '', '', '8', '0000-00-00', '', '1969-12-31', 'Y0674', '', 'Windows w/ Wraps', '', '1969-12-31', '1957', '', '0000-00-00', '', 'hc', '2015-12-16', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', '', '', '', 'do not order until finance approved 
finance approved using 3 jose leon windows from V6286---31 3/4 x 37 1/4 - (3)----129-372950/951/952', '1969-12-31', '', 'Approved', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2015-12-15', '', '1969-12-31', '', '1969-12-31', '4705-0001-0119-5287', '');
INSERT INTO customerTickets VALUES ('325', '267', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '', 'Incomplete', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-12-14', '1969-12-31', '', '', '', '', '9', '', '', '', '9', '0000-00-00', '', '1969-12-31', 'F0831', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'hc', '2015-12-14', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('326', '215', '', 'Single Property', '', '', 'Albion', 'Choose One', '68620', 'Ordered', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2015-12-15', '2015-12-14', '10291', '', '', '', '1', '', '', '', '1', '0000-00-00', '', '1969-12-31', 'X8239', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'SDD', '2015-12-15', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'will need L\'s', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('327', '268', '', 'Single Property', '904 5th St.', '', 'Duncan', 'Nebraska', '', 'Complete', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Karla ', '2015-12-15', '2015-11-11', '', '41.3862998', '-97.4937595', '', 'Active PD Sash', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'bf', '2015-12-24', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('328', '269', '', 'Single Property', '', '', 'Pierce', 'Choose One', '68767', 'Sold', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2015-12-15', '2015-12-15', '072-10295', '', '', '', '1 window and 1 patiod door', '', '1 window', '', '1 patio door', '0000-00-00', '', '1969-12-31', '', '', 'Windows w/ Wraps', '', '1969-12-31', '', 'Yes', '2015-12-15', '', 'kf', '2015-12-15', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', 'White', '', '', '1 window 1 patio door', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2015-12-15', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('329', '270', '', 'Single Property', '', '', 'Creighton', 'Choose One', '68729', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-12-15', '1969-12-31', '', '', '', '', 'whistling window ', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'ak', '2015-12-15', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'Window is whistling around the frame with directional wind......', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('330', '192', '', 'Single Property', '', '', 'Humphrey', 'Choose One', '68642', 'Ordered', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', '', '2015-12-16', '2015-12-16', '10296', '', '', '', '6', '', '6', '26722059', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '1902', '', '0000-00-00', '', 'hc', '2015-12-16', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'No', '', '', '', '', 'told her January install', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '1');
INSERT INTO customerTickets VALUES ('331', '269', '', 'Single Property', '', '', 'Pierce', 'Choose One', '68767', 'Ordered', '0000-00-00', '2015-12-18', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2015-12-16', '1969-12-31', '10295', '', '', '', '1+1PD', '', '1', '26721802', '1 PD', '0000-00-00', '', '1969-12-31', 'Y0715', '', 'Windows w/ Wraps', '', '1969-12-31', '1968', '', '0000-00-00', '', 'HBC', '2015-12-18', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', '', '', '', '', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2015-12-18', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('333', '271', '', 'Single Property', '', '', 'David City', 'Choose One', '68632', 'Ordered', '0000-00-00', '2015-12-21', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Hailey', '2015-12-17', '2015-12-14', '10298', '', '', '', '3', '', '3', '26722220', '', '0000-00-00', '', '1969-12-31', '', '', 'Windows w/ Wraps', '', '1969-12-31', '', '', '0000-00-00', '', 'bf', '2015-12-21', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', '', '', '', '', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2015-12-16', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('335', '97', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '', 'Estimate', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', '', '2015-12-17', '1969-12-31', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'SDD', '2015-12-17', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('340', '275', '', 'Single Property', '', '', 'Lindsay', 'Choose One', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', '', '2015-12-18', '1969-12-31', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'bf', '2015-12-18', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'need a operable panel with cut glass ordered with single prairie came in with double  ', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '1');
INSERT INTO customerTickets VALUES ('341', '276', '', 'Single Property', '', '', 'Battle Creek', 'Choose One', '68715', 'Needs Measured', '2015-12-18', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-12-18', '1969-12-31', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '1983', '', '0000-00-00', '', 'HBC', '2015-12-18', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', '', '', '', '', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('342', '277', '', 'Single Property', '', '', 'Stanton', 'Choose One', '68779', 'Ordered', '0000-00-00', '2015-12-23', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2015-12-18', '2015-12-23', '072-10305', '', '', '', '4 windows', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'kf', '2015-12-23', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '2015-12-23', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2015-12-23', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('344', '280', '', 'Single Property', '', '', 'Wausa', 'Choose One', '', 'Ordered', '0000-00-00', '2015-12-21', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2015-12-21', '1969-12-31', 'order a part for old garden window ', '', '', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'ak', '2015-12-21', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '2015-12-21', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('345', '281', '', 'Single Property', '', '', 'Lindsay', 'Choose One', '68644', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Mark ', '2015-12-21', '2015-11-10', '', '', '', '', '1 Glass', '', '', '', '', '0000-00-00', '', '1969-12-31', 'New Glass FO: S8054 129-339769', '', 'Glass', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2015-12-21', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('358', '293', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68701', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2015-12-21', '2015-11-03', '', '', '', '', '1 Left Slider Sash', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'bf', '2015-12-23', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'From Outside: Left
122-043356', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('348', '282', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68701', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2015-12-21', '1969-12-31', '', '', '', '', '1 PD Handle', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Other', '', '1969-12-31', '', '', '0000-00-00', '', 'bf', '2015-12-23', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'Patio Door Handle(UNDER HC DESK)', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('349', '284', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68701', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2015-12-21', '2015-04-27', '', '', '', '', 'Dyad Operator', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '1982', '', '0000-00-00', '', 'bf', '2015-12-23', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'Dyad Operator(UNDER HC DESK)', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('350', '285', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68701', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2015-12-21', '2015-10-03', '', '', '', '', '4 Balances', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Other', '', '1969-12-31', '1952', '', '0000-00-00', '', 'HBC', '2015-12-21', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '(4) Balances.(Under HC Desk)', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('351', '286', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68701', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2015-12-21', '2015-12-07', '', '', '', '', '2 Slider Sashes', '', '', '', '', '0000-00-00', '', '1969-12-31', 'W8288        129-380280,281', '', 'Other', '', '1969-12-31', '', '', '0000-00-00', '', 'bf', '2015-12-23', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '2 Slider Sashes-HE WAS NOT HAPPY WHEN HE CAME IN THE LAST TIME.', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '1');
INSERT INTO customerTickets VALUES ('352', '287', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68701', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2015-12-21', '2015-12-07', '', '', '', '', '1 Upper Sash', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Double Hung', '', '1969-12-31', '1971', '', '0000-00-00', '', 'bf', '2015-12-23', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '(1) Upper sash
Original Serial #: 121-633619
New Serial #: W8296;129-380198

', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('353', '288', '', 'Multiple Property', '603 E. Braasch Ave', '210 N. Boxelder St.', '', 'Choose One', '', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2015-12-21', '1969-12-31', '', '', '', '', '1 Upper Sash', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Double Hung', '', '1969-12-31', '1962', '', '0000-00-00', '', 'HBC', '2015-12-21', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '(1) Upper Sash
Original: 121-530590
New: X2805; 255-356211', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('354', '289', '', 'Multiple Property', '313 Brentwood Dr.', '', 'Norfolk', 'Nebraska', '68701', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2015-12-21', '2015-08-24', '', '', '', '', '1 Frame', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Other', '', '1969-12-31', '1990', '', '0000-00-00', '', 'bf', '2015-12-23', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '(1) Frame
Original: 121-032258
New:C3279; 129-191815', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('355', '290', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68701', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2015-12-21', '1969-12-31', '', '', '', '', '1 Sash', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Double Hung', '', '1969-12-31', '1969', '', '0000-00-00', '', 'bf', '2015-12-23', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('356', '291', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68701', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2015-12-21', '2015-10-12', '', '', '', '', '1 Glass', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Glass', '', '1969-12-31', '1984', '', '0000-00-00', '', 'bf', '2015-12-23', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '*Also need to look @ Dropping window*

(1) Glass
Original: 122-276592 (SEAL FAIL)', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('359', '294', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68701', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2015-12-22', '1969-12-31', '', '', '', '', '1 Upper Sash', '', '', '', '', '0000-00-00', '', '1969-12-31', 'New: V4798     129-370159', '', 'Double Hung', '', '1969-12-31', '', '', '0000-00-00', '', 'bf', '2015-12-23', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '(1) Upper Sash
Original 123-911098
Reason: Vandalism

', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('360', '295', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2015-12-22', '2015-11-25', '', '', '', '', '1 Upper/1 Lower', '', '', '', '', '0000-00-00', '', '1969-12-31', 'New: V4920 129-370160,161', '', 'Double Hung', '', '1969-12-31', '1990', '', '0000-00-00', '', 'HBC', '2015-12-22', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '1 Upper/1 Lower:
Original: Upper 123-536307
             Lower 123-536308
Reason: Seal Fails', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('361', '22', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2015-12-22', '1969-12-31', '', '', '', '', '1 slider sash', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Other', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2015-12-22', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'Per Josh 11-24-15:
(1) Left(from outside) Slider Sash
Original: #26693543.2
Reason: Glass Broke
', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '1');
INSERT INTO customerTickets VALUES ('362', '178', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2015-12-22', '2015-11-09', '', '', '', '', '1 Glass', '', '', 'New: #26711018.1', '', '0000-00-00', '', '1969-12-31', '', '', 'Glass', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2015-12-22', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'PW Glass
Original: #26679397
Reason: Scratches between Panes', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('363', '296', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68701', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2015-12-22', '1969-12-31', '', '', '', '', 'WPU: 1 Casement Sash', '', '', '', '', '0000-00-00', '', '1969-12-31', 'New: V4796 129-370150', '', 'Casement', '', '1969-12-31', '', '', '0000-00-00', '', 'bf', '2015-12-23', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '(1) Casement Sash;
From Outside: Left
Original: 127-599060

', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('364', '297', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68701', 'Ordered', '0000-00-00', '2015-12-22', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2015-12-22', '2015-12-22', '072-10299', '', '', '', '2', '', '2', '#26723142', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '1999', '', '0000-00-00', '', 'HBC', '2015-12-22', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', '', '', '', '', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '1');
INSERT INTO customerTickets VALUES ('365', '299', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68701', 'Ordered', '0000-00-00', '2015-12-23', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2015-12-22', '2015-12-22', '072-10301', '', '', '', '4 windows', '', '4', '26723243', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '1915', '', '0000-00-00', '', 'HBC', '2015-12-23', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2012-01-15', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('366', '278', '', 'Single Property', '', '', 'Plainview', 'Choose One', '68769', 'Ordered', '0000-00-00', '2015-12-23', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2015-12-22', '2015-12-22', '072-10301', '', '', '', '8 windows', '', '8', '26723244', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2015-12-23', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'apartment 7', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2015-12-22', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('367', '298', '', 'Single Property', '', '', 'Bloomfield', 'Choose One', '', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2015-12-22', '2015-11-12', '', '', '', '', 'WPU! 1 Lower Sash', '', '', '', '', '0000-00-00', '', '1969-12-31', 'New: T5269   129-351-954', '', 'Double Hung', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2015-12-22', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '(1) Lower Sash
Original: 123-247949
Reason: Seal Fail', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('368', '300', '', 'Single Property', '', '', 'Hoskins', 'Choose One', '', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2015-12-22', '1969-12-31', '', '', '', '', 'WPU: 1 Upper Sash', '', '', '', '', '0000-00-00', '', '1969-12-31', 'New: N0563   129-298482', '', 'Double Hung', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2015-12-22', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '(1) Upper Sash
Original: 123-941630
', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('369', '301', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', '', '2015-12-22', '1969-12-31', '', '', '', '', '4 Locking Mechanisms', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Other', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2015-12-22', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '(4) locking mechanisms', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('374', '306', '', 'Single Property', '', '', 'Wakefield', 'Choose One', '', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', '', '2015-12-22', '1969-12-31', '', '', '', '', '2 sashes/Wrap: 2 doors/1 window-Jon Arens has sashes', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Double Hung', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2015-12-22', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', 'White', '', '', '2 Sashes
Also:
Wrap: 2 doors/1 window(WHITE)', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('371', '302', '', 'Single Property', '', '', 'Madison', 'Choose One', '68748', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2015-12-22', '2015-10-22', '', '', '', '', '12 Balances', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Other', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2015-12-22', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('372', '303', '', 'Single Property', '', '', 'Madison', 'Choose One', '', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2015-12-22', '1969-12-31', '', '', '', '', '1 Upper Sash', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Double Hung', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2015-12-22', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '(1) Upper Sash
Original:122-985747', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('375', '307', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '', 'Ordered', '0000-00-00', '2015-12-22', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2015-12-22', '2015-12-16', '', '', '', '', 'Balances', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Other', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2015-12-22', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'Balances for Lower Sash
Original: 125-758484', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('376', '308', '', 'Single Property', '', '', 'Plainview', 'Choose One', '68769', 'Ready to Install', '0000-00-00', '2015-12-22', '2015-12-22', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2015-12-22', '2015-12-07', '', '', '', '', '1 Upper Sash', '', '', 'New: 26719514.1', '', '0000-00-00', '', '1969-12-31', '', '', 'Double Hung', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2015-12-22', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '(1) Upper Sash
Original: #26696254.4', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('377', '309', '', 'Single Property', '', '', 'Wayne', 'Choose One', '', 'Sold', '2015-12-22', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', '', '2015-12-22', '2015-12-22', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Tough Install', '', '1969-12-31', '', '', '0000-00-00', '', 'bf', '2015-12-22', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Siding', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('378', '311', '', 'Single Property', '', '', 'Madison', 'Choose One', '68748', 'Ordered', '0000-00-00', '2015-12-23', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2015-12-22', '2015-12-22', '072-10303', '', '', '', '4', '', '4', '26723376', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '?', '', '0000-00-00', '', 'HBC', '2015-12-23', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2015-06-08', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('379', '312', '', 'Single Property', '', '', 'Battle Creek', 'Choose One', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2015-12-22', '2015-12-22', '10302', '', '', '', '14', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'kf', '2015-12-22', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2015-01-12', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('380', '72', '', 'Single Property', '', '', 'Columbus', 'Choose One', '68601', 'Ordered', '0000-00-00', '2015-12-23', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Columbus', 'Hailey', '2015-12-22', '2015-12-22', '072-10304', '', '', '', '1', '', '', '', '1', '0000-00-00', '', '1969-12-31', 'Z0054', '', 'Basic', '', '1969-12-31', '2006', '', '0000-00-00', '', 'HBC', '2015-12-23', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '2015-12-16', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('381', '158', '', 'Single Property', '', '', 'Coleridge', 'Choose One', '68727', 'Paid', '0000-00-00', '0000-00-00', '2015-12-22', '0000-00-00', '', '0000-00-00', '2015-12-23', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2015-12-22', '2015-12-09', '', '', '', '', '1 Screen', '', '', '', '', '0000-00-00', '', '1969-12-31', 'New: 26720217.1', '', 'Other', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2015-12-22', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'Per Dwayne:
(1) Screen
Original: 26707359.1', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('382', '310', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68701', 'Ready to Install', '0000-00-00', '0000-00-00', '2015-12-22', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', '', '2015-12-22', '1969-12-31', '', '', '', '', 'WPU: 1 sash', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'bf', '2015-12-23', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '(1) Left Sash
Original: #26676605.1


Note: originally ordered a screen as well, factory didnt place that order. had to reordered 12/22/2015', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('383', '310', '', 'Single Property', '', '', 'Norfolk', 'Choose One', '68701', 'Ordered', '0000-00-00', '2015-12-22', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Hailey', '2015-12-22', '2015-12-22', '', '', '', '', '1 Screen', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Other', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2015-12-22', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '(1) Screen
#26676605.1

Note: Angi ordered this back on 12/7/2015,but the factory didnt order it. Had to reorder on 12/22/2015', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Windows', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('384', '36', '', 'Multiple Property', 'Rental: 308 Kent St-MADISON', '', 'Madison', 'Choose One', '68748', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Mark ', '2015-12-22', '1969-12-31', '', '', '', '', 'Frame & Sash', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Other', '', '1969-12-31', '', '', '0000-00-00', '', 'HBC', '2015-12-22', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'Frame & Bottom Sash:
Original: 26685136.3', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('393', '314', '', 'Single Property', '207 West Norfolk Avenue', '', 'Norfolk', 'Nebraska', '68701', 'Need to Order', '2015-12-28', '2015-12-24', '2015-12-23', '2015-12-23', '', '2015-12-29', '2015-12-28', '2015-12-29', '2015-12-29', '2015-12-28', '2015-12-29', 'Norfolk', 'Angi', '2015-12-23', '2015-12-23', '1233', '42.0326883', '-97.4089798', '', '123', '', '', '', '', '0000-00-00', '', '2015-12-23', '', '', 'Entry Door', '', '2015-12-23', '1980', 'Yes', '2015-12-23', '', 'kf', '2015-12-29', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', 'Yes', '', '', '', '', 'Ticket Notes', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '2015-12-28', '', '1969-12-31', '', '1969-12-31', '', '1');
INSERT INTO customerTickets VALUES ('396', '316', '', 'Single Property', '2007 Koenigstein Ave', '', 'Norfolk', 'Nebraska', '', 'Scheduled', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Brent ', '2015-12-23', '1969-12-31', '', '42.0341803', '-97.4384754', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Attic', '', '1969-12-31', '1966', '', '0000-00-00', '', 'HBC', '2015-12-23', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Solar Zone Attic', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '');
INSERT INTO customerTickets VALUES ('399', '138', '', 'Single Property', '271 3rd Ave', '', 'Columbus', 'Nebraska', '68601', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', '', '2015-12-24', '1969-12-31', '', '41.4188627', '-97.3298099', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'bf', '2015-12-24', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', 'Mark needs to put mull on windows', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '1');
INSERT INTO customerTickets VALUES ('400', '322', '', 'Single Property', '402 N 7TH BOX 188', '', 'Plainview', 'Nebraska', '', 'Ready to Install', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'Norfolk', 'Dwayne', '2015-12-24', '1969-12-31', '', '42.3497265', '-97.7920091', '', '', '', '', '', '', '0000-00-00', '', '1969-12-31', '', '', 'Basic', '', '1969-12-31', '', '', '0000-00-00', '', 'bf', '2015-12-24', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '1969-12-31', '', '', '', '', '', '', '', '', '', '1969-12-31', '', '', 'December', '2015', '', '', '0000-00-00', '', '1969-12-31', '1969-12-31', '1969-12-31', 'Window Door Repair', '1969-12-31', '', '', '', '', '', '1969-12-31', '', '1969-12-31', '', '1969-12-31', '', '1');


#
# Table structure for table `listToDo`
#

DROP TABLE IF EXISTS `listToDo`;
CREATE TABLE `listToDo` (
  `listID` int(11) NOT NULL AUTO_INCREMENT,
  `listTitle` varchar(250) NOT NULL,
  `listDate` date NOT NULL,
  `listDetails` text NOT NULL,
  `listAssign` varchar(250) DEFAULT NULL,
  `listStatus` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`listID`)
) ENGINE=MyISAM AUTO_INCREMENT=141 DEFAULT CHARSET=latin1;

#
# Dumping data for table `listToDo`
#

INSERT INTO listToDo VALUES ('15', 'go finish connies mull strip', '2015-10-05', '', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('10', 'test', '2015-07-29', 'test', '', '');
INSERT INTO listToDo VALUES ('14', 'Wayne Estimate', '2015-10-01', 'Claudia Ancona
212 Main St. Apt: A
Wayne, NE 
402-287-5018
594-9933

Need to Contact her on Tuesday to let her know when we will be in the area.', 'Hailey', 'Complete');
INSERT INTO listToDo VALUES ('16', 'Richard Stelling', '2015-10-05', 'Go measure a window for Richard Stelling 4029920335

10-13-15: Planned on going there Wed Oct 21. HE said he will see if his boys still want us to look @ it and he will let us know if he wants us to do it.', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('17', 'Ruby Jurgensen-When?', '2015-10-01', 'Wisner: (6)
When?? General Timeframe?? 
Ordered: 7-14-15  
402-529-6576', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('18', 'Pete Hastreiter-When?', '2015-10-16', 'Norfolk: (8)
When??  Told September by jerry
Ordered: 8-7-15   
402-920-0684


HE also called on the 1st of october~', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('19', 'Justin Wetjen-When??', '2015-10-01', 'Newman Grove: (5)
When?? I think he may have gotten forgot about, so may need to try and squeeze in.
Ord: 9-1-15
920-0422', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('47', 'West Point/Wisner Estimates', '2015-10-23', 'West Point:
Lorrie Woodbury: Needs an estimate; Set up when we are in the area;402-649-0615
Wisner:
John Obermeyer: needs an estimate after 415pm; Rental: 509 7th St-wisner 
402-851-1301 or 402-5654338

Tricia Peters: est-basement windows; 913 9th St. Wisner; 518-0675', 'Hailey', 'Complete');
INSERT INTO listToDo VALUES ('20', 'Ryan Baumgard-When?', '2015-10-02', 'Norfolk: (10+1PD)
When?
Ord: 8-21-15
605-595-3293', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('21', 'Stacy Alexander-When?', '2015-10-05', 'Wayne: (6)
When? Told end of October. She would really like a call back.
Ord: 9-15-15
369-2787
', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('22', 'Brian Hohnholt-O\'Neill estimate', '2015-10-05', 'Est: Sun Porch
804 E. Douglas
O\'Neill

402-366-8470
He is available anytime really. In process of buying this house.
May want to call him and feel him out. Maybe quote him over the phone.', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('23', 'Steve McClure-Schedule Columbus estimate', '2015-10-05', '', 'Hailey', 'Complete');
INSERT INTO listToDo VALUES ('24', 'Karla Linsteadt-', '2015-10-05', 'Norfolk: (1 Bay)
told her last week of oct or first part of nov

402-371-9158', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('25', 'Joann Meyer-When??', '2015-10-22', 'Her son called for her yesterday. waitin to finish remodeling, but needs the windows. Karla told them we would get them in next week. need to call them today with a date.

Norfolk: (2)
Was told end of September-Beginning of October. Is she on the list??
Ordered: 7/21/15
402-371-7573
(leave message if no answer)

Also called on 10-5-15
Also called on 10-19-15', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('26', 'Marilyn Parmenter-When?', '2015-10-06', 'Plainview: (3)
When?? Do same time as Norma White. HC told her that you had them in your sights but i wasnt sure of when exactly.
Ord: 8/4/15
402-582-3501
', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('27', 'Gretchen O\'Reily-Siding', '2015-10-07', 'When on siding? would like a general timeframe-they have bushes they are tearing out before we come. She called last week-no call back.
605-670-*1984', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('28', 'Mitch &amp; Neighborworks', '2015-10-09', '750-3240
308 S. Boxelder-Match siding? wasnt sure if you had a chance to look at it yet.', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('29', 'Humphrey Estimate', '2015-10-09', 'Patty Sliva
701 Main
Humphrey
923-1723
Home all day. Wants an estimate when we are in the area. (5 windows) ', 'Hailey', 'Complete');
INSERT INTO listToDo VALUES ('30', 'Mona Michaels(Plainview) ', '2015-10-12', 'Replace Underside of Bay-ASK BRENT!!!!', 'Dwayne', 'Complete');
INSERT INTO listToDo VALUES ('31', 'Frank Morrison', '2015-10-13', 'Darrel Steckelberg is ready for us after today. So whenever!!:', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('32', 'Nick Humphrey        316-0013', '2015-10-14', 'Oversized Gutter Roughly 35 ft.
Price????', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('33', 'steve shoemaker ask mark', '2015-10-16', 'about under window and siding', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('34', 'kathy patras wants estimate on other windows ', '2015-10-16', 'measurements are in the folder', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('35', 'lamili and perry', '2015-10-16', 'check on lamili sash and perrys interlocks and ', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('36', 'Denny Gos-Call him back.', '2015-10-19', '308-942-3110
Said he spoke with you Friday about windows. would like you to call him back.', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('37', 'Marry Braun-When??', '2015-10-19', '649-7326
 Was told October and she would be given a weeks notice. We\'re coming up on the end of October so was just wondering a timeframe.

She called last week as well..

6 windows Ordered: 9-15-15.', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('38', 'Call Lori Uecker', '2015-10-20', '750-9485

She called for you. Please call her back.', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('39', 'Kiddie Corral-Angie Hausman', '1969-12-31', '', 'Karla ', 'Complete');
INSERT INTO listToDo VALUES ('40', 'Kiddie Corral-Angie Hausman      372-8947', '2015-10-20', 'She is mailing remaining $400.00

Wants to know when we can install now. Said the fire marshall stopped by. She asked that you call her.', 'Karla ', 'Complete');
INSERT INTO listToDo VALUES ('41', 'Kiddie Corral-Angie Hausman', '1969-12-31', '', 'Karla ', 'Complete');
INSERT INTO listToDo VALUES ('42', 'TRUDY MOSEL FIGURE OUT A WAY TO DO WINDOWS', '2015-10-21', 'check out porch and see how much to gut it and redo next spring', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('43', 'Paul Alpress wondering when on Windows 402-371-9192   ', '2015-10-21', 'In Norfolk 
6 casements and a patio door  ', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('44', 'gladis 809 s 4th out of balance 4023164634', '2015-10-21', '', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('45', 'jack sauswer called about when on this patio door - he said he hopes before snow flies', '2015-10-22', '', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('46', 'Bob Pollock                 402-640-5058', '2015-10-22', 'When?
(14 windows)
Ordered: 10-12-15
Was just wondering, his renters are moving out now..so if we could get in now, that would be ideal.', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('48', 'Shana Worm', '2015-10-23', 'Mail 2 white casement handles when they come in. AMI', 'Hailey', 'Complete');
INSERT INTO listToDo VALUES ('49', 'Greg Thiele(wife) 649-1210', '2015-10-26', '2614 Westside
Norfolk

You had called once before, she missed your message. She is available this week.
Mon-Wed-Friday: All Day
Tues-Thurs: After lunch', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('50', 'dylan bush wants to order ', '2015-10-26', 'dylan bush wants to order windows 805 irving st fullerton 3085500777 wants everything except wraps', 'Hailey', 'Complete');
INSERT INTO listToDo VALUES ('51', 'jim bahm', '2015-10-26', 'check and see 303 aspen dr 4023718775', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('52', 'sergio deanda', '2015-10-26', 'sergio deanda 2580 3rd ave columbus 402 270 2238 looking for bid called last week jeff has already been there', 'Hailey', 'Complete');
INSERT INTO listToDo VALUES ('53', 'ask mark how many windows they wrapped at mechelle grimes house', '2015-10-26', '', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('54', 'Shellee-Rugosa', '2015-10-27', 'Wanted to tell you she is back from vacation.

Also....408 Pierce St. is not wrapped on front from last year.', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('55', 'MELISSA HYDE 4530 31ST ST COLUMBUS  JEFF SAID NEEDS WARM WEATHER WANTED TO RUSH HER IN  4022768761', '2015-10-28', '', 'Hailey', 'Complete');
INSERT INTO listToDo VALUES ('56', 'FROEHNER,TOM AND  JESSICA 4029423940', '2015-10-28', 'WANTS TO KNOW WHEN', 'Hailey', 'Complete');
INSERT INTO listToDo VALUES ('57', 'SHARON ROBERT  372-3522', '2015-10-29', '123 COLFAX
WEST POINT

has had issue with her windows howling. Brent went and fixed them once before...She called again today. Said the wind was strong this week. and 2 of her windows are howling again..1 is REALLY bad.
she would like us to fix it when we are in the area again.', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('58', 'Kip Duerst', '2015-10-29', 'Need to caulk 1 window.
Sash
Screen

These things need to be done yet @ their rental in eldorado.
His wife called asking about these.', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('59', 'Patty Thiele-Clearwater', '2015-10-30', 'When???

Called last week..never heard anything.', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('60', 'Please schedule estimate for Doris Chrisp....in customers with notes .....I told her probably the week of November 9th ', '2015-10-30', '', 'Hailey', 'Complete');
INSERT INTO listToDo VALUES ('61', 'Set up Estimate for Jim Luedtke in Clarkson ', '2015-10-30', 'Got a ranch style home full of windows....wants to start with 5 in the bedroom.  Hard to schedule because he works with big construction equipment :-/ but could make noon hours work .', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('62', 'steve clearly schedule for whole house', '2015-10-30', '', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('63', 'Matt Klabnes-Rental-Estimate', '2015-11-02', '410 5th St.
Neligh
402-750-9908

Has a house he just bought. Wants a quote on every window in the house. He doesnt want to be there but wants this done asap.
Nobody lives there now.

Windows used to have an arch at the top that was once taken out and framed in with wood. He wants NO wood showing. and he wants the arch back in the windows.', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('64', 'Deb Misfeldt', '1969-12-31', 'trim work not stained-have 2 windows without curtains
when can we finish this??
371-4984', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('65', 'Scott Rutten-measure', '2015-11-02', 'Called to reschedule a measure time-his kid was sick when you were passing through last time.', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('66', 'Ron Gadeken 887-4644', '2015-11-02', 'Said he called last week.
When??
was told october
Ordered: 9/2/15
(5 windows) ', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('67', 'Russ Eggerling-Dropping window; 371-9529', '2015-11-02', '1004 Southern Drive
Norfolk

Elderly gentleman-Window out of balance. needs us to fix for him.', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('68', 'Mike Moeller-Beemer-When??', '2015-11-02', '688 K  Rd
Beemer
(19 windows) 
Ordered: 7/8/15
380-1581

Carrie called 11/04/15 ---said not pushing just wants to know if needs to put up plastic ---her work number is 402-5296878', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('69', 'Lori Forsch', '2015-11-02', 'having screen issues on her patio door.
would like you to call her to discuss them.', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('70', 'lori frasch ask dwayne about screen door', '2015-11-03', '', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('71', 'mary erb wait a week see if finance goes through call her back ', '2015-11-03', '', 'Brent ', 'Processing');
INSERT INTO listToDo VALUES ('72', 'GARY KOEPITZ WINDOW TRIM BY STANTON', '2015-11-04', '', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('73', 'BRUCE BRESTER--WANTS YOU TO CALL---402-649-5430', '2015-11-04', '', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('74', 'Set up Estimate for Greg and Carla Pippitt Laurel (in the system) 402-375-0622 or 402-256-3635 he\'s a farmer ', '2015-11-05', '', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('75', 'KRIS KNOFF ', '2015-11-05', 'WANTS TO KNOW WHERE HER ESTIMATE IS 3104 40 TH ST COLUMBUS 4022762151', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('76', 'ernest brabec ', '2015-11-06', '121 spruce st clarkson 4028923580 reflective insulation', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('77', 'Carol Michaels 750-0064', '2015-11-06', 'Has a question for you regarding her windows.!! Please call', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('78', 'Wes VanErt          739-1952', '2015-11-10', 'Did we get those other 2 windows ordered?? 1 is broke out and would like installed sooner than later.
Go ahead and order AsAP', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('79', 'dean and pat chapman', '2015-11-10', 'dean and pat chapman - 1501 south chestnut - norfolk ---repeat customer wants a couple more windows told him $350.00 basic install --call and go ---i told we would try to get there yet this week', 'Brent ', 'Processing');
INSERT INTO listToDo VALUES ('80', 'karen fundus 306 south 12th norfolk - 7507727--measure', '2015-11-10', '', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('81', 'Roger Garbers: Columbus called him back 11-11', '2015-11-10', 'Work: 563-7275     You gave him an est(#6809) on 9/28/2015. He would like you to call him about it.', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('82', 'Kent Adkins 379-1022', '2015-11-10', 'Has a window out of balance.
1111 S. 1st St-Norfolk', 'Angi', 'Processing');
INSERT INTO listToDo VALUES ('83', 'Mary Mrsny 640-4922', '2015-11-13', 'Still on for the beginning of December?? she would like a call back.

Also Called on 11/10/2015

', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('84', 'Zack Lindsley-Creston', '2015-11-11', 'You gave him a quote a few weeks ago. Said he hasnt gotten anything yet. If you could email him a copy, he\'d appreciate it. (His email is in quickbooks and in this ticket system as well)', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('85', 'Michael Kuester-When? 640-3957', '2015-11-11', 'Ordered: 1 Patio door on Oct 13. JW when? ', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('86', 'Joe &amp; Jenan Rehak-Siding quote', '2015-11-12', 'JOE REHAK
391 ROAD X
CLARKSON, NE  68629

We originally did siding. Tree fell and hit siding-broke a few pieces. Would like a quote.....need to know $ so they can determine if they need to turn into insurance or not.

276-0511
', 'Brent ', 'Processing');
INSERT INTO listToDo VALUES ('87', 'donna ingoglai ', '2015-11-12', 'need scott to do drip cap(can charge for) shutters and check large living room window also run a magnet across lawn ', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('88', 'Call Donna Ingoglia', '2015-11-13', '360-3208 She asked that you call her. ', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('89', 'kendra feddern called again wants to know when--call 640-2339', '2015-11-13', 'adddress is 806 south 5th - norfolk - 4 windows', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('90', 'Chad Huigens in Plainview was checking to see if we still were on for the end of November....I told very good chance.....he\'s not worried or needs a call I just wanted to put it on the radar ', '2015-11-13', '', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('91', 'Chad Huigens in Plainview was checking to see if we still were on for the end of November....I told very good chance.....he\'s not worried or needs a call I just wanted to put it on the radar ', '1969-12-31', '', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('105', 'when tory and kelli berryman - call today or tomorrow if possible 402-750-3609,  norfolk job on birch street - 3 windows', '2015-11-30', '', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('92', 'jeff jensen says go with casement on North matching the living room windows for color ', '2015-11-13', '', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('93', 'Curt Nielsen-----When?? 649-4549', '2015-11-17', '1811 Imperial Rd-Norfolk
Ordered: 10-21-2015(3 windows) ', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('94', 'James Lenz(hi wife)-When??     283-4024', '2015-11-17', '211 E. Canfield-Coleridge
Ordered:10-29-2015(2 windows)', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('95', 'jamie wichman order 1/4 inch smaller sashes', '1969-12-31', '', 'Angi', 'Complete');
INSERT INTO listToDo VALUES ('96', 'SHARON ROBERT  372-3522', '2015-12-16', 'West Point: has another howling window.', 'Brent ', 'Processing');
INSERT INTO listToDo VALUES ('97', 'Ryan Baumgard-When Finish Wraps???', '2015-11-18', 'Stopped in, said we were there recently to put on inside pieces..but still have 3 big windows outside that need wrapped. Been 3 weeks since we installed them. Also: the kitchen window-caulked wrap to the shutter. he took down shutters to paint. That window needs to be caulked to house.', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('98', 'Patty Sliva-Humphrey', '2015-11-20', 'NEver got her estimate. Please mail.', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('99', 'Kelly Muchmore 402-270-9951', '2015-11-23', 'Call ASAP. wants to know if she needs to start tearing off siding.', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('100', 'tom neuman price for a roll of artic fox', '2015-11-23', '', 'Brent ', 'Processing');
INSERT INTO listToDo VALUES ('101', 'Steve Jorgensen-When?? 402-286-4328', '2015-11-23', 'Has 8 windows in Winside. Was jw when? if they are out a while, thats fine. wife just wants to put up  Christmas tree and doesnt want it to be in the way.', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('102', 'Steve Jorgensen-When?? 402-286-4328', '2015-11-23', 'Has 8 windows in Winside. Was jw when? if they are out a while, thats fine. wife just wants to put up  Christmas tree and doesnt want it to be in the way. ', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('103', 'Steve Shoemaker-Gutters called and left message 11-30-15 order door and go with gutters just the run use his downs grids in the door', '2015-11-24', 'He said he had spoke with you one time about doing gutters. They just got their siding bill. was wondering if we were still planning on doing the gutters??', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('104', 'Diane Miller-750-2704', '2015-11-25', 'Has windows(we installed these windows before she moved in) that wont shut. Says she has had us out before to try and help her with her windows. Wont shut after she cleans them. Please help!

Bought from Heppner.', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('106', 'theresa perry called and was worry about her deadline of the 10th---i told i\'m sure your on it', '2015-11-30', '', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('107', 'Kelly Muchmore called and wants you to call her 402-270-9951', '2015-11-30', '', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('108', 'Mitch Neighborworks - estimate at wayne', '2015-12-01', 'Mitch called wants an estimate on Main and 2nd floor, and 4 basement windows at Wayne---the contact to get in the house is Charlie Bonanno at 712-259-0697---wants upper grids with vertical lines like they have', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('109', 'Bob Ziemba - st Paul called and said he has called several times and we are suppose to be getting a sash for him down to Columbus so he can pick it up ', '1969-12-31', 'try and call him 12/02/15 if possible   1-308-750-0532', 'Hailey', 'Complete');
INSERT INTO listToDo VALUES ('110', 'Jerry Johnson  402-368-2243', '2015-12-02', 'Has a double hung window he cant get to lock. It closes but its roughly 1/8 of an inch from locking. Told he we would stop by when in the area. Has to be around 3ish.', 'Brent ', 'Processing');
INSERT INTO listToDo VALUES ('111', 'Karla &amp; Bob Linsteadt 371-9158', '2015-12-03', 'wants to know if there is something that we can do to somewhat fix his bay or if we have to replace the whole thing. They would like to stain the inside if possible but doesnt want to if we\'re going to have to replace the whole thing. Doesnt know what the next step is. Please call him.', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('112', 'Adam &amp; Wendy Brewer      750-8161', '2015-12-04', 'Some spots, gutters leaky. Talked about them before with you. Would like you to follow up.', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('113', 'Muffin Morris-When?? 605-202-0577 called and told her next week if possible or week after xmas check kitchen window when we do window says operates weird ', '2015-12-18', 'Seeing where she is at in line? was hoping to get in before end of year if possible.

Also called: 12-7-15', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('114', 'Tammy Korth-Kevin 402-992-5775', '2015-12-07', 'Had a message that you called to install. Call him back please.', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('115', 'Jeremy Pichler', '2015-12-07', 'He returned your call. It was about 4:45 pm.', 'Karla ', 'Complete');
INSERT INTO listToDo VALUES ('116', 'Carrie Brandt(1)-When?  750-9112', '2015-12-08', 'Ordered back in November. Was just wondering where she was on the list.', 'Brent ', 'Processing');
INSERT INTO listToDo VALUES ('117', 'Deloris Jaeke(1)-when??', '2015-12-08', '371-0069', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('118', 'Tony Squire-Lindsday      276-4690', '2015-12-08', 'When?? was just curious of a time frame.
', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('119', 'Jason Brandt-Pierce 402-360-4297', '2015-12-08', 'You were supposed to measure this at 5pm on Monday Nov. 30. We eneded up having that snowstorm that day. But he never heard anything to reschedule. He was wondering when you can reschedule.', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('120', 'Tom-Carhart in Tilden 368-2202', '2015-12-09', 'He called at 10:25 this morning. would like you to call him please.', 'Karla ', 'Complete');
INSERT INTO listToDo VALUES ('121', 'Call Theresa Perry 841-3996', '2015-12-09', 'Would like you to call her to make sure everything is done.', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('122', 'Les Strong-371-0664', '2015-12-09', 'feels patio door handle is going to fall off soon
-Usually around
-Norfolk Job', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('123', 'Bill Lamm-When??', '2015-12-10', '', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('124', 'Berry company Frontier directory Jordan Stokes called 3368214208', '2015-12-10', '', 'Angi', 'Processing');
INSERT INTO listToDo VALUES ('125', 'Lonnie Forsch-Measure garage siding', '2015-12-10', 'she is selling her  house. wants the garage sided. and matched with whats on her house. we orginally sided her house.

1213 Hayes
Norfolk.', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('126', 'Cory Schmidt-When??', '2015-12-11', '649-8350
Norfolk 

Ordered 10-12-15', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('127', 'jim and pat hostrieter 82424 528th rd madison look for estimate 402 285 0275', '2015-12-11', '', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('128', 'Maria Babel-When? 447-6144', '2015-12-14', '113 N. 5th.
Newman Grove
Wondering When? ', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('129', 'Ron Kallenbach 563-0362', '2015-12-15', 'Anyday next week after 2 works for us to do that Mull.', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('130', 'Call Gary Coolidge 841-4038', '2015-12-16', '', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('131', 'Lisa @ Wesport/Lakewood Apts need to order screen clips from simonton for bennington apt', '2015-12-18', 'Call her. 402-992-1983', 'Brent ', 'Processing');
INSERT INTO listToDo VALUES ('132', 'chad fridder have scott give a price on soffit and fascia ', '2015-12-18', 'chad fridder wants you to call him at 402-369-0369', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('133', 'Deloris Kneifel-Mail Sticker', '2015-12-18', 'Mail copy of NFRC sticker to Deloris Kneifel after you get it from Heather.
', 'Hailey', 'Processing');
INSERT INTO listToDo VALUES ('134', 'Theresa Perry', '2015-12-22', 'She sent the papers to insurance guy already. However, its not all done.
There are 4 wraps(that she is paying for) then 2 more wraps above. There is also an issue with one of the patio doors we installed. Apparnetly we keep getting the wrong part?', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('135', 'Ryan Stusse:Floor', '2015-12-22', 'He fixed your floor, take a look at it and let him know what you think. He put the key back under the mat.', 'Karla ', 'Complete');
INSERT INTO listToDo VALUES ('136', 'John Beckner', '2015-12-22', 'Please call:
402-741-1477', 'Brent ', 'Complete');
INSERT INTO listToDo VALUES ('137', 'Steve @ Guarantee Pest Control', '2015-12-22', 'Call him on his personal cell: 640-1669', 'Brent ', 'Complete');


#
# Table structure for table `sinBin`
#

DROP TABLE IF EXISTS `sinBin`;
CREATE TABLE `sinBin` (
  `sinID` int(11) NOT NULL AUTO_INCREMENT,
  `sinName` varchar(250) DEFAULT NULL,
  `sinModel` varchar(250) DEFAULT NULL,
  `sinSize` varchar(250) DEFAULT NULL,
  `sinInterior` varchar(250) DEFAULT NULL,
  `sinExterior` varchar(250) DEFAULT NULL,
  `sinGrid` varchar(250) DEFAULT NULL,
  `sinSerial` varchar(250) DEFAULT NULL,
  `sinNail` varchar(250) DEFAULT NULL,
  `sinPrice` varchar(250) DEFAULT NULL,
  `sinDonated` varchar(250) DEFAULT NULL,
  `sinDate` date NOT NULL,
  PRIMARY KEY (`sinID`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

#
# Dumping data for table `sinBin`
#

INSERT INTO sinBin VALUES ('4', 'Angi Houser', '1675-Casement   Qty: 1', '27 1/4 x 45 1/4', 'White', 'White', 'No', '#26665648.1', 'No', '', '', '2015-10-13');
INSERT INTO sinBin VALUES ('2', 'Test Names', 'Model', 'Size', 'White', 'Tan', 'No', '12345', 'Yes', '125.52', 'Yes', '2015-08-20');
INSERT INTO sinBin VALUES ('5', 'Columbus Aquatic Center', '1650-DH     Qty: 2', '41 1/4 x 41 1/4', 'White', 'White', 'No', '#26687501.1', 'No', '', '', '2015-10-30');
INSERT INTO sinBin VALUES ('6', 'Jim Bahm', '1650-DH   Qty: 1', '39 1/2 x 37 1/4', 'White', 'White', 'No', '#26691504.1', 'No', '', '', '2015-11-23');
INSERT INTO sinBin VALUES ('7', 'Francisco Medina  ', '3002-DH     Qty: 1', '76 3/4 x 35 3/4', 'White', 'White', 'No', '129-272502', 'No', '', '', '2015-12-08');
INSERT INTO sinBin VALUES ('8', 'Jose Leon: Rental ', '1650-DH     Qty: 1', '31 3/4 x 37 1/4', 'White', 'White', 'No', '#26715955.3', '', '', '', '2015-12-09');
INSERT INTO sinBin VALUES ('9', 'Walter Johnson', '0751-Awning Qty:1', '31 1/2 x 37 1/2', 'White', 'White', 'No', '129-256670', 'No', '', '', '2015-12-24');
INSERT INTO sinBin VALUES ('10', 'Mike Matteo', '1675-Double Casement  Qty: 1', '47 3/8 x 34 1/2', 'Colonial Cherry', 'White', '', '#26673915.1', 'No', '', '', '2015-12-24');


#
# Table structure for table `ticketAttachments`
#

DROP TABLE IF EXISTS `ticketAttachments`;
CREATE TABLE `ticketAttachments` (
  `attachID` int(11) NOT NULL AUTO_INCREMENT,
  `ticketID` varchar(20) DEFAULT NULL,
  `leadTestPDF` varchar(250) NOT NULL,
  `testKitPDF` varchar(250) NOT NULL,
  `renoRecPDF` varchar(250) NOT NULL,
  `measSheetPDF` varchar(250) NOT NULL,
  `invoiceSheetPDF` varchar(250) NOT NULL,
  `leadDate` date NOT NULL,
  `testDate` date NOT NULL,
  `renoTestDate` date NOT NULL,
  `measDate` date NOT NULL,
  `invoicDate` date NOT NULL,
  PRIMARY KEY (`attachID`)
) ENGINE=MyISAM AUTO_INCREMENT=424 DEFAULT CHARSET=latin1;

#
# Dumping data for table `ticketAttachments`
#

INSERT INTO ticketAttachments VALUES ('1', '9', 'lead-9.pdf', 'test-kit-9.pdf', 'renovation-9.pdf', 'measure-9.pdf', 'invoice-9.pdf', '2015-07-22', '2015-07-21', '2015-07-21', '2015-07-21', '2015-07-21');
INSERT INTO ticketAttachments VALUES ('6', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('3', '14', 'lead-14.pdf', 'test-kit-14.pdf', 'renovation-14.pdf', 'measure-14.pdf', 'invoice-14.pdf', '2015-08-19', '2015-08-19', '2015-08-19', '2015-08-19', '2015-08-19');
INSERT INTO ticketAttachments VALUES ('7', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('5', '16', '', '', '', '', '', '1969-12-31', '1969-12-31', '1969-12-31', '1969-12-31', '1969-12-31');
INSERT INTO ticketAttachments VALUES ('8', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('9', '17', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('10', '18', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('11', '19', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('12', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('13', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('14', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('15', '20', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('16', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('17', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('18', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('19', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('20', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('21', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('22', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('23', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('24', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('25', '21', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('26', '22', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('27', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('28', '23', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('29', '24', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('30', '25', '', '', '', '', '', '2015-09-13', '1969-12-31', '1969-12-31', '1969-12-31', '1969-12-31');
INSERT INTO ticketAttachments VALUES ('31', '26', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('32', '27', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('33', '28', '', '', '', '', '', '1969-12-31', '1969-12-31', '1969-12-31', '1969-12-31', '1969-12-31');
INSERT INTO ticketAttachments VALUES ('34', '29', '', '', '', '', '', '1969-12-31', '1969-12-31', '1969-12-31', '1969-12-31', '1969-12-31');
INSERT INTO ticketAttachments VALUES ('35', '30', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('36', '31', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('37', '32', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('38', '33', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('39', '34', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('40', '35', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('41', '36', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('42', '37', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('43', '38', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('44', '39', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('45', '40', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('46', '41', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('47', '42', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('48', '43', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('49', '44', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('50', '45', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('51', '46', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('52', '47', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('53', '48', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('54', '49', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('55', '50', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('56', '51', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('57', '52', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('58', '53', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('59', '54', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('60', '55', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('61', '56', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('62', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('63', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('64', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('65', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('66', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('67', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('68', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('69', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('70', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('71', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('72', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('73', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('74', '57', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('75', '58', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('76', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('77', '59', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('78', '60', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('79', '61', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('80', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('81', '62', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('82', '63', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('83', '64', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('84', '65', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('85', '66', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('86', '67', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('87', '68', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('88', '69', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('89', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('90', '70', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('91', '71', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('92', '72', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('93', '73', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('94', '74', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('95', '75', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('96', '76', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('97', '77', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('98', '78', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('99', '79', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('100', '80', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('101', '81', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('102', '82', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('103', '83', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('104', '84', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('105', '85', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('106', '86', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('107', '87', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('108', '88', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('109', '89', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('110', '90', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('111', '91', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('112', '92', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('113', '93', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('114', '94', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('115', '95', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('116', '96', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('117', '97', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('118', '98', '', '', '', '', '', '1969-12-31', '1969-12-31', '1969-12-31', '1969-12-31', '1969-12-31');
INSERT INTO ticketAttachments VALUES ('119', '99', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('120', '100', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('121', '101', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('122', '102', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('123', '103', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('124', '104', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('125', '105', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('126', '106', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('127', '107', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('128', '108', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('129', '109', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('130', '110', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('131', '111', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('132', '112', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('133', '113', '', '', '', '', '', '1969-12-31', '1969-12-31', '1969-12-31', '1969-12-31', '1969-12-31');
INSERT INTO ticketAttachments VALUES ('134', '114', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('135', '115', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('136', '116', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('137', '117', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('138', '118', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('139', '119', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('140', '120', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('141', '121', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('142', '122', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('143', '123', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('144', '124', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('145', '125', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('146', '126', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('147', '127', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('148', '128', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('149', '129', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('150', '130', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('151', '131', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('152', '132', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('153', '133', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('154', '134', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('155', '135', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('156', '136', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('157', '137', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('158', '138', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('159', '139', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('160', '140', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('161', '141', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('162', '142', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('163', '143', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('164', '144', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('165', '145', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('166', '146', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('167', '147', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('168', '148', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('169', '149', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('170', '150', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('171', '151', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('172', '152', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('173', '153', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('174', '154', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('175', '155', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('176', '156', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('177', '157', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('178', '158', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('377', '357', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('180', '160', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('181', '161', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('182', '162', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('183', '163', '', '', '', '', '', '1969-12-31', '1969-12-31', '1969-12-31', '1969-12-31', '1969-12-31');
INSERT INTO ticketAttachments VALUES ('311', '291', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('185', '165', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('363', '343', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('187', '167', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('188', '168', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('189', '169', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('190', '170', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('191', '171', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('192', '172', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('193', '173', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('194', '174', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('195', '175', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('196', '176', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('197', '177', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('198', '178', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('199', '179', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('200', '180', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('201', '181', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('202', '182', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('203', '183', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('204', '184', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('205', '185', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('206', '186', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('207', '187', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('208', '188', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('209', '189', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('210', '190', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('211', '191', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('212', '192', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('213', '193', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('214', '194', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('215', '195', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('216', '196', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('217', '197', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('218', '198', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('219', '199', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('220', '200', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('418', '397', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('222', '202', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('223', '203', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('224', '204', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('225', '205', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('226', '206', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('227', '207', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('228', '208', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('229', '209', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('230', '210', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('231', '211', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('232', '212', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('233', '213', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('234', '214', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('235', '215', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('236', '216', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('237', '217', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('238', '218', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('239', '219', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('240', '220', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('241', '221', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('242', '222', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('243', '223', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('244', '224', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('245', '225', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('246', '226', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('247', '227', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('248', '228', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('249', '229', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('250', '230', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('251', '231', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('252', '232', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('253', '233', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('254', '234', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('255', '235', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('256', '236', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('257', '237', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('258', '238', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('259', '239', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('260', '240', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('261', '241', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('262', '242', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('263', '243', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('264', '244', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('265', '245', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('266', '246', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('267', '247', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('393', '373', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('269', '249', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('270', '250', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('271', '251', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('272', '252', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('273', '253', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('274', '254', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('275', '255', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('276', '256', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('277', '257', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('278', '258', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('279', '259', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('280', '260', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('281', '261', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('282', '262', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('283', '263', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('284', '264', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('285', '265', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('286', '266', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('287', '267', '', '', '', '', '', '1969-12-31', '1969-12-31', '1969-12-31', '1969-12-31', '1969-12-31');
INSERT INTO ticketAttachments VALUES ('422', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('289', '269', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('290', '270', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('291', '271', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('292', '272', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('293', '273', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('294', '274', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('295', '275', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('296', '276', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('297', '277', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('298', '278', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('299', '279', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('300', '280', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('301', '281', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('302', '282', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('303', '283', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('304', '284', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('305', '285', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('306', '286', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('307', '287', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('308', '288', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('309', '289', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('310', '290', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('312', '292', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('313', '293', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('314', '294', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('315', '295', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('316', '296', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('317', '297', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('318', '298', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('319', '299', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('320', '300', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('321', '301', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('322', '302', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('323', '303', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('324', '304', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('325', '305', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('326', '306', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('327', '307', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('328', '308', '', '', '', '', '', '1969-12-31', '1969-12-31', '1969-12-31', '1969-12-31', '1969-12-31');
INSERT INTO ticketAttachments VALUES ('329', '309', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('330', '310', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('331', '311', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('332', '312', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('333', '313', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('334', '314', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('335', '315', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('336', '316', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('337', '317', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('338', '318', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('339', '319', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('343', '323', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('341', '321', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('342', '322', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('344', '324', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('345', '325', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('346', '326', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('347', '327', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('348', '328', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('349', '329', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('350', '330', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('351', '331', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('352', '332', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('353', '333', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('355', '335', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('356', '336', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('361', '341', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('358', '338', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('360', '340', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('362', '342', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('364', '344', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('365', '345', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('378', '358', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('368', '348', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('369', '349', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('370', '350', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('371', '351', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('372', '352', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('373', '353', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('374', '354', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('375', '355', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('376', '356', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('379', '359', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('380', '360', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('381', '361', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('382', '362', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('383', '363', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('384', '364', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('385', '365', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('386', '366', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('387', '367', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('388', '368', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('389', '369', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('394', '374', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('391', '371', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('392', '372', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('395', '375', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('396', '376', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('397', '377', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('398', '378', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('399', '379', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('400', '380', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('401', '381', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('402', '382', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('403', '383', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('404', '384', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('413', '393', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('416', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('417', '396', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('423', '0', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('420', '399', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO ticketAttachments VALUES ('421', '400', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');


#
# Table structure for table `ticketInstallers`
#

DROP TABLE IF EXISTS `ticketInstallers`;
CREATE TABLE `ticketInstallers` (
  `installerID` int(11) NOT NULL AUTO_INCREMENT,
  `ticketID` varchar(250) DEFAULT NULL,
  `installerName` varchar(250) DEFAULT NULL,
  `installerType` varchar(1) DEFAULT NULL,
  `installerNum` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`installerID`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

#
# Dumping data for table `ticketInstallers`
#

INSERT INTO ticketInstallers VALUES ('1', '13', 'Angie', 'C', '35');
INSERT INTO ticketInstallers VALUES ('2', '13', 'Bryant', 'A', '52');
INSERT INTO ticketInstallers VALUES ('3', '13', 'Bryant', 'A', '2');
INSERT INTO ticketInstallers VALUES ('4', '14', 'Angi', 'B', '5');
INSERT INTO ticketInstallers VALUES ('5', '14', 'Bryant', 'C', '54');
INSERT INTO ticketInstallers VALUES ('6', '30', 'Angi', 'A', '');
INSERT INTO ticketInstallers VALUES ('7', '82', 'Angi', 'A', '');
INSERT INTO ticketInstallers VALUES ('8', '145', 'Angi', 'A', '');
INSERT INTO ticketInstallers VALUES ('9', '209', 'Mark ', 'B', '2');
INSERT INTO ticketInstallers VALUES ('10', '209', 'Mark ', 'C', '2');


#
# Table structure for table `ticketTask`
#

DROP TABLE IF EXISTS `ticketTask`;
CREATE TABLE `ticketTask` (
  `taskID` int(11) NOT NULL AUTO_INCREMENT,
  `taskticketID` varchar(250) DEFAULT NULL,
  `taskCust` varchar(250) NOT NULL,
  `taskEmp` varchar(100) DEFAULT NULL,
  `createdBy` varchar(50) DEFAULT NULL,
  `taskNotes` text NOT NULL,
  `taskDate` date NOT NULL,
  `taskStatus` varchar(100) DEFAULT NULL,
  `completeBy` date NOT NULL,
  `ticketRedFlag` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`taskID`)
) ENGINE=MyISAM AUTO_INCREMENT=42 DEFAULT CHARSET=latin1;

#
# Dumping data for table `ticketTask`
#

INSERT INTO ticketTask VALUES ('35', '', '142', 'Brent ', 'Brent ', 'J.D. called wants to order 1 window says we gave him an estimate per window when we quote patio door---i did not have time to look for it but will need to be measured and you would call him and go measure - 402-992-8728', '2015-12-28', 'Processing', '1969-12-31', '');
INSERT INTO ticketTask VALUES ('31', '', '201', 'Brent ', 'Brent ', 'Set up Estimate for Greg and Carla Pippitt Laurel (in the system) 402-375-0622 or 402-256-3635 he\'s a farmer', '2015-12-24', 'Processing', '1969-12-31', '');
INSERT INTO ticketTask VALUES ('32', '', '321', 'Brent ', 'Brent ', 'wants estimate on reflective insulation', '2015-12-24', 'Processing', '1969-12-31', '');
INSERT INTO ticketTask VALUES ('33', '', '314', 'Angi', 'Angi', 'Testing from Power Pages', '2015-12-24', 'Complete', '2015-12-25', '');
INSERT INTO ticketTask VALUES ('34', '', '323', 'Brent ', 'Karla ', 'Brent ---please call Tom Schmitz - Wayne when going that way they stopped into office and want an estimate closing on house next door to them---would be interested in single hungs or keeping it as respnable as possible---possible gutter estimate on garage also,  call him on his cell 402-375-0412', '2015-12-28', 'Processing', '1969-12-31', '');
INSERT INTO ticketTask VALUES ('5', '28', '12', 'Hailey', '', 'Take care of payment when this guy come stops to pick up siding. He should be picking up sometime today.', '2015-09-16', 'Complete', '0000-00-00', '');
INSERT INTO ticketTask VALUES ('6', '42', '27', 'Brent ', 'Hailey', 'JOB TO DO IN SPRING SOLD 9-22-15 TOLD HIM WE WOULD GET HALF DOWN WHEN WE ORDERED WINDOWS', '2016-02-15', 'Processing', '0000-00-00', '');
INSERT INTO ticketTask VALUES ('7', '48', '32', 'Brent ', 'Hailey', 'When??? 1 PD: Ordered 7-6-15
Lives In Randolph', '2015-09-23', 'Complete', '2015-11-21', 'Yes');
INSERT INTO ticketTask VALUES ('9', '56', '35', 'Brent ', '', 'Please call him. He needs an estimate on a bay. Wants to know when you are going to be in Orchard. KF told him you would call him tomorrow with a possible date.', '2015-09-24', 'Processing', '1969-12-31', '');
INSERT INTO ticketTask VALUES ('30', '', '56', 'Brent ', 'Brent ', 'send someone up to figure out price and how to do the porch', '2015-12-24', 'Processing', '1969-12-31', '');
INSERT INTO ticketTask VALUES ('12', '79', '46', 'Hailey', '', 'Need to Schedule this estimate(siding/windows) when we do this job.

Jenny Stevens
128 N. Walnut
Polk
402-710-2209', '2015-10-01', 'Complete', '1969-12-31', '');
INSERT INTO ticketTask VALUES ('13', '86', '54', 'Brent ', '', 'told we will order when new window is out', '2015-10-05', 'Processing', '2015-11-27', '');
INSERT INTO ticketTask VALUES ('14', '111', '77', 'Jeff ', '', 'Put new spring mechanism on front screen door.', '2015-10-09', 'Processing', '0000-00-00', '');
INSERT INTO ticketTask VALUES ('15', '112', '78', 'Brent ', '', 'We didnt finish job. Said we would be back in a week-never came. Have a sash and 1 screen will need rerolled.
', '2015-10-09', 'Complete', '1969-12-31', '');
INSERT INTO ticketTask VALUES ('16', '125', '91', 'Brent ', '', 'Look @ Joel Kracke Gutters', '2015-10-13', 'Complete', '1969-12-31', '');
INSERT INTO ticketTask VALUES ('17', '143', '110', 'Hailey', '', 'Josh Job: Ordered New Screen: install when it comes in.
Has 1 window that is \"off set\". Need to look at when we put screen in.
', '2015-10-20', 'Processing', '0000-00-00', '');
INSERT INTO ticketTask VALUES ('18', '132', '100', 'Hailey', '', '129-154803 Bottom sash(stress crack)
Ordered 10-20-15', '2015-10-20', 'Processing', '1969-12-31', '');
INSERT INTO ticketTask VALUES ('29', '', '161', 'Angi', 'Hailey', 'Need to order (4) sashes for Muffin Morris. I have created a ticket already.
Use Ticket #00397', '2015-12-23', 'Processing', '2015-12-25', '');
INSERT INTO ticketTask VALUES ('22', '186', '152', 'Brent ', 'Angi', 'Look at north window.', '2015-12-04', 'Processing', '2015-12-08', 'Yes');
INSERT INTO ticketTask VALUES ('24', '316', '259', 'Jeff ', 'Hailey', 'A screen for this job went to Cbus on 12/7/2015. This needs to be done asap or im sure he wont pay. The window never had a screen.', '2015-12-08', 'Processing', '2015-12-11', 'Yes');
INSERT INTO ticketTask VALUES ('25', '277', '227', 'Brent ', 'Angi', 'Steve wants to add 2 garage windows to the order.....so when we go that direction measure.....if we could get them ordered ASAp so we can do them all at once.', '2015-12-14', 'Processing', '1969-12-31', 'Yes');
INSERT INTO ticketTask VALUES ('26', '325', '267', 'Brent ', 'Hailey', 'Josh needs to finish Sticky expander.', '2015-12-14', 'Processing', '2015-12-23', 'Yes');
INSERT INTO ticketTask VALUES ('36', '', '314', 'Angi', 'Brent ', 'Test for PPGS', '2015-12-28', 'Complete', '2015-12-29', '');
INSERT INTO ticketTask VALUES ('37', '', '179', 'Brent ', 'Karla ', 'peg webster - wayne - wants to know when - 402-369-1118', '2015-12-28', 'Processing', '1969-12-31', '');
INSERT INTO ticketTask VALUES ('38', '', '179', 'Brent ', 'Karla ', 'peg webster - wayne - wants to know when - 402-369-1118', '2015-12-28', 'Processing', '1969-12-31', '');
INSERT INTO ticketTask VALUES ('39', '', '64', 'Angi', 'Karla ', 'i put a refferall letter on your desk and angela\'s folder ---she is not very happy,  i thought maybe you should call her and see if you can settle her down, so she is happy and we can do siding in spring, sounds like a lot of confustion--i would call here but here alone and trying to consentrate on year end stuff ', '2015-12-29', 'Processing', '1969-12-31', 'Yes');
INSERT INTO ticketTask VALUES ('40', '', '186', 'Angi', 'Karla ', 'jackie samway called today and said her wraps were not done and she would be gone next week but to go ahead and do it---i would have put this on mark\'s but he is not looking yet so i put it on  your\'s
i talked to mark and he said he knows about this plus he has to do another coat of drywall mud at the randles job', '2015-12-30', 'Processing', '1969-12-31', '');
INSERT INTO ticketTask VALUES ('41', '', '191', 'Jeff ', '', 'CALLED TODAY SAID IF NOT DONE BY JAN 2ND CANCELLING JOB', '2015-12-31', 'Processing', '1969-12-31', '');


#
# Table structure for table `ticketTimes`
#

DROP TABLE IF EXISTS `ticketTimes`;
CREATE TABLE `ticketTimes` (
  `timeID` int(11) NOT NULL AUTO_INCREMENT,
  `ticketID` varchar(250) DEFAULT NULL,
  `empID` varchar(100) DEFAULT NULL,
  `timeDate` date NOT NULL,
  `timeTime` varchar(250) DEFAULT NULL,
  `timeNotes` text,
  PRIMARY KEY (`timeID`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

#
# Dumping data for table `ticketTimes`
#

INSERT INTO ticketTimes VALUES ('4', '13', 'Bryant', '2015-07-29', '', 'Windows are done. Siding needs to be installed');
INSERT INTO ticketTimes VALUES ('3', '13', 'Bryant', '2015-07-24', '55', 'note');
INSERT INTO ticketTimes VALUES ('5', '14', 'Bryant', '2015-08-19', '55', 'Drove to Columbus');


#
# Table structure for table `users`
#

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

#
# Dumping data for table `users`
#

INSERT INTO users VALUES ('1', 'demouser', '8cb2237d0679ca88db6464eac60da96345513964');
INSERT INTO users VALUES ('2', 'testuser', '8cb2237d0679ca88db6464eac60da96345513964');


#
# Table structure for table `warrantyTransfer`
#

DROP TABLE IF EXISTS `warrantyTransfer`;
CREATE TABLE `warrantyTransfer` (
  `warrantyID` int(11) NOT NULL AUTO_INCREMENT,
  `ticketID` varchar(4) DEFAULT NULL,
  `custID` varchar(250) DEFAULT NULL,
  `oldcustID` varchar(250) NOT NULL,
  `warrantyDate` date NOT NULL,
  `newName` varchar(150) DEFAULT NULL,
  `newPhone` varchar(100) DEFAULT NULL,
  `newEmail` varchar(250) DEFAULT NULL,
  `newNotes` text,
  `newShow` varchar(2) DEFAULT NULL,
  PRIMARY KEY (`warrantyID`)
) ENGINE=MyISAM AUTO_INCREMENT=429 DEFAULT CHARSET=latin1;

#
# Dumping data for table `warrantyTransfer`
#

INSERT INTO warrantyTransfer VALUES ('65', '56', '37', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('64', '55', '36', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('63', '54', '19', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('62', '53', '35', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('61', '52', '25', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('60', '51', '34', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('59', '50', '34', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('58', '49', '33', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('57', '48', '32', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('56', '47', '31', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('55', '46', '30', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('54', '45', '29', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('53', '44', '27', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('52', '43', '28', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('51', '42', '27', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('50', '41', '22', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('49', '40', '23', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('48', '39', '26', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('47', '38', '', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('46', '37', '24', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('45', '36', '', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('44', '35', '21', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('43', '34', '9', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('42', '33', '19', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('41', '32', '18', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('40', '31', '17', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('39', '30', '16', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('38', '29', '13', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('37', '28', '12', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('36', '27', '10', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('35', '26', '9', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('34', '25', '7', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('33', '24', '3', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('105', '81', '48', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('104', '80', '47', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('103', '79', '46', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('102', '78', '45', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('10', '0', '8', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('9', '16', '6', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('96', '72', '4', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('97', '73', '40', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('98', '74', '41', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('99', '75', '41', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('100', '76', '43', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('101', '77', '44', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('4', '3', '2', '', '1969-12-31', 'test', '', '', '', '');
INSERT INTO warrantyTransfer VALUES ('106', '82', '49', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('107', '83', '50', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('108', '84', '50', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('109', '85', '52', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('110', '86', '54', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('111', '87', '9', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('112', '88', '28', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('113', '89', '9', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('114', '90', '49', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('115', '91', '55', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('116', '92', '58', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('117', '93', '57', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('118', '94', '59', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('119', '95', '60', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('120', '96', '61', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('121', '97', '62', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('122', '98', '63', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('123', '99', '64', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('124', '100', '65', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('125', '101', '66', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('126', '102', '67', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('127', '103', '69', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('128', '104', '70', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('129', '105', '71', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('130', '106', '72', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('131', '107', '73', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('132', '108', '74', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('133', '109', '75', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('134', '110', '76', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('135', '111', '77', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('136', '112', '78', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('137', '113', '81', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('138', '114', '82', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('139', '115', '79', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('140', '116', '83', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('141', '117', '84', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('142', '118', '85', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('143', '119', '86', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('144', '120', '87', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('145', '121', '82', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('146', '122', '88', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('147', '123', '89', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('148', '124', '90', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('149', '125', '91', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('150', '126', '92', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('151', '127', '93', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('152', '128', '95', '', '2015-10-14', 'Hass & MCKayla Hammond', '640-3796', '', '', '1');
INSERT INTO warrantyTransfer VALUES ('153', '129', '96', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('154', '130', '98', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('155', '131', '99', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('156', '132', '100', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('157', '133', '101', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('158', '134', '102', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('159', '135', '103', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('160', '136', '106', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('161', '137', '80', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('162', '138', '107', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('163', '139', '108', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('164', '140', '109', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('165', '141', '38', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('166', '142', '111', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('167', '143', '110', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('168', '144', '110', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('169', '145', '100', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('170', '146', '112', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('171', '147', '114', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('172', '148', '115', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('173', '149', '116', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('174', '150', '117', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('175', '151', '118', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('176', '152', '72', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('177', '153', '120', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('178', '154', '120', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('179', '155', '121', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('180', '156', '122', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('181', '157', '123', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('182', '158', '124', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('381', '357', '292', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('184', '160', '126', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('185', '161', '124', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('186', '162', '127', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('187', '163', '128', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('315', '291', '239', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('189', '165', '130', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('367', '343', '279', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('191', '167', '132', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('192', '168', '134', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('193', '169', '135', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('194', '170', '136', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('195', '171', '136', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('196', '172', '137', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('197', '173', '138', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('198', '174', '139', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('199', '175', '140', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('200', '176', '140', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('201', '177', '142', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('202', '178', '143', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('203', '179', '144', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('204', '180', '145', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('205', '181', '146', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('206', '182', '149', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('207', '183', '148', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('208', '184', '150', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('209', '185', '151', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('210', '186', '152', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('211', '187', '132', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('212', '188', '64', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('213', '189', '148', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('214', '190', '153', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('215', '191', '141', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('216', '192', '112', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('217', '193', '154', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('218', '194', '61', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('219', '195', '155', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('220', '196', '156', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('221', '197', '48', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('222', '198', '158', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('223', '199', '159', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('224', '200', '160', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('423', '397', '161', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('226', '202', '162', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('227', '203', '163', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('228', '204', '164', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('229', '205', '165', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('230', '206', '166', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('231', '207', '166', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('232', '208', '167', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('233', '209', '168', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('234', '210', '9', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('235', '211', '170', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('236', '212', '171', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('237', '213', '172', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('238', '214', '173', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('239', '215', '177', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('240', '216', '178', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('241', '217', '183', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('242', '218', '184', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('243', '219', '179', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('244', '220', '182', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('245', '221', '180', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('246', '222', '185', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('247', '223', '39', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('248', '224', '186', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('249', '225', '186', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('250', '226', '188', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('251', '227', '188', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('252', '228', '189', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('253', '229', '190', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('254', '230', '191', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('255', '231', '181', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('256', '232', '161', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('257', '233', '190', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('258', '234', '174', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('259', '235', '193', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('260', '236', '126', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('261', '237', '194', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('262', '238', '16', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('263', '239', '195', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('264', '240', '196', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('265', '241', '197', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('266', '242', '198', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('267', '243', '199', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('268', '244', '19', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('269', '245', '200', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('270', '246', '202', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('271', '247', '203', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('397', '373', '305', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('273', '249', '204', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('274', '250', '206', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('275', '251', '207', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('276', '252', '208', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('277', '253', '209', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('278', '254', '209', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('279', '255', '157', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('280', '256', '63', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('281', '257', '39', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('282', '258', '210', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('283', '259', '212', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('284', '260', '203', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('285', '261', '84', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('286', '262', '213', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('287', '263', '214', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('288', '264', '215', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('289', '265', '216', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('290', '266', '218', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('291', '267', '220', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('427', '0', '221', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('293', '269', '221', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('294', '270', '222', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('295', '271', '223', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('296', '272', '224', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('297', '273', '225', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('298', '274', '20', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('299', '275', '226', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('300', '276', '219', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('301', '277', '227', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('302', '278', '140', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('303', '279', '228', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('304', '280', '217', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('305', '281', '229', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('306', '282', '230', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('307', '283', '231', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('308', '284', '9', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('309', '285', '232', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('310', '286', '233', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('311', '287', '234', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('312', '288', '235', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('313', '289', '236', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('314', '290', '237', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('316', '292', '240', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('317', '293', '230', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('318', '294', '241', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('319', '295', '9', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('320', '296', '243', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('321', '297', '244', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('322', '298', '245', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('323', '299', '230', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('324', '300', '246', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('325', '301', '9', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('326', '302', '9', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('327', '303', '9', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('328', '304', '248', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('329', '305', '249', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('330', '306', '250', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('331', '307', '251', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('332', '308', '9', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('333', '309', '252', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('334', '310', '207', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('335', '311', '40', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('336', '312', '253', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('337', '313', '255', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('338', '314', '257', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('339', '315', '258', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('340', '316', '259', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('341', '317', '260', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('342', '318', '261', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('343', '319', '261', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('347', '323', '30', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('345', '321', '262', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('346', '322', '264', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('348', '324', '266', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('349', '325', '267', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('350', '326', '215', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('351', '327', '268', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('352', '328', '269', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('353', '329', '270', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('354', '330', '192', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('355', '331', '269', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('356', '332', '272', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('357', '333', '271', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('359', '335', '97', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('360', '336', '274', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('365', '341', '276', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('362', '338', '3', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('364', '340', '275', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('366', '342', '277', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('368', '344', '280', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('369', '345', '281', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('382', '358', '293', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('372', '348', '282', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('373', '349', '284', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('374', '350', '285', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('375', '351', '286', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('376', '352', '287', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('377', '353', '288', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('378', '354', '289', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('379', '355', '290', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('380', '356', '291', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('383', '359', '294', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('384', '360', '295', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('385', '361', '22', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('386', '362', '178', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('387', '363', '296', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('388', '364', '297', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('389', '365', '299', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('390', '366', '278', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('391', '367', '298', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('392', '368', '300', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('393', '369', '301', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('398', '374', '306', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('395', '371', '302', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('396', '372', '303', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('399', '375', '307', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('400', '376', '308', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('401', '377', '309', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('402', '378', '311', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('403', '379', '312', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('404', '380', '72', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('405', '381', '158', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('406', '382', '310', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('407', '383', '310', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('408', '384', '36', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('420', '393', '314', '', '2015-12-23', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('421', '0', '221', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('422', '396', '316', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('428', '0', '221', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('425', '399', '138', '', '0000-00-00', '', '', '', '', '0');
INSERT INTO warrantyTransfer VALUES ('426', '400', '322', '', '0000-00-00', '', '', '', '', '0');


